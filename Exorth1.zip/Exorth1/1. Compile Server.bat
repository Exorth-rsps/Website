@Echo Off
Title BattleScape
COLOR 04
Echo Compiling BattleScape, Please Wait...
Echo -------------------------------------
JAVAC *.java
Echo -------------------------------------
Echo Succesfull Compiled BattleScape
Pause