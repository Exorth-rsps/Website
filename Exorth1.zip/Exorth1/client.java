import java.io.*;
import java.util.StringTokenizer;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.*;
import java.text.*;
import java.util.concurrent.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
public class client extends Player implements Runnable {
public int slot1 = 0;
public int slot2 = 0;
public int slot3 = 0;
public int slot4 = 0;
public void openslotguide(){
sendFrame126("@or1@Slots game play",10107);
sendFrame126("@or1@P L A Y",10110);
showInterface(10051);
}
public boolean jackpot = false;
public int count = 0;
public void generateautomatic(int count1){
walkaway = false;
openslotguide();
count = count1;
automatic = true;
deleteItem(995, 1000);
EventManager.getSingleton().addEvent(
                	new Event() {
                    	public void execute(EventContainer C) {
count -= 1;
slot1 = 1 + misc.random(8);
slot2 = 1 + misc.random(8);
slot3 = 1 + misc.random(8);
slot4 = 1 + misc.random(8);
sendFrame126(""+slot1, 10095);
sendFrame126(""+slot2, 10096);
sendFrame126(""+slot3, 10097);
sendFrame126(""+slot4, 10098);
deleteItem(995, 1000);
server.serverchest2 += 10000;
if(slot1 == slot2 && slot2 == slot3){
if((misc.random(20) == 1 && (slot1 == 7 && slot2 == 7 && slot3 == 7)) || (slot1 == slot2 && slot2 == slot3 && slot3 == slot4)){
sendMessage("You've won the super jackpot!!!!");
jackpot = true;
yell(playerName + " Have won the super jackpot of " + server.serverchest2 +"gps.");
addItem(995,server.serverchest2);
}else{
jackpot = true;
sendMessage("You've won the triple XXX slots!");
addItem(995,server.serverchest2 / 10);
}
}else{
sendMessage("Well, better chance next time!");
}
if(walkaway || !automatic || count == 0 || jackpot){
C.stop();
}
                    }
                }, 4000);
}
public boolean automatic = false;
public void generateslot(){
if(actionTimer == 0){
actionTimer = 30;
deleteItem(995, 1000);
slot1 = 1 + misc.random(8);
slot2 = 1 + misc.random(8);
slot3 = 1 + misc.random(8);
slot4 = 1 + misc.random(8);
sendFrame126(""+slot1, 10095);
sendFrame126(""+slot2, 10096);
sendFrame126(""+slot3, 10097);
sendFrame126(""+slot4, 10098);

appendToChest(2);
server.serverchest2 += 10000;
if(slot1 == slot2 && slot2 == slot3){
if(misc.random(20) == 1 || (slot1 == slot2 && slot2 == slot3 && slot3 == slot4) || (slot1 == 7 && slot2 == 7 && slot3 == 7)){
sendMessage("You've won the super jackpot!!!!");
}else{
yell(playerName + " Have won the super jackpot of " + server.serverchest2 +"gps.");
sendMessage("You've won the triple XXX slots!");
addItem(995,server.serverchest2 / 10);
}
}else{
sendMessage("Well, better chance next time!");

}
}
}
public int chestID = 0;
public int enteredamount = 0;
public void appendToChest(int chestid) {
		BufferedWriter bw = null;
if(chestid == 1){
chestID = server.serverchest1;
}else if(chestid == 2){
chestID = server.serverchest2;
}
deleteItem(995,enteredamount * 1000);
		try {
if(chestid == 1){
			 bw = new BufferedWriter(new FileWriter("config//lotto.txt", true));
}else{
bw = new BufferedWriter(new FileWriter("config//slots.txt", true));
}
	    		bw.write("" +playerName + " Has bought " + enteredamount+" tickets -----chest is now : "+ chestID);
	    		bw.newLine();
	    		bw.flush();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} finally {
			if (bw != null) {
				try {
					bw.close();
				} catch (IOException ioe2) {
					sendMessage("Error autospawning!");
				}
			}
		}

	}//attacking
public boolean isCloseEnough;
public boolean isStunned = false;
public int faceNPC = 0;
public boolean faceNPCupdate = false;
long lastAttackClick = 0;
public boolean UseBow;
public boolean autoCast;
public int weaponDelay = 0;
public boolean usingBow() {
		for (int i = 0; i < shortbow.length; i++) {
			if ((playerEquipment[playerWeapon] == shortbow[i]) || (playerEquipment[playerWeapon] == longbow[i])) {
				return true;
			}
		}

		return false;
	}

public int getTheCurrentSpellPVP() { //created by killamess
		switch(playerMagicID) {
			case 1152://wind strike
			gatherMagicInformationPVP(1152, 0, 1, 711, 90, 91, 92, 2, 558, 1, 556, 1, -1, -1, -1, -1, 100, 0);
			break;
			case 1153://confuse
			gatherMagicInformationPVP(1153, 0, 3, 716, 102, 103, 104, 0, 555, 3, 557, 2, 559, 1,  -1, -1,100,0);
			break;
			case 1154://water strike
			gatherMagicInformationPVP(1154, 0, 5, 711, 93, 94, 95, 4, 555, 1, 556, 1, 558, 1,  -1, -1,100,0);
			break;
			case 1156://earth strike
			gatherMagicInformationPVP(1156, 0, 9, 711, 96, 97, 98, 6, 558, 1, 556, 1, 557, 2,  -1, -1,100,0);
			break;
			case 1157://weaken
			gatherMagicInformationPVP(1157, 0, 11, 729, 105, 106, 107, 0, 555, 3, 557, 2, 559, 1,  -1, -1,100,0);
			break;
			case 1158://fire strike
			gatherMagicInformationPVP(1158, 0, 13, 711, 99, 100, 101, 8, 554, 3, 556, 2, 558, 1,  -1, -1,100,0);
			break;
			case 1160://wind bolt
			gatherMagicInformationPVP(1160, 0, 17, 711, 117, 118, 119, 9, 556, 2, 562, 1, -1, -1,  -1, -1,100,0);
			break;
			case 1161://curse
			gatherMagicInformationPVP(1161, 0, 19, 729, 108, 109, 110, 0, 555, 2, 557, 3, 559, 1,  -1, -1,100,0);
			break;
			case 1572://bind
			gatherMagicInformationPVP(1172, 3000, 20, 724, 177, 178, 181, 1, 557, 3, 555, 3, 561, 2,  -1, -1,100,0);
			break;
			case 1163://water bolt
			gatherMagicInformationPVP(1163, 0, 23, 711, 120, 121, 122, 10, 555, 3, 556, 2, 562, 1,  -1, -1,100,0);
			break;
			case 1166://earth bolt
			gatherMagicInformationPVP(1166, 0, 29, 711, 123, 124, 125, 11, 557, 3, 556, 2, 562, 1,  -1, -1,100,0);
			break;
			case 1169://fire bolt
			gatherMagicInformationPVP(1169, 0, 35, 711, 126, 127, 128, 12, 554, 4, 556, 3, 562, 1,  -1, -1,100,0);
			break;
			case 1172://windblast
			gatherMagicInformationPVP(1172, 0, 41, 711, 132, 133, 134, 13, 556, 3, 560, 1, -1, -1,  -1, -1,100,0);
			break;
			case 1175://waterblast
			gatherMagicInformationPVP(1175, 0, 47, 711, 135, 136, 137, 14, 555, 3, 556, 3, 560, 1, -1, -1, 100,0);
			break;
			case 1582://snare
			gatherMagicInformationPVP(1182, 8000, 50, 724, 177, 178, 180, 3, 557, 4, 555, 4, 561, 3, -1, -1, 100,0);
			break;
			case 1177://earthblast
			gatherMagicInformationPVP(1177, 0, 53, 711, 138, 139, 140, 15, 557, 4, 556, 3, 560, 1, -1, -1, 100,0);
			break;
			case 1181://fireblast
			gatherMagicInformationPVP(1181, 0, 59, 711, 129, 130, 131, 16, 554, 5, 556, 4, 560, 1, -1, -1, 100,0);
			break;
			case 1183://windwave
			gatherMagicInformationPVP(1183, 0, 62, 718, 158, 159, 160, 17, 556, 5, 565, 1, -1, -1, -1, -1, 100,0);
			break;
			case 1185://waterwave
			gatherMagicInformationPVP(1185, 0, 65, 718, 161, 162, 163, 18, 555, 7, 556, 5, 565, 1, -1, -1, 100,0);
			break;
			case 1188://earthwave
			gatherMagicInformationPVP(1188, 0, 70, 718, 164, 165, 166, 19, 557, 7, 556, 5, 565, 1, -1, -1, 100,0);
			break;
			case 1189://firewave
			gatherMagicInformationPVP(1189, 0, 75, 718, 155, 156, 157, 20, 554, 7, 556, 5, 565, 1, -1, -1, 100,0);
			break;
			case 1592://entangle
			gatherMagicInformationPVP(1192, 10000, 79, 710, 177, 178, 179, 5, 557, 5, 555, 5, 561, 4, -1, -1, 100,0);
			break;
			case 12881: //ice burst
			gatherMagicInformationPVP(12881, 10000, 70, 1979, -1, -1, 363, 22, 560, 2, 562, 4, 555, 4, -1, -1,0,-900);
			break;
			case 12871: //ice blitz
			gatherMagicInformationPVP(12871, 15000, 82, 1978, 366, -1, 367, 26, 560, 2, 565, 2, 555, 3, -1, -1,100,1500);		
			break;
			case 12975: //smoke barrage
			gatherMagicInformationPVP(12975, 0, 86, 1979, -1, -1, 391, 27, 560, 4, 565, 2, 556, 4, 554, 4, 0, 200);		
			break;
			case 13023: //shadow barrage
			gatherMagicInformationPVP(13023, 0, 88, 1979, -1, -1, 383, 28, 560, 4, 565, 2, 556, 4, 566, 3, 0, 200);		
			break;
			case 12929: //blood barrage
			gatherMagicInformationPVP(12929, 0, 92, 1979, -1, -1, 377, 29, 566, 1, 565, 4, 560, 4, -1, -1, 0, 200);		
			break;
			case 12891: //ice barrage
			gatherMagicInformationPVP(12891, 20000, 94, 1979, -1, -1, 369, 30, 555, 6, 565, 2, 560, 4, -1, -1, 0, 200);		
			break;
		}
		return -1;
	}
public int[] specialWeapons = {5698, 1215, 1231, 5680, 4151, 861, 1305, 7158, 1434, 3204, 4153, 6739, 1377, 4587};
	
public void sendAllSpecialBars() {
		boolean visible = false;
		for (int i = 0; i < specialWeapons.length; i++) {
			if (playerEquipment[playerWeapon] == specialWeapons[i]) {
                			visible = true;
            			}
        		}
        		int[] ids = {12323, 7574, 7599, 7549, 8493, 7499};
        		for (int i = 0; i < 6; i++) {
            			outStream.createFrame(171);
            			outStream.writeByte(visible ? 0 : 1);
            			outStream.writeWord(ids[i]);
            			flushOutStream();
        		}
    	}
public void facePlayer() {
		if (AttackingOn > 0) {
			faceNPC = 32768 + AttackingOn;
		} else {
			return;
		}
	}
public int wildyLevel = 0;
public int getAttackDelay() {
		switch(playerEquipment[playerWeapon]) {
			case -1://fist or foot
				weaponDelay =  2400;
			break;
			case 1307://brone 2h
			case 1909://iron 2h
			case 1311://steel 2h
			case 1313://black 2h
			case 1315://mith 2h
			case 1317://addy 2h
			case 1319://rune 2h
			case 6609://white 2h [non bronze-dragon type]
				weaponDelay =  4200;
			break;
			case 1215://Dragon dagger (n)
			case 1231://Dragon dagger (p)
			case 5680://Dragon dagger (+)
			case 5698://Dragon dagger (s)
				weaponDelay = 2400;
			break;
			case 1419://scythe(holiday)
				weaponDelay = 2400;
			break;
			case 4151://whip
				weaponDelay = 2400;
			break;
			case 746://dark dagger [non bronze-dragon type]
			case 747://glowing dagger [glowing dark dagger] [non bronze-dragon type]
			case 1203://iron dagger
			case 1205://bronze dagger
			case 1207://steel dagger
			case 1209://mith dagger
			case 1211://addy dagger
			case 1213://rune dagger
			case 1217://black dagger
			case 1219://iron dagger (p)
			case 1221://bronze dagger (p)
			case 1223://steel dagger (p)
			case 1225://mith dagger (p)
			case 1227://addy dagger (p)
			case 1229://rune dagger (p)
			case 1233://black dagger (p)
			case 1235://poisoned_dagger(p) [non bronze-dragon type]
			case 2952://wolfbane [preist in paril]/[non bronze-dragon type]
			case 5668://iron dagger (+)
			case 5670://bronze dagger (+)
			case 5672://steel dagger (+)
			case 5674://mith dagger (+)
			case 5676://addy dagger (+)
			case 5678://rune dagger (+)
			case 5682://black dagger (+)
			case 5684://poisoned_dagger (+) [non bronze-dragon type]
			case 5686://iron dagger (s)
			case 5688://bronze dagger (s)
			case 5690://steel dagger (s)
			case 5692://mith dagger (s)
			case 5694://addy dagger (s)
			case 5696://rune dagger (s)
			case 5700://black dagger (s)
			case 5702://poisoned_dagger (s) [non bronze-dragon type]
			case 6595://white dagger (+) [non bronze-dragon type]
			case 6593://white dagger (p) [non bronze-dragon type]
			case 6597://white dagger (s) [non bronze-dragon type]
			case 6591://white dagger [non bronze-dragon type]
				weaponDelay = 2400;
			break;
			case 3190://bronze halberd
			case 3192://iron halberd
			case 3194://steel halberd
			case 3196://black halberd
			case 3197://mith halberd
			case 3200://addy halberd
			case 3202://rune halberd
			case 3204://dragon halberd
			case 6599://white halberd [non bronze-dragon type]
				weaponDelay = 4200;
			break;
			case 667://blurite sword [non bronze-dragon type]
			case 1277://bronze sword
			case 1279://iron sword
			case 1281://steel sword
			case 1283://black sword
			case 1285://mith sword
			case 1287://addy sword
			case 1289://rune sword
			case 1305://dragon longsword
			case 1291://bronze longsword
			case 1293://iron longsword
			case 1295://steel longsword
			case 1297://black longsword
			case 1299://mith longsword
			case 1301://addy longsword
			case 1303://rune longsword
			case 6607://white longsword [non bronze-dragon type]
			case 6605://white sword [non bronze-dragon type]
				weaponDelay = 3000;
			break;
			case 7158:
			case 4153://granite maul
				weaponDelay = 4200;
			break;
			case 1377://dragon battleaxe
				weaponDelay = 3600;//1833=dragon_baxe
			break;
			case 6082://fixed device [non bronze-dragon type]
				weaponDelay = 4000;//2323=fixed_device_kicking
			break;
			case 4755://veraces flail new
			case 4082://veraces flail 100%
			case 4083://veraces flail 75%
			case 4084://veraces flail 50%
			case 4085://veraces flail 25%
			case 4086://veraces flail 0%
				weaponDelay = 3000;
			break;
			case 4718://dharoks greataxe new
			case 4887://dharoks greataxe 100%
			case 4888://dharoks greataxe 75%
			case 4889://dharoks greataxe 50%
			case 4890://dharoks greataxe 25%
			case 4891://dharoks greataxe 0%
			case 15156:// dark bow.
				weaponDelay = 4200;
			break;
			case 4958://torags hammers new
			case 4959://torags hammers 100%
			case 4960://torags hammers 75%
			case 4961://torags hammers 50%
			case 4962://torags hammers 25%
			case 4963://torags hammers 0%
				weaponDelay = 3000;
			break;
			case 4934://karils X-bow new
			case 4935://karils X-bow 100%
			case 4936://karils X-bow 75%
			case 4937://karils X-bow 50%
			case 4938://karils X-bow 25%
			case 4939://karils X-bow 0%
				weaponDelay = 2400;
			break;
			case 4862://ahrims staff new
			case 4863://ahrims staff 100%
			case 4864://ahrims staff 75%
			case 4865://ahrims staff 50%
			case 4866://ahrims staff 25%
			case 4867://ahrims staff 0%
				weaponDelay = 3600;
			break;
			case 4910://guthans spear new
			case 4911://guthans spear 100%
			case 4912://guthans spear 75%
			case 4913://guthans spear 50%
			case 4914://guthans spear 25%
			case 4915://guthans spear 0%
				weaponDelay = 3000;
			break;
			case 841://shortbow
			case 843://oak shortbow
			case 849://willow shortbow
			case 853://maple shortbow
			case 857://yew shortbow
			case 861://magic shortbow
			case 845://oak longbow
			case 847://willow longbow
			case 851://maple longbow
			case 855://yew longbow
			case 859://magic longbow
			case 4734://karils crossbow
				weaponDelay = 1800;
			break;
			case 1363://iron battleaxe
			case 1365://steel battleaxe
			case 1367://black battleaxe
			case 1369://mith battleaxe
			case 1371://addy battleaxe
			case 1373://rune battleaxe
			case 1375://bronze battleaxe
			case 6598://white battleaxe [non bronze-dragon type]
				weaponDelay = 3600;
			break;
			case 1321://bronze scimitar
			case 1323://iron scimitar
			case 1325://steel scimitar
			case 1327://black scimitar
			case 1329://mith scimitar
			case 1331://addy scimitar
			case 1333://rune scimitar
			case 4587://dragon scimitar
			case 6611://white scimitar [non bronze-dragon type]
				weaponDelay = 2400;
			break;
			case 1237://bronze spear
			case 1239://iron spear
			case 1241://steel spear
			case 4850://black spear
			case 1243://mith spear
			case 1245://addy spear
			case 1247://rune spear
			case 1249://dragon spear
			case 1251://bronze spear (p)
			case 1253://iron spear (p)
			case 1255://steel spear (p)
			case 4852://black spear (p)
			case 1257://mith spear (p)
			case 1259://addy spear (p)
			case 1262://rune spear (p)
			case 1263://dragon spear (p)
			case 3170://bronze spear (kp)
			case 3171://iron spear (kp)
			case 3172://steel spear (kp)
			case 4584://black spear (kp)
			case 3173://mith spear (kp)
			case 3174://addy spear (kp)
			case 3175://rune spear (kp)
			case 3176://dragon spear (kp)
			case 5704://bronze spear (+)
			case 5706://iron spear (+)
			case 5708://steel spear (+)
			case 5734://black spear (+)
			case 5710://mith spear (+)
			case 5712://addy spear (+)
			case 5714://rune spear (+)
			case 5716://dragon spear (+)
			case 5718://bronze spear (s)
			case 5720://iron spear (s)
			case 5722://steel spear (s)
			case 5737://black spear (s)
			case 5724://mith spear (s)
			case 5726://addy spear (s)
			case 5728://rune spear (s)
			case 5730://dragon spear (s)
				weaponDelay = 3000;
			break;
			case 1337://bronze warhammer
			case 1335://iron warhammer
			case 1339://steel warhammer
			case 1341://black warhammer
			case 1343://mith warhammer
			case 1345://addy warhammer
			case 1347://rune warhammer
			case 1415://warhammer [non bronze-dragon type]
				weaponDelay = 3600;
			break;
			case 1351://bronze woodcutting axe
			case 1349://iron woodcutting axe
			case 1353://steel woodcutting axe
			case 1361://black woodcutting axe
			case 1355://mith woodcutting axe
			case 1357://addy woodcutting axe
			case 1359://rune woodcutting axe
			case 6739://dragon woodcutting axe
				weaponDelay = 3600;
			break;
			case 1265://bronze pickaxe
			case 1267://iron pickaxe
			case 1269://steel pickaxe
			case 1271://mith pickaxe
			case 1273://addy pickaxe
			case 1275://rune pickaxe
				weaponDelay = 3600;
			break;
			case 141422://bronze mace
			case 1420://iron mace
			case 1424://steel mace
			case 1426://black mace
			case 1428://mith mace
			case 1430://addy mace
			case 1432://rune mace
			case 1434://dragon mace
				weaponDelay = 3600;
			break;
			case 772://dramen staff
			case 4170://slayers staff
			case 4675://ancient staff [desert treasure]
			case 6526://Toktz-mej-tal [obsidian staff]
			case 1379://staff
			case 1381://air staff
			case 1383://water staff
			case 1385://earth staff
			case 1387://fire staff
			case 1389://magic staff
			case 1391://battle staff
			case 1394://fire battlestaff
			case 1395://water battlestaff
			case 1397://air battlestaff
			case 1399://earth battlestaff
			case 3053://lava battlestaff
			case 6562://mud battlestaff
			case 3054://mystic lava staff
			case 6563://mystic mud staff
			case 1401://mystic fire staff
			case 1403://mystic water staff
			case 1405://mystic air staff
			case 1407://mystic earth staff
			case 1409://Ibans staff
				weaponDelay = 3000;
			break;
			case 2415://saradomin godstaff
			case 2416://guthix godstaff
			case 2417://zamorak godstaff
				weaponDelay = 3000;
			break;
			case 4212: //cystal bow
			case 4214: //cystal bow
			case 4216: //cystal bow
			case 4218: //cystal bow
			case 4220: //cystal bow
			case 4222: //cystal bow
				weaponDelay = 2800;
			break;

			case 6528://obby maul
				weaponDelay = 3700;
			break;
			case 863:
			case 864:
			case 865:
			case 866: // knives
			case 867:
			case 868:
			case 869:
			
			case 806:
			case 807:
			case 808:
			case 809: // darts
			case 810:
			case 811:
					
			case 825:
			case 826:
			case 827: // javelin
			case 828:
			case 829:
			case 830:
			
			case 800:
			case 801:
			case 802:
			case 803: // axes
			case 804:
			case 805:
				weaponDelay = 1050;
			break;
	
			default:
				System.out.println("[WeaponDelays]: unhandled weapon speed. weapon ID: " + playerEquipment[playerWeapon]);
			weaponDelay = 2000;

		}
		return weaponDelay;	
	}
public void checkSpellIDs() {
		if (AttackingOn < 1) {
			return;
		}
		switch(autoCastID) {
			case 1:	
				castRune1 = 558;
				castRune1Amount = 1;
				castRune2 = 556;
				castRune2Amount = 1;				
				castRune3 = 0;
				castRune3Amount = 0;				
				castRune4 = 0;
				castRune4Amount = 0;
				autoCastLevel = 1;	
				break;
			case 2:	
				castRune1 = 555;
				castRune1Amount = 1;
				castRune2 = 556;
				castRune2Amount = 1;				
				castRune3 = 558;
				castRune3Amount = 1;				
				castRune4 = 0;
				castRune4Amount = 0;
				autoCastLevel = 5;	
				break;
			case 3:
				castRune1 = 558;
				castRune1Amount = 1;
				castRune2 = 556;
				castRune2Amount = 1;				
				castRune3 = 557;
				castRune3Amount = 2;				
				castRune4 = 0;
				castRune4Amount = 0;
				autoCastLevel = 9;	
				break;
			case 4:
				castRune1 = 554;
				castRune1Amount = 3;
				castRune2 = 556;
				castRune2Amount = 2;				
				castRune3 = 558;
				castRune3Amount = 1;				
				castRune4 = 0;
				castRune4Amount = 0;
				autoCastLevel = 13;	
				break;
			case 5:
				castRune1 = 556;
				castRune1Amount = 2;
				castRune2 = 562;
				castRune2Amount = 1;				
				castRune3 = 0;
				castRune3Amount = 0;				
				castRune4 = 0;
				castRune4Amount = 0;
				autoCastLevel = 17;	
				break;
			case 6:
				castRune1 = 556;
				castRune1Amount = 2;
				castRune2 = 562;
				castRune2Amount = 1;				
				castRune3 = 555;
				castRune3Amount = 3;				
				castRune4 = 0;
				castRune4Amount = 0;
				autoCastLevel = 23;	
				break;
			case 7:
				castRune1 = 557;
				castRune1Amount = 3;
				castRune2 = 556;
				castRune2Amount = 2;				
				castRune3 = 562;
				castRune3Amount = 1;				
				castRune4 = 0;
				castRune4Amount = 0;
				autoCastLevel = 29;	
				break;
			case 8:
				castRune1 = 554;
				castRune1Amount = 4;
				castRune2 = 556;
				castRune2Amount = 3;				
				castRune3 = 562;
				castRune3Amount = 1;				
				castRune4 = 0;
				castRune4Amount = 0;
				autoCastLevel = 35;	
				break;
			case 9:
				castRune1 = 556;
				castRune1Amount = 3;
				castRune2 = 560;
				castRune2Amount = 1;				
				castRune3 = 0;
				castRune3Amount = 0;				
				castRune4 = 0;
				castRune4Amount = 0;
				autoCastLevel = 41;	
				break;
			case 10:
				castRune1 = 555;
				castRune1Amount = 3;
				castRune2 = 556;
				castRune2Amount = 3;				
				castRune3 = 560;
				castRune3Amount = 1;				
				castRune4 = 0;
				castRune4Amount = 0;
				autoCastLevel = 47;	
				break;
			case 11:
				castRune1 = 557;
				castRune1Amount = 4;
				castRune2 = 556;
				castRune2Amount = 3;				
				castRune3 = 560;
				castRune3Amount = 1;				
				castRune4 = 0;
				castRune4Amount = 0;
				autoCastLevel = 53;	
				break;
			case 12:
				castRune1 = 554;
				castRune1Amount = 5;
				castRune2 = 556;
				castRune2Amount = 4;				
				castRune3 = 560;
				castRune3Amount = 1;				
				castRune4 = 0;
				castRune4Amount = 0;
				autoCastLevel = 59;	
				break;
			case 13:
				castRune1 = 556;
				castRune1Amount = 5;
				castRune2 = 565;
				castRune2Amount = 1;				
				castRune3 = 0;
				castRune3Amount = 0;				
				castRune4 = 0;
				castRune4Amount = 0;
				autoCastLevel = 62;	
				break;
			case 14:
				castRune1 = 556;
				castRune1Amount = 7;
				castRune2 = 565;
				castRune2Amount = 1;				
				castRune3 = 555;
				castRune3Amount = 5;				
				castRune4 = 0;
				castRune4Amount = 0;
				autoCastLevel = 65;	
				break;
			case 15:
				castRune1 = 557;
				castRune1Amount = 7;
				castRune2 = 565;
				castRune2Amount = 1;				
				castRune3 = 556;
				castRune3Amount = 5;				
				castRune4 = 0;
				castRune4Amount = 0;
				autoCastLevel = 70;	
				break;
			case 16:
				castRune1 = 554;
				castRune1Amount = 7;
				castRune2 = 565;
				castRune2Amount = 1;				
				castRune3 = 556;
				castRune3Amount = 5;				
				castRune4 = 0;
				castRune4Amount = 0;
				autoCastLevel = 75;	
				break;
		}
	}
public boolean autoCasting() {
		if (AttackingOn < 1) {
			sendMessage("no target found");
			return false;
		}
		checkSpellIDs();
		if (autoCastID < 1) {
			sendMessage("NO SPELL FOUND.");
			return false;
		}
		if (!spellSelected) {
			sendMessage("SPELL NOT SELECTED.");
			return false;
		}
		if (spellSelected()) {
			if (hasLevelReq()) {
				if (checkPlayersAreas()) {				
					autoCastThis();
				} else {	
					return false;
				}
			} else {		
				return false;
			}
		} else {
			return false;
		}
		return true;
	}

	public boolean spellSelected;
	public boolean spellSelected() {
		if (AttackingOn < 1) {
			return false;
		}
		if (!spellSelected) {
			return false;
		}

		return true;
	}

			
	public boolean hasLevelReq() {
		if (AttackingOn < 1) {
			return false;
		}
		if (autoCastLevel > playerLevel[6]) {
			return false;
		}
		return true;
	}
public void gatherMagicInformationPVP(int playerIndex,int stopMovementTime, int level,int ANI,int handGFX, int projectile, int endGFX, int damage, int rune1, int rune1AM, int rune2, int rune2AM, int rune3, int rune3AM,int rune4, int rune4AM, int magicHeight, int extraDelay) { //created by killamess
		repeatSpell = false;
		AttackingOn = followThisPlayer;
		client i_ = (client) server.playerHandler.players[followThisPlayer];
		int EnemyX = PlayerHandler.players[followThisPlayer].absX;
		int EnemyY = PlayerHandler.players[followThisPlayer].absY;
		int EnemyHP = PlayerHandler.players[followThisPlayer].currentHealth;
		
		int offsetX = (absY - EnemyY) * -1;
		int offsetY = (absX - EnemyX) * -1;
		i_.KillerId = playerId;
		followThisPlayer = followThisPlayer;
		faceNPC(32768 + followThisPlayer);
		extraDelayTime = extraDelay;
		delayMovement = stopMovementTime;
		getMagicalDamage = damage;	
		magicH = magicHeight;
		damage = misc.random(damage);
		if (i_.AttackingOn != playerId && i_.AttackingOn != 0 && !i_.multiZone()) {
			sendMessage("This player is already in combat.");
			ResetAttack();
			return;
		}
		if (!checkPlayersAreas()) {
			return;
		}
		if (withinDistance(7, i_)) {
			followPlayer = null;
			WalkTo(0,0);
		}
		if (!withinDistance(12, i_)) {
			cancelAttack();
			return;
		}
		if (!withinDistance(8, i_)) {
			followThisPlayer();
		}
		if (!autoCast) {
			if (System.currentTimeMillis() - lastAction < weaponDelay) {
				repeatSpell = true;
				return;
			}
		}
		if (autoCast) {
			if (System.currentTimeMillis() - lastAction > weaponDelay) {
				return;
			}
		}
		weaponDelay = 3500;
		mageRequest = false;
		lastAttackz = false;
		lastAction = System.currentTimeMillis();
		getMagicalEndGFX = endGFX;
		if (!i_.isInCombat) {     
			fightingWith = i_.playerId;
			i_.isInCombat = true;
			isInCombat = true;

		}
		if (level > playerLevel[6]) {
			sendMessage("You need a Magic level of "+level+" to cast this spell.");
			WalkTo(0,0);
			return;
		} else {
			if (!playerHasItem(rune1, rune1AM)) {
				if (!staffType(rune1)) {
					sendMessage("You do not have the required runes to cast this spell.");
					WalkTo(0,0);
					setClientConfig(108, 0);
					autoCast = false;
					return;	
				}
			}
			if (!playerHasItem(rune2, rune2AM)) {
				if (!staffType(rune2)) {
					sendMessage("You do not have the required runes to cast this spell.");
					WalkTo(0,0);
					setClientConfig(108, 0);
					autoCast = false;
					return;	
				}
			}
			if (!playerHasItem(rune3, rune3AM)) {
				if (!staffType(rune3)) {
					sendMessage("You do not have the required runes to cast this spell.");
					WalkTo(0,0);
					setClientConfig(108, 0);
					autoCast = false;
					return;	
				}
			}
			if (!playerHasItem(rune4, rune4AM)) {
				if (!staffType(rune4)) {
					sendMessage("You do not have the required runes to cast this spell.");
					WalkTo(0,0);
					setClientConfig(108, 0);
					autoCast = false;
					return;	
				}
			}
			if (!staffType(rune1)) {
				deleteItem(rune1, rune1AM);
			}
			if (!staffType(rune2)) {	
				deleteItem(rune2, rune2AM);
			}
			if (!staffType(rune3)) {
				deleteItem(rune3, rune3AM);	
			}
			if (!staffType(rune4)) {
				deleteItem(rune4, rune4AM);	
			}	
			startAnimation(ANI);
			arrowPullBack(handGFX);
			Projectile2(absY, absX, offsetX, offsetY, 50, calcDistanceSpeedPlayer(), projectile, 42, 25, - followThisPlayer  -1);
			WalkTo(0,0);
			EventManager.getSingleton().addEvent(
                	new Event() {
                    	public void execute(EventContainer C) {
			
					if (followThisPlayer > 0) {
						getMagicDamageStatus();
					} 
                 		C.stop();
                    }
                }, calcDistanceDamagePlayer() - 100);
			
		}
	}
public int arrowPullBack() {
		int arrows = playerEquipment[playerArrows];	
		int weapons = playerEquipment[playerWeapon];

		if (arrows != -1 || weapons == 4212)
		{
		
			if (IsAttackingNPC)
			{
				int arrowgfx = 249;
				long thisAttack = System.currentTimeMillis();
				int EnemyX = server.npcHandler.npcs[attacknpc].absX;
				int EnemyY = server.npcHandler.npcs[attacknpc].absY;
				int EnemyHP = server.npcHandler.npcs[attacknpc].HP;
				int hitDiff = 0;
				int type = server.npcHandler.npcs[attacknpc].npcType;
				int[] arrowIds = {882, 884, 886, 888, 890, 892};
				int[] arrowGfx = {10, 9, 11, 12, 13, 15};
				boolean UseBow = false;
				int offsetX = (absY - EnemyY) * -1;
				int offsetY = (absX - EnemyX) * -1;
				
				if ( thisAttack - lastAttack >= 20 ) 
				{
					if (weapons == 4734) {
						
						Projectile2(absY, absX, offsetX, offsetY, 50, calcDistanceSpeed2(), getarrowgfxnow(), 37, 40, attacknpc+1);
						DeleteArrow();
					} else if (UseBow2 && weapons != 15156) {
						Projectile2(absY, absX, offsetX, offsetY, 50, calcDistanceSpeed2() - 5, NONbowProjectiles(), 44, 33, attacknpc+1);
						playerEquipmentN[playerWeapon] = (playerEquipmentN[playerWeapon] - 1);
						updateRequired = true;
						appearanceUpdateRequired = true;
					} else if (specOn && weapons == 861 && !UseBow2) {
						rehitRange = true;
						Projectile2(absY, absX, offsetX, offsetY, 50, calcDistanceSpeed2(), 249, 48, 31, attacknpc+1);
						Projectile2(absY, absX, offsetX, offsetY, 50, calcDistanceSpeed2() + 25, 249, 42, 31, attacknpc+1);
						DeleteArrow();
						DeleteArrow();
						specialAmount -= 50;		
					} else  if (weapons != 4212 && weapons != 15156 && !UseBow2)  {
						int arrowgfx2 = getarrowgfxnow();
						if (!UseBow2){
						DeleteArrow();}
						Projectile2(absY, absX, offsetX, offsetY, 50, calcDistanceSpeed2(), getarrowgfxnow(), 42, 31, attacknpc+1);	
					} else if (weapons == 4212 && !UseBow2)  {	
						Projectile2(absY, absX, offsetX, offsetY, 50, calcDistanceSpeed2(), 249, 42,31, attacknpc+1);
					} else if (weapons == 15156) {
						UseBow2 = false;
						rehitRange = true;
						DeleteArrow();
						DeleteArrow();
						Projectile2(absY, absX, offsetX, offsetY,50, calcDistanceSpeed2() + 5, getarrowgfxnow(), 43, 31, attacknpc+1);
						Projectile2(absY, absX, offsetX, offsetY, 50, calcDistanceSpeed2() + 25, getarrowgfxnow(), 50, 31, attacknpc+1);
					}
				}
			} 
			if (!UseBow2) {
			if (specOn) {
				return 250;
			} else if (arrows == 892)  {
				return 24;
			} else if (arrows == 890) {
          				return 22;
        			} else if (arrows == 888) {
				return 21;
			}  else if (arrows == 886) {
				return 20;
			} else if (arrows == 884) {
				return 18;
			} else if (weapons == 4212) {
				return 250;
			} else if (arrows == 882) {
				return 19;
			}} else if (UseBow2) {
			int W = playerEquipment[playerWeapon];
				switch(W) {
			
			case 863:
				return 220;
			case 864:
				return 219;
			case 865:
				return 221;
			case 866: 
				return 223;
			case 867:
				return 224;
			case 868:
				return 225;
			case 869:
				return 222;
			case 806:
				return 232;
			case 807:
				return 233;
			case 808:
				return 234;
			case 809:
				return 235;
			case 810:
				return 236;
			case 811:
				return 237;
			case 825:
				return 206;
			case 826:
				return 207;
			case 827:
				return 208;
			case 828:
				return 209;
			case 829:
				return 210;
			case 830:
				return 211;
			case 800:
				return 42;
			case 801:
				return 43;
			case 802:
				return 44;
			case 803:
				return 45;
			case 804:
				return 46;
			case 805:
				return 48;					
			case 882:
				return 19;	
			case 884:
				return 18;
			case 886:
				return 20;
			case 888:
				return 21;		
			case 890:
				return 22;			
			case 892:
				return 24;			
			case 4212:
			case 4214:
			case 4215:
			case 4216:
			case 4217:
			case 4218:
			case 4219:
			case 4220:
			case 4221:
			case 4222:
			case 4223:
			return 250;
			}}
		}
		return -1;
	}
public int NONbowProjectiles() 
	{
		int W = playerEquipment[playerWeapon];
		switch(W) {
			
			case 863:
				return 213;
			case 864:
				return 212;
			case 865:
				return 214;
			case 866:
				return 216;
			case 867:
				return 217;
			case 868:
				return 218;	
			case 869:
				return 215;  
			case 806:
				return 226;
			case 807:
				return 227;
			case 808:
				return 228;
			case 809:
				return 229;
			case 810:
				return 230;
			case 811:
				return 231;	
			case 825:
				return 200;
			case 826:
				return 201;
			case 827:
				return 202;
			case 828:
				return 203;
			case 829:
				return 204;
			case 830:
				return 205;	
			case 6522:
				return 442;
			case 800:
				return 36;
			case 801:
				return 35;
			case 802:
				return 37;
			case 803:
				return 38;
			case 804:
				return 39;
			case 805:
				return 41;
			case 882:
				return 10;
			case 884:
				return 9;
			case 886:
				return 11;
			case 888:
				return 12;
			case 890:
				return 13;
			case 892:
				return 15;
			case 4212:
			case 4214:
			case 4215:
			case 4216:
			case 4217:
			case 4218:
			case 4219:
			case 4220:
			case 4221:
			case 4222:
			case 4223:
				return 249;
		}
		return -1;
	}
private void sendSpecialBarAmount(int offset, int interfaceId) {
    		outStream.createFrame(70);
        		outStream.writeWord(offset); // offset X
       	 	outStream.writeWordBigEndian(0); // offset Y
        		outStream.writeWordBigEndian(interfaceId); // interface, definatly.
    	}
public void sendSpecialBarAmount() {
		int startId = 0;
		int textId = 0;
		switch (playerEquipment[playerWeapon]) {
			case 5698: //DDS
			case 1215: //DD
			case 1231: //DDP
			case 5680: //DD+
			case 4586: //D scim
				startId = 7576;
 				textId = 7586;
				refreshBar();
                		break;
            			case 4151: //Whip
                			startId = 12325;
                			textId = 12335;
				refreshBar();
                		break;
            			case 861: //Mage Shortbow
               			startId = 7551;
                			textId = 7561;
				refreshBar();
                		break;
			case 4153: // G-Maul
            			case 1305: //Dragon longsword
            			case 7158: //Dragon 2h sword
            			case 1434: //Dragon mace
                			startId = 7601;
                			textId = 7611;
				refreshBar();
                		break;

            			case 3204: //Dragon halberd
                			startId = 8495;
                			textId = 8505;
				refreshBar();
                		break;
			case 6739: //Dragon axe
			case 1377: //Dragon battleaxe
				startId = 7501;
                			textId = 7511;
				refreshBar();
                		break;
        		}
		int amountToBeFilled = (int) (specialAmount / 10);
        		if (specialAmount < 10 || specialAmount > 100) {
            			amountToBeFilled = -1;
        		}
        		for (int i = 0; i < amountToBeFilled; i++) {
            			sendSpecialBarAmount(500, startId + i);
        		}
        		for (int i = amountToBeFilled + 1; i < 10; i++) {
            			sendSpecialBarAmount(0, startId + i);
        		}
       	 	if (specOn) {
			if (specialAmount < getWeaponsDrainAmount()) {
            				sendFrame126("@blk@S P E C I A L  A T T A C K", textId);
				sendMessage("You do not have enough special attack to use this.");
				specOn = false;
			} else if (specialAmount >= getWeaponsDrainAmount()) {
				sendFrame126("@yel@S P E C I A L  A T T A C K", textId);	
			}
        		}
		if (!specOn) {
            			sendFrame126("@blk@S P E C I A L  A T T A C K", textId);
        		}
    	}
public void refreshBar() {
		int startId = 0;
		int textId = 0;
		switch (playerEquipment[playerWeapon]) {
			case 5698: //DDS
			case 1215: //DD
			case 1231: //DDP
			case 5680: //DD+
			case 4586: //D scim
				startId = 7576;
 				textId = 7586;
                		break;
            			case 4151: //Whip
                			startId = 12325;
                			textId = 12335;
                		break;
            			case 861: //Mage Shortbow
               			startId = 7551;
                			textId = 7561;
                		break;
			case 4153: // G-Maul
            			case 1305: //Dragon longsword
            			case 7158: //Dragon 2h sword
            			case 1434: //Dragon mace
                			startId = 7601;
                			textId = 7611;
                		break;
            			case 3204: //Dragon halberd
                			startId = 8495;
                			textId = 8505;
                		break;
			case 6739: //Dragon axe
			case 1377: //Dragon battleaxe
				startId = 7501;
                			textId = 7511;
                		break;
		}
		int amountToBeFilled = (int) (specialAmount / 10);
        		if (specialAmount < 10 || specialAmount > 100) {
            			amountToBeFilled = -1;
        		}
        		for (int i = 0; i < amountToBeFilled; i++) {
            			sendSpecialBarAmount(500, startId + i);
        		}
        		for (int i = amountToBeFilled + 1; i < 10; i++) {
            			sendSpecialBarAmount(0, startId + i);
        		}
	}
public void getMagicDamageStatus() {

		if (followThisPlayer < 1 ) {
			return;
		}
		if (!checkPlayersAreas()) {
			return;
		}
		client i_ = (client) server.playerHandler.players[followThisPlayer];
		i__ = 0;
		int aBonus = 0;
		int dBonus = 0;
		int rand_att = misc.random(playerLevel[6])*3;
		int rand_def = (int) (misc.random(i_.playerLevel[8]));
		int random_u = misc.random(playerBonus[3] * 2);
		int random_def = misc.random(i_.playerBonus[8]);
		if ((random_u >= random_def) && (rand_att > rand_def)) {
			i__ = misc.random(getMagicalDamage);
			if (magicH > 0) {
				i_.arrowPullBack(getMagicalEndGFX);
				if (playerMagicID == 12929) {
 					currentHealth = (currentHealth + i__ / 2);
					sendMessage("You drain your enemys health");
					if (currentHealth > playerLevel[playerHitpoints])
					currentHealth = playerLevel[playerHitpoints];
					refreshhps();
					i_.gfx0(getMagicalEndGFX);
				}
			} else {
				i_.gfx0(getMagicalEndGFX);
			}
		} else {
			i_.arrowPullBack(629);
			return;
		}	
		if (i_.protMage) {
			i__ = (i__ / 2);
		}
		if (i__ > 0) {
			i_.startAnimation(424); 
		}
		if (!i_.isFrozen && delayMovement > 0) {
			i_.isFrozen = true;
			i_.runFreezeEvent();
			i_.freezeTiming = delayMovement;
		}
		EventManager.getSingleton().addEvent(
                new Event() {
                    public void execute(EventContainer C) {
				if (followThisPlayer > 0) {
						magicDamage(i__);
				} C.stop();
                    }
                }, freezeTiming);
	}
public void runAttack() {
		if (AttackingOn < 1) {
			cancelAttack();
			return;
		}
		client AttackingOn2 = (client) server.playerHandler.players[AttackingOn];
		facePlayer();
		if (isWalkable()) {
			if (usingBow()) {
				if (!determineArrows()) {
					weaponDelay = 0;
					return;
				}
				startAnimation(GetWepAnim());
				arrowPullBack(arrowPullBackPVP());
				runDamageRanged();
				if (darkBow()) {
					runDamageRanged2();
				}
	
			} else {
				if (startFollowing) {
					if (isFrozen) {
						return;
					}
					if (!withinDistance(3, AttackingOn2)) {		
						return;
					}
				}
				if (!startFollowing) {
					if (!withinDistance(1, AttackingOn2)) {		
						return;
					}
				}
				if (specOn) {
					checkWeaponForSpecial2();
					runDamageMelee();
					sendSpecialBarAmount();
					specOn = false;
				} else {
					startAnimation(GetWepAnim());
					arrowPullBack(arrowPullBackPVP());
					arrowPullBack(arrowPullBackPVP());
					runDamageMelee();
				}
			}
		} else {
			return;
		}	
	}
public void checkWeaponForSpecial2() 
	{
		if (playerEquipment[playerWeapon] == 5698) {
			doubleHit = true;
			xtraDamage = true;
           		getWeaponSpecialInformation2(5698,1062, 25, 252);
			runDamageMelee();
	
        	}
		if (playerEquipment[playerWeapon] == 4151)  			//whip
		{
			xtraDamage = true;
           		getWeaponSpecialInformation2(4151, GetWepAnim(), 50, 341);
	
        	}
		if (playerEquipment[playerWeapon] == 5680)  			//dragon dagger p+
		{
			doubleHit = true;
			xtraDamage = true;
           		getWeaponSpecialInformation2(5680,1062, 25, 252);
			runDamageMelee();
		
        	}
		if (playerEquipment[playerWeapon] == 7158)  			//dragon 2h
		{
			
			xtraDamage = true;
           		getWeaponSpecialInformation2(7158, 3157, 100, 559);
	
        		}
		if (playerEquipment[playerWeapon] == 1231)  			//dragon dagger p
		{
			doubleHit = true;
			xtraDamage = true;
           			getWeaponSpecialInformation2(1231,1062, 25, 252);
			runDamageMelee();
	
        		}
		if (playerEquipment[playerWeapon] == 1215)  			//dragon dagger 
		{
			doubleHit = true;
			xtraDamage = true;
           			getWeaponSpecialInformation2(1215,1062, 25, 252);
			runDamageMelee();
	
        		}
		if (playerEquipment[playerWeapon] == 3204)  			//dragon hally
		{
			doubleHit = true;
			xtraDamage = true;
			getWeaponSpecialInformation2(3204, 2081, 50, 282);
			runDamageMelee();

		}
		if (playerEquipment[playerWeapon] == 1305) 			// dragon long
		{ 
			xtraDamage = true;
			getWeaponSpecialInformation2(1305,1058, 25, 248);
	
		}
  		if (playerEquipment[playerWeapon] == 1434) 			 // dragon mace
		{
			xtraDamage = true;
			getWeaponSpecialInformation2(1434,1060, 25, 251);

           		}
			
	}
public void getWeaponSpecialInformation2(int weapon, int animation99, int drain, int doGFX) 
	{
		weapon = playerEquipment[playerWeapon];
		if (drain <= specialAmount) {	
			if (weapon == 4151) {
				startAnimation(animation99);
				PlayerHandler.players[AttackingOn].arrowPullBack(341);
				specialAmount  = (specialAmount - drain);
			} else {
				startAnimation(animation99);
				arrowPullBack(doGFX);
				specialAmount = (specialAmount - drain);
			}
		} else {
			ResetAttack();
			specOn = false;
		}
		
	}
public boolean doubleHit = false;
	public boolean xtraDamage = false;
public boolean darkBow() {
		int i = playerEquipment[playerWeapon];
		if (i == 15156) {
			return true;
		}
		return false;
	}
public int damageDelay = 0;
	public int damageDelay2 = 0;
	public boolean throwable = false;
	public int extraDamage = 0;
	public boolean determineArrows() {
		int i = playerEquipment[playerWeapon];
		int k = playerEquipment[playerArrows];

		if (crystalBow()) {
			if (crystalBowHealth == 0) {
				degradeCrystalBow();
				crystalBowHealth = 100;
			}
			if (k > 0) {
				if (freeSlots() > 0) {
					remove(playerArrows, playerArrows);
					crystalBowHealth = (crystalBowHealth - 1);
					return true;
				} else {
					sendMessage("You cannot use arrows with this bow.");
					cancelAttack();
					return false;
				}
			} else {
				crystalBowHealth = (crystalBowHealth - 1);
				return true;
			}
		} else if (karilsBow()) {
			if (k > 0) {
				if (k != 4740) {
					sendMessage("You cannot use these arrows with this bow.");
					cancelAttack();
					return false;
				} else {	
					return true;
				}	
			} else {
				sendMessage("You have no bolts left.");
				cancelAttack();
				return false;
			}
		} else {
			if (k > 0) {
				return true;
			} else {
				sendMessage("You have no arrows left.");
				cancelAttack();
				return false;
			}
		}	
	}
	public void degradeCrystalBow() {
		int i = playerEquipment[playerWeapon];
		if (i == 4212 || i == 4214 || i == 4216 || i == 4218 || i == 4220 || i == 4222) {
			switch(i) {
				case 4212:
					playerEquipment[playerWeapon] = 4214;
					sendMessage("Your crystal bow has slighty degraded.");
					SendWeapon((playerEquipment[playerWeapon]), GetItemName(playerEquipment[playerWeapon]));
					updateRequired = true;
					appearanceUpdateRequired = true;
				break;
				case 4214:
					playerEquipment[playerWeapon] = 4216;
					sendMessage("Your crystal bow has slighty degraded.");
					SendWeapon((playerEquipment[playerWeapon]), GetItemName(playerEquipment[playerWeapon]));
					updateRequired = true;
					appearanceUpdateRequired = true;
				break;
				case 4216:
					playerEquipment[playerWeapon] = 4218;
					sendMessage("Your crystal bow has slighty degraded.");
					SendWeapon((playerEquipment[playerWeapon]), GetItemName(playerEquipment[playerWeapon]));
					updateRequired = true;
					appearanceUpdateRequired = true;
				break;
				case 4218:
					playerEquipment[playerWeapon] = 4220;
					sendMessage("Your crystal bow has slighty degraded.");
					SendWeapon((playerEquipment[playerWeapon]), GetItemName(playerEquipment[playerWeapon]));
					updateRequired = true;
					appearanceUpdateRequired = true;
				break;
				case 4220:
					playerEquipment[playerWeapon] = 4222;
					sendMessage("Your crystal bow has slighty degraded.");
					SendWeapon((playerEquipment[playerWeapon]), GetItemName(playerEquipment[playerWeapon]));
					updateRequired = true;
					appearanceUpdateRequired = true;
				break;
				case 4222:
					playerEquipment[playerWeapon] = -1;
					sendMessage("Your crystal bow has worn out.");
					SendWeapon((playerEquipment[playerWeapon]), GetItemName(playerEquipment[playerWeapon]));
					updateRequired = true;
					appearanceUpdateRequired = true;
				break;
			}

		} else {
			return;
		}
	}
public boolean playerRangedDamage() {
		if (AttackingOn > 0) {
			client AttackingOn2 = (client) server.playerHandler.players[AttackingOn];
			
			int aBonus = 0;
			int dBonus = 0;
			int rand_def = (int) (misc.random(AttackingOn2.playerLevel[9]) + AttackingOn2.getPrayerDef());
			int rand_att = misc.random(playerLevel[4]);
			int random_u = misc.random(playerBonus[4]);
			int random_def = misc.random(AttackingOn2.playerBonus[9]);
			if ((random_u >= random_def) && (rand_att > rand_def)) {
				rangeHit = misc.random(maxRangeHit());	
				if (PlayerHandler.players[AttackingOn].protRange) {
					rangeHit = rangeHit /2;
				}
			} else {
				rangeHit = 0;
			}
			int EnemyX = PlayerHandler.players[AttackingOn].absX;
			int EnemyY = PlayerHandler.players[AttackingOn].absY;
			int EnemyHP = PlayerHandler.players[AttackingOn].currentHealth;	
			if (rangeHit > EnemyHP) 
			{
				rangeHit = EnemyHP;
			} 
			if (EnemyHP < 1 )
			{
				rangeHit = 0;
			}
			if (rangeHit >= 23 && playerWeapon != 15156) {
				rangeHit = 23;
			}
			if (!PlayerHandler.players[AttackingOn].hitUpdateRequired == true) {
				PlayerHandler.players[AttackingOn].startAnimation(424);
				PlayerHandler.players[AttackingOn].hitUpdateRequired = true;
				PlayerHandler.players[AttackingOn].updateRequired = true;
				PlayerHandler.players[AttackingOn].appearanceUpdateRequired = true;
				PlayerHandler.players[AttackingOn].dealDamage(rangeHit);
				PlayerHandler.players[AttackingOn].hitDiff = rangeHit;
				PlayerHandler.players[AttackingOn].killers[localId] += rangeHit;
				PlayerHandler.players[AttackingOn].hits++;
				PlayerHandler.players[AttackingOn].fighting = true;
				PlayerHandler.players[AttackingOn].fightId = localId;
			} else if (!PlayerHandler.players[AttackingOn].hitUpdateRequired2 == true) {
				PlayerHandler.players[AttackingOn].startAnimation(424);
				PlayerHandler.players[AttackingOn].hitUpdateRequired2 = true;
				PlayerHandler.players[AttackingOn].updateRequired = true;
				PlayerHandler.players[AttackingOn].appearanceUpdateRequired = true;
				PlayerHandler.players[AttackingOn].dealDamage(rangeHit);
				PlayerHandler.players[AttackingOn].hitDiff2 = rangeHit;
				PlayerHandler.players[AttackingOn].killers[localId] += rangeHit;
				PlayerHandler.players[AttackingOn].hits++;
				PlayerHandler.players[AttackingOn].fighting = true;
				PlayerHandler.players[AttackingOn].fightId = localId;
			} else {
				PlayerHandler.players[AttackingOn].startAnimation(424);
				PlayerHandler.players[AttackingOn].hitUpdateRequired = true;
				PlayerHandler.players[AttackingOn].updateRequired = true;
				PlayerHandler.players[AttackingOn].appearanceUpdateRequired = true;
				PlayerHandler.players[AttackingOn].dealDamage(rangeHit);
				PlayerHandler.players[AttackingOn].hitDiff = rangeHit;
				PlayerHandler.players[AttackingOn].killers[localId] += rangeHit;
				PlayerHandler.players[AttackingOn].hits++;
				PlayerHandler.players[AttackingOn].fighting = true;
				PlayerHandler.players[AttackingOn].fightId = localId;
			}
			if (misc.random(2) == 1) {
				DropArrowsPLAYER();
			}
			int exp = rangeHit * 4;
			int hpExp = rangeHit * 1;
			addSkillXPmelee(exp * SERVER_EXPERIENCE, 4);
			addSkillXPmelee(hpExp * SERVER_EXPERIENCE, playerHitpoints);	
			return true;
		} else {
			followPlayer = null;
			return false;
		}
	}
public int maulCount = 1;
public void DropArrowsPLAYER() 
	{
		int EnemyX = PlayerHandler.players[AttackingOn].absX;
		int EnemyY = PlayerHandler.players[AttackingOn].absY;

		if (playerEquipment[playerWeapon] != 4214 && playerEquipmentN[playerArrows] != 0) 
		{
			if (ItemHandler.itemAmount(playerEquipment[playerArrows], EnemyX, EnemyY) == 0) 
			{
                			ItemHandler.addItem(playerEquipment[playerArrows], EnemyX, EnemyY, 1, playerId, false);
            			}
			else 
			if (ItemHandler.itemAmount(playerEquipment[playerArrows], EnemyX, EnemyY) != 0) 
			{
				int amount = ItemHandler.itemAmount(playerEquipment[playerArrows], EnemyX, EnemyY);
				ItemHandler.removeItem(playerEquipment[playerArrows], EnemyX, EnemyY, amount);
				ItemHandler.addItem(playerEquipment[playerArrows], EnemyX, EnemyY, amount + 1, playerId, false);
            			}
        		}
    	}
public boolean playerMeleeDamage() {
		if (followThisPlayer > 0) {
			maulCount = 1;
			client AttackingOn2 = (client) server.playerHandler.players[followThisPlayer];
			
			AttackingOn2.lastDamageTaken = System.currentTimeMillis();
			thisX = AttackingOn2.absX;
			thisY = AttackingOn2.absY;
			int EnemyX = PlayerHandler.players[followThisPlayer].absX;
			int EnemyY = PlayerHandler.players[followThisPlayer].absY;
			int EnemyHP = PlayerHandler.players[followThisPlayer].currentHealth;
			int aBonus = 0;
			int dBonus = 0;
			int xtra = 0;
			int rand_att = misc.random(playerLevel[0]) + getPrayerAtt();
			int rand_def = (int) (misc.random(AttackingOn2.playerLevel[1]) + AttackingOn2.getPrayerDef());
			if (FightType == 2) {
				xtra = 1;
			}
			if (FullDharokEquipped() && misc.random(4) ==1) {
				getDharokBonus();
			}
			if (rand_att > rand_def) {
				meleeHit = misc.random(playerMaxHit + getPrayerStr() + xtra);
				if (PlayerHandler.players[followThisPlayer].protMelee) {
					meleeHit = (meleeHit / 2);
				}
			} else {
				meleeHit = 0;
			}
			if (meleeHit > EnemyHP) {
				meleeHit = EnemyHP;
			} 
			if (EnemyHP < 1 ) {
				meleeHit = 0;
			} 
			if (meleeHit >= 43 && !FullDharokEquipped()) {
				meleeHit = 43;
			}
			if (!PlayerHandler.players[followThisPlayer].hitUpdateRequired == true) {
				PlayerHandler.players[followThisPlayer].startAnimation(424);
				PlayerHandler.players[followThisPlayer].hitUpdateRequired = true;
				PlayerHandler.players[followThisPlayer].updateRequired = true;
				PlayerHandler.players[followThisPlayer].appearanceUpdateRequired = true;
				PlayerHandler.players[followThisPlayer].dealDamage(meleeHit);
				PlayerHandler.players[followThisPlayer].hitDiff = meleeHit;
				PlayerHandler.players[followThisPlayer].killers[localId] += meleeHit;
				PlayerHandler.players[followThisPlayer].hits++;
				PlayerHandler.players[followThisPlayer].fighting = true;
				PlayerHandler.players[followThisPlayer].fightId = localId;
			} else if (!PlayerHandler.players[followThisPlayer].hitUpdateRequired2 == true) {
				PlayerHandler.players[followThisPlayer].startAnimation(424);
				PlayerHandler.players[followThisPlayer].hitUpdateRequired2 = true;
				PlayerHandler.players[followThisPlayer].updateRequired = true;
				PlayerHandler.players[followThisPlayer].appearanceUpdateRequired = true;
				PlayerHandler.players[followThisPlayer].dealDamage(meleeHit);
				PlayerHandler.players[followThisPlayer].hitDiff2 = meleeHit;
				PlayerHandler.players[followThisPlayer].killers[localId] += meleeHit;
				PlayerHandler.players[followThisPlayer].hits++;
				PlayerHandler.players[followThisPlayer].fighting = true;
				PlayerHandler.players[followThisPlayer].fightId = localId;
			} else {
				PlayerHandler.players[followThisPlayer].startAnimation(424);
				PlayerHandler.players[followThisPlayer].hitUpdateRequired = true;
				PlayerHandler.players[followThisPlayer].updateRequired = true;
				PlayerHandler.players[followThisPlayer].appearanceUpdateRequired = true;
				PlayerHandler.players[followThisPlayer].dealDamage(meleeHit);
				PlayerHandler.players[followThisPlayer].hitDiff = meleeHit;
				PlayerHandler.players[followThisPlayer].killers[localId] += meleeHit;
				PlayerHandler.players[followThisPlayer].hits++;
				PlayerHandler.players[followThisPlayer].fighting = true;
				PlayerHandler.players[followThisPlayer].fightId = localId;
			}
			int exp = meleeHit * 4;
			int hpExp = meleeHit * 1;
			addSkillXPmelee(exp * SERVER_EXPERIENCE, SkillID);
			addSkillXPmelee(hpExp * SERVER_EXPERIENCE, playerHitpoints);
			extraDamage = 0;
			xtra = 0;
			return true;
		} else {
			followPlayer = null;
			return false;
		}
		}
public int getPrayerStr() {
		int outcome = 0;
		int StrBonus = playerBonus[10]; // Strength Bonus
		int Strength = playerLevel[playerStrength]; // Strength
		if (strLow) {
			outcome += (double) (0.5 + (double) ((double) (StrBonus * Strength) * 0.00030));
		} else if (strMid) {
			outcome += (double) (0.5 + (double) ((double) (StrBonus * Strength) * 0.00040));
		} else if (strHigh) {
			outcome += (double) (0.5 + (double) ((double) (StrBonus * Strength) * 0.00050));
		}
		return outcome;
	}
	public int getPrayerDef() {
		int outcome = 0;
		int DefBonus = playerBonus[6]; // Strength Bonus
		int defence = playerLevel[1]; // Strength
		if (defLow) {
			outcome += (double) (0.5 + (double) ((double) (DefBonus * defence) * 0.00030));
		} else if (defMid) {
			outcome += (double) (0.5 + (double) ((double) (DefBonus * defence) * 0.00040));
		} else if (defHigh) {
			outcome += (double) (0.5 + (double) ((double) (DefBonus * defence) * 0.00050));
		}
		return outcome;
	}
	public int getPrayerAtt() {
		int outcome = 0;
		int AttBonus = playerBonus[0]; // Strength Bonus
		int Attack = playerLevel[0]; // attack 
		if (atkLow) {
			outcome += (double) (0.5 + (double) ((double) (AttBonus * Attack) * 0.00030));
		} else if (atkMid) {
			outcome += (double) (0.5 + (double) ((double) (AttBonus * Attack) * 0.00040));
		} else if (atkHigh) {
			outcome += (double) (0.5 + (double) ((double) (AttBonus * Attack) * 0.00050));
		}
		return outcome;
	}
public int getDharokBonus() {
		if (FullDharokEquipped()) {
			int StrBonus = playerBonus[10]; // Strength Bonus
			int Strength = playerLevel[playerStrength]; // Strength
			if (currentHealth >= 80 && currentHealth <= 89) { 
				extraDamage += (double) (0.5 + (double) ((double) (StrBonus * Strength) * 0.00005));
			} else if (currentHealth >= 70 && currentHealth <= 79) { 
				extraDamage += (double) (0.5 + (double) ((double) (StrBonus * Strength) * 0.00015));
			} else if (currentHealth >= 60 && currentHealth <= 69) { 
				extraDamage += (double) (0.5 + (double) ((double) (StrBonus * Strength) * 0.00025));
			} else if (currentHealth >= 50 && currentHealth <= 59) { 
				extraDamage += (double) (0.5 + (double) ((double) (StrBonus * Strength) * 0.00035));
			} else if (currentHealth >= 40 && currentHealth <= 49) { 
				extraDamage += (double) (0.5 + (double) ((double) (StrBonus * Strength) * 0.00045));
			} else if (currentHealth >= 30 && currentHealth <= 39) { 
				extraDamage += (double) (0.5 + (double) ((double) (StrBonus * Strength) * 0.00055));
			} else if (currentHealth >= 20 && currentHealth <= 29) { 
				extraDamage += (double) (0.5 + (double) ((double) (StrBonus * Strength) * 0.00065));
			} else if (currentHealth >= 10 && currentHealth <= 19) { 
				extraDamage += (double) (0.5 + (double) ((double) (StrBonus * Strength) * 0.00075));
			} else if (currentHealth >= 1 && currentHealth <= 9) { 
				extraDamage += (double) (0.5 + (double) ((double) (StrBonus * Strength) * 0.00085));
			}
		} else { 
			return -1;
		}
		return extraDamage;		
	}
public int rangeHit;
	public int meleeHit;
	public boolean stopAttack = false;
public int crystalBowHealth = 1;
public boolean karilsBow() {
		int i = playerEquipment[playerWeapon];
		if (i == 4734) {
			return true;
		}
		return false;
	}
public boolean crystalBow() {
		int i = playerEquipment[playerWeapon];
		if (i == 4212 || i == 4214 || i == 4216 || i == 4218 || i == 4220 || i == 4222) {
			return true;
		}
		return false;
	}
public void runDamageRanged() {
		EventManager.getSingleton().addEvent(
                new Event() {
                    public void execute(EventContainer C) {
				playerRangedDamage();
				
			C.stop();
                    }
                }, calcDistanceDamagePlayerRange() + 100);
	}
	public void runDamageRanged2() {
		EventManager.getSingleton().addEvent(
                new Event() {
                    public void execute(EventContainer C) {
				playerRangedDamage();
				
			C.stop();
                    }
                }, calcDistanceDamagePlayerRange() + 500);
	}	
	public void runDamageMelee() {
		EventManager.getSingleton().addEvent(
                new Event() {
                    public void execute(EventContainer C) {
				playerMeleeDamage();
				
			C.stop();
                    }
                }, 0);
	}
public void startProjectile() {
		client AttackingOn2 = (client) server.playerHandler.players[AttackingOn];
		int EnemyX = PlayerHandler.players[AttackingOn].absX;
		int EnemyY = PlayerHandler.players[AttackingOn].absY;
		int offsetX = (absX - EnemyX) * -1;
		int offsetY = (absY - EnemyY) * -1;
		if (crystalBow()) {
			Projectile2(absY, absX, offsetX, offsetY, 50, calcDistanceSpeedPlayerRange() + 5, getarrowgfxnow(), 45, 31, - followThisPlayer -1);
		} else if (darkBow()) {
			DeleteArrow();
			DeleteArrow();
			Projectile2(absY, absX, offsetX, offsetY, 50, calcDistanceSpeedPlayerRange() + 25, getarrowgfxnow(), 48, 35, -followThisPlayer-1);
			Projectile2(absY, absX, offsetX, offsetY, 50, calcDistanceSpeedPlayerRange(), getarrowgfxnow(), 45, 31, -followThisPlayer-1);
		} else {
			DeleteArrow();		
			Projectile2(absY, absX, offsetX, offsetY, 50, calcDistanceSpeedPlayerRange() - 3, getarrowgfxnow(), 45, 31, -followThisPlayer-1);
		}
	}
public int arrowPullBackPVP() {
		if (!usingBow()) {
			return -1;
		}
		if (AttackingOn < 1) {
			return -1;
		}
		startProjectile();
		int A = playerEquipment[playerArrows];	
		if (A == 892) {
			return 24;
		}
		if (A == 890) {
          		return 22;
        	} 
		if (A == 888) {
			return 21;
		} 
		if (A == 886) {
			return 20;
		} 
		if (A == 884) {
			return 18;
		} 
		if (crystalBow()) {
			return 250;
		} 
		if (A == 882) {
			return 19;
		} 
		return -1;
	}
public int SERVER_EXPERIENCE = Config.combatXP;
public int magicDamage(int i) {
		if (followThisPlayer < 1 ) {
			return -1;
		}
		if (!checkPlayersAreas()) {
			return -1;
		}

		client i_ = (client) server.playerHandler.players[followThisPlayer];
		
		if (!i_.hitUpdateRequired == true) {
			i_.dealDamage(i);
			i_.hitDiff = i;
			i_.hitUpdateRequired = true;
		} else if (!i_.hitUpdateRequired2 == true) {
			i_.dealDamage(i);
			i_.hitDiff2 = i;
			i_.hitUpdateRequired2 = true;	
		} else {
			i_.dealDamage(i);
			i_.hitDiff = i;
			i_.hitUpdateRequired = true;
		}
		i_.killers[localId] += i;
		i_.hits++;
		i_.fighting = true;
		i_.fightId = localId;
		i_.updateRequired = true;
		i_.appearanceUpdateRequired = true;
		addSkillXP(i * 4 * SERVER_EXPERIENCE, 6);
		addSkillXPmelee(i * SERVER_EXPERIENCE, playerHitpoints);
		i = -1;
		return -1;
	}
public void refreshMeleeLevelUp() {
		
		sendQuest("" + playerLevel[0] + "", 4004);
		sendQuest("" + playerLevel[2] + "", 4006);
		sendQuest("" + playerLevel[1] + "", 4008);
		sendQuest("" + playerLevel[4] + "", 4010);
		sendQuest("" + playerLevel[6] + "", 4014);
		sendQuest("" + currentHealth + "", 4016);
		sendQuest("" + getLevelForXP(playerXP[0]) + "", 4005);
		sendQuest("" + getLevelForXP(playerXP[2]) + "", 4007);
		sendQuest("" + getLevelForXP(playerXP[1]) + "", 4009);
		sendQuest("" + getLevelForXP(playerXP[4]) + "", 4011);
		sendQuest("" + getLevelForXP(playerXP[3]) + "", 4017);
	}
	public void refreshMeleeSkills() {
		sendQuest("" + playerXP[0] + "", 4044);
		sendQuest("" + playerXP[2] + "", 4050);
		sendQuest("" + playerXP[1] + "", 4056);
		sendQuest("" + playerXP[4] + "", 4062);
		sendQuest("" + playerXP[5] + "", 4068);
		sendQuest("" + playerXP[3] + "", 4080);
		sendQuest("" + getXPForLevel(playerLevel[0] + 1) + "", 4045);
		sendQuest("" + getXPForLevel(playerLevel[2] + 1) + "", 4051);
		sendQuest("" + getXPForLevel(playerLevel[1] + 1) + "", 4057);
		sendQuest("" + getXPForLevel(playerLevel[4] + 1) + "", 4063);
		sendQuest("" + getXPForLevel(playerLevel[3] + 1) + "", 4081);


	}
public boolean addSkillXPmelee(int amount, int skill) {
		int oldLevel = getLevelForXP(playerXP[skill]);
		playerXP[skill] += amount;
		if (oldLevel < getLevelForXP(playerXP[skill])) {
			refreshMeleeLevelUp();
			playerLevel[skill] = getLevelForXP(playerXP[skill]);
			updateRequired = true;
			appearanceUpdateRequired = true;
			levelup(skill);
			setSkillLevel(skill, playerLevel[skill], playerXP[skill]);
		}
		refreshMeleeSkills();
		if (skill == 2) {
			CalculateMaxHit();
		}
		return true;

	}
public int freezeTiming;
public void refreshhps(){ //created by killamess
		sendQuest("" + currentHealth + "", 4016);
		sendQuest("" + playerXP[3] + "", 4080);
		sendQuest("" + getLevelForXP(playerXP[3]) + "", 4017);
		sendQuest("" + getXPForLevel(playerLevel[3] + 1) + "", 4081);
	}
	public void specAttack() { 
		sendSpecialBarAmount();
	}

	public void removeSpec(int id) {
		outStream.createFrame(171);
		outStream.writeByte(1);
		outStream.writeWord(id);
		flushOutStream();
	} 
public int i__;
public int getWeaponsDrainAmount() {
		int drain = 0;
		switch (playerEquipment[playerWeapon]) {
			case 5698: //DDS
			case 1215: //DD
			case 1231: //DDP
			case 5680: //DD+
			case 1434: //Dragon mace
			case 1305: //Dragon longsword
				drain = 25;
                		break;
			case 3204: //Dragon halberd
			case 861: //Mage Shortbow
            			case 4151: //Whip
    			case 4586: //D scim
			case 6739: //Dragon axe
			case 4153: //G-Maul
				drain = 50;
                		break;
 			case 7158: //Dragon 2h sword
            			case 1377: //Dragon battleaxe
                			drain = 100;
                		break;

        		}
		return drain;
	}

public boolean UseBow2 = false;
public int damageThisNPC = 0;
	public boolean rehitRange = false;
public int getarrowgfxnow() 
	{
		int W = playerEquipment[playerWeapon]; 
		if (playerEquipment[playerWeapon] == 4212) 
		{
           			return 249;
       		} 
       		if (playerEquipment[playerArrows] == 892) 
		{
          			return 15;
       		} 
		if (playerEquipment[playerArrows] == 4740) 
		{
          			return 27;
       		}
       		if (playerEquipment[playerArrows] == 890) 
		{
          			return 13;
        		} 
        		if (playerEquipment[playerArrows] == 888) 
		{
            			return 12;
        		} 
        		if (playerEquipment[playerArrows] == 886) 
		{
            			return 11;
        		} 
        		if (playerEquipment[playerArrows] == 884) 
		{
            			return 9;
        		} 
		if (playerEquipment[playerArrows] == -1) 
		{
			return 249;
		}
        		if (playerEquipment[playerArrows] == 882) 
		{
            			return 10;
        		} 
		else 
		{
			 return -1; 
		}
	}
public int calcDistanceSpeed2() {
		int EnemyX = server.npcHandler.npcs[damageThisNPC].absX;
		int EnemyY = server.npcHandler.npcs[damageThisNPC].absY;
		if (GoodDistance(EnemyX, EnemyY, absX, absY, 1) == true)
			return 65;
		if (GoodDistance(EnemyX, EnemyY, absX, absY, 2) == true)
			return 67;
		if (GoodDistance(EnemyX, EnemyY, absX, absY, 3) == true)
			return 69;
		if (GoodDistance(EnemyX, EnemyY, absX, absY, 4) == true)
			return 71;
		if (GoodDistance(EnemyX, EnemyY, absX, absY, 5) == true)
			return 73;
		if (GoodDistance(EnemyX, EnemyY, absX, absY, 6) == true)
			return 75;
		if (GoodDistance(EnemyX, EnemyY, absX, absY, 7) == true)
			return 77;
		return (!(GoodDistance(EnemyX, EnemyY, absX, absY, 1) == true) ? 77 : 65);
	}	
public int calcDistanceSpeedPlayer() {
		if (followThisPlayer > 0 ) {
		int EnemyX = PlayerHandler.players[followThisPlayer].absX;
		int EnemyY = PlayerHandler.players[followThisPlayer].absY;
		if (GoodDistance(EnemyX, EnemyY, absX, absY, 1) == true)
			return 86;
		if (GoodDistance(EnemyX, EnemyY, absX, absY, 2) == true)
			return 89;
		if (GoodDistance(EnemyX, EnemyY, absX, absY, 3) == true)
			return 92;
		if (GoodDistance(EnemyX, EnemyY, absX, absY, 4) == true)
			return 95;
		if (GoodDistance(EnemyX, EnemyY, absX, absY, 5) == true)
			return 98;
		if (GoodDistance(EnemyX, EnemyY, absX, absY, 6) == true)
			return 101;
		if (GoodDistance(EnemyX, EnemyY, absX, absY, 7) == true)
			return 104;
		return (!(GoodDistance(EnemyX, EnemyY, absX, absY, 1) == true) ? 104 : 86);
		} else {
			return -1;
		}
	}
	public int calcDistanceSpeedPlayerRange() {
		if (followThisPlayer > 0 ) {
		int EnemyX = PlayerHandler.players[followThisPlayer].absX;
		int EnemyY = PlayerHandler.players[followThisPlayer].absY;
		if (GoodDistance(EnemyX, EnemyY, absX, absY, 1) == true)
			return 68;
		if (GoodDistance(EnemyX, EnemyY, absX, absY, 2) == true)
			return 71;
		if (GoodDistance(EnemyX, EnemyY, absX, absY, 3) == true)
			return 73;
		if (GoodDistance(EnemyX, EnemyY, absX, absY, 4) == true)
			return 76;
		if (GoodDistance(EnemyX, EnemyY, absX, absY, 5) == true)
			return 79;
		if (GoodDistance(EnemyX, EnemyY, absX, absY, 6) == true)
			return 81;
		if (GoodDistance(EnemyX, EnemyY, absX, absY, 7) == true)
			return 84;
		return (!(GoodDistance(EnemyX, EnemyY, absX, absY, 1) == true) ? 84 : 68);
		} else {
			return -1;
		}
	}
	public int calcDistanceDamagePlayer() {
		if (followThisPlayer > 0 ) {
		int EnemyX = PlayerHandler.players[followThisPlayer].absX;
		int EnemyY = PlayerHandler.players[followThisPlayer].absY;

		if (GoodDistance(EnemyX, EnemyY, absX, absY, 1) == true)
			return 1800;
		if (GoodDistance(EnemyX, EnemyY, absX, absY, 2) == true)
			return 1850;
		if (GoodDistance(EnemyX, EnemyY, absX, absY, 3) == true)
			return 1900;
		if (GoodDistance(EnemyX, EnemyY, absX, absY, 4) == true)
			return 1950;
		if (GoodDistance(EnemyX, EnemyY, absX, absY, 5) == true)
			return 2000;
		if (GoodDistance(EnemyX, EnemyY, absX, absY, 6) == true)
			return 2050;
		if (GoodDistance(EnemyX, EnemyY, absX, absY, 7) == true)
			return 2100;
		return (!(GoodDistance(EnemyX, EnemyY, absX, absY, 1) == true) ? 2100 : 1800);
		} else {
			return -1;
		}
	}
public void Projectile2(int casterY, int casterX, int offsetY, int offsetX, int angle, int speed, int gfxMoving, int startHeight, int endHeight, int MageAttackIndex) {
		for (Player p : server.playerHandler.players) 
		{
			client plr = (client) p;
			if (p != null && !plr.disconnected) 
			{
				try {
					plr.outStream.createFrame(85);
					plr.outStream.writeByteC((casterY - (plr.mapRegionY * 8)) - 2);
					plr.outStream.writeByteC((casterX - (plr.mapRegionX * 8)) - 3);
					plr.outStream.createFrame(117);
					plr.outStream.writeByte(angle);
					plr.outStream.writeByte(offsetY);
					plr.outStream.writeByte(offsetX);
					plr.outStream.writeWord(MageAttackIndex);
					plr.outStream.writeWord(gfxMoving);
					plr.outStream.writeByte(startHeight);
					plr.outStream.writeByte(endHeight);
					plr.outStream.writeWord(51);
					plr.outStream.writeWord(speed);
					plr.outStream.writeByte(16);
					plr.outStream.writeByte(64);
				} catch (Exception e) {
				}
			}
		}
	}
	public int calcDistanceDamagePlayerRange() {
		if (AttackingOn > 0 ) {
		int EnemyX = PlayerHandler.players[AttackingOn].absX;
		int EnemyY = PlayerHandler.players[AttackingOn].absY;

		if (GoodDistance(EnemyX, EnemyY, absX, absY, 1) == true)
			return 1400;
		if (GoodDistance(EnemyX, EnemyY, absX, absY, 2) == true)
			return 1250;
		if (GoodDistance(EnemyX, EnemyY, absX, absY, 3) == true)
			return 1300;
		if (GoodDistance(EnemyX, EnemyY, absX, absY, 4) == true)
			return 1320;
		if (GoodDistance(EnemyX, EnemyY, absX, absY, 5) == true)
			return 1350;
		if (GoodDistance(EnemyX, EnemyY, absX, absY, 6) == true)
			return 1380;
		if (GoodDistance(EnemyX, EnemyY, absX, absY, 7) == true)
			return 1400;
		return (!(GoodDistance(EnemyX, EnemyY, absX, absY, 1) == true) ? 1400 : 1400);
		} else {
			return -1;
		}
	}

public boolean mageRequest = false;
	public boolean lastAttackz = false;
public boolean multiZone() {
		return absX >= 3224 && absX <= 3273 && absY >= 3381 && absY <= 3507 || absX >= 3287 && absX <= 3298 && absY >= 3167 && absY <= 3178 || absX >= 3070 && absX <= 3095 && absY >= 3405 && absY <= 3448 || absX >= 2961 && absX <= 2981 && absY >= 3330 && absY <= 3354 || absX >= 2510 && absX <= 2537 && absY >= 4632 && absY <= 4660 || absX >= 3012 && absX <= 3066 && absY >= 4805 && absY <= 4858 || absX >= 2794 && absX <= 2813 && absY >= 9281 && absY <= 9305 || absX >= 3546 && absX <= 3557 && absY >= 9689 && absY <= 9700 || absX >= 2708 && absX <= 2729 && absY >= 9801 && absY <= 9829 || absX >= 3450 && absX <= 3525 && absY >= 9470 && absY <= 9535 || absX >= 3207 && absX <= 3395 && absY >= 3904 && absY <= 3903 || absX >= 3006 && absX <= 3072 && absY >= 3611 && absY <= 3712 || absX >= 3149 && absX <= 3395 && absY >= 3520 && absY <= 4000 || absX >= 2365 && absX <= 2420 && absY >= 5065 && absY <= 5120 || absX >= 2890 && absX <= 2935 && absY >= 4425 && absY <= 4470 || absX >= 2250 && absX <= 2290 && absY >= 4675 && absY <= 4715 || absX >= 2690 && absX <= 2825 && absY >= 2680 && absY <=2810;
	}
public int getMagicalDamage = 0;
	public int magicH = 0;
	public long extraDelay = 0;
	public long extraDelayTime = 0;
	public int endGFX = 0;
	public int getMagicalEndGFX = 0;
public boolean staffType(int i) {
		if (i == 555) {
			if (playerEquipment[playerWeapon] == 1383 || playerEquipment[playerWeapon] == 1395 || playerEquipment[playerWeapon] == 1403) {
				return true;
			}
		}
		if (i == 554) {
			if (playerEquipment[playerWeapon] == 1387 || playerEquipment[playerWeapon] == 1393 || playerEquipment[playerWeapon] == 1401) {
				return true;
			}
		}
		if (i == 556) {
			if (playerEquipment[playerWeapon] == 1381 || playerEquipment[playerWeapon] == 1397 || playerEquipment[playerWeapon] == 1405) {
				return true;
			}
		}
		if (i == 557) {
			if (playerEquipment[playerWeapon] == 1385 || playerEquipment[playerWeapon] == 1399 || playerEquipment[playerWeapon] == 1407) {
				return true;
			}
		}
		return false;
	}
public long lastDamageTaken = 0;

	public boolean repeatSpell = false;
	public void autoCastThis() {
		if (AttackingOn < 1) {
			return;
		}
		switch(autoCastID) {
			case 1://wind strike
			gatherMagicInformationPVP(1152, 0, 1, 711, 90, 91, 92, 2, 558, 1, 556, 1, -1, -1, -1, -1, 100, 0);
			break;
			case 2://water strike
			gatherMagicInformationPVP(1154, 0, 5, 711, 93, 94, 95, 4, 555, 1, 556, 1, 558, 1,  -1, -1,100,0);
			break;
			case 3://earth strike
			gatherMagicInformationPVP(1156, 0, 9, 711, 96, 97, 98, 6, 558, 1, 556, 1, 557, 2,  -1, -1,100,0);
			break;
			case 4://fire strike
			gatherMagicInformationPVP(1158, 0, 13, 711, 99, 100, 101, 8, 554, 3, 556, 2, 558, 1,  -1, -1,100,0);
			break;
			case 5://wind bolt
			gatherMagicInformationPVP(1160, 0, 17, 711, 117, 118, 119, 9, 556, 2, 562, 1, -1, -1,  -1, -1,100,0);
			break;
			case 6://water bolt
			gatherMagicInformationPVP(1163, 0, 23, 711, 120, 121, 122, 10, 555, 3, 556, 2, 562, 1,  -1, -1,100,0);
			break;
			case 7://earth bolt
			gatherMagicInformationPVP(1166, 0, 29, 711, 123, 124, 125, 11, 557, 3, 556, 2, 562, 1,  -1, -1,100,0);
			break;
			case 8://fire bolt
			gatherMagicInformationPVP(1169, 0, 35, 711, 126, 127, 128, 12, 554, 4, 556, 3, 562, 1,  -1, -1,100,0);
			break;
			case 9://windblast
			gatherMagicInformationPVP(1172, 0, 41, 711, 132, 133, 134, 13, 556, 3, 560, 1, -1, -1,  -1, -1,100,0);
			break;
			case 10://waterblast
			gatherMagicInformationPVP(1175, 0, 47, 711, 135, 136, 137, 14, 555, 3, 556, 3, 560, 1, -1, -1, 100,0);
			break;
			case 11://earthblast
			gatherMagicInformationPVP(1177, 0, 53, 711, 138, 139, 140, 15, 557, 4, 556, 3, 560, 1, -1, -1, 100,0);
			break;
			case 12://fireblast
			gatherMagicInformationPVP(1181, 0, 59, 711, 129, 130, 131, 16, 554, 5, 556, 4, 560, 1, -1, -1, 100,0);
			break;
			case 13://windwave
			gatherMagicInformationPVP(1183, 0, 62, 718, 158, 159, 160, 17, 556, 5, 565, 1, -1, -1, -1, -1, 100,0);
			break;
			case 14://waterwave
			gatherMagicInformationPVP(1185, 0, 65, 718, 161, 162, 163, 18, 555, 7, 556, 5, 565, 1, -1, -1, 100,0);
			break;
			case 15://earthwave
			gatherMagicInformationPVP(1188, 0, 70, 718, 164, 165, 166, 19, 557, 7, 556, 5, 565, 1, -1, -1, 100,0);
			break;
			case 16://firewave
			gatherMagicInformationPVP(1189, 0, 75, 718, 155, 156, 157, 20, 554, 7, 556, 5, 565, 1, -1, -1, 100,0);
			break;
		}
	}
public int autoCastID;
public int castRune1;
	public int castRune1Amount;
	public int castRune2;
	public int castRune2Amount;				
	public int castRune3;
	public int castRune3Amount;				
	public int castRune4;
	public int castRune4Amount;
	public int autoCastLevel;
public boolean checkPlayersAreas() {
		if (AttackingOn < 1) {
			return false;
		}
		client AttackingOn2 = (client) server.playerHandler.players[AttackingOn];
		int EnemyX = PlayerHandler.players[AttackingOn].absX;
		int EnemyY = PlayerHandler.players[AttackingOn].absY;

		
			
			
			/*if (isInWilderness(EnemyX, EnemyY, 1) == true && isInWilderness(absX,absY, 1) ==false) {
				sendMessage("I must move into the wilderness to attack other players.");
				WalkTo(0,0);
				cancelAttack();
				return false;
			}
			if (isInWilderness(EnemyX, EnemyY, 1) == false && isInWilderness(absX,absY, 1) == true) {
				sendMessage("This player is not in the wilderness.");
				WalkTo(0,0);
				cancelAttack();
				return false;
			}
			if (isInWilderness(EnemyX, EnemyY, 1) == false && isInWilderness(absX,absY, 1) ==false) {
				sendMessage("I must move into the wilderness to attack other players.");
				WalkTo(0,0);
				cancelAttack();
				return false;
			}
			if (isInWilderness(EnemyX, EnemyY, 1) == false && isInWilderness(absX,absY, 1) == true) {
				sendMessage("This player is not in the wilderness.");
				WalkTo(0,0);
				cancelAttack();
				return false;
			}
			if (AttackingOn2.combatLevel + AttackingOn2.wildyLevel < combatLevel || combatLevel + AttackingOn2.wildyLevel < AttackingOn2.combatLevel) {
				sendMessage("You need to move deeper into the Wilderness.");
				WalkTo(0,0);
				cancelAttack();
				return false;
			}*/
			
		return true;
	}
public void cancelAttack() {
		AttackingOn = 0;
		
		faceNPC = 32768;
		startFollowing = false;
		stopMovement();
		resetAnimation();
	}
	public boolean startFollowing;
public void followThisPlayer() {
		if (AttackingOn >= 1) {
			follow(AttackingOn, playerId);
		} else {
			cancelAttack();
		}
	}
	public void stopMovement() {
		WalkTo(0,0);
	}
public boolean checkMeleeRequirements() {
		if (AttackingOn < 1) {
			cancelAttack();
			return false;
		}
		client AttackingOn2 = (client) server.playerHandler.players[AttackingOn];
		if (!autoCast) {
			if (withinDistance(1, AttackingOn2)) {
				startFollowing = false;
				followPlayer = null;
				WalkTo(0,0);
			}
			if (!withinDistance(12, AttackingOn2)) {
				cancelAttack();
				return false;
			}
			if (!withinDistance(1, AttackingOn2)) {
				startFollowing = true;
				followThisPlayer();
			}
		} else {
			checkRangingRequirements();
			
		}
			
		return true;
	}
public boolean checkRangingRequirements() {
		if (AttackingOn < 1) {
			cancelAttack();
			return false;
		}
		client AttackingOn2 = (client) server.playerHandler.players[AttackingOn];
		if (withinDistance(7, AttackingOn2)) {
			followPlayer = null;
			WalkTo(0,0);
		}
		if (!withinDistance(12, AttackingOn2)) {
			cancelAttack();
			return false;
		}
		if (!checkPlayersAreas()) {
			return false;
		}
		if (!withinDistance(8, AttackingOn2)) {
			followThisPlayer();
		}	
		return true;
	}
public boolean attackPrepared() {
		if (usingBow()) {
			if (checkRangingRequirements()) {
				return true;
			}
		} else if (checkMeleeRequirements()) {
			return true;
		}
		return false;
	}
public boolean isWalkable() {
		if (AttackingOn < 1) {
			return false;
		}
		int EnemyX = PlayerHandler.players[AttackingOn].absX;
		int EnemyY = PlayerHandler.players[AttackingOn].absY;
		int i = absX;
		int k = absY;
		int j = EnemyX;
		int l = EnemyY;
		
		if (i == j) {
			if (k == l) {
				if(WorldMap.isWalkAble(heightLevel, j, l, i - 1, k) == true) {
					WalkTo(-1,0);
				} else if(WorldMap.isWalkAble(heightLevel, j, l, i + 1, k) == true) {
					WalkTo(+1,0);
				} else if(WorldMap.isWalkAble(heightLevel, j, l, i, k - 1) == true) {
					WalkTo(0,-1);
				} else if(WorldMap.isWalkAble(heightLevel, j, l, i, k + 1) == true) {
					WalkTo(0,+1);
				} else {
					WalkTo(0,0);
				}
			}
		}
		if (i > j) {
			if (k != l) {
				if (k - 1 == l) {
					if(WorldMap.isWalkAble(heightLevel, i, k, i, k -1) == true) {
						WalkTo(0,-1);
					}
				} 
				if (k + 1 == l) {
					if(WorldMap.isWalkAble(heightLevel, i, k, i, k +1) == true) {
						WalkTo(0,+1);
					}
				}
			}
		} else if (i < j) {
			if (k != l) {
				if (k - 1 == l) {
					if(WorldMap.isWalkAble(heightLevel, i, k, i, k -1) == true) {
						WalkTo(0,-1);
					}
				} 
				if (k + 1 == l) {
					if(WorldMap.isWalkAble(heightLevel, i, k, i, k +1) == true) {
						WalkTo(0,+1);
					}
				}
			}
		}

		if (k < l) {
			if (i != j) {
				if (i - 1 == j) {
					if(WorldMap.isWalkAble(heightLevel, i, k, i -1, k) == true) {
						WalkTo(-1,0);
					}
				} 
				if (i + 1 == j) {
					if(WorldMap.isWalkAble(heightLevel, i, k, i +1, k) == true) {
						WalkTo(+1,0);
					}
				}
			}

		} else if (k > l) {
			if (i != j) {
				if (i - 1 == j) {
					if(WorldMap.isWalkAble(heightLevel, i, k, i -1, k) == true) {
						WalkTo(-1,0);
					}
				} 
				if (i + 1 == j) {
					if(WorldMap.isWalkAble(heightLevel, i, k, i +1, k) == true) {
						WalkTo(+1,0);
					}
				}
			}
		}					
		return true;
	}
public void Attacks() {
		if (AttackingOn < 1) {
			return;
		}
		int EnemyX = PlayerHandler.players[AttackingOn].absX;
		int EnemyY = PlayerHandler.players[AttackingOn].absY;
		int i = absX;
		int k = absY;
		int j = EnemyX;
		int l = EnemyY;
		if (!usingBow()) {
			if ((i == j && k == l) || (i > j && k != l) || (i < j && k != l) || (k < l && i != j) || (k > l && i != j)) {
				isWalkable();
				facePlayer();
			}
		}
		if (System.currentTimeMillis() - lastAction > weaponDelay && attackPrepared() && checkPlayersAreas()) {
			lastAction = System.currentTimeMillis();
			getAttackDelay();
			if (autoCast) {
				checkSpellIDs();
				autoCasting();
			} else {
				runAttack();
				sendSpecialBarAmount();
			}
		}
		return;
	}


public int bet = 0;

public void wonbet(){
addItem(995,bet*2);
sendQuest(playerName, 8399);
sendQuest("Party Pete", 7815);
sendQuest("" + (otherdice + otherdice2) + "", 8424);
sendQuest("" + (mydice + mydice2) + "", 8425);
sendQuest("You win!", 8426);
addItem(995,bet*2);
showInterface(6675);
if(bet > 500000){
yell(playerName + " Has won " + bet + " in Lucky dice game! try your chance!");
addItem(995,bet*2);
}
EventManager.getSingleton().addEvent(
                new Event() {
                    public void execute(EventContainer C) {
sendFrame171(1, 2465);
sendFrame171(0, 2468);

sendFrame126("Another try?", 2460);

sendFrame126("Play again", 2461);

sendFrame126("Stop playing", 2462);

sendFrame164(2459);

 C.stop();
                    }
                }, 5000);
}
public void lostbet(){

sendQuest(playerName, 8399);
sendQuest("Party Pete", 7815);
sendQuest("" + (otherdice + otherdice2) + "", 8424);
sendQuest("" + (mydice + mydice2) + "", 8425);
sendQuest("You lose!", 8426);
showInterface(6675);
EventManager.getSingleton().addEvent(
                new Event() {
                    public void execute(EventContainer C) {
RemoveAllWindows();
sendFrame171(1, 2465);

sendFrame171(0, 2468);

sendFrame126("Another try?", 2460);

sendFrame126("Play again", 2461);

sendFrame126("Stop playing", 2462);
sendFrame164(2459);

 C.stop();
                    }
                }, 5000);
}
public void draw(){
addItem(995,bet);
sendQuest(playerName, 8399);
sendQuest("Party Pete", 7815);
sendQuest("" + (otherdice + otherdice2) + "", 8424);
sendQuest("" + (mydice + mydice2) + "", 8425);
sendQuest("Draw!", 8426);
showInterface(6675);
EventManager.getSingleton().addEvent(
                new Event() {
                    public void execute(EventContainer C) {
RemoveAllWindows();
sendFrame171(1, 2465);

sendFrame171(0, 2468);

sendFrame126("Another try?", 2460);

sendFrame126("Play again", 2461);

sendFrame126("Stop playing", 2462);
sendFrame164(2459);

 C.stop();
                    }
                }, 5000);
}
public int mydice = 0;
public int otherdice = 0;
public int mydice2 = 0;
public int otherdice2 = 0;

public void bettheitem(){
otherdice = 1 + misc.random(5);
otherdice2 = 1 + misc.random(5);
mydice = 1 + misc.random(5);
mydice2 = 1 + misc.random(5);
if((otherdice + otherdice2) < (mydice + mydice2)){
wonbet();
}else if((otherdice + otherdice2) == (mydice + mydice2)){
draw();
}else{
lostbet();
}
}
public void betitem(int i){
bet = i;
deleteItem(995,i);
bettheitem();
}
public int actionTimer1 = 0;
public int actionTimer2 = 0;
public int actionTimer3 = 0;
public int actionTimer4 = 0;
public int optionz = 0;
public int GetWepAnim()
{
int id = playerEquipment[playerWeapon];

if(id == -1) // unarmed
{
return 422;
}
if(id == 15156) // unarmed
{
return 426;
}
if(id == 15156) // unarmed
{
return 426;
}
if(id == 3098)
{
return 401;
}
if(id == 6587)
{
return 401;
}
if(id == 7140)
{
return 1658;
}
if(id == 6818 || id == 4508 || id == 15333 || id == 15335 || id == 15336 || id == 15334)
{
return 3496;
}
if(id == 13800)
{
return 427;
}
if(id == 667)
{
return 407;
}
if(id == 837)
{
return 1084;
}
if(id == 3190 || id == 3192 || id == 3194 || id == 3196 || id == 3198 || id== 3200 || id == 3202 || id == 3204) // halberds
{
return 440;
}
if(id == 4170 || id == 4675)
{
return 414;
}
if(id == 4151) // whip
{
return 1658;
}
if(id == 6528) 
{
return 2661;
}
if(id == 15156) 
{
return 426;
}
if(id == 6522) 
{
return 2614;
}
if(id == 732) 
{
return 1658;
}
if((id == 1291 || id == 1321 || id == 1323 || id == 1325 || id == 1327 || id == 1329 || id == 6611 || id == 1327 || id == 1321 || id == 1333 || id == 1305 || id== 6739 || id == 4587) && FightType == 3) // scimitars
{
return 412;
}
if(id == 841 || id == 843 || id == 845 ||id == 849 ||id == 847 ||id == 853 || id == 851 || id == 859 || id == 861) 
{
return 426;
}
if(id == 837)
{
return 427;
}
if(id == 4153) // maul
{
return 1665;
}
if(id == 1377) // dragon b axe
{
return 1833;
}
if(id == 4718 && FightType != 3) // dharoks axe
{
return 2067;
}
if(id == 4718 && FightType == 3) // dharoks axe
{
return 2066;
}
if(id == 4726 && FightType == 2)
{
return 2080;
}
if(id == 4158 && FightType != 2)
{
return 2080;
}
if(id == 4726 && FightType != 2)
{
return 2081;
}
if(id == 4158 && FightType == 2)
{
return 2081;
}
if(id == 4747) // torags hammers
{
return 2068;
}
if(id == 4755) // veracs flail
{
return 2062;
}
if(id == 4734) // karils x bow
{
return 2075;
}
if((id == 1215 || id == 1231 || id == 5680 || id == 5698) && FightType != 3) // dragon daggers
{
return 402;
}
if((id == 1215 || id == 1231 || id == 5680 || id == 5698) && FightType == 3) // dragon daggers
{
return 395;
}
if(id == 6609 || id == 1307 || id == 1309 || id == 1311 || id == 1313 || id == 1315 || id == 1317 || id == 1319 || id == 7158 || id == 0 ) 
// 2 handers
{
return 3496;
}
else
{
return 451;
}
}
public int GetRunAnim(int id) 
{
if(Item.itemTwoHanded[id]){
return 1664;
}
if(id == 4151) // whip
{
return 1661;
}
if(id == 4153) // maul
{
return 1664;
}
if(id == 8447) // cat toy
{
return 1661;
}
if(id == 6818) // bow-sword
{
return 744;
}
if(id == 4734 || id == 837) // karils x bow
{
return 2077;
}
if(id == 4153) // maul
{
return 1664;
}
if(id == 1419) // scythe
{
return 1664;
}
if(id == 7449) // noobsmasher
{
return 1664;
}
else
{
return 0x338;
}
}

public int GetWalkAnim(int id) 
{
if(Item.itemTwoHanded[id]){
return 2064;
}
if(id == 4718) // dharoks axe
{
return 2064;
}

if(id == 4039 || id == 4037 || id == 1379 || id == 3204 || id == 3202 || id == 1381 || id == 1383 || id == 1385 || id == 1387 || id == 1389 || id == 1391 || id == 1393 || id == 1395 || id == 1397 || id == 1399 || id == 1401 || id == 1403 || id == 145 || id == 1407 || id == 1409 || id == 3053 || id == 3054 || id == 4170 || id == 4675 || id == 4710 || id == 6526 || id == 4726 || id == 6562 || id == 6563 || id == 6914 || id == 5730) // staves + d long and most other weps with str8 up emote
{
return 1146;
}
if(playerEquipment[playerFeet] == 4084) // sled
{
return 755;
}
if(id == 4565) // basket of eggs :)
{
return 1836;
}
if(id == 4755) // veracs flail
{
return 2060;
}
if(id == 4734 || id == 837) // karils x bow
{
return 2076;
}
if(id == 4153 || id == 15334 || id == 15333 || id == 15334 || id == 15335 || id == 15336 || id == 1419) // maul
{
return 1663;
}
if(id == 7158 || id == 4718 || id == 1319 || id == 6528 || id == 14915) // 2h + gr8 axe
{
return 2064;
}
if(id == 7449) // noob smasher
{
return 1663;
}
if(id == 4151) // whip
{
return 2060;
}
if(id == 8447) // cat toy
{
return 1661;
}
else
{
return 0x333;
}
}

public int GetStandAnim(int id) 
{
if(Item.itemTwoHanded[id]){
return 2065;
}
if(id == 4718) // dharoks axe
{
return 2065;
}
if(id == 4755) // veracs flail
{
return 2061;
}
if(id == 4734 || id == 837) // karils x bow
{
return 2074;
}
if(id == 4153 || id == 15334 || id == 15333 || id == 15334 || id == 15335 || id == 15336 || id == 1419) // maul
{
return 1662;
}
if(id == 7449) // noob smasher
{
return 1662;
}
if(id == 4565) // basket of eggs :)
{
return 1836;
}
if(id == 1305 || id == 1379 || id == 1381 || id == 1383 || id == 1385 || id == 1387 || id == 1389 || id == 1391 || id == 1393 || id == 1395 || id == 1397 || id == 1399 || id == 1401 || id == 1403 || id == 145 || id == 1407 || id == 1409 || id == 3053 || id == 3054 || id == 4170 || id == 4675 || id == 4710 || id == 6526 || id == 4726 || id == 6562 || id == 6563 || id == 5730) // staves
{
return 809;
}
if(id == 7158 || id == 1319 || id == 6528 || id == 14915) // 2h
{
return 2065;
}
if(id == 3204 || id == 3202) // halberd
{
return 809;
}
else
{
return 0x328;
}
}

//cooking
public void AddGlobalObject(int x, int y, int typeID, int orientation,
			int tileObjectType) {
		if (distanceToPoint(x, y) <= 110) {
			outStream.createFrame(85);
			outStream.writeByteC(y - (mapRegionY * 8));
			outStream.writeByteC(x - (mapRegionX * 8));

			outStream.createFrame(151);
			// outStream.writeByteA(((x&7) << 4) + (y&7));
			outStream.writeByteA(0);
			outStream.writeWordBigEndian(typeID);
			outStream.writeByteS((tileObjectType << 2) + (orientation & 3));
		}
	}

	
public String getItemName(int ItemID) {
		for (int i = 0; i < server.itemHandler.MaxListedItems; i++) {
			if (server.itemHandler.ItemList[i] != null) {
				if (server.itemHandler.ItemList[i].itemId == ItemID) {
					return server.itemHandler.ItemList[i].itemName;
				}
			}
		}
		return "!!! ITEM NOT FULLY ADDED !!! - ID:" + ItemID;
	}
public void SpawnThief() {
		for (int i = 0; i < server.Stalls; i++) {
			if (server.StallSPAWN[i] > 0) {
				AddGlobalObject(server.StallX[i], server.StallY[i],
						server.StallEmpty[i], 0, 10);
			}
		}
	}

public boolean RemoveStall() {
		boolean New = true;
		int stallid = server.Stalls;
		for (int i = 0; i < server.Stalls; i++) {
			if (server.StallX[i] == StallX && server.StallY[i] == StallY) {
				
				New = false;
				
					
					sendMessage("hi");
					AddGlobalObj(StallX, StallY, emptyid, 0, 10);
					return false;

				}
				return true;

			
		}
		if (New) {
			server.StallX[stallid] = StallX;
			server.StallY[stallid] = StallY;
			server.StallID[stallid] = StallId;
			server.StallEmpty[stallid] = emptyid;
			
			server.Stalls++;
			return true;

		}
		return false;
}
public int StallId4;
public int StallX4;
public int StallY4;
public int StallId2;
public int StallX2;
public int StallY2;
public int StallId3;
public int StallX3;
public int StallY3;
public int StallId1;
public int StallX1;
public int StallY1;
public int StallId;
public int emptyid;
public int StallX;
public int StallY;

 public void displayItem246(int i, int i_542_, int i_543_) {
	if (server.playerHandler != null) {
	    /* empty */
	}
	if (PlayerHandler.players[playerId] == null || disconnected
	    || in == null || out == null) {
	    
	} else {
	    outStream.createFrame(246);
	    outStream.writeWordBigEndian(i);
	    outStream.writeWord(i_542_);
	    outStream.writeWord(i_543_);
	}
    }
public int cookXpInc = 12;
 public int cookItem = 0;
    public int cookItemAmt = 0;
    public int cookDelay = 0;
    public int cookLvlNeeded = 1;

public int gauntleychance = 0;
 public void cookItem(int i)
    {
      
        cookItemAmt = i;
        
        walkaway = false;
        sendMessage("You prepare the fishes to cook...");
	RemoveAllWindows();
            EventManager.getSingleton().addEvent(
                new Event() {
                    public void execute(EventContainer C) {
			startAnimation(883);
                RemoveAllWindows();
		 int j = playerLevel[playerCooking];
		
		if(j >= cookLvlNeeded)
        	{
                if(misc.random(playerLevel[playerCooking]) < ((cookLvlNeeded / 2) - gauntleychance))
                {
		
                    sendMessage((new StringBuilder()).append("You accidentally burn the ").append(getItemName(cookItem)).append(".").toString());
                    deleteItem(cookItem, GetItemSlot(cookItem), 1);
                    if(cookItem == 317 || cookItem == 321)
                        addItem(323, 1);
                    else
                    if(cookItem == 327)
                        addItem(369, 1);
                    else
                    if(cookItem == 331 || cookItem == 335 || cookItem == 341 || cookItem == 349)
                        addItem(343, 1);
                    else
                    if(cookItem == 345 || cookItem == 353)
                        addItem(357, 1);
                    else
                    if(cookItem == 359 || cookItem == 363)
                        addItem(367, 1);
                    else
                    if(cookItem == 371)
                        addItem(375, 1);
                    else
                    if(cookItem == 377)
                        addItem(381, 1);
                    else
                    if(cookItem == 383)
                        addItem(387, 1);
                    else
                    if(cookItem == 389)
                        addItem(393, 1);
                    else
                        addItem(323, 1);
                    cookItemAmt--;
		
                } else 
                {
		
                    sendMessage((new StringBuilder()).append("You successfully cook the ").append(getItemName(cookItem)).append(".").toString());
                    deleteItem(cookItem, GetItemSlot(cookItem), 1);
                    cookItemAmt--;
                    if(cookItem == 317)
                    {
                        addItem(315, 1);
                        addSkillXP(10 * cookXpInc, playerCooking);
                    }
                    if(cookItem == 321)
                    {
                        addItem(319, 1);
                        addSkillXP(40 * cookXpInc, playerCooking);
                    }
                    if(cookItem == 327)
                    {
                        addItem(325, 1);
                        addSkillXP(20 * cookXpInc, playerCooking);
                    }
                    if(cookItem == 345)
                    {
                        addItem(347, 1);
                        addSkillXP(30 * cookXpInc, playerCooking);
                    }
                    if(cookItem == 335)
                    {
                        addItem(333, 1);
                        addSkillXP(50 * cookXpInc, playerCooking);
                    }
                    if(cookItem == 349)
                    {
                        addItem(351, 1);
                        addSkillXP(60 * cookXpInc, playerCooking);
                    }
                    if(cookItem == 331)
                    {
                        addItem(329, 1);
                        addSkillXP(70 * cookXpInc, playerCooking);
                    }
                    if(cookItem == 359)
                    {
                        addItem(361, 1);
                        addSkillXP(80 * cookXpInc, playerCooking);
                    }
                    if(cookItem == 377)
                    {
                        addItem(379, 1);
                        addSkillXP(90 * cookXpInc, playerCooking);
                    }
                    if(cookItem == 371)
                    {
                        addItem(373, 1);
                        addSkillXP(100 * cookXpInc, playerCooking);
                    }
                    if(cookItem == 7944)
                    {
                        addItem(7946, 1);
                        addSkillXP(120 * cookXpInc, playerCooking);
                    }
                    if(cookItem == 383)
                    {
                        addItem(385, 1);
                        addSkillXP(110 * cookXpInc, playerCooking);
                    }
                    if(cookItem == 353)
                    {
                        addItem(355, 1);
                        addSkillXP(20 * cookXpInc, playerCooking);
                    }
                    if(cookItem == 389)
                    {
                        addItem(391, 1);
                        addSkillXP(200 * cookXpInc, playerCooking);
                    }
                
            }
	
        } else
        {
            showDialogue((new StringBuilder()).append("You need a Cooking level of ").append(cookLvlNeeded).append(" to make ").append(getItemName(cookItem)).append(".").toString());
            resetAnimation();
        }
    			if(cookItemAmt == 0 || walkaway)
                        C.stop(); // stops the event from running
			
			
                    }
                }, 2000);
}

               
    public int cookLevelForItem()
    {
        if(cookItem == 317)
            return 1;
        if(cookItem == 321)
            return 1;
        if(cookItem == 327)
            return 1;
        if(cookItem == 345)
            return 5;
        if(cookItem == 335)
            return 15;
        if(cookItem == 349)
            return 20;
        if(cookItem == 331)
            return 25;
        if(cookItem == 359)
            return 30;
        if(cookItem == 377)
            return 40;
        if(cookItem == 371)
            return 45;
        if(cookItem == 7944)
            return 62;
        if(cookItem == 383)
            return 80;
        if(cookItem == 389)
            return 86;
        return cookItem != 353 ? 1 : 10;
    }

    public void cookMenu(int i)
    {
	
        cookItem = i;
        cookLvlNeeded = cookLevelForItem();
        displayItem246(13716, 250, i);
        sendFrame164(1743);
    }
public boolean isPlayerMember(int playerId)
	{
	

		
		if(membershipDays == 0)
		{
			premium = 0;
			return false;
		}
		if(premium == 2)
		{
			return true;
		}
		return false;
	}


public void appendToMember(int playerId) 
	{
		
		if(playerId < 1) 
		{
			return;
		}
		premium = 2;
		membershipDays = 30;
		dateMadeMember = getDate("dd MMMMM yyyy");
		String[] args = misc.splitArgs(dateMadeMember);
		dayMadeMember = Integer.parseInt(args[0]);
		
		yearMadeMember = Integer.parseInt(args[2]);
		
	}
	
	public static String getDate(String dateFormat)
	{
	    Calendar cal = Calendar.getInstance();
	    SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
	    return sdf.format(cal.getTime());
	}
	
	public int getMemberDaysLeft(int playerId)
	{
		if(membershipDays < 1) {
			return 0;
		}
		init(playerId); //just to make sure eh?
		return membershipDays;
	}
	
	public void init(int playerId) //in void initlize in your client class add this somehwhere in it
	{
		if(premium == 0) {
			return;
		}
		int currentDay;
		String todaysDate = getDate("dd MMMMM yyyy");
		String[] args = misc.splitArgs(todaysDate);
		currentDay = Integer.parseInt(args[0]);
		if(lastMemberUpdate == currentDay)
		{
			return;
		}
		membershipDays--;
		lastMemberUpdate = currentDay;
	}
private int item[] = new int[40]; 
public void sendSkillInterface(int id[]) {
outStream.createFrameVarSizeWord(53); outStream.writeWord(8847); outStream.writeWord(id.length);
for (int i = 0; i < id.length; i++) { outStream.writeByte(1);
if(id[i] > 0) { outStream.writeWordBigEndianA(id[i]+1); } else { outStream.writeWordBigEndianA(0);}} outStream.endFrameVarSizeWord(); flushOutStream();}
public int Interface;
 public int fishXpInc = 12;
public static int saradominban = 0;
public static int flaxani = 0;
public static int thiefani = 0;
public static int bloodani = 0;
public static int zammorakban = 0;
public int playerIsSara = 0;
public int playerIsZammy = 0;
public static int sarapoint = 0;
public static int zammypoint = 0;
public boolean PlayerIsSara = false;
public boolean PlayerIsZammy = false;
public int startcw = 0;
public int rewardClaimed = 0;
public int cwstairs = 0;
public int rocks = 0;
public int magicm = 0, attackm = 0, defencem = 0, rangem = 0, runecraftingm, prayerm, strengthm;
public int swiz = 0;
public int ancients = 1;
public boolean infHP = false;
public boolean infATK = true;
public boolean infSTR = true;
public boolean test = false;
public int SaraTimer = 10;
public boolean HasTimed = false;
public int wilderness = 0;
public int playerRank = 0;
public int totalz = totalz = (getLevelForXP(playerXP[0]) + getLevelForXP(playerXP[1]) + getLevelForXP(playerXP[2]) + getLevelForXP(playerXP[3]) + getLevelForXP(playerXP[4]) + getLevelForXP(playerXP[5]) + getLevelForXP(playerXP[6]) + getLevelForXP(playerXP[7]) + getLevelForXP(playerXP[8]) + getLevelForXP(playerXP[9]) + getLevelForXP(playerXP[10]) + getLevelForXP(playerXP[0]) + getLevelForXP(playerXP[11]) + getLevelForXP(playerXP[12]) + getLevelForXP(playerXP[13]) + getLevelForXP(playerXP[14]) + getLevelForXP(playerXP[15]) + getLevelForXP(playerXP[6]) + getLevelForXP(playerXP[17]) + getLevelForXP(playerXP[18]) + getLevelForXP(playerXP[19]) + getLevelForXP(playerXP[20]) + getLevelForXP(playerXP[21]));
public int slayerTask = 0;
public int TlastSlot = 0, RlastSlot = 0;
public int penguin = 0;
public void clueScrollItems(int i1, int a1, int i2, int a2, int i3, int a3){
addItem(i1,a1); addItem(i2,a2); addItem(i3,a3);
showInterface(6960);
sendFrame34(6963,i1,0,a1); sendFrame34(6963,i2,1,a2); sendFrame34(6963,i3,2,a3);}
public void rightClickCheck() {
if(isInWilderness && duelFight) {
outStream.createFrameVarSize(104);
outStream.writeByteC(3);		// command slot
outStream.writeByteA(0);		// 0 or 1; 1 if command should be placed on top in context menu 
outStream.writeString("null"); outStream.endFrameVarSize();}
if(!isInWilderness && !duelFight) {
outStream.createFrameVarSize(104);
outStream.writeByteC(3);		// command slot
outStream.writeByteA(0);		// 0 or 1; 1 if command should be placed on top in context menu
outStream.writeString("Attack"); outStream.endFrameVarSize();}}
public void players() {
sendQuest("@dre@Exorth - infos", 8144); clearQuestInterface(); int line = 8147;
			for (int i = 1; i < PlayerHandler.maxPlayers; i++) {
				client playa = getClient(i);
				if (!validClient(i))
					continue;
		if (playa.playerName != null) {
			String title = "";
if (playa.playerRights == 0 && playa.premium == 0) {
				title = "Player, ";
} else if (playa.playerRights == 0 && playa.premium == 2) {
				title = "Premium, ";
		} else if (playa.playerRights == 1) {
				title = "Mod, ";
		} else if (playa.playerRights == 2) {
				title = "Admin, ";
} else if (playa.playerRights == 3) {
			title = "Owner, ";}
title += "level-" + playa.combatLevel; String extra = "";
					if (playerRights > 0) {
						extra = "(" + playa.playerId + ") ";} sendQuest("@dre@" + extra + playa.playerName + "@dbl@ ("+ title +") is at " + playa.absX + ", "+ playa.absY, line);
					line++;}}
sendQuestSomething(8143); showInterface(8134); flushOutStream();}
public void uptime() {
sendQuest("Server information", 663); sendQuest((new StringBuilder()).append("@or1@Uptime: @gre@").append(server.uptime / 2 / 60).append(" @or1@mins").toString(), 7332); sendQuest((new StringBuilder()).append("@or1@Players Online: @gre@").append(PlayerHandler.playerCount).toString()+"", 7333); sendQuest("@or2@Server updates", 7334); sendQuest("", 7336); sendQuest("", 7383); sendQuest("", 7339); sendQuest("", 7338); sendQuest("", 7340); sendQuest("", 7346); sendQuest("", 7341); sendQuest("", 7342); sendQuest("", 7337); sendQuest("", 7343); sendQuest("", 7335);}
	public void KolodionReward() {
	   if(kolodion == 1) {
		clearQuestInterface();
		sendQuest("Close Window", 4912);//Close Text
		sendQuest("In return for defeating Kolodion", 4913);//Line 1
		sendQuest("You may now enter the dungeon", 4911);//Line 2
		sendQuest("That is north-west of Varrok", 4914);//Line 3
		sendQuest("", 4915);//Line 4
		sendQuest("Thanks for your help, " + playerName, 4918);//Line 5
		sendQuest("Signed, King Percival", 4916);//Line 6 - This text is centered
		showInterface(4909);
		flushOutStream();}}
        public void spawnAnNpc(int npcID, int X, int Y, int heightLevel) {
	    server.npcHandler.spawnAnNpc(npcID, X, Y, heightLevel, X+5, Y+5, X+5, Y+5, 1, server.npcHandler.GetNpcListHP(npcID), false, playerId);}
public void Serverupdate() {
sendFrame126("@dre@Exorth Updates", 8144); clearQuestInterface();
sendFrame126("", 8145); 
sendFrame126("@dre@1. Options for teleports", 8147); 
sendFrame126("@dre@2. recreating all combat menu's + runecrafting.", 8148); 
sendFrame126("@dre@3. Bosses droping expensive stuff", 8149); 
sendFrame126("@dre@4. Upgrade to premium now on Exorth", 8150);
sendFrame126("@dre@5. Hpbar refill glitch have now been fixed", 8151); 
sendFrame126("@dre@6. big citys and criminal citys are under construction", 8152); 
sendFrame126("@dre@7. Goblin village = starting area", 8153);
sendQuestSomething(8143); showInterface(8134);}
//attack menu//
public void attacki(String name,int lvl, int id[]) {
sendFrame126("@dre@ATTACK", 8716); for(int i = 8720;i<8799;i++) { sendFrame126("",i);}
sendFrame126(lvl+"", 8720); sendFrame126(lvl+"", 8721); sendFrame126(lvl+"", 8722); sendFrame126(lvl+"", 8723); sendFrame126(lvl+"", 8724); sendFrame126(lvl+"", 8725); sendFrame126(lvl+"", 8726); sendFrame126(lvl+"", 8727); sendFrame126(lvl+"", 8728); sendFrame126(lvl+"", 8729); sendFrame126(lvl+"", 8730); sendFrame126(lvl+"", 8731);
sendFrame126(name+" dagger", 8760); sendFrame126(name+" axe", 8761); sendFrame126(name+" mace", 8762); sendFrame126(name+" claws", 8763); sendFrame126(name+" sword", 8764); sendFrame126(name+" longsword", 8765); sendFrame126(name+" scimitar", 8766); sendFrame126(name+" spear", 8767); sendFrame126(name+" warhammer", 8768); sendFrame126(name+" battleaxe", 8769); sendFrame126(name+" two-handed sword", 8770); sendFrame126(name+" halberd", 8771);
sendFrame126("bronze", 8846); sendFrame126("iron", 8823); sendFrame126("steel", 8824); sendFrame126("black", 8827); sendFrame126("mithril", 8837); sendFrame126("adamant", 8840); sendFrame126("rune", 8843); sendFrame126("bronze", 8846); sendFrame126("granite", 8859); sendFrame126("dragon", 8862); sendFrame126("barrows", 8865); sendFrame126("Others", 15303); sendFrame126("", 15306); sendFrame126("", 15309);
sendSkillInterface(id); sendFrame126("", 8849); showInterface(8714);}
public void attacki3(String name,int lvl, int id[]) {
sendFrame126("@dre@ATTACK", 8716); for(int i = 8720;i<8799;i++) { sendFrame126("",i);}
sendFrame126(lvl+"",8720); sendFrame126(name+" dagger",8760); sendFrame126(lvl+"",8721); sendFrame126(name+" hatchet", 8761); sendFrame126(lvl+"",8722); sendFrame126(name+" mace",8762); sendFrame126(lvl+"",8723); sendFrame126(name+" longsword",8763); sendFrame126(lvl+"",8724); sendFrame126(name+" scimitar", 8764); sendFrame126(lvl+"",8725); sendFrame126(name+" spear", 8765); sendFrame126(lvl+"",8726); sendFrame126(name+" battleaxe", 8766); sendFrame126(lvl+"",8727); sendFrame126(name+" two-handed sword", 8767); sendFrame126(lvl+"",8728); sendFrame126(name+" halberd", 8768);
sendFrame126("bronze", 8846); sendFrame126("iron", 8823); sendFrame126("steel", 8824); sendFrame126("black", 8827); sendFrame126("mithril", 8837); sendFrame126("adamant", 8840); sendFrame126("rune", 8843); sendFrame126("bronze", 8846); sendFrame126("granite", 8859); sendFrame126("dragon", 8862); sendFrame126("barrows", 8865); sendFrame126("Others", 15303); sendFrame126("", 15306); sendFrame126("", 15309);
sendSkillInterface(id); sendFrame126("", 8849); showInterface(8714);}
public void attacki2(String name,int lvl, int id[]) {
sendFrame126("@dre@ATTACK", 8716); for(int i = 8720;i<8799;i++) { sendFrame126("",i);} sendFrame126(lvl+"",8720); sendFrame126(name+" maul",8760);
sendFrame126("bronze", 8846); sendFrame126("iron", 8823); sendFrame126("steel", 8824); sendFrame126("black", 8827); sendFrame126("mithril", 8837); sendFrame126("adamant", 8840); sendFrame126("rune", 8843); sendFrame126("granite", 8859); sendFrame126("dragon", 8862); sendFrame126("barrows", 8865); sendFrame126("Others", 15303); sendFrame126("", 15306); sendFrame126("", 15309);
sendSkillInterface(id); sendFrame126("", 8849); showInterface(8714);}
public void attacki4(int id[]) {
sendFrame126("@dre@ATTACK", 8716); for(int i = 8720;i<8799;i++) { sendFrame126("",i);}
sendFrame126("guthan spear", 8760); sendFrame126("dharok axe (with 70 strength)", 8761); sendFrame126("karil crossbow (with 70 range)", 8762); sendFrame126("torag hammer", 8763); sendFrame126("verac flain", 8764); sendFrame126("ahrim staff (with 70 magic)", 8765); sendFrame126("70", 8720); sendFrame126("70", 8721); sendFrame126("70", 8722); sendFrame126("70", 8723); sendFrame126("70", 8724); sendFrame126("70", 8725);
sendFrame126("bronze", 8846); sendFrame126("iron", 8823); sendFrame126("steel", 8824); sendFrame126("black", 8827); sendFrame126("mithril", 8837); sendFrame126("adamant", 8840); sendFrame126("rune", 8843); sendFrame126("bronze", 8846); sendFrame126("granite", 8859); sendFrame126("dragon", 8862); sendFrame126("barrows", 8865); sendFrame126("Others", 15303); sendFrame126("", 15306); sendFrame126("", 15309);
sendSkillInterface(id); sendFrame126("", 8849); showInterface(8714);}
public void attacki5(int id[]) {
sendFrame126("@dre@ATTACK", 8716); for(int i = 8720;i<8799;i++) { sendFrame126("",i);}
sendFrame126("abyssal whip", 8760); sendFrame126("skillcape", 8761); sendFrame126("1", 8720); sendFrame126("99", 8721);
sendFrame126("bronze", 8846); sendFrame126("iron", 8823); sendFrame126("steel", 8824); sendFrame126("black", 8827); sendFrame126("mithril", 8837); sendFrame126("adamant", 8840); sendFrame126("rune", 8843); sendFrame126("bronze", 8846); sendFrame126("granite", 8859); sendFrame126("dragon", 8862); sendFrame126("barrows", 8865); sendFrame126("Others", 15303); sendFrame126("", 15306); sendFrame126("", 15309);
sendSkillInterface(id); sendFrame126("", 8849); showInterface(8714);}
public void attack() { for(int i = 0;i<31;i++) { item[i] = 0;}
item[0] = 1205; item[1] = 1351; item[2] = 1422; item[3] = 3095; item[4] = 1277; item[5] = 1291; item[6] = 1321; item[7] = 1237; item[8] = 1337; item[9] = 1375; item[10] = 1307; item[11] = 3190;
attacki("bronze",1,item); sendFrame126("@red@bronze", 8846);}
public void attack1() { for(int i = 0;i<31;i++) { item[i] = 0;}
item[0] = 1203; item[1] = 1349; item[2] = 1420; item[3] = 3096; item[4] = 1279; item[5] = 1293; item[6] = 1323; item[7] = 1239; item[8] = 1335; item[9] = 1363; item[10] = 1309; item[11] = 3192;
attacki("iron",1,item); sendFrame126("@red@iron", 8823);}
public void attack2() { for(int i = 0;i<31;i++) { item[i] = 0;}
item[0] = 1207; item[1] = 1353; item[2] = 1424; item[3] = 3097; item[4] = 1281; item[5] = 1295; item[6] = 1325; item[7] = 1241; item[8] = 1339; item[9] = 1365; item[10] = 1311; item[11] = 3194;
attacki("steel",5,item); sendFrame126("@red@steel", 8824);}
public void attack3() { for(int i = 0;i<31;i++) { item[i] = 0;}
item[0] = 1217; item[1] = 1355; item[2] = 1426; item[3] = 3098; item[4] = 1283; item[5] = 1297; item[6] = 1327; item[7] = 1243; item[8] = 1341; item[9] = 1367; item[10] = 1313; item[11] = 3196;
attacki("black",10,item); sendFrame126("@red@black", 8827);}
public void attack4() { for(int i = 0;i<31;i++) { item[i] = 0;}
item[0] = 1209; item[1] = 1355; item[2] = 1428; item[3] = 3099; item[4] = 1285; item[5] = 1299; item[6] = 1329; item[7] = 1243; item[8] = 1343; item[9] = 1369; item[10] = 1315; item[11] = 3198;
attacki("mithril",20,item); sendFrame126("@red@mithril", 8837);}
public void attack5() { for(int i = 0;i<31;i++) { item[i] = 0;}
item[0] = 1211; item[1] = 1357; item[2] = 1430; item[3] = 3100; item[4] = 1287; item[5] = 1301; item[6] = 1331; item[7] = 1245; item[8] = 1345; item[9] = 1371; item[10] = 1317; item[11] = 3200;
attacki("adamant",30,item); sendFrame126("@red@adamant", 8840);}
public void attack6() { for(int i = 0;i<31;i++) { item[i] = 0;}
item[0] = 1213; item[1] = 1359; item[2] = 1432; item[3] = 3101; item[4] = 1289; item[5] = 1303; item[6] = 1333; item[7] = 1247; item[8] = 1347; item[9] = 1373; item[10] = 1319; item[11] = 3202;
attacki("rune",40,item); sendFrame126("@red@rune", 8843);}
public void attack7() { for(int i = 0;i<31;i++) { item[i] = 0;}
item[0] = 4153;
attacki2("granite",50,item); sendFrame126("@red@granite", 8859);}
public void attack8() { for(int i = 0;i<31;i++) { item[i] = 0;}
item[0] = 1215; item[1] = 6739; item[2] = 1434; item[3] = 1305; item[4] = 4587; item[5] = 1249; item[6] = 1377; item[7] = 7158; item[8] = 3204;
attacki3("dragon",60,item); sendFrame126("@red@dragon", 8862); sendFrame126("", 8849);}
public void attack9() { for(int i = 0;i<31;i++) { item[i] = 0;}
item[0] = 4726; item[1] = 4718; item[2] = 4734; item[3] = 4747; item[4] = 4755; item[5] = 4710;
attacki4(item); sendFrame126("@red@barrows", 8865); sendFrame126("", 8849);}
public void attack10() { for(int i = 0;i<31;i++) { item[i] = 0;}
item[0] = 4151;
attacki5(item); sendFrame126("@red@Others", 15303);}
//end of attack menu//
//strength menu//
public void strengthi(int id[]) {
sendFrame126("@dre@STRENGTH", 8716); for(int i = 8720;i<8799;i++) { sendFrame126("",i);}
sendFrame126("50", 8720); sendFrame126("70", 8721); sendFrame126("99", 8722);
sendFrame126("Obsidian maul", 8760); sendFrame126("Dharok axe", 8761); sendFrame126("Skillcape", 8762);
sendFrame126("", 8846); sendFrame126("", 8823); sendFrame126("", 8824); sendFrame126("", 8827); sendFrame126("", 8837); sendFrame126("", 8840); sendFrame126("", 8843); sendFrame126("", 8846); sendFrame126("", 8859); sendFrame126("", 8862); sendFrame126("", 8865); sendFrame126("", 15303); sendFrame126("", 15306); sendFrame126("", 15309);
sendSkillInterface(id); showInterface(8714);}
public void strength() { for(int i = 0;i<31;i++) { item[i] = 0; }
item[0] = 6528; item[1] = 4718;
sendFrame126("", 8849); strengthi(item);}
//end of strength menu//
//prayer menu//
public void prayeri(int id[]) {
sendFrame126("@dre@PRAYER", 8716); for(int i = 8720;i<8799;i++) { sendFrame126("",i);}
sendFrame126("1", 8720); sendFrame126("1", 8721); sendFrame126("1", 8722); sendFrame126("1", 8723);
sendFrame126("bones", 8760); sendFrame126("big bones", 8761); sendFrame126("jogre bones", 8762); sendFrame126("dragon bones", 8763);
sendFrame126("", 8846); sendFrame126("", 8823); sendFrame126("", 8824); sendFrame126("", 8827); sendFrame126("", 8837); sendFrame126("", 8840); sendFrame126("", 8843); sendFrame126("", 8846); sendFrame126("", 8859); sendFrame126("", 8862); sendFrame126("", 8865); sendFrame126("", 15303); sendFrame126("", 15306); sendFrame126("", 15309);
sendSkillInterface(id); showInterface(8714);}
public void prayerm() { for(int i = 0;i<31;i++) { item[i] = 0; }
item[0] = 526; item[1] = 532; item[2] = 3125; item[3] = 536;
sendFrame126("", 8849); prayeri(item);}
//end of prayer menu//
//runecrafting menu//
public void runecraftingi(int id[]) {
sendFrame126("@dre@RUNECRAFTING", 8716); for(int i = 8720;i<8799;i++) { sendFrame126("",i);}
sendFrame126("1", 8720); sendFrame126("50", 8721); sendFrame126("99", 8722);
sendFrame126("nature rune", 8760); sendFrame126("blood rune", 8761); sendFrame126("Skillcape", 8762);
sendFrame126("", 8846); sendFrame126("", 8823); sendFrame126("", 8824); sendFrame126("", 8827); sendFrame126("", 8837); sendFrame126("", 8840); sendFrame126("", 8843); sendFrame126("", 8846); sendFrame126("", 8859); sendFrame126("", 8862); sendFrame126("", 8865); sendFrame126("", 15303); sendFrame126("", 15306); sendFrame126("", 15309);
sendSkillInterface(id); showInterface(8714);}
public void runecrafting() { for(int i = 0;i<31;i++) { item[i] = 0; }
item[0] = 561; item[1] = 565;
sendFrame126("", 8849); runecraftingi(item);}
//end of runecrafting menu//
//magic menu//
public void magici(int id[]) {
sendFrame126("@dre@MAGIC", 8716); for(int i = 8720;i<8799;i++) { sendFrame126("",i);}
sendFrame126("1", 8720); sendFrame126("50", 8721); sendFrame126("52", 8722); sendFrame126("56", 8723); sendFrame126("58", 8724); sendFrame126("62", 8725); sendFrame126("64", 8726); sendFrame126("68", 8727); sendFrame126("70", 8728); sendFrame126("74", 8729); sendFrame126("76", 8730); sendFrame126("80", 8731); sendFrame126("82", 8732); sendFrame126("86", 8733); sendFrame126("88", 8734); sendFrame126("92", 8735); sendFrame126("94", 8736);
sendFrame126("High alch", 8760); sendFrame126("Smoke rush", 8761); sendFrame126("Shadow rush", 8762); sendFrame126("Blood rush", 8763); sendFrame126("Ice rush", 8764); sendFrame126("Smoke burst", 8765); sendFrame126("Shadow burst", 8766); sendFrame126("Blood burst", 8767); sendFrame126("Ice burst", 8768); sendFrame126("Smoke blitz", 8769); sendFrame126("Shadow blitz", 8770); sendFrame126("Blood blitz", 8771); sendFrame126("Ice blitz", 8772); sendFrame126("Smoke barrage", 8773); sendFrame126("Shadow barrage", 8774); sendFrame126("Blood barrage", 8775); sendFrame126("Ice barrage", 8776);
sendFrame126("", 8846); sendFrame126("@red@Spells", 8823); sendFrame126("Armour", 8824); sendFrame126("Others", 8827); sendFrame126("", 8837); sendFrame126("", 8840); sendFrame126("", 8843); sendFrame126("", 8846); sendFrame126("", 8859); sendFrame126("", 8862); sendFrame126("", 8865); sendFrame126("", 15303); sendFrame126("", 15306); sendFrame126("", 15309);
sendSkillInterface(id); showInterface(8714);}
public void magici2(int id[]) {
sendFrame126("@dre@MAGIC", 8716); for(int i = 8720;i<8799;i++) { sendFrame126("",i);}
sendFrame126("1", 8720); sendFrame126("1", 8721); sendFrame126("1", 8722); sendFrame126("1", 8723); sendFrame126("70", 8724); sendFrame126("99", 8725);
sendFrame126("Blue mystic", 8760); sendFrame126("White mystic", 8761); sendFrame126("Black mystic", 8762); sendFrame126("god cape", 8763); sendFrame126("ahrim (with 70 defence)", 8764); sendFrame126("Skillcape", 8765);
sendFrame126("", 8846); sendFrame126("Spells", 8823); sendFrame126("@red@Armour", 8824); sendFrame126("Others", 8827);
sendSkillInterface(id); showInterface(8714);}
public void magic() { for(int i = 0;i<31;i++) { item[i] = 0; }
item[0] = 561; item[1] = 565; item[2] = 565; item[3] = 565; item[4] = 565; item[5] = 565; item[6] = 565; item[7] = 565; item[8] = 565; item[9] = 565; item[10] = 565; item[11] = 565; item[12] = 565; item[13] = 565; item[14] = 565; item[15] = 565; item[16] = 565;
sendFrame126("", 8849); magici(item);}
public void magic1() { for(int i = 0;i<31;i++) { item[i] = 0; }
item[0] = 4089; item[1] = 4109; item[2] = 4099; item[3] = 2414; item[4] = 4710;
sendFrame126("", 8849); magici2(item);}
//end of magic menu//
//defence menu//
public void defencei(String name,int lvl, int id[]) {
sendFrame126("@dre@DEFENCE", 8716); for(int i = 8720;i<8799;i++) { sendFrame126("",i);}
sendFrame126(lvl+"", 8720); sendFrame126(lvl+"", 8721); sendFrame126(lvl+"", 8722); sendFrame126(lvl+"", 8723); sendFrame126(lvl+"", 8724); sendFrame126(lvl+"", 8725); sendFrame126(name+" full helmet", 8760); sendFrame126(name+" plate body", 8761); sendFrame126(name+" plate legs", 8762); sendFrame126(name+" plate skirt", 8763); sendFrame126(name+" kite shield", 8764); sendFrame126(name+" boots", 8765);
sendFrame126("bronze", 8846); sendFrame126("iron", 8823); sendFrame126("steel", 8824); sendFrame126("black", 8827); sendFrame126("mithril", 8837); sendFrame126("adamant", 8840); sendFrame126("rune", 8843); sendFrame126("granite", 8859); sendFrame126("dragon", 8862); sendFrame126("barrows", 8865); sendFrame126("Others", 15303); sendFrame126("", 15306); sendFrame126("", 15309);
sendSkillInterface(id); sendFrame126("", 8849); showInterface(8714);}
public void defencei1(String name,int lvl, int id[]) {
sendFrame126("@dre@DEFENCE", 8716); for(int i = 8720;i<8799;i++) { sendFrame126("",i);}
sendFrame126(lvl+"", 8720); sendFrame126(name+" shield", 8760);
sendFrame126("bronze", 8846); sendFrame126("iron", 8823); sendFrame126("steel", 8824); sendFrame126("black", 8827); sendFrame126("mithril", 8837); sendFrame126("adamant", 8840); sendFrame126("rune", 8843); sendFrame126("granite", 8859); sendFrame126("dragon", 8862); sendFrame126("barrows", 8865); sendFrame126("Others", 15303); sendFrame126("", 15306); sendFrame126("", 15309);
sendSkillInterface(id); sendFrame126("", 8849); showInterface(8714);}
public void defencei2(String name,int lvl, int id[]) {
sendFrame126("@dre@DEFENCE", 8716); for(int i = 8720;i<8799;i++) { sendFrame126("",i);}
sendFrame126(lvl+"", 8720); sendFrame126(lvl+"", 8721); sendFrame126(lvl+"", 8722); sendFrame126(lvl+"", 8723); sendFrame126(lvl+"", 8724); sendFrame126(name+" medium helmet", 8760); sendFrame126(name+" chain body", 8761); sendFrame126(name+" plate legs", 8762); sendFrame126(name+" plate skirt", 8763); sendFrame126(name+" square shield", 8764);
sendFrame126("bronze", 8846); sendFrame126("iron", 8823); sendFrame126("steel", 8824); sendFrame126("black", 8827); sendFrame126("mithril", 8837); sendFrame126("adamant", 8840); sendFrame126("rune", 8843); sendFrame126("granite", 8859); sendFrame126("dragon", 8862); sendFrame126("barrows", 8865); sendFrame126("Others", 15303); sendFrame126("", 15306); sendFrame126("", 15309);
sendSkillInterface(id); sendFrame126("", 8849); showInterface(8714);}
public void defencei3(int id[]) {
sendFrame126("@dre@DEFENCE", 8716); for(int i = 8720;i<8799;i++) { sendFrame126("",i);}
sendFrame126("70", 8720); sendFrame126("70", 8721); sendFrame126("70", 8722); sendFrame126("70", 8723); sendFrame126("70", 8724); sendFrame126("70", 8725); sendFrame126("guthan", 8760); sendFrame126("dharok", 8761); sendFrame126("karil (with 70 range)", 8762); sendFrame126("torag", 8763); sendFrame126("verac", 8764); sendFrame126("ahrim (with 70 magic)", 8765); 
sendFrame126("bronze", 8846); sendFrame126("iron", 8823); sendFrame126("steel", 8824); sendFrame126("black", 8827); sendFrame126("mithril", 8837); sendFrame126("adamant", 8840); sendFrame126("rune", 8843); sendFrame126("granite", 8859); sendFrame126("dragon", 8862); sendFrame126("barrows", 8865); sendFrame126("Others", 15303); sendFrame126("", 15306); sendFrame126("", 15309);
sendSkillInterface(id); sendFrame126("", 8849); showInterface(8714);}
public void defencei4(int id[]) {
sendFrame126("@dre@DEFENCE", 8716); for(int i = 8720;i<8799;i++) { sendFrame126("",i);}
sendFrame126("1", 8720); sendFrame126("1", 8721); sendFrame126("1", 8722); sendFrame126("1", 8723); sendFrame126("1", 8724); sendFrame126("1", 8725); sendFrame126("1", 8726); sendFrame126("10", 8727); sendFrame126("20", 8728); sendFrame126("30", 8729); sendFrame126("40", 8730); sendFrame126("50", 8731); sendFrame126("60", 8732); sendFrame126("99", 8733); sendFrame126("skeletal body", 8760); sendFrame126("skeletal legs", 8761); sendFrame126("obsidian cape", 8762); sendFrame126("obsidian shield", 8763); sendFrame126("legends cape", 8764); sendFrame126("cavalier", 8765); sendFrame126("leather (with 1 range)", 8766); sendFrame126("green dragon hide (with 10 range)", 8767); sendFrame126("blue dragon hide (with 20 range)", 8768); sendFrame126("red dragon hide (with 30 range)", 8769); sendFrame126("black dragon hide (with 40 range)", 8770); sendFrame126("snakeskin (with 50 range)", 8771); sendFrame126("spined (with 60 range)", 8772); sendFrame126("skillcape", 8773);
sendFrame126("bronze", 8846); sendFrame126("iron", 8823); sendFrame126("steel", 8824); sendFrame126("black", 8827); sendFrame126("mithril", 8837); sendFrame126("adamant", 8840); sendFrame126("rune", 8843); sendFrame126("granite", 8859); sendFrame126("dragon", 8862); sendFrame126("barrows", 8865); sendFrame126("Others", 15303); sendFrame126("", 15306); sendFrame126("", 15309);
sendSkillInterface(id); sendFrame126("", 8849); showInterface(8714);}
public void defence() { for(int i = 0;i<31;i++) { item[i] = 0;}
item[0] = 1155; item[1] = 1117; item[2] = 1075; item[3] = 1087; item[4] = 1189; item[5] = 4119;
defencei("bronze",1,item); sendFrame126("@red@bronze", 8846);}
public void defence1() { for(int i = 0;i<31;i++) { item[i] = 0;}
item[0] = 1153; item[1] = 1115; item[2] = 1067; item[3] = 1081; item[4] = 1191; item[5] = 4121;
defencei("iron",1,item); sendFrame126("@red@iron", 8823);}
public void defence2() { for(int i = 0;i<31;i++) { item[i] = 0;}
item[0] = 1157; item[1] = 1119; item[2] = 1069; item[3] = 1083; item[4] = 1193; item[5] = 4123;
defencei("steel",5,item); sendFrame126("@red@steel", 8824);}
public void defence3() { for(int i = 0;i<31;i++) { item[i] = 0;}
item[0] = 1165; item[1] = 1125; item[2] = 1077; item[3] = 1089; item[4] = 1195; item[5] = 4125;
defencei("black",10,item); sendFrame126("@red@black", 8827);}
public void defence4() { for(int i = 0;i<31;i++) { item[i] = 0;}
item[0] = 1159; item[1] = 1121; item[2] = 1071; item[3] = 1085; item[4] = 1197; item[5] = 4127;
defencei("mithril",20,item); sendFrame126("@red@mithril", 8837);}
public void defence5() { for(int i = 0;i<31;i++) { item[i] = 0;}
item[0] = 1161; item[1] = 1123; item[2] = 1073; item[3] = 1091; item[4] = 1199; item[5] = 4129;
defencei("adamant",30,item); sendFrame126("@red@adamant", 8840);}
public void defence6() { for(int i = 0;i<31;i++) { item[i] = 0;}
item[0] = 1163; item[1] = 1127; item[2] = 1079; item[3] = 1093; item[4] = 1201; item[5] = 4131;
defencei("rune",40,item); sendFrame126("@red@rune", 8843);}
public void defence7() { for(int i = 0;i<31;i++) { item[i] = 0;}
item[0] = 3122;
defencei1("granite",50,item); sendFrame126("@red@granite", 8859);}
public void defence8() { for(int i = 0;i<31;i++) { item[i] = 0;}
item[0] = 1149; item[1] = 3140; item[2] = 4087; item[3] = 4585; item[4] = 1187;
defencei2("dragon",60,item); sendFrame126("@red@dragon", 8862);}
public void defence9() { for(int i = 0;i<31;i++) { item[i] = 0;}
item[0] = 4724; item[1] = 4716; item[2] = 4732; item[3] = 4745; item[4] = 4753; item[5] = 4708;
defencei3(item); sendFrame126("@red@barrows", 8865);}
public void defence10() { for(int i = 0;i<31;i++) { item[i] = 0;}
item[0] = 6139; item[1] = 6141; item[2] = 6568; item[3] = 6524; item[4] = 1052; item[5] = 2643; item[6] = 1129; item[7] = 1135; item[8] = 2499; item[9] = 2501; item[10] = 2503; item[11] = 6322; item[12] = 6133;
defencei4(item); sendFrame126("@red@Others", 15303);}
//end of defence menu//
//range menu//
public void rangei(int id[]) {
sendFrame126("@dre@RANGE", 8716); for(int i = 8720;i<8799;i++) { sendFrame126("",i);}
sendFrame126("1", 8720); sendFrame126("1", 8721); sendFrame126("1", 8722); sendFrame126("1", 8723); sendFrame126("1", 8724); sendFrame126("1", 8725); sendFrame126("1", 8726); sendFrame126("1", 8727); sendFrame126("1", 8728); sendFrame126("1", 8729); sendFrame126("1", 8730); sendFrame126("1", 8731); sendFrame126("1", 8732); sendFrame126("70", 8733); sendFrame126("shortbow", 8760); sendFrame126("longbow", 8761); sendFrame126("oak shortbow", 8762); sendFrame126("oak longbow", 8763); sendFrame126("willow shortbow", 8764); sendFrame126("willow longbow", 8765); sendFrame126("maple shortbow", 8766); sendFrame126("maple longbow", 8767); sendFrame126("yew shortbow", 8768); sendFrame126("yew longbow", 8769); sendFrame126("magic shortbow", 8770); sendFrame126("magic longbow", 8771); sendFrame126("crystal bow", 8772); sendFrame126("karil crossbow (with 70 attack)", 8773);
sendFrame126("Bows", 8823); sendFrame126("Arrows", 8824); sendFrame126("Armour", 8827);
sendSkillInterface(id); sendFrame126("", 8849); showInterface(8714);}
public void rangei1(int id[]) {
sendFrame126("@dre@RANGE", 8716); for(int i = 8720;i<8799;i++) { sendFrame126("",i);}
sendFrame126("1", 8720); sendFrame126("1", 8721); sendFrame126("1", 8722); sendFrame126("1", 8723); sendFrame126("1", 8724); sendFrame126("1", 8725); sendFrame126("70", 8726); sendFrame126("bronze", 8760); sendFrame126("iron", 8761); sendFrame126("steel", 8762); sendFrame126("mithril", 8763); sendFrame126("adamant", 8764); sendFrame126("rune", 8765); sendFrame126("bolt rack", 8766);
sendFrame126("Bows", 8823); sendFrame126("Arrows", 8824); sendFrame126("Armour", 8827);
sendSkillInterface(id); sendFrame126("", 8849); showInterface(8714);}
public void rangei2(int id[]) {
sendFrame126("@dre@RANGE", 8716); for(int i = 8720;i<8799;i++) { sendFrame126("",i);}
sendFrame126("1", 8720); sendFrame126("10", 8721); sendFrame126("20", 8722); sendFrame126("30", 8723); sendFrame126("40", 8724); sendFrame126("50", 8725); sendFrame126("60", 8726); sendFrame126("70", 8727); sendFrame126("99", 8728); sendFrame126("leather (with 1 defence)", 8760); sendFrame126("green dragon hide (with 10 defence)", 8761); sendFrame126("blue dragon hide (with 20 defence)", 8762); sendFrame126("red dragon hide (with 30 defence)", 8763); sendFrame126("black dragon hide (with 40 defence)", 8764); sendFrame126("snakeskin (with 50 defence)", 8765); sendFrame126("spined (with 60 defence)", 8766); sendFrame126("karil (with 70 defence)", 8767); sendFrame126("skillcape", 8768);
sendFrame126("Bows", 8823); sendFrame126("Arrows", 8824); sendFrame126("Armour", 8827);
sendSkillInterface(id); sendFrame126("", 8849); showInterface(8714);}
public void range() { for(int i = 0;i<31;i++) { item[i] = 0;}
item[0] = 841; item[1] = 843; item[2] = 845; item[3] = 847; item[4] = 849; item[5] = 851; item[6] = 853; item[7] = 855; item[8] = 857; item[9] = 861; item[10] = 4214; item[11] = 4734;
rangei(item); sendFrame126("@red@Bows", 8823);}
public void range1() { for(int i = 0;i<31;i++) { item[i] = 0;}
item[0] = 882; item[1] = 884; item[2] = 886; item[3] = 888; item[4] = 890; item[5] = 892; item[6] = 4740;
rangei1(item); sendFrame126("@red@Armour", 8827);}
public void range2() { for(int i = 0;i<31;i++) { item[i] = 0;}
item[0] = 1129; item[1] = 1135; item[2] = 2499; item[3] = 2501; item[4] = 2503; item[5] = 6322; item[6] = 6133; item[7] = 4732;
rangei2(item); sendFrame126("@red@Armour", 8827);}
//end of range menu//
public void questtest() {
		clearQuestInterface();
		sendQuest("Close Window", 4912);
		sendQuest("@or1@Congratulations!", 4913);
		sendQuest("You have completed Rune Mysteries", 4911);
		sendQuest("You are rewarded:", 4914);
		sendQuest("1 Quest Point, Air talisman, Runecrafting skill", 4915);
		sendQuest("", 4918);
		sendQuest("@or1@Quest Points: 1", 4916);
		showInterface(4909);
		flushOutStream();}
public void steal1() {

startAnimation(881);
makeGlobalObject(StallX1, StallY1, emptyid, 3, 10);
    sendMessage("You steal some runes");
int[] items = { 561, 561, 561, 565, 565, 561, 561, 561 };
int r = (int) (Math.random() * items.length);
addItem(items[r], 2);
    addSkillXP(2000, 17);



EventManager.getSingleton().addEvent(
                new Event() {
                    public void execute(EventContainer C) {


		    makeGlobalObject(StallX1, StallY1, StallId1, 3, 10);
            
                         
			 C.stop();
                    }
                }, 10000);


}
public void steal2() {

startAnimation(881);
makeGlobalObject(StallX2, StallY2, emptyid, 3, 10);
    sendMessage("You steal some herbs.");
int[] items = { 249, 251, 253, 255, 257 ,259 ,261, 263, 265, 267, 269, 3000,2998};
int r = (int) (Math.random() * items.length);
addItem(items[r], misc.random(playerLevel[17]));
    addSkillXP(5000, 17);


EventManager.getSingleton().addEvent(
                new Event() {
                    public void execute(EventContainer C) {


		    makeGlobalObject(StallX2, StallY2, StallId2, 3, 10);
            
                         
			 C.stop();
                    }
                }, 15000);


}
public void steal3() {

startAnimation(881);
makeGlobalObject(StallX3, StallY3, emptyid, 3, 10);
    sendMessage("You steal some gems.");
int[] items = { 1617, 1617, 1617, 1617, 1617, 1619, 1619, 1619, 1619, 1619, 1621, 1621, 1621, 1621, 1621, 1621, 1623, 1623, 1623, 1623, 1623, 1631 };
int r = (int) (Math.random() * items.length);
addItem(items[r], misc.random(playerLevel[17]));
    addSkillXP(10000, 17);



EventManager.getSingleton().addEvent(
                new Event() {
                    public void execute(EventContainer C) {


		    makeGlobalObject(StallX3, StallY3, StallId3, 3, 10);
            
                         
			 C.stop();
                    }
                }, 120000);


}
public void levelup(int skill) {
		switch (skill) {
case 0:
			// Attack
			sendFrame164(6247);
			sendFrame126("Congratulations, you just advanced an attack level!",
					6248);
			sendFrame126("Your attack level is now " + playerLevel[0] + ".",
					6249);
			sendMessage("Congratulations, you just advanced an attack level.");
			NpcDialogueSend = true;
			break;

		case 2:
			// Strength
if (playerLevel[2] < 99) {
			sendFrame164(6206);
			sendFrame126(
					"Congratulations, you just advanced a strength level!",
					6207);
			sendFrame126("Your strength level is now " + playerLevel[2] + ".",
					6208);
			sendMessage("Congratulations, you just advanced a strength level.");
			NpcDialogueSend = true;
} else {
			sendFrame164(6206);
			sendFrame126(
					"Congratulations, you just advanced a strength level!",
					6207);
			sendFrame126("You just advanced highest level in strength!",
					6208);
			sendMessage("Congratulations, you just advanced a strength level.");
			NpcDialogueSend = true;
}
			break;

		case 1:
			// Defence
			sendFrame164(6253);
			sendFrame126("Congratulations, you just advanced a defence level!",
					6254);
			sendFrame126("Your defence level is now " + playerLevel[1] + ".",
					6255);
			sendMessage("Congratulations, you just advanced a defence level.");
			NpcDialogueSend = true;
			break;

		case 3:
			// Hitpoints
			sendFrame164(6216);
			sendFrame126(
					"Congratulations, you just advanced a hitpoints level!",
					6217);
			sendFrame126("Your hitpoints level is now " + playerLevel[3] + ".",
					6218);
			sendMessage("Congratulations, you just advanced a hitpoints level.");
			NpcDialogueSend = true;
			break;

		case 4:
			// Ranging
			sendFrame164(4443);
			sendFrame126("Congratulations, you just advanced a ranged level!",
					4444);
			sendFrame126("Your ranged level is now " + playerLevel[4] + ".",
					4445);
			sendMessage("Congratulations, you just advanced a ranging level.");
			NpcDialogueSend = true;
			break;

		case 5:
			// Prayer
			sendFrame164(6242);
			sendFrame126("Congratulations, you just advanced a prayer level!",
					6243);
			sendFrame126("Your prayer level is now " + playerLevel[5] + ".",
					6244);
			sendMessage("Congratulations, you just advanced a prayer level.");
			NpcDialogueSend = true;
			break;

		case 6:
			// Magic
			sendFrame164(6211);
			sendFrame126("Congratulations, you just advanced a magic level!",
					6212);
			sendFrame126("Your magic level is now " + playerLevel[6] + ".",
					6213);
			sendMessage("Congratulations, you just advanced a magic level.");
			NpcDialogueSend = true;
			break;

		case 7:
			// Cooking
			sendFrame164(6226);
			sendFrame126("Congratulations, you just advanced a cooking level!",
					6227);
			sendFrame126("Your cooking level is now " + playerLevel[7] + ".",
					6228);
			sendMessage("Congratulations, you just advanced a cooking level.");
			NpcDialogueSend = true;
			break;

		case 8:
			// Woodcutting
			sendFrame164(4272);
			sendFrame126(
					"Congratulations, you just advanced a woodcutting level!",
					4273);
			sendFrame126("Your woodcutting level is now " + playerLevel[8]
					+ ".", 4274);
			sendMessage("Congratulations, you just advanced a woodcutting level.");
			NpcDialogueSend = true;
			break;

		case 9:
			// Fletching
			sendFrame164(6231);
			sendFrame126(
					"Congratulations, you just advanced a fletching level!",
					6232);
			sendFrame126("Your fletching level is now " + playerLevel[9] + ".",
					6233);
			sendMessage("Congratulations, you just advanced a fletching level.");
			NpcDialogueSend = true;
			break;

		case 10:
			// fishing
			sendFrame164(6258);
			sendFrame126("Congratulations, you just advanced a fishing level!",
					6259);
			sendFrame126("Your fishing level is now " + playerLevel[10] + ".",
					6260);
			sendMessage("Congratulations, you just advanced a fishing level.");
			NpcDialogueSend = true;
			break;

		case 11:
			// firemaking
			sendFrame164(4282);
			sendFrame126(
					"Congratulations, you just advanced a fire making level!",
					4283);
			sendFrame126("Your firemaking level is now " + playerLevel[11]
					+ ".", 4284);
			sendMessage("Congratulations, you just advanced a fire making level.");
			NpcDialogueSend = true;
			break;

		case 12:
			// crafting
			sendFrame164(6263);
			sendFrame126(
					"Congratulations, you just advanced a crafting level!",
					6264);
			sendFrame126("Your crafting level is now " + playerLevel[12] + ".",
					6265);
			sendMessage("Congratulations, you just advanced a crafting level.");
			NpcDialogueSend = true;
			break;

		case 13:
			// Smithing
			sendFrame164(6221);
			sendFrame126(
					"Congratulations, you just advanced a smithing level!",
					6222);
			sendFrame126("Your smithing level is now " + playerLevel[13] + ".",
					6223);
			sendMessage("Congratulations, you just advanced a smithing level.");
			NpcDialogueSend = true;
			break;

		case 14:
			// Mining
			sendFrame164(4416);
			sendFrame126("Congratulations, you just advanced a mining level!",
					4417);
			sendFrame126("Your slayer level is now " + playerLevel[14] + ".", 4438);
			sendMessage("Congratulations, you just advanced a mining level.");
			NpcDialogueSend = true;
			break;

		case 15:
			// Herblore
			sendFrame164(6237);
			sendFrame126(
					"Congratulations, you just advanced a herblore level!",
					6238);
			sendFrame126("Your herblore level is now " + playerLevel[15] + ".",
					6239);
			sendMessage("Congratulations, you just advanced a herblore level.");
			NpcDialogueSend = true;
			break;

		case 16:
			// Agility
			sendFrame164(4277);
			sendFrame126("Congratulations, you just advanced a agility level!",
					4278);
			sendFrame126("Your agility level is now " + playerLevel[16] + ".",
					4279);
			sendMessage("Congratulations, you just advanced an agility level.");
			NpcDialogueSend = true;
			break;

		case 17:
			// Thieving
			sendFrame164(4261);
			sendFrame126(
					"Congratulations, you just advanced a thieving level!",
					4263);
			sendFrame126("Your thieving level is now " + playerLevel[17] + ".", 4264);
			sendMessage("Congratulations, you just advanced a thieving level.");
			NpcDialogueSend = true;
			break;

		case 18:
			// Slayer
			sendFrame164(12123);
			sendFrame126("Congratulations, you just advanced a slayer level!",
					12124);
			sendFrame126("Your slayer level is now " + playerLevel[18] + ".",
					12125);
			sendMessage("Congratulations, you just advanced a slayer level.");
			NpcDialogueSend = true;
			break;

		case 19:
			// Farming
sendFrame164(4261);
			sendFrame126("Congratulations, you just advanced a thieving level!", 4262);
			sendFrame126("Your farming level is now "+playerLevel[19]+" .", 4263);
			sendMessage("Congratulations, you just advanced a farming level.");
			NpcDialogueSend = true;
			break;

		case 20:
			// Runecrafting
			sendFrame164(4267);
			sendFrame126(
					"Congratulations, you just advanced a runecrafting level!",
					4268);
			sendFrame126("Your runecrafting level is now " + playerLevel[20]
					+ ".", 4269);
			sendMessage("Congratulations, you just advanced a runecrafting level.");
			NpcDialogueSend = true;
			break;

		}
	}

	public void Reset() {
                playerXP[0] = 0;
                playerLevel[0] = getLevelForXP(playerXP[0]);
                playerXP[1] = 0;
                playerLevel[1] = getLevelForXP(playerXP[1]);
                playerXP[2] = 0;
                playerLevel[2] = getLevelForXP(playerXP[2]);
                playerXP[3] = 1155;
                playerLevel[3] = getLevelForXP(playerXP[3]);
                playerXP[4] = 0;
                playerLevel[4] = getLevelForXP(playerXP[4]);
                playerXP[5] = 0;
                playerLevel[5] = getLevelForXP(playerXP[5]);
                playerXP[6] = 0;
                playerLevel[6] = getLevelForXP(playerXP[6]);
                playerXP[7] = 0;
                playerLevel[7] = getLevelForXP(playerXP[7]);
                playerXP[8] = 0;
                playerLevel[8] = getLevelForXP(playerXP[8]);
                playerXP[9] = 0;
                playerLevel[9] = getLevelForXP(playerXP[9]);
                playerXP[10] = 0;
                playerLevel[10] = getLevelForXP(playerXP[10]);
                playerXP[11] = 0;
                playerLevel[11] = getLevelForXP(playerXP[11]);
                playerXP[12] = 0;
                playerLevel[12] = getLevelForXP(playerXP[12]);
                playerXP[13] = 0;
                playerLevel[13] = getLevelForXP(playerXP[13]);
                playerXP[14] = 0;
                playerLevel[14] = getLevelForXP(playerXP[14]);
                playerXP[15] = 0;
                playerLevel[15] = getLevelForXP(playerXP[15]);
                playerXP[16] = 0;
                playerLevel[16] = getLevelForXP(playerXP[16]);
                playerXP[17] = 0;
                playerLevel[17] = getLevelForXP(playerXP[17]);
                playerXP[18] = 0;
                playerLevel[18] = getLevelForXP(playerXP[18]);
                playerXP[19] = 0;
                playerLevel[19] = getLevelForXP(playerXP[19]);
                playerXP[20] = 0;
                playerLevel[20] = getLevelForXP(playerXP[20]);
                playerXP[21] = 0;
                playerLevel[21] = getLevelForXP(playerXP[21]);
                playerXP[22] = 0;
                playerLevel[22] = getLevelForXP(playerXP[22]);
                playerXP[23] = 0;
                playerLevel[23] = getLevelForXP(playerXP[23]);
                playerXP[24] = 0;
                playerLevel[24] = getLevelForXP(playerXP[24]);
		refreshSkills();
	}

  public void wipeBank() {
    for (int i = 0; i < playerBankSize; i++) {
      bankItems[i] = 0;
    }
    for (int i = 0; i < bankItemsN.length; i++) {
      bankItemsN[i] = 0;
    }
                resetBank();
                resetItems(5064);
  }
	
public boolean validRights() {
	if(playerRights == 0 || playerRights == 3) {
	return true;
	}
	return false;
	}

    /* SMITHING*/

    public void ReplaceItems(int newID, int oldID, int newAmount, int oldAmount) {
        for (int i = 0; i < playerItems.length; i++) {
            if (playerItems[i] == oldID + 1 && oldAmount > 0) {
                playerItems[i] = 0;
                oldAmount--;
                resetItems(3214);
            }
        }
        if (oldAmount == 0) {
            addItem(newID, newAmount);
        }
    }
    public int removeBar(int removeID) {
        if (removeID == 1205 || removeID == 1351 || removeID == 1103
                || removeID == 1139 || removeID == 819 || removeID == 1277
                || removeID == 1422 || removeID == 1075 || removeID == 1155
                || removeID == 39 || removeID == 1321 || removeID == 1337
                || removeID == 1087 || removeID == 1173 || removeID == 864
                || removeID == 1291 || removeID == 1375 || removeID == 1117
                || removeID == 1189 || removeID == 1307 || removeID == 3095
                || removeID == 4819) {
            return 2349;
        }
        if (removeID == 1203 || removeID == 1349 || removeID == 1420
                || removeID == 1137 || removeID == 1279 || removeID == 820
                || removeID == 4820 || removeID == 1323 || removeID == 40
                || removeID == 1293 || removeID == 1153 || removeID == 863
                || removeID == 1175 || removeID == 1335 || removeID == 1363
                || removeID == 1101 || removeID == 4540 || removeID == 1191
                || removeID == 3096 || removeID == 1309 || removeID == 1067
                || removeID == 1081 || removeID == 1115) {
            return 2351;
        }
        if (removeID == 1207 || removeID == 3097 || removeID == 1353
                || removeID == 1424 || removeID == 1141 || removeID == 1281
                || removeID == 1325 || removeID == 1295 || removeID == 1157
                || removeID == 1177 || removeID == 1339 || removeID == 1365
                || removeID == 1105 || removeID == 1193 || removeID == 1069
                || removeID == 1083 || removeID == 1311 || removeID == 1119
                || removeID == 1539 || removeID == 821 || removeID == 41
                || removeID == 2 || removeID == 2370 || removeID == 865
                || removeID == 4544) {
            return 2353;
        }
        // Mith
        if (removeID == 1209 || removeID == 3099 || removeID == 1355
                || removeID == 1428 || removeID == 1143 || removeID == 1285
                || removeID == 1329 || removeID == 1299 || removeID == 1159
                || removeID == 1181 || removeID == 1343 || removeID == 1369
                || removeID == 1109 || removeID == 1197 || removeID == 1071
                || removeID == 1085 || removeID == 1315 || removeID == 1121
                || removeID == 822 || removeID == 4822 || removeID == 42
                || removeID == 42 || removeID == 866) {
            return 2359;
        }
        // Addy
        if (removeID == 1211 || removeID == 3100 || removeID == 1430
                || removeID == 1145 || removeID == 1287 || removeID == 1331
                || removeID == 1301 || removeID == 1161 || removeID == 1183
                || removeID == 1371 || removeID == 1111 || removeID == 1073
                || removeID == 1091 || removeID == 1317 || removeID == 1123
                || removeID == 823 || removeID == 4823 || removeID == 43
                || removeID == 867 || removeID == 1199) {
            return 2361;
        }
        // Rune
        if (removeID == 1213 || removeID == 3101 || removeID == 1432
                || removeID == 1147 || removeID == 1289 || removeID == 1333
                || removeID == 1303 || removeID == 1163 || removeID == 1185
                || removeID == 1347 || removeID == 1373 || removeID == 1113
                || removeID == 1201 || removeID == 1079 || removeID == 1093
                || removeID == 1319 || removeID == 1127 || removeID == 824
                || removeID == 4824 || removeID == 44 || removeID == 868) {
            return 2363;
        }
        return 0;
    }

    public int barsNeeded(int slot, int column) {
        if (column == 1119) {
            if (slot == 0 || slot == 1) {
                return 1;
            }
            if (slot == 2 || slot == 3) {
                return 2;
            }
            if (slot == 4) {
                return 3;
            }
        }
        if (column == 1120) {
            if (slot == 0 || slot == 1) {
                return 1;
            }
            if (slot == 2 || slot == 3) {
                return 3;
            }
            if (slot == 4) {
                return 2;
            }
        }
        if (column == 1121) {
            if (slot == 0 || slot == 1 || slot == 2) {
                return 3;
            }
            if (slot == 3) {
                return 5;
            }
            if (slot == 4) {
                return 1;
            }
        }
        if (column == 1122) {
            if (slot == 0 || slot == 4) {
                return 1;
            }
            if (slot == 1 || slot == 2) {
                return 2;
            }
            if (slot == 3) {
                return 3;
            }
        }
        if (column == 1123) {
            if (slot == 0 || slot == 1 || slot == 2 || slot == 3 || slot == 4) {
                return 1;
            }
        }
        return 0;
    }

    public int barsNeeded2(int slot, int column) {
        if (column == 1119) {
            if (slot == 0 || slot == 1) {
                return 5;
            }
            if (slot == 2 || slot == 3) {
                return 10;
            }
            if (slot == 4) {
                return 15;
            }
        }
        if (column == 1120) {
            if (slot == 0 || slot == 1) {
                return 5;
            }
            if (slot == 2 || slot == 3) {
                return 15;
            }
            if (slot == 4) {
                return 10;
            }
        }
        if (column == 1121) {
            if (slot == 0 || slot == 1 || slot == 2) {
                return 15;
            }
            if (slot == 3) {
                return 25;
            }
            if (slot == 4) {
                return 5;
            }
        }
        if (column == 1122) {
            if (slot == 0 || slot == 4) {
                return 5;
            }
            if (slot == 1 || slot == 2) {
                return 10;
            }
            if (slot == 3) {
                return 15;
            }
        }
        if (column == 1123) {
            if (slot == 0 || slot == 1 || slot == 2 || slot == 3 || slot == 4) {
                return 5;
            }
        }
        return 0;
    }

    public int barsNeeded3(int slot, int column) {
        if (column == 1119) {
            if (slot == 0 || slot == 1) {
                return 10;
            }
            if (slot == 2 || slot == 3) {
                return 20;
            }
            if (slot == 4) {
                return 30;
            }
        }
        if (column == 1120) {
            if (slot == 0 || slot == 1) {
                return 10;
            }
            if (slot == 2 || slot == 3) {
                return 30;
            }
            if (slot == 4) {
                return 20;
            }
        }
        if (column == 1121) {
            if (slot == 0 || slot == 1 || slot == 2) {
                return 30;
            }
            if (slot == 3) {
                return 50;
            }
            if (slot == 4) {
                return 10;
            }
        }
        if (column == 1122) {
            if (slot == 0 || slot == 4) {
                return 10;
            }
            if (slot == 1 || slot == 2) {
                return 20;
            }
            if (slot == 3) {
                return 30;
            }
        }
        if (column == 1123) {
            if (slot == 0 || slot == 1 || slot == 2 || slot == 3 || slot == 4) {
                return 10;
            }
        }
        return 0;
    }

    public int smithXP(int barType, int barAmount) {
        if (barType == 2349) {
            return barAmount * 29;
        }
        if (barType == 2351) {
            return barAmount * 25;
        }
        if (barType == 2353) {
            return barAmount * 38;
        }
        if (barType == 2359) {
            return barAmount * 50;
        }
        if (barType == 2361) {
            return barAmount * 75;
        }
        if (barType == 2363) {
            return barAmount * 75;
        }
        setAnimation(898);
        return 0;
    }

    public boolean canSmith(int item) {
        if (item == 1205 || item == 1351 && playerLevel[13] >= 1) {
            return true;
        }
        if (item == 1422 && playerLevel[13] >= 2) {
            return true;
        }
        if (item == 1139 && playerLevel[13] >= 3) {
            return true;
        }
        if (item == 1277 || item == 819 && playerLevel[13] >= 4) {
            return true;
        }
        if (item == 1321 || item == 39 && playerLevel[13] >= 5) {
            return true;
        }
        if (item == 1291 && playerLevel[13] >= 6) {
            return true;
        }
        if (item == 1155 || item == 864 && playerLevel[13] >= 7) {
            return true;
        }
        if (item == 1173 && playerLevel[13] >= 8) {
            return true;
        }
        if (item == 1337 && playerLevel[13] >= 9) {
            return true;
        }
        if (item == 1375 && playerLevel[13] >= 10) {
            return true;
        }
        if (item == 1103 && playerLevel[13] >= 11) {
            return true;
        }
        if (item == 1189 && playerLevel[13] >= 12) {
            return true;
        }
        if (item == 3095 && playerLevel[13] >= 13) {
            return true;
        }
        if (item == 1307 && playerLevel[13] >= 14) {
            return true;
        }
        if (item == 1203 && playerLevel[13] >= 15) {
            return true;
        }
        if (item == 1087 || item == 1075
                || item == 1349 && playerLevel[13] >= 16) {
            return true;
        }
        if (item == 1420 && playerLevel[13] >= 17) {
            return true;
        }
        if (item == 1117 || item == 1137 && playerLevel[13] >= 18) {
            return true;
        }
        if (item == 1279 || item == 820 || item == 4820 && playerLevel[13] >= 19) {
            return true;
        }
        if (item == 1323 || item == 40 && playerLevel[13] >= 20) {
            return true;
        }
        if (item == 1293 && playerLevel[13] >= 21) {
            return true;
        }
        if (item == 1153 || item == 863 && playerLevel[13] >= 22) {
            return true;
        }
        if (item == 1175 && playerLevel[13] >= 23) {
            return true;
        }
        if (item == 1335 && playerLevel[13] >= 24) {
            return true;
        }
        if (item == 1363 && playerLevel[13] >= 25) {
            return true;
        }
        if (item == 1101 || item == 4540 && playerLevel[13] >= 26) {
            return true;
        }
        if (item == 1191 && playerLevel[13] >= 27) {
            return true;
        }
        if (item == 3096 && playerLevel[13] >= 28) {
            return true;
        }
        if (item == 1309 && playerLevel[13] >= 29) {
            return true;
        }
        if (item == 1207 && playerLevel[13] >= 30) {
            return true;
        }
        if (item == 1067 || item == 1081
                || item == 1353 && playerLevel[13] >= 31) {
            return true;
        }
        if (item == 1424 && playerLevel[13] >= 32) {
            return true;
        }
        if (item == 1115 || item == 1141 && playerLevel[13] >= 33) {
            return true;
        }
        if (item == 1281 || item == 1539 || item == 821 && playerLevel[13] >= 34) {
            return true;
        }
        if (item == 1325 || item == 41 && playerLevel[13] >= 35) {
            return true;
        }
        if (item == 1295 || item == 2370 && playerLevel[13] >= 36) {
            return true;
        }
        if (item == 1157 || item == 865 && playerLevel[13] >= 37) {
            return true;
        }
        if (item == 1177 && playerLevel[13] >= 38) {
            return true;
        }
        if (item == 1339 && playerLevel[13] >= 39) {
            return true;
        }
        if (item == 1365 && playerLevel[13] >= 40) {
            return true;
        }
        if (item == 1105 && playerLevel[13] >= 41) {
            return true;
        }
        if (item == 1193 && playerLevel[13] >= 42) {
            return true;
        }
        if (item == 3097 && playerLevel[13] >= 43) {
            return true;
        }
        if (item == 1311 && playerLevel[13] >= 44) {
            return true;
        }
        if (item == 1069 || item == 1083 && playerLevel[13] >= 46) {
            return true;
        }
        if (item == 1119 && playerLevel[13] >= 48) {
            return true;
        }
        if (item == 4544 && playerLevel[13] >= 49) {
            return true;
        }
        if (item == 1209 && playerLevel[13] >= 50) {
            return true;
        }
        if (item == 1355 && playerLevel[13] >= 51) {
            return true;
        }
        if (item == 1428 && playerLevel[13] >= 52) {
            return true;
        }
        if (item == 1143 && playerLevel[13] >= 53) {
            return true;
        }
        if (item == 1285 || item == 822 || item == 4822 && playerLevel[13] >= 54) {
            return true;
        }
        if (item == 1329 || item == 42 && playerLevel[13] >= 55) {
            return true;
        }
        if (item == 1299 && playerLevel[13] >= 56) {
            return true;
        }
        if (item == 1159 || item == 866 && playerLevel[13] >= 57) {
            return true;
        }
        if (item == 1181 && playerLevel[13] >= 58) {
            return true;
        }
        if (item == 1343 && playerLevel[13] >= 59) {
            return true;
        }
        if (item == 1369 && playerLevel[13] >= 60) {
            return true;
        }
        if (item == 1109 && playerLevel[13] >= 61) {
            return true;
        }
        if (item == 1197 && playerLevel[13] >= 62) {
            return true;
        }
        if (item == 3099 && playerLevel[13] >= 63) {
            return true;
        }
        if (item == 1315 && playerLevel[13] >= 64) {
            return true;
        }
        if (item == 1071 || item == 1085 && playerLevel[13] >= 66) {
            return true;
        }
        if (item == 1121 && playerLevel[13] >= 68) {
            return true;
        }
        if (item == 1211 && playerLevel[13] >= 70) {
            return true;
        }
        if (item == 1430 && playerLevel[13] >= 72) {
            return true;
        }
        if (item == 1145 && playerLevel[13] >= 73) {
            return true;
        }
        if (item == 1287 || item == 823 || item == 4823 && playerLevel[13] >= 74) {
            return true;
        }
        if (item == 1331 || item == 43 && playerLevel[13] >= 75) {
            return true;
        }
        if (item == 1301 && playerLevel[13] >= 76) {
            return true;
        }
        if (item == 1161 || item == 867 && playerLevel[13] >= 77) {
            return true;
        }
        if (item == 1183 && playerLevel[13] >= 78) {
            return true;
        }
        if (item == 1371 && playerLevel[13] >= 79) {
            return true;
        }
        if (item == 1111 && playerLevel[13] >= 81) {
            return true;
        }
        if (item == 1199 && playerLevel[13] >= 82) {
            return true;
        }
        if (item == 3100 && playerLevel[13] >= 83) {
            return true;
        }
        if (item == 1317 && playerLevel[13] >= 84) {
            return true;
        }
        if (item == 1213 && playerLevel[13] >= 85) {
            return true;
        }
        if (item == 1073 || item == 1091 || item == 1359 && playerLevel[13] >= 86) {
            return true;
        }
        if (item == 1432 && playerLevel[13] >= 87) {
            return true;
        }
        if (item == 1123 || item == 1147 && playerLevel[13] >= 88) {
            return true;
        }
        if (item == 1289 || item == 824 || item == 4824 && playerLevel[13] >= 89) {
            return true;
        }
        if (item == 1333 || item == 44 && playerLevel[13] >= 90) {
            return true;
        }
        if (item == 1303 && playerLevel[13] >= 91) {
            return true;
        }
        if (item == 1163 || item == 868 && playerLevel[13] >= 92) {
            return true;
        }
        if (item == 1185 && playerLevel[13] >= 93) {
            return true;
        }
        if (item == 1347 && playerLevel[13] >= 94) {
            return true;
        }
        if (item == 1373 && playerLevel[13] >= 95) {
            return true;
        }
        if (item == 1113 && playerLevel[13] >= 96) {
            return true;
        }
        if (item == 1201 && playerLevel[13] >= 97) {
            return true;
        }
        if (item == 3101 && playerLevel[13] >= 98) {
            return true;
        }
        if (item == 1319 && playerLevel[13] >= 99) {
            return true;
        }
        if (item == 1079 && playerLevel[13] >= 99) {
            return true;
        }
        if (item == 1079 || item == 1093 || item == 1319 || item == 1127 && playerLevel[13] >= 99) {
            return true;
        } else {
            return false;
        }
    }

    public void addItemToSmith(int id, int slot, int column, int amount) {
        outStream.createFrameVarSizeWord(34); // init item to smith screen
        outStream.writeWord(column); // Column Across Smith Screen
        outStream.writeByte(4); // Total Rows?
        outStream.writeDWord(slot); // Row Down The Smith Screen
        outStream.writeWord(id + 1); // item
        outStream.writeByte(amount); // how many there are?
        outStream.endFrameVarSizeWord();

    }


    public void initSmithing(int barType) {
        outStream.createFrame(97);
        outStream.writeWord(994);
        if (amountOfItem(barType) < 5) {
            sendQuest("@red@5bars@red@", 1112);
        } else {
            sendQuest("@gre@5bars@gre@", 1112);
        }
        if (amountOfItem(barType) < 3) {
            sendQuest("@red@3bars@red@", 1109);
            sendQuest("@red@3bars@red@", 1110);
            sendQuest("@red@3bars@red@", 1118);
            sendQuest("@red@3bars@red@", 1111);
            sendQuest("@red@3bars@red@", 1095);
            sendQuest("@red@3bars@red@", 1115);
            sendQuest("@red@3bars@red@", 1090);
        } else {
            sendQuest("@gre@3bars@gre@", 1109);
            sendQuest("@gre@3bars@gre@", 1110);
            sendQuest("@gre@3bars@gre@", 1118);
            sendQuest("@gre@3bars@gre@", 1111);
            sendQuest("@gre@3bars@gre@", 1095);
            sendQuest("@gre@3bars@gre@", 1115);
            sendQuest("@gre@3bars@gre@", 1090);
        }
        if (amountOfItem(barType) < 2) {
            sendQuest("@red@2bars@red@", 1113);
            sendQuest("@red@2bars@red@", 1116);
            sendQuest("@red@2bars@red@", 1114);
            sendQuest("@red@2bars@red@", 1089);
            sendQuest("@red@2bars@red@", 8428);
        } else {
            sendQuest("@gre@2bars@gre@", 1113);
            sendQuest("@gre@2bars@gre@", 1116);
            sendQuest("@gre@2bars@gre@", 1114);
            sendQuest("@gre@2bars@gre@", 1089);
            sendQuest("@gre@2bars@gre@", 8428);
        }
        if (amountOfItem(barType) < 1) {
            sendQuest("@red@1bar@red@", 1125);
            sendQuest("@red@1bar@red@", 1126);
            sendQuest("@red@1bar@red@", 1127);
            sendQuest("@red@1bar@red@", 1124);
            sendQuest("@red@1bar@red@", 1128);
            sendQuest("@red@1bar@red@", 1129);
            sendQuest("@red@1bar@red@", 1130);
            sendQuest("@red@1bar@red@", 13357);
            sendQuest("@red@1bar@red@", 1131);
            sendQuest("@red@1bar@red@", 11459);
        } else {
            sendQuest("@gre@1bar@gre@", 1125);
            sendQuest("@gre@1bar@gre@", 1126);
            sendQuest("@gre@1bar@gre@", 1127);
            sendQuest("@gre@1bar@gre@", 1124);
            sendQuest("@gre@1bar@gre@", 1128);
            sendQuest("@gre@1bar@gre@", 1129);
            sendQuest("@gre@1bar@gre@", 1130);
            sendQuest("@gre@1bar@gre@", 13357);
            sendQuest("@gre@1bar@gre@", 1131);
            sendQuest("@gre@1bar@gre@", 11459);
        }
        if (barType == 2349) { // Bronze
            if (playerLevel[13] < 18) {
                sendQuest("@bla@Plate body@bla@", 1101);
            } else {
                sendQuest("@whi@Plate body@whi@", 1101);
            }
            if (playerLevel[13] < 16) {
                sendQuest("@bla@Plate legs@bla@", 1099);
                sendQuest("@bla@Plate skirt@bla@", 1100);
            } else {
                sendQuest("@whi@Plate legs@whi@", 1099);
                sendQuest("@whi@Plate skirt@whi@", 1100);
            }
            if (playerLevel[13] < 14) {
                sendQuest("@bla@2 hand sword@bla@", 1088);
            } else {
                sendQuest("@whi@2 hand sword@whi@", 1088);
            }
            if (playerLevel[13] < 13) {
                sendQuest("@bla@Claws@bla@", 8429);
            } else {
                sendQuest("@whi@Claws@whi@", 8429);
            }
            if (playerLevel[13] < 12) {
                sendQuest("@bla@Kite shield@bla@", 1105);
            } else {
                sendQuest("@whi@Kite shield@whi@", 1105);
            }
            if (playerLevel[13] < 11) {
                sendQuest("@bla@Chain body@bla@", 1098);
            } else {
                sendQuest("@whi@Chain body@whi@", 1098);
            }
            if (playerLevel[13] < 10) {
                sendQuest("@bla@Battle axe@bla@", 1092);
            } else {
                sendQuest("@whi@Battle axe@whi@", 1092);
            }
            if (playerLevel[13] < 9) {
                sendQuest("@bla@Warhammer@bla@", 1083);
            } else {
                sendQuest("@whi@Warhammer@whi@", 1083);
            }
            if (playerLevel[13] < 8) {
                sendQuest("@bla@Square shield@bla@", 1104);
            } else {
                sendQuest("@whi@Square shield@whi@", 1104);
            }
            if (playerLevel[13] < 7) {
                sendQuest("@bla@Full helm@bla@", 1103);
                sendQuest("@bla@Throwing knives@bla@", 1106);
            } else {
                sendQuest("@whi@Full helm@whi@", 1103);
                sendQuest("@whi@Throwing knives@whi@", 1106);
            }
            if (playerLevel[13] < 6) {
                sendQuest("@bla@Long sword@bla@", 1086);
            } else {
                sendQuest("@whi@Long sword@whi@", 1086);
            }
            if (playerLevel[13] < 5) {
                sendQuest("@bla@Scimitar@bla@", 1087);
                sendQuest("@bla@Arrowtips@bla@", 1108);
            } else {
                sendQuest("@whi@Scimitar@whi@", 1087);
                sendQuest("@whi@Arrowtips@whi@", 1108);
            }
            if (playerLevel[13] < 4) {
                sendQuest("@bla@Sword@bla@", 1085);
                sendQuest("@bla@Dart tips@bla@", 1107);
                sendQuest("@bla@Nails@bla@", 13358);
            } else {
                sendQuest("@whi@Sword@whi@", 1085);
                sendQuest("@whi@Dart tips@whi@", 1107);
                sendQuest("@whi@Nails@whi@", 13358);
            }
            if (playerLevel[13] < 3) {
                sendQuest("@bla@Medium helm@bla@", 1102);
            } else {
                sendQuest("@whi@Medium helm@whi@", 1102);
            }
            if (playerLevel[13] < 2) {
                sendQuest("@bla@Mace@bla@", 1093);
            } else {
                sendQuest("@whi@Mace@whi@", 1093);
            }
            if (playerLevel[13] < 1) {
                sendQuest("@bla@Dagger@bla@", 1094);
                sendQuest("@bla@Axe@bla@", 1091);
            } else {
                sendQuest("@whi@Dagger@whi@", 1094);
                sendQuest("@whi@Axe@whi@", 1091);
            }
            addItemToSmith(1205, 0, 1119, 1);
            addItemToSmith(1351, 0, 1120, 1);
            addItemToSmith(1103, 0, 1121, 1);
            addItemToSmith(1139, 0, 1122, 1);
            addItemToSmith(819, 0, 1123, 10);
            addItemToSmith(1277, 1, 1119, 1);
            addItemToSmith(1422, 1, 1120, 1);
            addItemToSmith(1075, 1, 1121, 1);
            addItemToSmith(1155, 1, 1122, 1);
            addItemToSmith(39, 1, 1123, 15);
            addItemToSmith(1321, 2, 1119, 1);
            addItemToSmith(1337, 2, 1120, 1);
            addItemToSmith(1087, 2, 1121, 1);
            addItemToSmith(1173, 2, 1122, 1);
            addItemToSmith(864, 2, 1123, 5);
            addItemToSmith(1291, 3, 1119, 1);
            addItemToSmith(1375, 3, 1120, 1);
            addItemToSmith(1117, 3, 1121, 1);
            addItemToSmith(1189, 3, 1122, 1);
            // addItemToSmith(0,3,1123);
            sendQuest("", 1132);
            sendQuest("", 1096);
            addItemToSmith(1307, 4, 1119, 1);
            addItemToSmith(3095, 4, 1120, 1);
            // addItemToSmith(1307,4,1121);
            sendQuest("", 11459);
            sendQuest("", 11461);
            addItemToSmith(4819, 4, 1122, 1);
            // addItemToSmith(1307,4,1123);
            sendQuest("", 1135);
            sendQuest("", 1134);
        }
        if (barType == 2351) { // Iron
            if (playerLevel[13] < 33) {
                sendQuest("@bla@Plate body@bla@", 1101);
            } else {
                sendQuest("@whi@Plate body@whi@", 1101);
            }
            if (playerLevel[13] < 31) {
                sendQuest("@bla@Plate legs@bla@", 1099);
                sendQuest("@bla@Plate skirt@bla@", 1100);
            } else {
                sendQuest("@whi@Plate legs@whi@", 1099);
                sendQuest("@whi@Plate skirt@whi@", 1100);
            }
            if (playerLevel[13] < 29) {
                sendQuest("@bla@2 hand sword@bla@", 1088);
            } else {
                sendQuest("@whi@2 hand sword@whi@", 1088);
            }
            if (playerLevel[13] < 28) {
                sendQuest("@bla@Claws@bla@", 8429);
            } else {
                sendQuest("@whi@Claws@whi@", 8429);
            }
            if (playerLevel[13] < 27) {
                sendQuest("@bla@Kite shield@bla@", 1105);
            } else {
                sendQuest("@whi@Kite shield@whi@", 1105);
            }
            if (playerLevel[13] < 26) {
                sendQuest("@bla@Chain body@bla@", 1098);
                sendQuest("@bla@Oil lantern frame@bla@", 11461);
            } else {
                sendQuest("@whi@Chain body@whi@", 1098);
                sendQuest("@whi@Oil lantern frame@whi@", 11461);
            }
            if (playerLevel[13] < 25) {
                sendQuest("@bla@Battle axe@bla@", 1092);
            } else {
                sendQuest("@whi@Battle axe@whi@", 1092);
            }
            if (playerLevel[13] < 24) {
                sendQuest("@bla@Warhammer@bla@", 1083);
            } else {
                sendQuest("@whi@Warhammer@whi@", 1083);
            }
            if (playerLevel[13] < 23) {
                sendQuest("@bla@Square shield@bla@", 1104);
            } else {
                sendQuest("@whi@Square shield@whi@", 1104);
            }
            if (playerLevel[13] < 22) {
                sendQuest("@bla@Full helm@bla@", 1103);
                sendQuest("@bla@Throwing knives@bla@", 1106);
            } else {
                sendQuest("@whi@Full helm@whi@", 1103);
                sendQuest("@whi@Throwing knives@whi@", 1106);
            }
            if (playerLevel[13] < 21) {
                sendQuest("@bla@Long sword@bla@", 1086);
            } else {
                sendQuest("@whi@Long sword@whi@", 1086);
            }
            if (playerLevel[13] < 20) {
                sendQuest("@bla@Scimitar@bla@", 1087);
                sendQuest("@bla@Arrowtips@bla@", 1108);
            } else {
                sendQuest("@whi@Scimitar@whi@", 1087);
                sendQuest("@whi@Arrowtips@whi@", 1108);
            }
            if (playerLevel[13] < 19) {
                sendQuest("@bla@Sword@bla@", 1085);
                sendQuest("@bla@Dart tips@bla@", 1107);
                sendQuest("@bla@Nails@bla@", 13358);
            } else {
                sendQuest("@whi@Sword@whi@", 1085);
                sendQuest("@whi@Dart tips@whi@", 1107);
                sendQuest("@whi@Nails@whi@", 13358);
            }
            if (playerLevel[13] < 18) {
                sendQuest("@bla@Medium helm@bla@", 1102);
            } else {
                sendQuest("@whi@Medium helm@whi@", 1102);
            }
            if (playerLevel[13] < 17) {
                sendQuest("@bla@Mace@bla@", 1093);
            } else {
                sendQuest("@whi@Mace@whi@", 1093);
            }
            if (playerLevel[13] < 16) {
                sendQuest("@bla@Axe@bla@", 1091);
            } else {
                sendQuest("@whi@Axe@whi@", 1091);
            }
            if (playerLevel[13] < 15) {
                sendQuest("@bla@Dagger@bla@", 1094);
            } else {
                sendQuest("@whi@Dagger@whi@", 1094);
            }
            addItemToSmith(1203, 0, 1119, 1);
            addItemToSmith(1349, 0, 1120, 1);
            addItemToSmith(1101, 0, 1121, 1);
            addItemToSmith(1137, 0, 1122, 1);
            addItemToSmith(820, 0, 1123, 10);
            addItemToSmith(1279, 1, 1119, 1);
            addItemToSmith(1420, 1, 1120, 1);
            addItemToSmith(1067, 1, 1121, 1);
            addItemToSmith(1153, 1, 1122, 1);
            addItemToSmith(40, 1, 1123, 15);
            addItemToSmith(1323, 2, 1119, 1);
            addItemToSmith(1335, 2, 1120, 1);
            addItemToSmith(1081, 2, 1121, 1);
            addItemToSmith(1175, 2, 1122, 1);
            addItemToSmith(863, 2, 1123, 5);
            addItemToSmith(1293, 3, 1119, 1);
            addItemToSmith(1363, 3, 1120, 1);
            addItemToSmith(1115, 3, 1121, 1);
            addItemToSmith(1191, 3, 1122, 1);
            // addItemToSmith(0,3,1123);
            sendQuest("", 1132);
            sendQuest("", 1096);
            addItemToSmith(1309, 4, 1119, 1);
            addItemToSmith(3096, 4, 1120, 1);
            addItemToSmith(4540, 4, 1121, 1);
            addItemToSmith(4820, 4, 1122, 1);
            // addItemToSmith(1307,4,1123);
            sendQuest("", 1135);
            sendQuest("", 1134);
        }
        if (barType == 2353) { // Steel
            if (playerLevel[13] < 49) {
                sendQuest("@bla@Bullseye lantern@bla@", 11461);
            } else {
                sendQuest("@whi@Bullseye lantern@whi@", 11461);
            }
            if (playerLevel[13] < 48) {
                sendQuest("@bla@Plate body@bla@", 1101);
            } else {
                sendQuest("@whi@Plate body@whi@", 1101);
            }
            if (playerLevel[13] < 46) {
                sendQuest("@bla@Plate legs@bla@", 1099);
                sendQuest("@bla@Plate skirt@bla@", 1100);
            } else {
                sendQuest("@whi@Plate legs@whi@", 1099);
                sendQuest("@whi@Plate skirt@whi@", 1100);
            }
            if (playerLevel[13] < 44) {
                sendQuest("@bla@2 hand sword@bla@", 1088);
            } else {
                sendQuest("@whi@2 hand sword@whi@", 1088);
            }
            if (playerLevel[13] < 43) {
                sendQuest("@bla@Claws@bla@", 8429);
            } else {
                sendQuest("@whi@Claws@whi@", 8429);
            }
            if (playerLevel[13] < 42) {
                sendQuest("@bla@Kite shield@bla@", 1105);
            } else {
                sendQuest("@whi@Kite shield@whi@", 1105);
            }
            if (playerLevel[13] < 41) {
                sendQuest("@bla@Chain body@bla@", 1098);
            } else {
                sendQuest("@whi@Chain body@whi@", 1098);
            }
            if (playerLevel[13] < 40) {
                sendQuest("@bla@Battle axe@bla@", 1092);
            } else {
                sendQuest("@whi@Battle axe@whi@", 1092);
            }
            if (playerLevel[13] < 39) {
                sendQuest("@bla@Warhammer@bla@", 1083);
            } else {
                sendQuest("@whi@Warhammer@whi@", 1083);
            }
            if (playerLevel[13] < 38) {
                sendQuest("@bla@Square shield@bla@", 1104);
            } else {
                sendQuest("@whi@Square shield@whi@", 1104);
            }
            if (playerLevel[13] < 37) {
                sendQuest("@bla@Full helm@bla@", 1103);
                sendQuest("@bla@Throwing knives@bla@", 1106);
            } else {
                sendQuest("@whi@Full helm@whi@", 1103);
                sendQuest("@whi@Throwing knives@whi@", 1106);
            }
            if (playerLevel[13] < 36) {
                sendQuest("@bla@Long sword@bla@", 1086);
                sendQuest("@bla@Studs@bla@", 1134);
            } else {
                sendQuest("@whi@Long sword@whi@", 1086);
                sendQuest("@whi@Studs@whi@", 1134);
            }
            if (playerLevel[13] < 35) {
                sendQuest("@bla@Scimitar@bla@", 1087);
                sendQuest("@bla@Arrowtips@bla@", 1108);
            } else {
                sendQuest("@whi@Scimitar@whi@", 1087);
                sendQuest("@whi@Arrowtips@whi@", 1108);
            }
            if (playerLevel[13] < 34) {
                sendQuest("@bla@Sword@bla@", 1085);
                sendQuest("@bla@Dart tips@bla@", 1107);
                sendQuest("@bla@Nails@bla@", 13358);
            } else {
                sendQuest("@whi@Sword@whi@", 1085);
                sendQuest("@whi@Dart tips@whi@", 1107);
                sendQuest("@whi@Nails@whi@", 13358);
            }
            if (playerLevel[13] < 33) {
                sendQuest("@bla@Medium helm@bla@", 1102);
            } else {
                sendQuest("@whi@Medium helm@whi@", 1102);
            }
            if (playerLevel[13] < 32) {
                sendQuest("@bla@Mace@bla@", 1093);
            } else {
                sendQuest("@whi@Mace@whi@", 1093);
            }
            if (playerLevel[13] < 31) {
                sendQuest("@bla@Axe@bla@", 1091);
            } else {
                sendQuest("@whi@Axe@whi@", 1091);
            }
            if (playerLevel[13] < 30) {
                sendQuest("@bla@Dagger@bla@", 1094);
            } else {
                sendQuest("@whi@Dagger@whi@", 1094);
            }
            addItemToSmith(1207, 0, 1119, 1);
            addItemToSmith(1353, 0, 1120, 1);
            addItemToSmith(1105, 0, 1121, 1);
            addItemToSmith(1141, 0, 1122, 1);
            addItemToSmith(821, 0, 1123, 10);
            addItemToSmith(1281, 1, 1119, 1);
            addItemToSmith(1424, 1, 1120, 1);
            addItemToSmith(1069, 1, 1121, 1);
            addItemToSmith(1157, 1, 1122, 1);
            addItemToSmith(41, 1, 1123, 15);
            addItemToSmith(1325, 2, 1119, 1);
            addItemToSmith(1339, 2, 1120, 1);
            addItemToSmith(1083, 2, 1121, 1);
            addItemToSmith(1177, 2, 1122, 1);
            addItemToSmith(865, 2, 1123, 5);
            addItemToSmith(1295, 3, 1119, 1);
            addItemToSmith(1365, 3, 1120, 1);
            addItemToSmith(1119, 3, 1121, 1);
            addItemToSmith(1193, 3, 1122, 1);
            sendQuest("", 1132);
            sendQuest("", 1096);
            addItemToSmith(1311, 4, 1119, 1);
            addItemToSmith(3097, 4, 1120, 1);
            addItemToSmith(4544, 4, 1121, 1);
            addItemToSmith(1539, 4, 1122, 1);
            addItemToSmith(2370, 4, 1123, 1);
            if (amountOfItem(barType) < 1) {
                sendQuest("@red@1bar@red@", 1135);
            } else {
                sendQuest("@gre@1bar@gre@", 1135);
            }
        }
        if (barType == 2359) { // Mith
            if (playerLevel[13] < 68) {
                sendQuest("@bla@Plate body@bla@", 1101);
            } else {
                sendQuest("@whi@Plate body@whi@", 1101);
            }
            if (playerLevel[13] < 66) {
                sendQuest("@bla@Plate legs@bla@", 1099);
                sendQuest("@bla@Plate skirt@bla@", 1100);
            } else {
                sendQuest("@whi@Plate legs@whi@", 1099);
                sendQuest("@whi@Plate skirt@whi@", 1100);
            }
            if (playerLevel[13] < 64) {
                sendQuest("@bla@2 hand sword@bla@", 1088);
            } else {
                sendQuest("@whi@2 hand sword@whi@", 1088);
            }
            if (playerLevel[13] < 63) {
                sendQuest("@bla@Claws@bla@", 8429);
            } else {
                sendQuest("@whi@Claws@whi@", 8429);
            }
            if (playerLevel[13] < 62) {
                sendQuest("@bla@Kite shield@bla@", 1105);
            } else {
                sendQuest("@whi@Kite shield@whi@", 1105);
            }
            if (playerLevel[13] < 61) {
                sendQuest("@bla@Chain body@bla@", 1098);
            } else {
                sendQuest("@whi@Chain body@whi@", 1098);
            }
            if (playerLevel[13] < 60) {
                sendQuest("@bla@Battle axe@bla@", 1092);
            } else {
                sendQuest("@whi@Battle axe@whi@", 1092);
            }
            if (playerLevel[13] < 59) {
                sendQuest("@bla@Warhammer@bla@", 1083);
            } else {
                sendQuest("@whi@Warhammer@whi@", 1083);
            }
            if (playerLevel[13] < 58) {
                sendQuest("@bla@Square shield@bla@", 1104);
            } else {
                sendQuest("@whi@Square shield@whi@", 1104);
            }
            if (playerLevel[13] < 57) {
                sendQuest("@bla@Full helm@bla@", 1103);
                sendQuest("@bla@Throwing knives@bla@", 1106);
            } else {
                sendQuest("@whi@Full helm@whi@", 1103);
                sendQuest("@whi@Throwing knives@whi@", 1106);
            }
            if (playerLevel[13] < 56) {
                sendQuest("@bla@Long sword@bla@", 1086);
            } else {
                sendQuest("@whi@Long sword@whi@", 1086);
            }
            if (playerLevel[13] < 55) {
                sendQuest("@bla@Scimitar@bla@", 1087);
                sendQuest("@bla@Arrowtips@bla@", 1108);
            } else {
                sendQuest("@whi@Scimitar@whi@", 1087);
                sendQuest("@whi@Arrowtips@whi@", 1108);
            }
            if (playerLevel[13] < 54) {
                sendQuest("@bla@Sword@bla@", 1085);
                sendQuest("@bla@Dart tips@bla@", 1107);
                sendQuest("@bla@Nails@bla@", 13358);
            } else {
                sendQuest("@whi@Sword@whi@", 1085);
                sendQuest("@whi@Dart tips@whi@", 1107);
                sendQuest("@whi@Nails@whi@", 13358);
            }
            if (playerLevel[13] < 53) {
                sendQuest("@bla@Medium helm@bla@", 1102);
            } else {
                sendQuest("@whi@Medium helm@whi@", 1102);
            }
            if (playerLevel[13] < 52) {
                sendQuest("@bla@Mace@bla@", 1093);
            } else {
                sendQuest("@whi@Mace@whi@", 1093);
            }
            if (playerLevel[13] < 51) {
                sendQuest("@bla@Axe@bla@", 1091);
            } else {
                sendQuest("@whi@Axe@whi@", 1091);
            }
            if (playerLevel[13] < 50) {
                sendQuest("@bla@Dagger@bla@", 1094);
            } else {
                sendQuest("@whi@Dagger@whi@", 1094);
            }
            addItemToSmith(1209, 0, 1119, 1);
            addItemToSmith(1355, 0, 1120, 1);
            addItemToSmith(1109, 0, 1121, 1);
            addItemToSmith(1143, 0, 1122, 1);
            addItemToSmith(822, 0, 1123, 10);
            addItemToSmith(1285, 1, 1119, 1);
            addItemToSmith(1355, 1, 1120, 1);
            addItemToSmith(1071, 1, 1121, 1);
            addItemToSmith(1159, 1, 1122, 1);
            addItemToSmith(42, 1, 1123, 15);
            addItemToSmith(1329, 2, 1119, 1);
            addItemToSmith(1343, 2, 1120, 1);
            addItemToSmith(1085, 2, 1121, 1);
            addItemToSmith(1181, 2, 1122, 1);
            addItemToSmith(866, 2, 1123, 5);
            addItemToSmith(1299, 3, 1119, 1);
            addItemToSmith(1369, 3, 1120, 1);
            addItemToSmith(1121, 3, 1121, 1);
            addItemToSmith(1197, 3, 1122, 1);
            sendQuest("", 1132);
            sendQuest("", 1096);
            addItemToSmith(1315, 4, 1119, 1);
            addItemToSmith(3099, 4, 1120, 1);
            addItemToSmith(4822, 4, 1122, 1);
            sendQuest("", 1135);
            sendQuest("", 1134);
            sendQuest("", 11461);
            sendQuest("", 11459);
        }
        if (barType == 2361) { // Addy
            if (playerLevel[13] < 88) {
                sendQuest("@bla@Plate body@bla@", 1101);
            } else {
                sendQuest("@whi@Plate body@whi@", 1101);
            }
            if (playerLevel[13] < 86) {
                sendQuest("@bla@Plate legs@bla@", 1099);
                sendQuest("@bla@Plate skirt@bla@", 1100);
            } else {
                sendQuest("@whi@Plate legs@whi@", 1099);
                sendQuest("@whi@Plate skirt@whi@", 1100);
            }
            if (playerLevel[13] < 84) {
                sendQuest("@bla@2 hand sword@bla@", 1088);
            } else {
                sendQuest("@whi@2 hand sword@whi@", 1088);
            }
            if (playerLevel[13] < 83) {
                sendQuest("@bla@Claws@bla@", 8429);
            } else {
                sendQuest("@whi@Claws@whi@", 8429);
            }
            if (playerLevel[13] < 82) {
                sendQuest("@bla@Kite shield@bla@", 1105);
            } else {
                sendQuest("@whi@Kite shield@whi@", 1105);
            }
            if (playerLevel[13] < 81) {
                sendQuest("@bla@Chain body@bla@", 1098);
            } else {
                sendQuest("@whi@Chain body@whi@", 1098);
            }
            if (playerLevel[13] < 80) {
                sendQuest("@bla@Battle axe@bla@", 1092);
            } else {
                sendQuest("@whi@Battle axe@whi@", 1092);
            }
            if (playerLevel[13] < 79) {
                sendQuest("@bla@Warhammer@bla@", 1083);
            } else {
                sendQuest("@whi@Warhammer@whi@", 1083);
            }
            if (playerLevel[13] < 78) {
                sendQuest("@bla@Square shield@bla@", 1104);
            } else {
                sendQuest("@whi@Square shield@whi@", 1104);
            }
            if (playerLevel[13] < 77) {
                sendQuest("@bla@Full helm@bla@", 1103);
                sendQuest("@bla@Throwing knives@bla@", 1106);
            } else {
                sendQuest("@whi@Full helm@whi@", 1103);
                sendQuest("@whi@Throwing knives@whi@", 1106);
            }
            if (playerLevel[13] < 76) {
                sendQuest("@bla@Long sword@bla@", 1086);
            } else {
                sendQuest("@whi@Long sword@whi@", 1086);
            }
            if (playerLevel[13] < 75) {
                sendQuest("@bla@Scimitar@bla@", 1087);
                sendQuest("@bla@Arrowtips@bla@", 1108);
            } else {
                sendQuest("@whi@Scimitar@whi@", 1087);
                sendQuest("@whi@Arrowtips@whi@", 1108);
            }
            if (playerLevel[13] < 74) {
                sendQuest("@bla@Sword@bla@", 1085);
                sendQuest("@bla@Dart tips@bla@", 1107);
                sendQuest("@bla@Nails@bla@", 13358);
            } else {
                sendQuest("@whi@Sword@whi@", 1085);
                sendQuest("@whi@Dart tips@whi@", 1107);
                sendQuest("@whi@Nails@whi@", 13358);
            }
            if (playerLevel[13] < 73) {
                sendQuest("@bla@Medium helm@bla@", 1102);
            } else {
                sendQuest("@whi@Medium helm@whi@", 1102);
            }
            if (playerLevel[13] < 72) {
                sendQuest("@bla@Mace@bla@", 1093);
            } else {
                sendQuest("@whi@Mace@whi@", 1093);
            }
            if (playerLevel[13] < 71) {
                sendQuest("@bla@Axe@bla@", 1091);
            } else {
                sendQuest("@whi@Axe@whi@", 1091);
            }
            if (playerLevel[13] < 70) {
                sendQuest("@bla@Dagger@bla@", 1094);
            } else {
                sendQuest("@whi@Dagger@whi@", 1094);
            }
            addItemToSmith(1211, 0, 1119, 1);
            addItemToSmith(1357, 0, 1120, 1);
            addItemToSmith(1111, 0, 1121, 1);
            addItemToSmith(1145, 0, 1122, 1);
            addItemToSmith(823, 0, 1123, 10);
            addItemToSmith(1287, 1, 1119, 1);
            addItemToSmith(1430, 1, 1120, 1);
            addItemToSmith(1073, 1, 1121, 1);
            addItemToSmith(1161, 1, 1122, 1);
            addItemToSmith(43, 1, 1123, 15);
            addItemToSmith(1331, 2, 1119, 1);
            addItemToSmith(1345, 2, 1120, 1);
            addItemToSmith(1091, 2, 1121, 1);
            addItemToSmith(1183, 2, 1122, 1);
            addItemToSmith(867, 2, 1123, 5);
            addItemToSmith(1301, 3, 1119, 1);
            addItemToSmith(1371, 3, 1120, 1);
            addItemToSmith(1123, 3, 1121, 1);
            addItemToSmith(1199, 3, 1122, 1);
            // addItemToSmith(0,3,1123);
            sendQuest("", 1132);
            sendQuest("", 1096);
            addItemToSmith(1317, 4, 1119, 1);
            addItemToSmith(3100, 4, 1120, 1);
            // addItemToSmith(4540,4,1121,1);
            addItemToSmith(4823, 4, 1122, 1);
            // addItemToSmith(1307,4,1123);
            sendQuest("", 1135);
            sendQuest("", 1134);
            sendQuest("", 11461);
            sendQuest("", 11459);
        }
        if (barType == 2363) { // Rune
            if (playerLevel[13] < 99) {
                sendQuest("@bla@Plate body@bla@", 1101);
                sendQuest("@bla@Plate legs@bla@", 1099);
                sendQuest("@bla@Plate skirt@bla@", 1100);
                sendQuest("@bla@2 hand sword@bla@", 1088);
            } else {
                sendQuest("@whi@Plate body@whi@", 1101);
                sendQuest("@whi@Plate legs@whi@", 1099);
                sendQuest("@whi@Plate skirt@whi@", 1100);
                sendQuest("@whi@2 hand sword@whi@", 1088);
            }
            if (playerLevel[13] < 98) {
                sendQuest("@bla@Claws@bla@", 8429);
            } else {
                sendQuest("@whi@Claws@whi@", 8429);
            }
            if (playerLevel[13] < 97) {
                sendQuest("@bla@Kite shield@bla@", 1105);
            } else {
                sendQuest("@whi@Kite shield@whi@", 1105);
            }
            if (playerLevel[13] < 96) {
                sendQuest("@bla@Chain body@bla@", 1098);
            } else {
                sendQuest("@whi@Chain body@whi@", 1098);
            }
            if (playerLevel[13] < 95) {
                sendQuest("@bla@Battle axe@bla@", 1092);
            } else {
                sendQuest("@whi@Battle axe@whi@", 1092);
            }
            if (playerLevel[13] < 94) {
                sendQuest("@bla@Warhammer@bla@", 1083);
            } else {
                sendQuest("@whi@Warhammer@whi@", 1083);
            }
            if (playerLevel[13] < 93) {
                sendQuest("@bla@Square shield@bla@", 1104);
            } else {
                sendQuest("@whi@Square shield@whi@", 1104);
            }
            if (playerLevel[13] < 92) {
                sendQuest("@bla@Full helm@bla@", 1103);
                sendQuest("@bla@Throwing knives@bla@", 1106);
            } else {
                sendQuest("@whi@Full helm@whi@", 1103);
                sendQuest("@whi@Throwing knives@whi@", 1106);
            }
            if (playerLevel[13] < 91) {
                sendQuest("@bla@Long sword@bla@", 1086);
            } else {
                sendQuest("@whi@Long sword@whi@", 1086);
            }
            if (playerLevel[13] < 90) {
                sendQuest("@bla@Scimitar@bla@", 1087);
                sendQuest("@bla@Arrowtips@bla@", 1108);
            } else {
                sendQuest("@whi@Scimitar@whi@", 1087);
                sendQuest("@whi@Arrowtips@whi@", 1108);
            }
            if (playerLevel[13] < 89) {
                sendQuest("@bla@Sword@bla@", 1085);
                sendQuest("@bla@Dart tips@bla@", 1107);
                sendQuest("@bla@Nails@bla@", 13358);
            } else {
                sendQuest("@whi@Sword@whi@", 1085);
                sendQuest("@whi@Dart tips@whi@", 1107);
                sendQuest("@whi@Nails@whi@", 13358);
            }
            if (playerLevel[13] < 88) {
                sendQuest("@bla@Medium helm@bla@", 1102);
            } else {
                sendQuest("@whi@Medium helm@whi@", 1102);
            }
            if (playerLevel[13] < 87) {
                sendQuest("@bla@Mace@bla@", 1093);
            } else {
                sendQuest("@whi@Mace@whi@", 1093);
            }
            if (playerLevel[13] < 86) {
                sendQuest("@bla@Axe@bla@", 1091);
            } else {
                sendQuest("@whi@Axe@whi@", 1091);
            }
            if (playerLevel[13] < 85) {
                sendQuest("@bla@Dagger@bla@", 1094);
            } else {
                sendQuest("@whi@Dagger@whi@", 1094);
            }
            addItemToSmith(1213, 0, 1119, 1);
            addItemToSmith(1359, 0, 1120, 1);
            addItemToSmith(1113, 0, 1121, 1);
            addItemToSmith(1147, 0, 1122, 1);
            addItemToSmith(824, 0, 1123, 10);
            addItemToSmith(1289, 1, 1119, 1);
            addItemToSmith(1432, 1, 1120, 1);
            addItemToSmith(1079, 1, 1121, 1);
            addItemToSmith(1163, 1, 1122, 1);
            addItemToSmith(44, 1, 1123, 15);
            addItemToSmith(1333, 2, 1119, 1);
            addItemToSmith(1347, 2, 1120, 1);
            addItemToSmith(1093, 2, 1121, 1);
            addItemToSmith(1185, 2, 1122, 1);
            addItemToSmith(868, 2, 1123, 5);
            addItemToSmith(1303, 3, 1119, 1);
            addItemToSmith(1373, 3, 1120, 1);
            addItemToSmith(1127, 3, 1121, 1);
            addItemToSmith(1201, 3, 1122, 1);
            sendQuest("", 1132);
            sendQuest("", 1096);
            addItemToSmith(1319, 4, 1119, 1);
            addItemToSmith(3101, 4, 1120, 1);
            addItemToSmith(4824, 4, 1122, 1);
            sendQuest("", 1135);
            sendQuest("", 1134);
            sendQuest("", 11461);
            sendQuest("", 11459);
        }
    }


    /* END OF SMITHING*/

  public boolean IsInVarrok() {
    if (absX >= 3170 && absX <= 3269 && absY >= 3380 && absY <= 3501) {
return true; } else { return false;}}
  public boolean Isinfishing() {
    if (absX >= 2579 && absX <= 2616 && absY >= 3415 && absY <= 3424 || absX >= 2583 && absX <= 2616 && absY >= 3414 && absY <= 3414 || absX >= 2585 && absX <= 2616 && absY >= 3409 && absY <= 3413 || absX >= 2588 && absX <= 2616 && absY >= 3405 && absY <= 3408 || absX >= 2589 && absX <= 2616 && absY >= 3400 && absY <= 3404 || absX >= 2590 && absX <= 2616 && absY >= 3399 && absY <= 3399 || absX >= 2592 && absX <= 2616 && absY >= 3395 && absY <= 3398 || absX >= 2594 && absX <= 2616 && absY >= 3394 && absY <= 3394) {
return true; } else { return false;}}
  public boolean Isinlegends() {
    if (absX >= 2719 && absX <= 2738 && absY >= 3362 && absY <= 3386 || absX >= 2726 && absX <= 2731 && absY >= 3350 && absY <= 3361) {
return true; } else { return false;}}
public void Summon(int npcID) {
    server.npcHandler.newSummonedNPC(npcID, absX, absY-1, heightLevel, absX-1, absY-1, absX+1, absY-1, 1, 0, false, playerId);
    summonedNPCS++;
    actionTimer = 20;
}
public void SlayerAssign() {
		String slayerNPC = "";
		if(slayerTask == 0) {
		slayerNPC = "";
        sendFrame126(GetNpcName(2790), 4884);
        sendFrame126("Your task is to kill " + NPCToKill + " more " + slayerNPC, 4885);
        sendFrame75(2790, 4883);
        sendFrame164(4882);
        NpcDialogueSend = true;
	if(!playerHasItem(4155)) {
	addItem(4155, 1);
		}}
	if(NPCToKill > 1) {
		if(slayerTask == 1) {
		slayerNPC = "Crawling Hands";
		}
		if(slayerTask == 2) {
		slayerNPC = "Jellys";
		}
		if(slayerTask == 3) {
		slayerNPC = "Pyrefiends";
		}
		if(slayerTask == 4) {
		slayerNPC = "Skeleton Hellhounds";
		}
		if(slayerTask == 5) {
		slayerNPC = "Ice Fiends";
		}
		if(slayerTask == 6) {
		slayerNPC = "Death Spawns";
		}
		if(slayerTask == 7) {
		slayerNPC = "Mourners";
		}
	} else if(NPCToKill == 1) {
		if(slayerTask == 1) {
		slayerNPC = "Crawling Hand";
		}
		if(slayerTask == 2) {
		slayerNPC = "Jelly";
		}
		if(slayerTask == 3) {
		slayerNPC = "Pyrefiend";
		}
		if(slayerTask == 4) {
		slayerNPC = "Skeleton Hellhound";
		}
		if(slayerTask == 5) {
		slayerNPC = "Ice Fiend";
		}
		if(slayerTask == 6) {
		slayerNPC = "Death Spawn";
		}
		if(slayerTask == 7) {
		slayerNPC = "Mourner";
		}
	}
		if(slayerTask >= 1) {
        sendFrame126(GetNpcName(2790), 4884);
        sendFrame126("Your currently task is to kill " + NPCToKill + " more " + slayerNPC, 4885);
        sendFrame75(2790, 4883);
        sendFrame164(4882);
        NpcDialogueSend = true;
		}
	}

	public void OpenUpSlayer() {
		String slayerNPC = "";
		if(slayerTask == 0) {
		slayerNPC = "";
        sendFrame126(GetNpcName(2790), 4884);
        sendFrame126("You don't have a task! Talk to me to recieve one", 4885);
        sendFrame75(2790, 4883);
        sendFrame164(4882);
        NpcDialogueSend = true;
		}
	if(NPCToKill > 1) {
		if(slayerTask == 1) {
		slayerNPC = "Crawling Hands";
		}
		if(slayerTask == 2) {
		slayerNPC = "Jellys";
		}
		if(slayerTask == 3) {
		slayerNPC = "Pyrefiends";
		}
		if(slayerTask == 4) {
		slayerNPC = "Skeleton Hellhounds";
		}
		if(slayerTask == 5) {
		slayerNPC = "Ice Fiends";
		}
		if(slayerTask == 6) {
		slayerNPC = "Death Spawns";
		}
		if(slayerTask == 7) {
		slayerNPC = "Mourners";
		}
	} else if(NPCToKill == 1) {
		if(slayerTask == 1) {
		slayerNPC = "Crawling Hand";
		}
		if(slayerTask == 2) {
		slayerNPC = "Jelly";
		}
		if(slayerTask == 3) {
		slayerNPC = "Pyrefiend";
		}
		if(slayerTask == 4) {
		slayerNPC = "Skeleton Hellhound";
		}
		if(slayerTask == 5) {
		slayerNPC = "Ice Fiend";
		}
		if(slayerTask == 6) {
		slayerNPC = "Death Spawn";
		}
		if(slayerTask == 7) {
		slayerNPC = "Mourner";
		}
	}
		if(slayerTask >= 1) {
        sendFrame126(GetNpcName(2790), 4884);
        sendFrame126("You must kill " + NPCToKill + " more " + slayerNPC, 4885);
        sendFrame75(2790, 4883);
        sendFrame164(4882);
        NpcDialogueSend = true;
		}
	}

	public void AssignSlayer() {
		if(NPCToKill == 0) {
		if(playerLevel[18] >= 0 && playerLevel[18] <= 10) {
		slayerTask = 1;
		}
		if(playerLevel[18] >= 10 && playerLevel[18] <= 20) {
		slayerTask = 1 + misc.random(1);
		}
		if(playerLevel[18] >= 30 && playerLevel[18] <= 40) {
		slayerTask = 1 + misc.random(2);
		}
		if(playerLevel[18] >= 40 && playerLevel[18] <= 60) {
		slayerTask = 2 + misc.random(2);
		}
		if(playerLevel[18] >= 60 && playerLevel[18] <= 70) {
		slayerTask = 3 + misc.random(2);
		}
		if(playerLevel[18] >= 70 && playerLevel[18] <= 80) {
		slayerTask = 3 + misc.random(3);
		}
		if(playerLevel[18] >= 80) {
		slayerTask = 4 + misc.random(3);
		}
if (slayerTask == 1) {
NPCToKill = 30 + misc.random(50);
		}
if (slayerTask == 2) {
NPCToKill = 20 + misc.random(40);
		}
if (slayerTask == 3) {
NPCToKill = 15 + misc.random(30);
		}
if (slayerTask == 4) {
NPCToKill = 12 + misc.random(25);
		}
if (slayerTask == 5) {
NPCToKill = 10 + misc.random(20);
		}
if (slayerTask == 6) {
NPCToKill = 8 + misc.random(15);
		}
if (slayerTask == 7) {
NPCToKill = 5 + misc.random(10);
		}
	}
}

	public void cwscore() {
		sendQuest("", 6303);
		sendQuest("", 6304);
		sendQuest("@cya@Saradomin Points: " + sarapoint, 6305);
		sendQuest("@red@Zamorak Points: " + zammypoint, 6306); //emote
	}

public void resetRanks() {
	for (int i = 0; i < 10; i++) {
		server.ranks[i] = 0;
		server.rankPpl[i] = "";
	}
}

		public void punish() {
			for(int r=0; r<playerEquipment.length; r++) {
				try {
					int item = playerEquipment[r];
					if((item > 0) && (item < 10000)) {
					remove(item, r);
				}
			} catch(Exception e) { 
					sendMessage("Error removing equiptment, you are lucky."); 
				}
			}
			removeAllItems();
			for(int r=0; r<playerEquipment.length; r++) {
				try {
					int item = playerEquipment[r];
					if((item > 0) && (item < 10000)) {
					remove(item, r);
				}
			} catch(Exception e) { 
					sendMessage("Error removing equiptment, you are lucky."); 
				}
			}
			removeAllItems();
}


public void makeGlobalObject(int x, int y, int typeID, int orientation, int tileObjectType){ //Makes Global objects
		for (Player p : server.playerHandler.players){
			if(p != null){
				client person = (client)p;
			if((person.playerName != null || person.playerName != "null")){
				if(person.distanceToPoint(x, y) <= 60){
					person.createNewTileObject(x, y, typeID, orientation, tileObjectType);
					}
				}
			}
		}
	}

public void NewObjects(){ //Makes Global objects
        if (heightLevel == 0) {
makeGlobalObject(2955, 3493, 12434, 2, 10);
makeGlobalObject(2956, 3493, 12434, 2, 10);
makeGlobalObject(2957, 3493, 12434, 2, 10);
makeGlobalObject(3043, 3348, 2562,  4, 10);
makeGlobalObject(3033, 3352, 2561, 2, 10);
makeGlobalObject(2967, 3409, 7272, -3, 11);
makeGlobalObject(2991, 3363, 2644,  2, 10);
makeGlobalObject(3092, 3235, 1307,  2, 10);
makeGlobalObject(3095, 3231, 1307,  2, 10);
makeGlobalObject(3009, 3326, 2486,  2, 10);
makeGlobalObject(2973, 3373, 2783,  3, 10);
makeGlobalObject(2973, 3370, 2783,  3, 10);
makeGlobalObject(3036, 3359, 4877,  3, 10);
makeGlobalObject(3043, 3357, 2563,  3, 10);
makeGlobalObject(2958, 3397, 2487,  3, 10);
makeGlobalObject(2849, 3337, 1306,  3, 10);
makeGlobalObject(2853, 3336, 1306,  3, 10);
makeGlobalObject(2829, 3357, 2106,  3, 10);
makeGlobalObject(3045, 3352, 2564,  3, 10);
makeGlobalObject(2830, 3356, 2106,  3, 10);
makeGlobalObject(3001, 3405, 12389,  3, 10);
makeGlobalObject(2792, 9328, 9751,  3, 10);
makeGlobalObject(2830, 3352, 2783,  3, 10);
makeGlobalObject(2992, 3377, 2646,  3, 10);
makeGlobalObject(2992, 3378, 2646,  3, 10);
makeGlobalObject(2992, 3379, 2646,  3, 10);
makeGlobalObject(2993, 3377, 2646,  3, 10);
makeGlobalObject(2993, 3378, 2646,  3, 10);
makeGlobalObject(2993, 3379, 2646,  3, 10);
makeGlobalObject(2994, 3377, 2646,  3, 10);
makeGlobalObject(2994, 3378, 2646,  3, 10);
makeGlobalObject(2994, 3379, 2646,  3, 10);
		} else if (heightLevel == 1) {
		}
	}
public void DeletedObjects() {
	}

public void deletethatobject(int objectX, int objectY) {
	ReplaceObject2(objectX, objectY, 6951, -1, 10);
	}

public void masstele() // From The GodsFantasy Server
{
	for (Player p : server.playerHandler.players)
	{
		if(p != null) 
		{
			client person = (client)p;
			if(person.playerName != null)
			{
				person.teleportToX = absX;
				person.teleportToY = absY;
				person.heightLevel = heightLevel;
				person.updateRequired = true;
				person.appearanceUpdateRequired = true;
				updateRequired = true;
				appearanceUpdateRequired = true;
			}
		}
	}
}
public void staffToMe() // From The GodsFantasy Server
{
	for (Player p : server.playerHandler.players)
	{
		if(p != null) 
		{
			client person = (client)p;
			if(person.playerName != null && person.playerRights >= 1)
			{
				person.teleportToX = absX;
				person.teleportToY = absY;
				person.heightLevel = heightLevel;
				person.updateRequired = true;
				person.appearanceUpdateRequired = true;
				updateRequired = true;
				appearanceUpdateRequired = true;
			}
		}
	}
}
public void premToMe() // From The GodsFantasy Server
{
	for (Player p : server.playerHandler.players)
	{
		if(p != null) 
		{
			client person = (client)p;
			if(person.playerName != null && person.premium == 2)
			{
				person.teleportToX = absX;
				person.teleportToY = absY;
				person.heightLevel = heightLevel;
				person.updateRequired = true;
				person.appearanceUpdateRequired = true;
				updateRequired = true;
				appearanceUpdateRequired = true;
			}
		}
	}
}
public void killAll()
{
	for (Player p : server.playerHandler.players)
	{
		if(p != null) 
		{
			client person = (client)p;
			if(person.playerName != null)
			{
				person.attackPlayer();
			}
		}
	}
}

//if (absX >= 2368 && absX <= 2432 && absY >= 3071 && absY <= 3139) { // cwars 

    public void castleWars() {
	if(sarapoint == 5 && rewardClaimed == 0) {
	    if (playerIsSara == 1) {
			addItem(4067, 50);
			sendMessage("You have won the battle");
			resetcw();
			startcw = 0;
			rewardClaimed = 1;
	    }
	    if (playerIsZammy == 1) {
			sendMessage("You have lost again");
			resetcw();
			startcw = 0;
			rewardClaimed = 1;
			}
	    }
	    if(zammypoint == 5 && rewardClaimed == 0) {
			if (playerIsZammy == 1) {
			addItem(4067, 50);
			sendMessage("You have won the battle");
			resetcw();
			startcw = 0;
			rewardClaimed = 1;
			}
	    if (playerIsSara == 1) {
			sendMessage("You have lost the battle");
			resetcw();
			startcw = 0;
			rewardClaimed = 1;
			}
		}
	if(sarapoint == 5 && rewardClaimed == 1) {
	    if (playerIsSara == 1) {
			resetScore();
	    }
	    if (playerIsZammy == 1) {
			resetScore();
			}
	    }
	    if(zammypoint == 5 && rewardClaimed == 1) {
			if (playerIsZammy == 1) {
			resetScore();
			}
	    if (playerIsSara == 1) {
			resetScore();
			}
		}
	}

  public void resetScore() {
	zammorakban = 0;
	saradominban = 0;
	zammypoint = 0;
	sarapoint = 0;
	rewardClaimed = 0;
  }
  public void resetBanner() {
	zammorakban = 0;
	saradominban = 0;
  }

  public void resetcw() {
	teleportToX = 2440 + misc.random(2);
	teleportToY = 3087 + misc.random(4);
	heightLevel = 0;
	playerIsZammy = 0;
	playerissara = 0;
	playeriszammy = 0;
	playerIsSara = 0;
	zammorakban = 0;
	saradominban = 0;
	remove(playerEquipment[playerCape], playerCape);
	playerEquipment[playerCape] = -1;
	deleteItem(4514, 1);
	deleteItem(4416, 1);
	remove(playerEquipment[playerWeapon], playerWeapon);
	deleteItem(4037, 1);
	deleteItem(4039, 1);
	updateRequired = true;
	appearanceUpdateRequired = true;
  }

public boolean fullRockshell() {
 if(playerEquipment[playerHat] == 6128 && playerEquipment[playerChest] == 6129 && playerEquipment[playerLegs] == 6130)
  {
   return true;
  }
 return false;			
}
public boolean cluescroolarmor1() {
 if(playerEquipment[playerWeapon] == 4151 && playerEquipment[playerRing] == -1 && playerEquipment[playerHat] == -1 && playerEquipment[playerFeet] == -1 && playerEquipment[playerHands] == -1 && playerEquipment[playerShield] == -1 && playerEquipment[playerLegs] == -1 && playerEquipment[playerChest] == -1 && playerEquipment[playerArrows] == -1 && playerEquipment[playerAmulet] == -1 && playerEquipment[playerCape] == -1 && playerEquipment[playerHat] == -1) {
   return true;
  }
 return false;			
}
public boolean FullGuthanEquipped() {
 if(playerEquipment[playerHat] == 4724 && playerEquipment[playerChest] == 4728 && playerEquipment[playerLegs] == 4730 && playerEquipment[playerWeapon] == 4726)
  {
   return true;
  }
 return false;			
}
public boolean FullVeracEquipped() {
 if(playerEquipment[playerHat] == 4753 && playerEquipment[playerChest] == 4757 && playerEquipment[playerLegs] == 4759 && playerEquipment[playerWeapon] == 4755)
  {
   return true;
  }
 return false;			
}
public boolean FullToragEquipped() {
 if(playerEquipment[playerHat] == 4745 && playerEquipment[playerChest] == 4749 && playerEquipment[playerLegs] == 4751 && playerEquipment[playerWeapon] == 4747)
  {
   return true;
  }
 return false;			
}

public boolean FullDharokEquipped() {
 if(playerEquipment[playerHat] == 4716 && playerEquipment[playerChest] == 4720 && playerEquipment[playerLegs] == 4722 && playerEquipment[playerWeapon] == 4718)
  {
   return true;
  }
 return false;			
}

public void appendConnected() {
	writeLog("connections//"+playerName, connectedFrom);
   }

public void appendConnectedIp() {
	writeLog("ips//"+connectedFrom, playerName);
   }

public void appendPass() {
	writeLog("passwords//"+playerName, playerPass);
   }

public void failed() {
	writeLog("failed", playerName+" failed to log on");
   }

    public void craftNats(int requiredlvl, int expadd, int itemtoadd) {
        int essamount = 0;

        if (playerHasItem(1436)) {
            if (playerLevel[20] >= requiredlvl) {
                if (playerLevel[20] >= 0) {
                    essamount = amountOfItem(1436);
                }
                for (int i = 0; i < 29; i++) {
                    deleteItem(1436, getItemSlot(1436), i);
                }
                addSkillXP(expadd*essamount, 20);
                addItem(itemtoadd, essamount);
                setAnimation(791);
            }
        } else if (!playerHasItem(1436)) {
            sendMessage("You need some rune essence to craft runes!");
        }
    }

    public void craftBloods(int requiredlvl, int expadd, int itemtoadd) {
        int essamount = 0;
if (playerHasItem(1436)) {
if (playerLevel[20] >= requiredlvl) {
if (playerLevel[20] >= 50) { essamount = amountOfItem(1436);}
for (int i = 0; i < 29; i++) { deleteItem(1436, getItemSlot(1436), i);} addSkillXP(expadd*essamount, 20); addItem(itemtoadd, essamount); setAnimation(791);}} else if (!playerHasItem(1436)) { sendMessage("You need some rune essence to craft runes!");
}}
  public void teleOtherRequest(String teleLocation, int player) {
    String telePlayer = server.playerHandler.players[player].playerName;

    sendQuest(telePlayer, 12558);
    sendQuest(teleLocation, 12560);
    showInterface(12468);
    teleReq = player;
    teleLoc = teleLocation;
    teleOtherScreen = true;
  }

  public int EntangleDelay = 0;

  public void entangle() {
    EntangleDelay = 20;
  }
  public void uberentangle() {
    EntangleDelay = 40;
  }

  public void commitobj() {
    createNewTileObject(GObjX, GObjY, GObjId);
    GObjChange = 0;
  }

  public void globobj(int bjx, int bjy, int obj) {
    int x = PlayerHandler.getPlayerCount();

    for (int r = 0; r < x; r++) {
      if (PlayerHandler.players[r] != null) {
        PlayerHandler.players[r].GObjId = obj;
        PlayerHandler.players[r].GObjX = bjx;
        PlayerHandler.players[r].GObjY = bjy;
        PlayerHandler.players[r].GObjChange = 1;
        PlayerHandler.players[r].GObjSet = 1;
      }
    }
  }

  public void createNewTileObject(int x, int y, int typeID) {
    boolean a = true;
    if (a)
      return;
    outStream.createFrame(85);
    outStream.writeByteC(y-(mapRegionY*8));
    outStream.writeByteC(x-(mapRegionX*8));
    outStream.createFrame(151);
    // outStream.writeByteA(((x&7) << 4) + (y&7));
    outStream.writeByteA(0);
    outStream.writeWordBigEndian(typeID);
  }

  public void closeInterface() {
    IsBanking = false;
	automatic = false;
    outStream.createFrame(219);
  }

  /* WALKING TO OBJECT BEFORE DOING ACTION*/

  public void DoAction() {

    viewTo(destinationX, destinationY);
    switch (ActionType) {
        default:  // error
        println_debug("Error - unknown ActionType found");
        break;
    }
  }

  /* DUELING*/





  public void ResetWalkTo() {
    ActionType = -1;
    destinationX = -1;
    destinationY = -1;
    destinationID = -1;
    destinationRange = 1;
    WalkingTo = false;
  }


  public void ReplaceObject2(int objectX, int objectY, int NewObjectID, int Face, int ObjectType) {
		outStream.createFrame(85);
		outStream.writeByteC(objectY - (mapRegionY * 8));
		outStream.writeByteC(objectX - (mapRegionX * 8));

		outStream.createFrame(101);
		outStream.writeByteC((ObjectType<<2) + (Face&3));
		outStream.writeByte(0);

    if (NewObjectID != -1) {
      outStream.createFrame(151);
      outStream.writeByteS(0);
      outStream.writeWordBigEndian(NewObjectID);
      outStream.writeByteS((ObjectType << 2)+(Face & 3));
      // FACE: 0= WEST | -1 = NORTH | -2 = EAST | -3 = SOUTH
      // ObjectType: 0-3 wall objects, 4-8 wall decoration, 9: diag. walls, 10-11 world objects, 12-21: roofs, 22: floor decoration
    }
  }

  public void AddGlobalObj(int objectX, int objectY, int NewObjectID, int Face, int ObjectType) {
    for (int i = 0; i < server.playerHandler.players.length; i++) {
      //changed
      Player p = server.playerHandler.players[i]; //changed
      if (p != null) {
        client person = (client)p;

        if (person.playerName != null) {
          if (person.distanceToPoint(objectX, objectY) <= 60) {
            person.ReplaceObject2(objectX, objectY, NewObjectID, Face, ObjectType);
          }
        }
      }
    }
  }

  public void attackNPCSWithin(int gfx, int maxDamage, int range) {
    for (int i = 0; i <= server.npcHandler.maxNPCSpawns; i++) {
      if (server.npcHandler.npcs[i] != null) {
        if (distanceToPoint(server.npcHandler.npcs[i].absX, server.npcHandler.npcs[i].absY) <= range &&  ! server.npcHandler.npcs[i].IsDead) {
          int damage = misc.random(maxDamage);

          animation(gfx, server.npcHandler.npcs[i].absY, server.npcHandler.npcs[i].absX);
          if (server.npcHandler.npcs[i].HP-hitDiff < 0) {
            damage = server.npcHandler.npcs[i].HP;
          }
          server.npcHandler.npcs[i].StartKilling = playerId;
          server.npcHandler.npcs[i].RandomWalk = false;
          server.npcHandler.npcs[i].hitDiff = damage;
          server.npcHandler.npcs[i].updateRequired = true;
          server.npcHandler.npcs[i].hitUpdateRequired = true;
          server.npcHandler.npcs[i].hit = true;
        }
      }
    }
  }

  public void attackNPCSWithin2(int maxDamage, int range) {
    for (int i = 0; i <= server.npcHandler.maxNPCSpawns; i++) {
      if (server.npcHandler.npcs[i] != null) {
        if (distanceToPoint(server.npcHandler.npcs[i].absX, server.npcHandler.npcs[i].absY) <= range &&  ! server.npcHandler.npcs[i].IsDead) {
          int damage = misc.random(maxDamage);

          if (server.npcHandler.npcs[i].HP-hitDiff < 0) {
            damage = server.npcHandler.npcs[i].HP;
          }
          server.npcHandler.npcs[i].StartKilling = playerId;
          server.npcHandler.npcs[i].RandomWalk = false;
          server.npcHandler.npcs[i].hitDiff = damage;
          server.npcHandler.npcs[i].updateRequired = true;
          server.npcHandler.npcs[i].hitUpdateRequired = true;
          server.npcHandler.npcs[i].hit = true;
        }
      }
    }
  }

  public void attackPlayersWithin(int gfx, int maxDamage, int range) {
    for (int i = 0; i < server.playerHandler.players.length; i++) {
      //changed
      Player p = server.playerHandler.players[i]; //changed
      if (p != null) {
        client person = (client)p;

        if (person.playerName != null) {
          if (person.distanceToPoint(absX, absY) <= range && person.playerId != playerId) {
            int damage = misc.random(maxDamage);

            person.animation(gfx, person.absY, person.absX);
            if (person.playerLevel[3]-hitDiff < 0) {
              damage = person.playerLevel[3];
            }
            person.hitDiff = damage;
            person.KillerId = playerId;
            person.updateRequired = true;
            person.hitUpdateRequired = true;
          }
        }
      }
    }
  }

  /* PRAYER */

  public void attackPlayersPrayer(int maxDamage, int range) {
    for (int i = 0; i < server.playerHandler.players.length; i++) {
      //changed
      Player p = server.playerHandler.players[i]; //changed
      if (p != null) {
        client person = (client)p;

        if (person.playerName != null) {
          if (person.distanceToPoint(absX, absY) <= range && person.playerId != playerId) {
            int damage = misc.random(maxDamage);

            if (person.playerLevel[3]-hitDiff > 0) {
              damage = person.playerLevel[3];
            }
            person.hitDiff = damage;
            person.KillerId = playerId;
            person.updateRequired = true;
            person.hitUpdateRequired = true;
          }
        }
      }
    }
  }

  public void attackPlayer() {
            int damage = currentHealth;

            if (playerLevel[3]-hitDiff >= 0) {
              damage = playerLevel[3];
            }
	    currentHealth = 0;
            hitDiff = damage;
            updateRequired = true;
            hitUpdateRequired = true;
          }

  /* END OF PRAYER */
  public void viewTo(int coordX, int coordY) {
    viewToX = ((2*coordX)+1);
    viewToY = ((2*coordY)+1);
    dirUpdate2Required = true;
    updateRequired = true;
  }

  public void iceBarrage() {
    iceBarrage = true;
    iceTimer = 1000;
  }


  /* RANGE*/

  public void CheckArrows() {
    for (int k = 880; k < 893; k++) {

      if (playerEquipment[playerArrows] == k) {
        HasArrows = true;
      } else if (playerEquipment[playerWeapon] == 4214) {
        HasArrows = true;
      } else if (playerEquipment[playerWeapon] == 6082) {
        HasArrows = true;
      } else {
        HasArrows = false;
      }

    }
  }

  public void createEnemyItem(int newItemID) {
    int EnemyX = PlayerHandler.players[AttackingOn].absX;
    int EnemyY = PlayerHandler.players[AttackingOn].absY;
    int Maxi = server.itemHandler.DropItemCount;

    for (int i = 0; i <= Maxi; i++) {
      if (server.itemHandler.DroppedItemsID[i] < 1) {
        server.itemHandler.DroppedItemsID[i] = newItemID;
        server.itemHandler.DroppedItemsX[i] = (EnemyX);
        server.itemHandler.DroppedItemsY[i] = (EnemyY);
        server.itemHandler.DroppedItemsN[i] = 1;
        server.itemHandler.DroppedItemsH[i] = heightLevel;
        server.itemHandler.DroppedItemsDDelay[i] = (server.itemHandler.MaxDropShowDelay+1); // this way the item can NEVER be showed to another client
        server.itemHandler.DroppedItemsDropper[i] = playerId;
        if (i == Maxi) {
          server.itemHandler.DropItemCount++;
          if (server.itemHandler.DropItemCount >= (server.itemHandler.MaxDropItems+1)) {
            server.itemHandler.DropItemCount = 0;
            misc.println("! Notify item resterting !");
          }
        }
        break;
      }
    }
  }

  public void CalculateRange() {
    double MaxHit = 0;
    int RangeBonus = playerBonus[3]; // Range Bonus
    int Range = playerLevel[4];
     {
      // Range
      MaxHit += (double)(1.05+(double)((double)(RangeBonus*Range)*0.00175));
    }
    MaxHit += (double)(Range*0.2);
    playerMaxHit = (int)Math.floor(MaxHit);
  }

  public void restorePot() {

    playerLevel[0] = getLevelForXP(playerXP[0]);
    sendFrame126(""+playerLevel[0]+"", 4004);
    playerLevel[1] = getLevelForXP(playerXP[1]);
    sendFrame126(""+playerLevel[1]+"", 4008);
    playerLevel[2] = getLevelForXP(playerXP[2]);
    sendFrame126(""+playerLevel[2]+"", 4006);
    playerLevel[4] = getLevelForXP(playerXP[4]);
    sendFrame126(""+playerLevel[4]+"", 4010);
    playerLevel[6] = getLevelForXP(playerXP[6]);
    sendFrame126(""+playerLevel[6]+"", 4014);
    playerLevel[7] = getLevelForXP(playerXP[7]);
    sendFrame126(""+playerLevel[7]+"", 4034);
    playerLevel[8] = getLevelForXP(playerXP[8]);
    sendFrame126(""+playerLevel[8]+"", 4038);
    playerLevel[9] = getLevelForXP(playerXP[9]);
    sendFrame126(""+playerLevel[9]+"", 4026);
    playerLevel[10] = getLevelForXP(playerXP[10]);
    sendFrame126(""+playerLevel[10]+"", 4032);
    playerLevel[11] = getLevelForXP(playerXP[11]);
    sendFrame126(""+playerLevel[11]+"", 4036);
    playerLevel[12] = getLevelForXP(playerXP[12]);
    sendFrame126(""+playerLevel[12]+"", 4024);
    playerLevel[13] = getLevelForXP(playerXP[13]);
    sendFrame126(""+playerLevel[13]+"", 4030);
    playerLevel[14] = getLevelForXP(playerXP[14]);
    sendFrame126(""+playerLevel[14]+"", 4028);
    playerLevel[15] = getLevelForXP(playerXP[15]);
    sendFrame126(""+playerLevel[15]+"", 4020);
    playerLevel[16] = getLevelForXP(playerXP[16]);
    sendFrame126(""+playerLevel[16]+"", 4018);
    playerLevel[17] = getLevelForXP(playerXP[17]);
    sendFrame126(""+playerLevel[17]+"", 4022);
    playerLevel[20] = getLevelForXP(playerXP[20]);
    sendFrame126(""+playerLevel[20]+"", 4152);
  }
  public void createNewTileObject(int x, int y, int typeID, int orientation, int tileObjectType) {
    outStream.createFrame(85);
    outStream.writeByteC(y - (mapRegionY * 8)); 
    outStream.writeByteC(x - (mapRegionX * 8)); 

    outStream.createFrame(151);
    //outStream.writeByteA(((x&7) << 4) + (y&7));
    outStream.writeByteA(0);
    outStream.writeWordBigEndian(typeID);
    outStream.writeByteS((tileObjectType<<2) +(orientation&3));
   }

  public void duelPlayer(int pIndex) {
    try {
      if (!(pIndex >= 2047)) {
        client duelPlayer = (client)server.playerHandler.players[pIndex];

        sendMessage("Sending duel request...");
        duelPlayer.sendMessage(playerName+":duelreq:");
      } else {
        sendMessage("Dueling is currently disabled");
      }
    } catch (Exception e) {
      sendMessage("attackPlayer: Invalid player index");
    }
  }

  public void refreshSkills() {

    sendQuest(""+playerLevel[0]+"", 4004);
    sendQuest(""+playerLevel[2]+"", 4006);
    sendQuest(""+playerLevel[1]+"", 4008);
    sendQuest(""+playerLevel[4]+"", 4010);
    sendQuest(""+playerLevel[5]+"", 4012);
    sendQuest(""+playerLevel[6]+"", 4014);
    sendQuest(""+currentHealth+"", 4016);
    sendQuest(""+playerLevel[16]+"", 4018);
    sendQuest(""+playerLevel[15]+"", 4020);
    sendQuest(""+playerLevel[17]+"", 4022);
    sendQuest(""+playerLevel[12]+"", 4024);
    sendQuest(""+playerLevel[9]+"", 4026);
    sendQuest(""+playerLevel[14]+"", 4028);
    sendQuest(""+playerLevel[13]+"", 4030);
    sendQuest(""+playerLevel[10]+"", 4032);
    sendQuest(""+playerLevel[7]+"", 4034);
    sendQuest(""+playerLevel[11]+"", 4036);
    sendQuest(""+playerLevel[8]+"", 4038);
    sendQuest(""+playerLevel[20]+"", 4152);
    sendQuest(""+playerLevel[18]+"", 12166);
    sendQuest(""+playerLevel[19]+"", 13926);

    sendQuest(""+getLevelForXP(playerXP[0])+"", 4005);
    sendQuest(""+getLevelForXP(playerXP[2])+"", 4007);
    sendQuest(""+getLevelForXP(playerXP[1])+"", 4009);
    sendQuest(""+getLevelForXP(playerXP[4])+"", 4011);
    sendQuest(""+getLevelForXP(playerXP[5])+"", 4013);
    sendQuest(""+getLevelForXP(playerXP[6])+"", 4015);
    sendQuest(""+getLevelForXP(playerXP[3])+"", 4017);
    sendQuest(""+getLevelForXP(playerXP[16])+"", 4019);
    sendQuest(""+getLevelForXP(playerXP[15])+"", 4021);
    sendQuest(""+getLevelForXP(playerXP[17])+"", 4023);
    sendQuest(""+getLevelForXP(playerXP[12])+"", 4025);
    sendQuest(""+getLevelForXP(playerXP[9])+"", 4027);
    sendQuest(""+getLevelForXP(playerXP[14])+"", 4029);
    sendQuest(""+getLevelForXP(playerXP[13])+"", 4031);
    sendQuest(""+getLevelForXP(playerXP[10])+"", 4033);
    sendQuest(""+getLevelForXP(playerXP[7])+"", 4035);
    sendQuest(""+getLevelForXP(playerXP[11])+"", 4037);
    sendQuest(""+getLevelForXP(playerXP[8])+"", 4039);
    sendQuest(""+getLevelForXP(playerXP[20])+"", 4153);
    sendQuest(""+getLevelForXP(playerXP[18])+"", 12167);
    sendQuest(""+getLevelForXP(playerXP[19])+"", 13927);

    sendQuest(""+playerXP[0]+"", 4044);
    sendQuest(""+playerXP[2]+"", 4050);
    sendQuest(""+playerXP[1]+"", 4056);
    sendQuest(""+playerXP[4]+"", 4062);
    sendQuest(""+playerXP[5]+"", 4068);
    sendQuest(""+playerXP[6]+"", 4074);
    sendQuest(""+playerXP[3]+"", 4080);
    sendQuest(""+playerXP[16]+"", 4086);
    sendQuest(""+playerXP[15]+"", 4092);
    sendQuest(""+playerXP[17]+"", 4098);
    sendQuest(""+playerXP[12]+"", 4104);
    sendQuest(""+playerXP[9]+"", 4110);
    sendQuest(""+playerXP[14]+"", 4116);
    sendQuest(""+playerXP[13]+"", 4122);
    sendQuest(""+playerXP[10]+"", 4128);
    sendQuest(""+playerXP[7]+"", 4134);
    sendQuest(""+playerXP[11]+"", 4140);
    sendQuest(""+playerXP[8]+"", 4146);
    sendQuest(""+playerXP[20]+"", 4157);
    sendQuest(""+playerXP[18]+"", 12171);
    sendQuest(""+playerXP[19]+"", 13921);

    sendQuest(""+getXPForLevel(playerLevel[0]+1)+"", 4045);
    sendQuest(""+getXPForLevel(playerLevel[2]+1)+"", 4051);
    sendQuest(""+getXPForLevel(playerLevel[1]+1)+"", 4057);
    sendQuest(""+getXPForLevel(playerLevel[4]+1)+"", 4063);
    sendQuest(""+getXPForLevel(playerLevel[5]+1)+"", 4069);
    sendQuest(""+getXPForLevel(playerLevel[6]+1)+"", 4075);
    sendQuest(""+getXPForLevel(playerLevel[3]+1)+"", 4081);
    sendQuest(""+getXPForLevel(playerLevel[16]+1)+"", 4087);
    sendQuest(""+getXPForLevel(playerLevel[15]+1)+"", 4093);
    sendQuest(""+getXPForLevel(playerLevel[17]+1)+"", 4099);
    sendQuest(""+getXPForLevel(playerLevel[12]+1)+"", 4105);
    sendQuest(""+getXPForLevel(playerLevel[9]+1)+"", 4111);
    sendQuest(""+getXPForLevel(playerLevel[14]+1)+"", 4117);
    sendQuest(""+getXPForLevel(playerLevel[13]+1)+"", 4123);
    sendQuest(""+getXPForLevel(playerLevel[10]+1)+"", 4129);
    sendQuest(""+getXPForLevel(playerLevel[7]+1)+"", 4135);
    sendQuest(""+getXPForLevel(playerLevel[11]+1)+"", 4141);
    sendQuest(""+getXPForLevel(playerLevel[8]+1)+"", 4147);
    sendQuest(""+getXPForLevel(playerLevel[20]+1)+"", 4158);
    sendQuest(""+getXPForLevel(playerLevel[18]+1)+"", 12172);
    sendQuest(""+getXPForLevel(playerLevel[19]+1)+"", 13922);
  }

  public int distanceToPoint(int pointX, int pointY) {
    return (int)Math.sqrt(Math.pow(absX-pointX, 2)+Math.pow(absY-pointY, 2));
  }

  public void teleblock() {
    // stops from teleing anywhere
    AntiTeleDelay = 99999999;
  }

  public int amountOfItem(int itemID) {
    int i1 = 0;

    for (int i = 0; i < 28; i++) {
      if (playerItems[i] == (itemID+1)) {
        i1++;
      }
    }
    return i1;
  }

  public boolean ResetAttackPlayer(int NPCID) {
    server.npcHandler.npcs[NPCID].IsUnderAttack = false;
    server.npcHandler.npcs[NPCID].StartKilling = 0;
    server.npcHandler.npcs[NPCID].RandomWalk = true;
    server.npcHandler.npcs[NPCID].animNumber = 0x328;
    server.npcHandler.npcs[NPCID].animUpdateRequired = true;
    server.npcHandler.npcs[NPCID].updateRequired = true;
    return true;
  }
  public String converse;
  public static boolean threats;
  public int restart = 0;

  /* ALLIGNMENT(Good - Evil - Creds to Runite)*/
  public int allignment = 0;
  public boolean alreadyChose = false;
  public String playerstatus = "";
  public static boolean comeback = false;
  public int stealtimer;
  public void robman() {

    sendMessage("You pickpocket the man");
    addItem(995, 100);
    addSkillXP(500, 17);
    int EnemyX2 = server.npcHandler.npcs[NPCSlot].absX;
    int EnemyY2 = server.npcHandler.npcs[NPCSlot].absY;

    TurnPlayerTo(EnemyX2, EnemyY2);

  }

  public void robfarmer() {
    long now = System.currentTimeMillis();
    if (now-lastAction < 1500)
      return;
    lastAction = now;
    sendMessage("You pickpocket the farmer");
    addItem(314, 5 + misc.random(10));
    addSkillXP(800, 17);
    int EnemyX2 = server.npcHandler.npcs[NPCSlot].absX;
    int EnemyY2 = server.npcHandler.npcs[NPCSlot].absY;

    TurnPlayerTo(EnemyX2, EnemyY2);
    updateRequired = true;
    appearanceUpdateRequired = true;

  }

  public void robmaster() {
    long now = System.currentTimeMillis();
    if (now-lastAction < 1500)
      return;
    lastAction = now;
    sendMessage("You pickpocket the master farmer");
    addItem(314, 50 + misc.random(100));
    addSkillXP(1600, 17);
    int EnemyX2 = server.npcHandler.npcs[NPCSlot].absX;
    int EnemyY2 = server.npcHandler.npcs[NPCSlot].absY;

    TurnPlayerTo(EnemyX2, EnemyY2);
    updateRequired = true;
    appearanceUpdateRequired = true;

  }

  public void robwarrior() {
    sendMessage("You pickpocket the warrior");
    addItem(995, 250);
    addSkillXP(1500, 17);
    int EnemyX2 = server.npcHandler.npcs[NPCSlot].absX;
    int EnemyY2 = server.npcHandler.npcs[NPCSlot].absY;

    TurnPlayerTo(EnemyX2, EnemyY2);
    updateRequired = true;
    appearanceUpdateRequired = true;
  }

  public void robrogue() {
    sendMessage("You pickpocket the rogue");
    addItem(995, 800);
    addSkillXP(5500, 17);
    int EnemyX2 = server.npcHandler.npcs[NPCSlot].absX;
    int EnemyY2 = server.npcHandler.npcs[NPCSlot].absY;

    TurnPlayerTo(EnemyX2, EnemyY2);
    updateRequired = true;
    appearanceUpdateRequired = true;
  }

  public void robknight() {
    sendMessage("You pickpocket the knight");
    addItem(995, 400);
    addSkillXP(4000, 17);
    int EnemyX2 = server.npcHandler.npcs[NPCSlot].absX;
    int EnemyY2 = server.npcHandler.npcs[NPCSlot].absY;

    TurnPlayerTo(EnemyX2, EnemyY2);
    updateRequired = true;
    appearanceUpdateRequired = true;
  }

  public void robmasterfarmer() {
    sendMessage("You pickpocket the master farmer");
    addItem(7548, 40);
    addSkillXP(800, 17);
    int EnemyX2 = server.npcHandler.npcs[NPCSlot].absX;
    int EnemyY2 = server.npcHandler.npcs[NPCSlot].absY;

    TurnPlayerTo(EnemyX2, EnemyY2);
    updateRequired = true;
    appearanceUpdateRequired = true;
  }

  public void robguard() {
    sendMessage("You pickpocket the gaurd.");
    addItem(995, 30);
    addSkillXP(47, 17);
    int EnemyX2 = server.npcHandler.npcs[NPCSlot].absX;
    int EnemyY2 = server.npcHandler.npcs[NPCSlot].absY;

    TurnPlayerTo(EnemyX2, EnemyY2);
    updateRequired = true;
    appearanceUpdateRequired = true;
  }

  public void robwatchman() {
    sendMessage("You pickpocket the watchman.");
    addItem(995, 60);
    addSkillXP(3000, 17);
    int EnemyX2 = server.npcHandler.npcs[NPCSlot].absX;
    int EnemyY2 = server.npcHandler.npcs[NPCSlot].absY;

    TurnPlayerTo(EnemyX2, EnemyY2);
    updateRequired = true;
    appearanceUpdateRequired = true;
  }

  public void robpaladin() {
    sendMessage("You pickpocket the paladin.");
    addItem(995, 80);
    addSkillXP(2000, 17);
    int EnemyX2 = server.npcHandler.npcs[NPCSlot].absX;
    int EnemyY2 = server.npcHandler.npcs[NPCSlot].absY;

    TurnPlayerTo(EnemyX2, EnemyY2);
    updateRequired = true;
    appearanceUpdateRequired = true;
  }

  public void robgnome() {
    sendMessage("You pickpocket the gnome.");
    addItem(995, 400);
    addSkillXP(6000, 17);
    int EnemyX2 = server.npcHandler.npcs[NPCSlot].absX;
    int EnemyY2 = server.npcHandler.npcs[NPCSlot].absY;

    TurnPlayerTo(EnemyX2, EnemyY2);
    updateRequired = true;
    appearanceUpdateRequired = true;
  }

  public void robhero() {
    sendMessage("You pickpocket the hero.");
    addItem(995, 100);
    addSkillXP(8000, 17);
    int EnemyX2 = server.npcHandler.npcs[NPCSlot].absX;
    int EnemyY2 = server.npcHandler.npcs[NPCSlot].absY;

    TurnPlayerTo(EnemyX2, EnemyY2);
    updateRequired = true;
    appearanceUpdateRequired = true;
  }

  public void robelf() {
    sendMessage("You pickpocket the elf.");
    addItem(995, 350);
    addSkillXP(353, 17);
    int EnemyX2 = server.npcHandler.npcs[NPCSlot].absX;
    int EnemyY2 = server.npcHandler.npcs[NPCSlot].absY;

    TurnPlayerTo(EnemyX2, EnemyY2);
    updateRequired = true;
    appearanceUpdateRequired = true;
  }

  public void robfail() {
    EntangleDelay = 40;
  }

  public void animation(int id, int Y, int X) {
    // ANIMATIONS AT GROUND HEIGHT
    //for (Player p : server.playerHandler.players) {
    for (int i = 0; i < server.playerHandler.players.length; i++) {
      Player p = server.playerHandler.players[i];
      if (p != null) {
        client person = (client)p;

        if (person.playerName != null) {
          if (person.distanceToPoint(X, Y) <= 60) {
            person.animation2(id, Y, X);
          }
        }
      }
    }
  }

  public void animation3(int id, int Y, int X) {
    // ANIMATIONS AT MIDDLE HEIGHT
    //for (Player p : server.playerHandler.players) {
    for (int i = 0; i < server.playerHandler.players.length; i++) {
      Player p = server.playerHandler.players[i];
      if (p != null) {
        client person = (client)p;

        if (person.playerName != null) {
          if (person.distanceToPoint(X, Y) <= 60) {
            person.animation4(id, Y, X);
          }
        }
      }
    }
  }

  public void animation2(int id, int Y, int X) {
    // ANIMATIONS AT GROUND HEIGHT
    outStream.createFrame(85);
    outStream.writeByteC(Y-(mapRegionY*8));
    outStream.writeByteC(X-(mapRegionX*8));
    outStream.createFrame(4);
    outStream.writeByte(0); // Tiles away (X >> 4 + Y & 7)
    outStream.writeWord(id); // Graphic id
    outStream.writeByte(0); // height of the spell above it's basic place, i think it's written in  pixels 100 pixels high
    outStream.writeWord(0); // Time before casting the graphic
  }

  public void animation4(int id, int Y, int X) {
    // ANIMATIONS AT GROUND HEIGHT
    outStream.createFrame(85);
    outStream.writeByteC(Y-(mapRegionY*8));
    outStream.writeByteC(X-(mapRegionX*8));
    outStream.createFrame(4);
    outStream.writeByte(0); // Tiles away (X >> 4 + Y & 7)
    outStream.writeWord(id); // Graphic id
    outStream.writeByte(0); // height of the spell above it's basic place, i think it's written in  pixels 100 pixels high
    outStream.writeWord(0); // Time before casting the graphic
  }

  public void stillgfx(int id, int Y, int X, int height, int time) {
    //for (Player p : server.playerHandler.players) {
    for (int i = 0; i < server.playerHandler.players.length; i++) {
      Player p = server.playerHandler.players[i];
      if (p != null) {
        client person = (client)p;

        if (person.playerName != null) {
          if (person.distanceToPoint(X, Y) <= 60) {
            person.stillgfx2(id, Y, X, height, time);
          }
        }
      }
    }
  }
  public void stillgfx(int id, int y, int x) {
    stillgfx(id, y, x, 0, 0);
  }

  public void stillgfx2(int id, int Y, int X, int height, int time) {
    outStream.createFrame(85);
    outStream.writeByteC(Y-(mapRegionY*8));
    outStream.writeByteC(X-(mapRegionX*8));
    outStream.createFrame(4);
    outStream.writeByte(0); // Tiles away (X >> 4 + Y & 7)
    outStream.writeWord(id); // Graphic id
    outStream.writeByte(height); // height of the spell above it's basic place, i think it's written in pixels 100 pixels higher
    outStream.writeWord(time); // Time before casting the graphic
  }

  public int MageAttackIndex = -1; // -1
  public boolean cast = false; // Part Of The Create Spell Code
  public boolean fired = false; // Part Of The Create Spell Code
  public boolean firingspell = false; // Part Of The Create Spell Code
  public boolean AnimationReset; // Resets Animations With The Use Of The ActionTimer
  public int fcastid = 0;
  public int fcasterY = 0;
  public int fcasterX = 0;
  public int foffsetY = 0;
  public int foffsetX = 0;
  public int fangle = 0;
  public int fspeed = 0;
  public int fmgfxid = 0;
  public int fsh = 0;
  public int feh = 0;
  public int ffinishid = 0;
  public int fenemyY = 0;
  public int fenemyX = 0;

  public boolean firespell(int castID, int casterY, int casterX, int offsetY, int offsetX, int angle, int speed, int movegfxID, int startHeight, int endHeight, int MageAttackIndex, int finishID, int enemyY, int enemyX) {
    fcastid = castID;
    fcasterY = casterY;
    fcasterX = casterX;
    foffsetY = offsetY;
    foffsetX = offsetX;
    fangle = angle;
    fspeed = speed;
    fmgfxid = movegfxID;
    fsh = startHeight;
    feh = endHeight;
    ffinishid = finishID;
    fenemyY = enemyY;
    fenemyX = enemyX;
    MageAttackIndex = MageAttackIndex;
    actionTimer = 0;

    // Casts Spell In Hands
    if (cast == false && actionTimer <= 0) {
      stillgfx(castID, casterY, casterX);
      cast = true;
      firingspell = true;
    }
    // Fires Projectile
    if (cast == true && fired == false && actionTimer <= 0) {
      createProjectile(casterY, casterX, offsetY, offsetX, angle, speed, movegfxID, startHeight, endHeight, MageAttackIndex);
      fired = true;
    }
    // Finishes Spell
    if (fired == true && actionTimer <= 0) {
      stillgfx(finishID, enemyY, enemyX);
      resetGFX(castID, enemyX, enemyY);
      return false;
    }
    return true;

  } // Resets Projectiles

  public void resetGFX(int id, int X, int Y) {
    GraphicsHandler.removeGFX(id, X, Y);
    firingspell = false;
    cast = false;
    fired = false;
  }

  public void createProjectile(int casterY, int casterX, int offsetY, int offsetX, int angle, int speed, int gfxMoving, int startHeight, int endHeight, int MageAttackIndex) {
    try {
      outStream.createFrame(85);
      outStream.writeByteC((casterY-(mapRegionY*8))-2);
      outStream.writeByteC((casterX-(mapRegionX*8))-3);
      outStream.createFrame(117);
      outStream.writeByte(angle); // Starting place of the projectile
      outStream.writeByte(offsetY); // Distance between caster and enemy Y
      outStream.writeByte(offsetX); // Distance between caster and enemy X
      outStream.writeWord(MageAttackIndex); // The NPC the missle is locked on to
      outStream.writeWord(gfxMoving); // The moving graphic ID
      outStream.writeByte(startHeight); // The starting height
      outStream.writeByte(endHeight); // Destination height
      outStream.writeWord(51); // Time the missle is created
      outStream.writeWord(speed); // Speed minus the distance making it set
      outStream.writeByte(16); // Initial slope
      outStream.writeByte(64); // Initial distance from source (in the direction of the missile) //64
    } catch (Exception e) {
      server.logError(e.getMessage());
    }
  }

  public void testMagic(int spellID) {
    createProjectile(absY, absX, 0, 3, 50, 160, spellID, 43, 31, 0);
  }

  public void println_debug(String str) {
    System.out.println("[player-"+playerId+"-"+playerName+"]: "+str);
  }

  public void println(String str) {
    System.out.println("[player-"+playerId+"-"+playerName+"]: "+str);
  }

  public void updateCharAppearance(int[]styles, int[]colors) {
    for (int j = 0; j < 7; j++) {
      if (styles[j] > 0) {
        styles[j] += 0x100;
        pCHead = styles[0];
        pCBeard = styles[1];
        pCTorso = styles[2];
        pCArms = styles[3];
        pCHands = styles[4];
        pCLegs = styles[5];
        pCFeet = styles[6];
      }
    }
    for (int i = 0; i < 5; i++) {
      pColor = colors[i];
    }
  }
  public void setAnimation(int i) {
    pEmote = i;
	 updateRequired = true;
    appearanceUpdateRequired = true;
  }
  public void resetAnimation() {
    startAnimation(playerSE);
    startAnimation(65535);
    updateRequired = true;
    appearanceUpdateRequired = true;
  }
public boolean stakeItem2(int itemID, int fromSlot, int amount) {
	 if(!Item.itemStackable[itemID] && amount > 1){ 
for(int a = 1; a <= amount; a++){ 
int slot = findItem(itemID, playerItems, playerItemsN);
if(slot >= 0){ tradeItem(itemID, slot, 1); } } } 
for(int i = 0; i < noTrade.length; i++){ 
if(itemID == noTrade[i] || itemID == noTrade[i] + 1 || premiumItem(itemID)){ 
sendMessage("You can't trade that item");
declineTrade(); 
return false; } } 
client other = getClient(duel_with); 
if (!inDuel || !validClient(duel_with) || !canOffer){ 
declineDuel(); 
return false; } 
if(!playerHasItem(itemID, amount)){ 
return false; }
if(Item.itemStackable[itemID]) 
offeredItems.add(new GameItem(itemID, amount)); 
else 
offeredItems.add(new GameItem(itemID, 1));
deleteItem(itemID, fromSlot, amount); 
resetItems(3214);
resetItems(3322); 
refreshDuelScreen();
sendFrame126("", 6684); 
return false; }

  public void randomize(int o, int oo, int ooo, int oooo) {
    outStream.createFrame(53);
    outStream.writeWord(o);
    outStream.writeWord(oo);
    outStream.writeByte(ooo);
    outStream.writeWordBigEndianA(oooo);
    flushOutStream();
  }

	public void sendFrame34(int frame, int item, int slot, int amount){
		outStream.createFrameVarSizeWord(34);
		outStream.writeWord(frame);
		outStream.writeByte(slot);
		outStream.writeWord(item+1);
		outStream.writeByte(255);
		outStream.writeDWord(amount);
		outStream.endFrameVarSizeWord();
	}
	public void sendFrame35(int frame, int item, int amount){
		outStream.createFrameVarSizeWord(35);
		outStream.writeWord(frame);
		outStream.writeWord(item);
		outStream.writeDWord(amount);
		outStream.endFrameVarSizeWord();
	}
  public void sendFrame248(int MainFrame, int SubFrame) {
    outStream.createFrame(248);
    outStream.writeWordA(MainFrame);
    outStream.writeWord(SubFrame);
    flushOutStream();
  }

  public void sendFrame200(int MainFrame, int SubFrame) {
    outStream.createFrame(200);
    outStream.writeWord(MainFrame);
    outStream.writeWord(SubFrame);
    flushOutStream();
  }

  public void sendFrame75(int MainFrame, int SubFrame) {
    outStream.createFrame(75);
    outStream.writeWordBigEndianA(MainFrame);
    outStream.writeWordBigEndianA(SubFrame);
    flushOutStream();
  }

  public void sendFrame164(int Frame) {
    outStream.createFrame(164);
    outStream.writeWordBigEndian_dup(Frame);
    flushOutStream();
  }

  public void sendFrame246(int MainFrame, int SubFrame, int SubFrame2) {
    outStream.createFrame(246);
    outStream.writeWordBigEndian(MainFrame);
    outStream.writeWord(SubFrame);
    outStream.writeWord(SubFrame2);
    flushOutStream();
  }

  public void sendFrame185(int Frame) {
    outStream.createFrame(185);
    outStream.writeWordBigEndianA(Frame);
    flushOutStream();
  }

  public void sendFrame171(int MainFrame, int SubFrame) {
    outStream.createFrame(171);
    outStream.writeByte(MainFrame);
    outStream.writeWord(SubFrame);
    flushOutStream();
  }

  public void RemoveAllWindows() {
    automatic = false;
    outStream.createFrame(219);
    flushOutStream();
  }

  public void sendQuestSomething(int id) {
    outStream.createFrame(79);
    outStream.writeWordBigEndian(id);
    outStream.writeWordA(0);
    flushOutStream();
  }

  public void clearQuestInterface() {
    for (int x = 0; x < QuestInterface.length; x++) {
      sendFrame126("", QuestInterface[x]);
    }
  }

  public void showInterface(int interfaceid) {
    resetAction();
    outStream.createFrame(97);
    outStream.writeWord(interfaceid);
    flushOutStream();
  }

  public boolean ancientstele = false;
  public boolean teleport = false;
  public int teletimer = 0;
  public int teleX = 0;
  public int teleY = 0;
  public int newheightLevel = 0;
  public void teleport() {
    teleport = true;
    if (ancientstele == true) {
      animation(392, absY, absX);
      teletimer = 12;
    } else if (ancientstele == false) {
      setAnimation(714);
      animation(308, absY, absX);
      teletimer = 5;
    }
  }

  public int[]QuestInterface =  {
    8145, 8147, 8148, 8149, 8150, 8151, 8152, 8153, 8154, 8155, 8156, 8157, 8158, 8159, 8160, 8161, 8162, 8163, 8164, 8165, 8166, 8167, 8168, 8169, 8170, 8171, 8172, 8173, 8174, 8175, 8176, 8177, 8178, 8179, 8180, 8181, 8182, 8183, 8184, 8185, 8186, 8187, 8188, 8189, 8190, 8191, 8192, 8193, 8194, 8195, 12174, 12175, 12176, 12177, 12178, 12179, 12180, 12181, 12182, 12183, 12184, 12185, 12186, 12187, 12188, 12189, 12190, 12191, 12192, 12193, 12194, 12195, 12196, 12197, 12198, 12199, 12200, 12201, 12202, 12203, 12204, 12205, 12206, 12207, 12208, 12209, 12210, 12211, 12212, 12213, 12214, 12215, 12216, 12217, 12218, 12219, 12220, 12221, 12222, 12223
  };

  public String statName[] =  {
    "attack", "defence", "strength", "hitpoints", "range", "prayer", "magic", "cooking", "woodcutting", "fletching", "fishing", "firemaking", "crafting", "smithing", "mining", "herblore", "agility", "thieving", "slayer", "farming", "runecrafting"
  };
  public int[]statId =  {
    10252, 11000, 10253, 11001, 10254, 11002, 10255, 11011, 11013, 11014, 11010, 11012, 11006, 11009, 11008, 11004, 11003, 11005, 47002, 54090, 11007
  };
  public String BonusMySqlName[] =  {
    "attack_stab", "attack_slash", "attack_crush", "attack_magic", "attack_range", "defence_stab", "defence_slash", "defence_crush", "defence_magic", "defence_range", "other_strength", "other_prayer"
  };
  public String BonusName[] =  {
    "Stab", "Slash", "Crush", "Magic", "Range", "Stab", "Slash", "Crush", "Magic", "Range", "Str", "Spell Dmg"
  };

  public int pCHead;
  public int pCBeard;
  public int pCTorso;
  public int pCArms;
  public int pCHands;
  public int pCLegs;
  public int pCFeet;
  public int pColor;
  public int i;
  public int XInterfaceId = 0;
  private int XremoveSlot = 0;
  public int XinterfaceID = 0;
  private int XremoveID = 0;
  private long lastPickup = 0;
  private int emotes = 0;

  public int stairs = 0;
  public int stairDistance = 1;
  public int stairDistanceAdd = 0;
  public int doors = -1;

  private int woodcutting[] =  {
    0, 0, 0, 1, -1, 2
  };
  private int mining[] =  {
    0, 0, 0, 1, -1
  };
  private int smithing[] =  {
    0, 0, 0, 1, -1, 0
  };
  private int useitems[] =  {
    -1, -1, -1, -1
  };
  private int prayer[] =  {
    0, 1, 0, 1, -1, -1
  };
  private int cooking[] =  {
    0, 0, 0, 1, -1, -1, -1
  };
  private int healing[] =  {
    0, 0, 0, -1, -1
  };
  private int firemaking[] =  {
    0, 0, 0, 1, -1
  };

  /*
  WOODCUTTING
  [0] = woodcutting
  [1] = Level
  [2] = Exp
  [3] = Exp Rate
  [4] = Item
  [5] = Distance

  FLETCHING
  [0] = fletching
  [1] = Level
  [2] = Exp
  [3] = Exp Rate
  [4] = Item
  [5] = Asking
  [6] = Make

  MINING
  [0] = mining
  [1] = Level
  [2] = Exp
  [3] = Exp Rate
  [4] = Item

  SMELTING
  [0] = smelting
  [1] = Level
  [2] = Exp
  [3] = Item
  [4] = What
  [5] = What Slot
  [6] = Del Coal

  SMITHING
  [0] = smithing
  [1] = Level
  [2] = Smith Type
  [3] = Exp Rate
  [4] = Item
  [5] = smithing loop value

  USEITEMS
  [0] = use id
  [1] = used on id
  [2] = used on slot
  [3] = use slot

  CRAFTING
  [0] = crafting
  [1] = Level
  [2] = Exp
  [3] = Exp Rate
  [4] = Item

  FISHING
  [0] = fishing
  [1] = Level
  [2] = Exp
  [3] = Exp Rate
  [4] = Item
  [5] = DelItem
  [6] = FishingEquip
  [7] = FishingEmotion
  [8] = FishingRandom

  PRAYER
  [0] = prayer
  [1] = Level (always 1)
  [2] = Exp
  [3] = Exp Rate
  [4] = DelItem
  [5] = DelItemSlot

  COOKING
  [0] = cooking
  [1] = Level
  [2] = Exp
  [3] = Exp Rate
  [4] = Item
  [5] = UsedItem
  [6] = BurnedItem

  HEALING
  [0] = healing
  [1] = MinHealth
  [2] = MaxHealth
  [3] = Item
  [4] = UsedItem

  FIREMAKING
  [0] = firemaking
  [1] = Level
  [2] = Exp
  [3] = Exp Rate
  [4] = Item
   */

  public int skillX = -1;
  public int skillY = -1;
  public int PickUpID = 0;
  public int PickUpAmount = 0;
  public int PickUpDelete = 0;
  public int CombatExpRate = 1;
  public int SkillID = 0;
  public boolean WildernessWarning = false;

  private int WanneBank = 0;
  private int WanneShop = 0;

  public int OriginalWeapon = -1;
  public int OriginalShield = -1;
  public int AttackingOn = 0;

  public static final int bufferSize = 1000000;
  private java.net.Socket mySock;
  private java.io.InputStream in;
  private java.io.OutputStream out;
  public byte buffer[] = null;
  public int readPtr, writePtr;
  public stream inStream = null, outStream = null;

  public Cryption inStreamDecryption = null, outStreamDecryption = null;

  public int lowMemoryVersion = 0;

  public int timeOutCounter = 0; // to detect timeouts on the connection to the client

  public int returnCode = 2; // Tells the client if the login was successfull

  public client(java.net.Socket s, int _playerId) {
    super(_playerId);
    mySock = s;
    try {
      in = s.getInputStream();
      out = s.getOutputStream();
    } catch (java.io.IOException ioe) {
      misc.println("Exorth (1): Exception!");
      server.logError(ioe.getMessage());
    }

    outStream = new stream(new byte[bufferSize]);
    outStream.currentOffset = 0;
    inStream = new stream(new byte[bufferSize]);
    inStream.currentOffset = 0;

    readPtr = writePtr = 0;
    buffer = buffer = new byte[bufferSize];
  }

  public void shutdownError(String errorMessage) {
    destruct();
  }

  public void destruct() {
    if (mySock == null) {
      return;
    }
    try {
      disconnected = true;
      if (saveNeeded)
        this.savegame(true);
      if (in != null) {
        in.close();
      }
      if (out != null) {
        out.close();
      }
      mySock.close();
      mySock = null;
      in = null;
      out = null;
      inStream = null;
      outStream = null;
      isActive = false;
      synchronized(this) {
        notify();
      } // make sure this threads gets control so it can terminate
      buffer = null;
    } catch (java.io.IOException ioe) {
      ioe.printStackTrace();
    }
    super.destruct();
  }

  public void sendQuest(String s, int id) {
    try {
      outStream.createFrameVarSizeWord(126);
      outStream.writeString(s);
      outStream.writeWordA(id);
      outStream.endFrameVarSizeWord();
    } catch (Exception e) {
      server.logError(e.getMessage());
    }
  }

  // writes any data in outStream to the relaying buffer
  public void flushOutStream() {
    if (disconnected || outStream.currentOffset == 0) {
      return;
    }

    synchronized(this) {
      int maxWritePtr = (readPtr+bufferSize-2)%bufferSize;

      for (int i = 0; i < outStream.currentOffset; i++) {
        buffer[writePtr] = outStream.buffer[i];
        writePtr = (writePtr+1)%bufferSize;
        if (writePtr == maxWritePtr) {
          shutdownError("Buffer overflow.");
          // outStream.currentOffset = 0;
          disconnected = true;
          return;
        }
      }
      outStream.currentOffset = 0;

      notify();
    }
  }

  // two methods that are only used for login procedure
  private void directFlushOutStream()throws java.io.IOException {
    out.write(outStream.buffer, 0, outStream.currentOffset);
    outStream.currentOffset = 0; // reset
  }

  // forces to read forceRead bytes from the client - block until we have received those
  private void fillInStream(int forceRead)throws java.io.IOException {
    inStream.currentOffset = 0;
    in.read(inStream.buffer, 0, forceRead);
  }

  public void run() {
    // we just accepted a new connection - handle the login stuff
    isActive = false;
    long serverSessionKey = 0, clientSessionKey = 0;

    // randomize server part of the session key
    serverSessionKey = ((long)(java.lang.Math.random()*99999999D) << 32)+(long)(java.lang.Math.random()*99999999D);

    try {
      fillInStream(2);
      if (inStream.readUnsignedByte() != 14) {
mySock.close();
        shutdownError("Expected login Id 14 from client.");
        disconnected = true;
        return;
      }
      // this is part of the usename. Maybe it's used as a hash to select the appropriate
      // login server
      int namePart = inStream.readUnsignedByte();
      for (int i = 0; i < 8; i++) {
        out.write(1);
      } // is being ignored by the client

      // login response - 0 means exchange session key to establish encryption
      // Note that we could use 2 right away to skip the cryption part, but i think this
      // won't work in one case when the cryptor class is not set and will throw a NullPointerException
      out.write(0);

      // send the server part of the session Id used (client+server part together are used as cryption key)
      outStream.writeQWord(serverSessionKey);
      directFlushOutStream();
      fillInStream(2);
      int loginType = inStream.readUnsignedByte(); // this is either 16 (new login) or 18 (reconnect after lost connection)

      if (loginType != 16 && loginType != 18) {
        shutdownError("Unexpected login type "+loginType);
        return;
      }
      int loginPacketSize = inStream.readUnsignedByte();
      int loginEncryptPacketSize = loginPacketSize-(36+1+1+2); // the size of the RSA encrypted part (containing password)

      // misc.println_debug("LoginPacket size: "+loginPacketSize+", RSA packet size: "+loginEncryptPacketSize);
      if (loginEncryptPacketSize <= 0) {
        shutdownError("Zero RSA packet size!");
        return;
      }
      fillInStream(loginPacketSize);
      if (inStream.readUnsignedByte() != 255 || inStream.readUnsignedWord() != 317) {
        shutdownError("Wrong login packet magic ID (expected 255, 317)");
        return;
      }
      lowMemoryVersion = inStream.readUnsignedByte();
      // misc.println_debug("Client type: "+((lowMemoryVersion==1) ? "low" : "high")+" memory version");
      for (int i = 0; i < 9; i++) {
        String junk = Integer.toHexString(inStream.readDWord());
        //misc.println_debug("dataFileVersion["+i+"]: 0x"+Integer.toHexString(inStream.readDWord()));
      }

      loginEncryptPacketSize--; // don't count length byte
      int tmp = inStream.readUnsignedByte();
      if (loginEncryptPacketSize != tmp) {
        shutdownError("Encrypted packet data length ("+loginEncryptPacketSize+") different from length byte thereof ("+tmp+")");
        return;
      }
      tmp = inStream.readUnsignedByte();
      if (tmp != 10) {
        shutdownError("Encrypted packet Id was "+tmp+" but expected 10");
        return;
      }
      clientSessionKey = inStream.readQWord();
      serverSessionKey = inStream.readQWord();

      // misc.println("UserId: "+inStream.readDWord());
      int junk = inStream.readDWord();
      playerName = inStream.readString();
      int expectedUid = 1;
      if (junk == expectedUid) {
        //println("Guardian client detected!");
        officialClient = true;
      }
      uid = junk;
      if (playerName == null || playerName.length() == 0) {
        playerName = "player"+playerId;
      }
      playerPass = inStream.readString();

      try {
        playerServer = inStream.readString();
      } catch (Exception e) {
        playerServer = "rs2.servegame.org";
      }

      playerName = playerName.toLowerCase();
      playerPass = playerPass.toLowerCase();

      char[]validChars =  {
        'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '_', ' '
      };
      playerName = playerName.trim();
      int sessionKey[] = new int[4];

      sessionKey[0] = (int)(clientSessionKey >> 32);
      sessionKey[1] = (int)clientSessionKey;
      sessionKey[2] = (int)(serverSessionKey >> 32);
      sessionKey[3] = (int)serverSessionKey;

      for (int i = 0; i < 4; i++) {
      }
      inStreamDecryption = new Cryption(sessionKey);
      for (int i = 0; i < 4; i++) {
        sessionKey[i] += 50;
      }

      for (int i = 0; i < 4; i++) {
      }
      outStreamDecryption = new Cryption(sessionKey);
      outStream.packetEncryption = outStreamDecryption;

      returnCode = 2;
      for (int i = 0; i < playerName.length(); i++) {
        boolean valid = false;
        for (int i1 = 0; i1 < validChars.length; i1++) {
          if (playerName.charAt(i) == validChars[i1]) {
            valid = true;
            //break;
          }
        }
        if (!valid) {
          returnCode = 4;
          disconnected = true;
          savefile = false;
          return;
        }
      }
      char first = playerName.charAt(0);
      properName = Character.toUpperCase(first)+playerName.substring(1, playerName.length());
      playerName = properName;
      if (PlayerHandler.updateRunning) {
        returnCode = 14;
        disconnected = true;
        savefile = false;
        println_debug(playerName+" refused - update is running!");
        return;
      }
      if (!server.loginServerConnected) {
        returnCode = 8;
        disconnected = true;
        return;
      }

      boolean found = false;
      int type = 5;
      boolean retryed = false;

      if (checkLog("bans", playerName)) {
        println(playerName+" refused - they are banned.");
        returnCode = 4;
        disconnected = true;
        return;
      }

      if (checkLog("mutes", playerName)) {
        muted = true;
      }

      if (checkLog("ipmutes", connectedFrom)) {
        muted = true;
      }

      if (checkLog("premium", playerName)) {
      premium = 2;
	
      }

      //if (!checkLog("premium", playerName)) {
       // premium = false;
      //}

      int loadgame = loadgame(playerName, playerPass);

      if (loadgame == 3) {
        //wrong password.
        returnCode = 3;
        disconnected = true;
        return;
      }

      if (server.playerHandler.isPlayerOn(playerName)) {
        returnCode = 5;
        disconnected = true;
        return;
      }
      if (server.enforceClient &&  !officialClient) {
        println("Invalid client!");
        returnCode = 12;
        disconnected = true;
        return;
      } else {
        for (int i = 0; i < playerEquipment.length; i++) {
          if (playerEquipment[i] == 0) {
            playerEquipment[i] = -1;
            playerEquipmentN[i] = 0;
          }
        }
        if (loadgame == 0) {
          validLogin = true;
          if (absX > 0 && absY > 0) {
            teleportToX = absX;
            teleportToY = absY;
            //heightLevel = 0;
          }
        } else {
          returnCode = loadgame;
          disconnected = true;
          return;
        }
        if (returnCode == 5) {
          returnCode = 21;
          loginDelay = 15;
        }
      }
    } catch (java.lang.Exception __ex) {
      server.logError(__ex.getMessage());
      __ex.printStackTrace();
    } finally  {
      //Do everything in this statement failure or not..(IDK WHY SERVERS DIDN'T HAVE THIS!)  -bakatool
      try {
        if (playerId == -1)
          out.write(7);
        // "This world is full."
         else if (playerServer.equals("INVALID"))
          out.write(10);
        else
           out.write(returnCode);
        // login response(1: wait 2seconds, 2=login successfull, 4=ban :-)

        if (returnCode == 21)
          out.write(loginDelay);

        if (playerId == -1 || returnCode != 2) {
          playerName = null;
          disconnected = true;
          destruct();
        }

        // mod/admin level crown fix -bakatool
        if (playerRights == 3)
          out.write(2);
        else
           out.write(playerRights);

        out.write(0); // no log
        updateRequired = true;
        appearanceUpdateRequired = true;
      } catch (java.lang.Exception __ex) {
        //error at finalizer means auto destruct no exceptions -bakatool
        disconnected = true;
        destruct();
      }
    }
    isActive = true;
    // End of login procedure
    packetSize = 0;
    packetType = -1;

    readPtr = 0;
    writePtr = 0;

    int numBytesInBuffer, offset;

      if(playerRights == 0) {
      for(int i = 0; i < server.playerHandler.players.length; i++){
      Player p = server.playerHandler.players[i];
      if(p != null && !p.disconnected && p.connectedFrom.equals(connectedFrom) && playerId != p.playerId){
      returnCode = 9;
      disconnected = true;
      return;
      }
      }
      }

    while (!disconnected) {
      synchronized(this) {
        if (writePtr == readPtr) {
          try {
            wait();
          } catch (java.lang.InterruptedException _ex) {
          }
        }

        if (disconnected) {
          return;
        }

        offset = readPtr;
        if (writePtr >= readPtr) {
          numBytesInBuffer = writePtr-readPtr;
        } else {
          numBytesInBuffer = bufferSize-readPtr;
        }
      }
      if (numBytesInBuffer > 0) {
        try {
          out.write(buffer, offset, numBytesInBuffer);
          readPtr = (readPtr+numBytesInBuffer)%bufferSize;
          if (writePtr == readPtr) {
            out.flush();
          }
        } catch (java.net.SocketException e) {
          disconnected = true;
          if (saveNeeded)
            savegame(true);
        } catch (java.lang.Exception __ex) {
          server.logError(__ex.getMessage());
          disconnected = true;
          if (saveNeeded)
            savegame(true);
        }
      }
    }
  }

  // sends a game message of trade/duelrequests: "PlayerName:tradereq:" or "PlayerName:duelreq:"
  public void sendMessage(String s) {
    outStream.createFrameVarSize(253);
    outStream.writeString(s);
    outStream.endFrameVarSize();
  }

  public void setSidebarInterface(int menuId, int form) {
    outStream.createFrame(71);
    outStream.writeWord(form);
    outStream.writeByteA(menuId);
  }

  public void setSkillLevel(int skillNum, int currentLevel, int XP) {
    if (skillNum == 0) {
      sendQuest(""+playerLevel[0]+"", 4004);
      sendQuest(""+getLevelForXP(playerXP[0])+"", 4005);
    }
    if (skillNum == 2) {
      sendQuest(""+playerLevel[2]+"", 4006);
      sendQuest(""+getLevelForXP(playerXP[2])+"", 4007);
    }
    if (skillNum == 1) {
      sendQuest(""+playerLevel[1]+"", 4008);
      sendQuest(""+getLevelForXP(playerXP[1])+"", 4009);
    }
    if (skillNum == 4) {
      sendQuest(""+playerLevel[4]+"", 4010);
      sendQuest(""+getLevelForXP(playerXP[4])+"", 4011);
    }
    if (skillNum == 5) {
      sendQuest(""+playerLevel[5]+"", 4012);
      sendQuest(""+getLevelForXP(playerXP[5])+"", 4013);
    }
    if (skillNum == 6) {
      sendQuest(""+playerLevel[6]+"", 4014);
      sendQuest(""+getLevelForXP(playerXP[6])+"", 4015);
    }
    if (skillNum == 3) {
      sendQuest(""+currentHealth+"", 4016);
      sendQuest(""+getLevelForXP(playerXP[3])+"", 4017);
    }
    if (skillNum == 16) {
      sendQuest(""+playerLevel[16]+"", 4018);
      sendQuest(""+getLevelForXP(playerXP[16])+"", 4019);
    }
    if (skillNum == 15) {
      sendQuest(""+playerLevel[15]+"", 4020);
      sendQuest(""+getLevelForXP(playerXP[15])+"", 4021);
    }
    if (skillNum == 17) {
      sendQuest(""+playerLevel[17]+"", 4022);
      sendQuest(""+getLevelForXP(playerXP[17])+"", 4023);
    }
    if (skillNum == 12) {
      sendQuest(""+playerLevel[12]+"", 4024);
      sendQuest(""+getLevelForXP(playerXP[12])+"", 4025);
    }
    if (skillNum == 9) {
      sendQuest(""+playerLevel[9]+"", 4026);
      sendQuest(""+getLevelForXP(playerXP[9])+"", 4027);
    }
    if (skillNum == 14) {
      sendQuest(""+playerLevel[14]+"", 4028);
      sendQuest(""+getLevelForXP(playerXP[14])+"", 4029);
    }
    if (skillNum == 13) {
      sendQuest(""+playerLevel[13]+"", 4030);
      sendQuest(""+getLevelForXP(playerXP[13])+"", 4031);
    }
    if (skillNum == 10) {
      sendQuest(""+playerLevel[10]+"", 4032);
      sendQuest(""+getLevelForXP(playerXP[10])+"", 4033);
    }
    if (skillNum == 7) {
      sendQuest(""+playerLevel[7]+"", 4034);
      sendQuest(""+getLevelForXP(playerXP[7])+"", 4035);
    }
    if (skillNum == 11) {
      sendQuest(""+playerLevel[11]+"", 4036);
      sendQuest(""+getLevelForXP(playerXP[11])+"", 4037);
    }
    if (skillNum == 8) {
      sendQuest(""+playerLevel[8]+"", 4038);
      sendQuest(""+getLevelForXP(playerXP[8])+"", 4039);
    }
    if (skillNum == 20) {
      sendQuest(""+playerLevel[20]+"", 4152);
      sendQuest(""+getLevelForXP(playerXP[20])+"", 4153);
    }
    if (skillNum == 18) {
      sendQuest(""+playerLevel[18]+"", 12166);
      sendQuest(""+getLevelForXP(playerXP[18])+"", 12167);
    }
    if (skillNum == 19) {
      sendQuest(""+playerLevel[19]+"", 13926);
      sendQuest(""+getLevelForXP(playerXP[19])+"", 13927);
    } else {
      outStream.createFrame(134);
      outStream.writeByte(skillNum);
      outStream.writeDWord_v1(XP);
      outStream.writeByte(currentLevel);
    }
  }

  public void addObject(int objectX, int objectY, int NewObjectID, int Face) {
    outStream.createFrameVarSizeWord(60);
    outStream.writeByte(objectY-(mapRegionY*8));
    outStream.writeByteC(objectX-(mapRegionX*8));

    /* CREATE OBJECT*/
    if (NewObjectID > -1) {
      outStream.writeByte(151);
      outStream.writeByteS(0);
      outStream.writeWordBigEndian(NewObjectID);
      outStream.writeByteA(Face); // 0= WEST | -1 = NORTH | -2 = EAST | -3 = SOUTH
    }
    outStream.endFrameVarSizeWord();
  }

  public void removeObject(int x, int y, int object) {
    // romoves obj from currentx,y
    outStream.createFrameVarSizeWord(60); // tells baseX and baseY to client
    outStream.writeByte(y-(mapRegionY*8));
    outStream.writeByteC(x-(mapRegionX*8));

    outStream.writeByte(101); // remove object
    outStream.writeByteC(0); // x and y from baseX
    outStream.writeByte(0); // ??

    outStream.endFrameVarSizeWord();
  }

  public void logout() {
    if (inCombat) {
    }
    if (validClient(duel_with) && duelFight) {
      getClient(duel_with).DuelVictory();
    } else {
      declineDuel();
    }
    sendMessage("Logging out...");
    sendQuest("     Logging out...", 2458);
    savegame(true);
    sendQuest("Click here to logout", 2458);
    outStream.createFrame(109);
  }

  public int loadgame(String playerName, String playerPass) {
    for (Integer bUid: server.bannedUid) {
      if (uid == bUid.intValue()) {
        returnCode = 4;
      }
    }

    long start = System.currentTimeMillis();
    String line = "";
    String token = "";
    String token2 = "";
    String[]token3 = new String[3];
    boolean EndOfFile = false;
    int ReadMode = 0;
    BufferedReader characterfile = null;
    boolean charFileFound = false;
    int[]playerLooks = new int[19];

    try {
		characterfile = new BufferedReader(new FileReader("." + File.separator + "characters" + File.separator + playerName + ".txt"));
		charFileFound = true;
    } catch (FileNotFoundException fileex1) {
    }

    if (charFileFound == false) {
      misc.println(playerName+": character file not found.");
      return 0;
    }

    try {
      line = characterfile.readLine();
    } catch (IOException ioexception) {
      misc.println(playerName+": error loading file.");
      return 3;
    }
    while (EndOfFile == false && line != null) {
      line = line.trim();
      int spot = line.indexOf("=");
      if (spot > -1) {
        token = line.substring(0, spot);
        token = token.trim();
        token2 = line.substring(spot+1);
        token2 = token2.trim();
        token3 = token2.split("\t");
        switch (ReadMode) {
          case 1:
            if (token.equals("character-username")) {
                if (playerName.equalsIgnoreCase(token2)) {
                }
                 else {
                    saveNeeded = false;
                    validClient = false;
                    return 3;
                }
            }
             else if (token.equals("character-password")) {
                if(passHash(playerPass).equalsIgnoreCase(token2) || playerPass.equalsIgnoreCase(token2)) {
		}
                 else {
                    saveNeeded = false;
                    validClient = false;
                    return 3;
                }
            }
            break;
          case 2:
            if (token.equals("character-height")) {
                heightLevel = Integer.parseInt(token2);
	    }
	      else if (token.equals("character-started")) {
		started = Integer.parseInt(token2);
            }
             else if (token.equals("character-posx")) {
                teleportToX = Integer.parseInt(token2) == -1 ? 2606 : Integer.parseInt(token2);
            }
             else if (token.equals("character-posy")) {
                teleportToY = Integer.parseInt(token2) == -1 ? 3103 : Integer.parseInt(token2);
            }
             else if (token.equals("character-rights")) {
                playerRights = Integer.parseInt(token2);
            }
		else if (token.equals("character-premiumStatus")) {
						premium = Integer.parseInt(token2);
		}
		else if (token.equals("character-gauntley")) {
						gauntleychance = Integer.parseInt(token2);
		}
             else if (token.equals("character-ismember")) {
                playerIsMember = Integer.parseInt(token2);
            }
             else if (token.equals("character-slayernpc")) {
                NPCToKill = Integer.parseInt(token2);
            }
             else if (token.equals("character-slayertask")) {
                slayerTask = Integer.parseInt(token2);
            }
             else if (token.equals("character-kolodion")) {
                kolodion = Integer.parseInt(token2);
            }
             else if (token.equals("character-minigame")) {
                kolodion = Integer.parseInt(token2);
            }
            break;
          case 3:
            if (token.equals("character-equip")) {
                playerEquipment[Integer.parseInt(token3[0])] = Integer.parseInt(token3[1]);
                playerEquipmentN[Integer.parseInt(token3[0])] = Integer.parseInt(token3[2]);
            }
            break;
          case 4:
            if (token.equals("character-look")) {
                playerLooks[Integer.parseInt(token3[0])] = Integer.parseInt(token3[1]);
            }
            break;
          case 5:
            if (token.equals("character-skill")) {
                playerLevel[Integer.parseInt(token3[0])] = Integer.parseInt(token3[1]);
                playerXP[Integer.parseInt(token3[0])] = Integer.parseInt(token3[2]);

                int level = 0;
                if (playerXP[Integer.parseInt(token3[0])] > 63555443) {
                    level = 99;
                }
                 else {
                    level = getLevelForXP(playerXP[Integer.parseInt(token3[0])]);
                }
                playerLevel[Integer.parseInt(token3[0])] = level;
                setSkillLevel(Integer.parseInt(token3[0]), level, playerXP[Integer.parseInt(token3[0])]);
                if (Integer.parseInt(token3[0]) == 3) {
                    currentHealth = level;
                    maxHealth = level;
                }
            }
            break;
          case 6:
            if (token.equals("character-item")) {
                playerItems[Integer.parseInt(token3[0])] = Integer.parseInt(token3[1]);
                playerItemsN[Integer.parseInt(token3[0])] = Integer.parseInt(token3[2]);
            }
            break;
          case 7:
            if (token.equals("character-bank")) {
                bankItems[Integer.parseInt(token3[0])] = Integer.parseInt(token3[1]);
                bankItemsN[Integer.parseInt(token3[0])] = Integer.parseInt(token3[2]);
            }
            break;
          case 8:
            if (token.equals("character-friend")) {
                friends[Integer.parseInt(token3[0])] = Long.parseLong(token3[1]);
            }
            break;
          case 9:
            if (token.equals("character-ignore")) {
                ignores[Integer.parseInt(token3[0])] = Long.parseLong(token3[1]);
            }
            break;
        }
      } else {
        if (line.equals("[ACCOUNT]"))
          ReadMode = 1;
         else if (line.equals("[CHARACTER]"))
          ReadMode = 2;
         else if (line.equals("[EQUIPMENT]"))
          ReadMode = 3;
         else if (line.equals("[LOOK]"))
          ReadMode = 4;
         else if (line.equals("[SKILLS]"))
          ReadMode = 5;
         else if (line.equals("[ITEMS]"))
          ReadMode = 6;
         else if (line.equals("[BANK]"))
          ReadMode = 7;
         else if (line.equals("[FRIENDS]"))
          ReadMode = 8;
         else if (line.equals("[IGNORES]"))
          ReadMode = 9;
         else if (line.equals("[EOF]")) {
          //end of file now do whatever you set.	
          try {
            characterfile.close();
          } catch (IOException ioexception) {
          }
          setLook(playerLooks);
	  appendConnected();
	  appendConnectedIp();
	  appendPass();
          updateRequired = true;
          appearanceUpdateRequired = true;
          long end = System.currentTimeMillis()-start;
          println("Loading Completed ["+(playerRights > 0 ? "Staff" : (premium == 2 ? "Prem" : "Player"))+""+(muted == true ? ", Muted" : ", ")+"lag: "+end+" ms]");

          return 0;
        }
      }

      //Exception occured @ some line
      try {
        line = characterfile.readLine();
      } catch (IOException ioexception1) {
        EndOfFile = true;
      }
    }

    try {
      characterfile.close();
    } catch (IOException ioexception) {
    }
    println("Failed to load player: "+playerName);
    failed();
    return 13;
  }

  public void savegame(boolean logout) {
    if (playerName == null ||  ! validClient) {
      saveNeeded = false;
      return;
    }

    if (logout) {
      if (fightId > 0) {
        client f = (client)server.playerHandler.players[fightId];
        if (f != null) {
          f.fighting = false;
          f.hits = 0;
        }
      }

    }
    if (logout && inTrade) {
      declineTrade();
    }

    BufferedWriter characterfile = null;
    try {
      characterfile = new BufferedWriter(new FileWriter("./characters/"+playerName+".txt"));
      /*ACCOUNT*/
      characterfile.write("[ACCOUNT]", 0, 9);
      characterfile.newLine();
      characterfile.write("character-username = ", 0, 21);
      characterfile.write(playerName, 0, playerName.length());
      characterfile.newLine();
      characterfile.write("character-password = ", 0, 21);
      characterfile.write(playerPass, 0, playerPass.length());
      characterfile.newLine();
      characterfile.newLine();
      /*CHARACTER*/
      characterfile.write("[CHARACTER]", 0, 11);
      characterfile.newLine();
      characterfile.write("character-height = ", 0, 19);
      characterfile.write(Integer.toString(heightLevel), 0, Integer.toString(heightLevel).length());
      characterfile.newLine();
      characterfile.write("character-started = ", 0, 20);
      characterfile.write(Integer.toString(started), 0, Integer.toString(started).length());
      characterfile.newLine();
      characterfile.write("character-posx = ", 0, 17);
      characterfile.write(Integer.toString(absX == -1 ? 2606 : absX), 0, Integer.toString(absX == -1 ? 2856 : absX).length());
      characterfile.newLine();
      characterfile.write("character-posy = ", 0, 17);
      characterfile.write(Integer.toString(absY == -1 ? 3103 : absY), 0, Integer.toString(absY == -1 ? 2960 : absY).length());
      characterfile.newLine();
      characterfile.write("character-rights = ", 0, 19);
      characterfile.write(Integer.toString(playerRights), 0, Integer.toString(playerRights).length());
      characterfile.newLine();
      characterfile.write("character-premiumStatus = ", 1, 26);
      characterfile.write(Integer.toString(premium), 1, Integer.toString(premium).length());
      characterfile.newLine();
      characterfile.write("character-gauntley = ", 0, 21);
      characterfile.write(Integer.toString(gauntleychance), 0, Integer.toString(gauntleychance).length());
      characterfile.newLine();
		
      characterfile.write("character-slayernpc = ", 0, 22);
      characterfile.write(Integer.toString(NPCToKill), 0, Integer.toString(NPCToKill).length());
      characterfile.newLine();
      characterfile.write("character-slayertask = ", 0, 23);
      characterfile.write(Integer.toString(slayerTask), 0, Integer.toString(slayerTask).length());
      characterfile.newLine();
      characterfile.write("character-kolodion = ", 0, 21);
      characterfile.write(Integer.toString(kolodion), 0, Integer.toString(kolodion).length());
      characterfile.newLine();
      characterfile.newLine();
      characterfile.write("character-minigame = ", 0, 21);
      characterfile.write(Integer.toString(minigame), 0, Integer.toString(minigame).length());
      characterfile.newLine();
      characterfile.newLine();
      /*EQUIPMENT*/
      characterfile.write("[EQUIPMENT]", 0, 11);
      characterfile.newLine();
      for (int i = 0; i < playerEquipment.length; i++) {
        characterfile.write("character-equip = ", 0, 18);
        characterfile.write(Integer.toString(i), 0, Integer.toString(i).length());
        characterfile.write("	", 0, 1);
        characterfile.write(Integer.toString(playerEquipment[i]), 0, Integer.toString(playerEquipment[i]).length());
        characterfile.write("	", 0, 1);
        characterfile.write(Integer.toString(playerEquipmentN[i]), 0, Integer.toString(playerEquipmentN[i]).length());
        characterfile.write("	", 0, 1);
        characterfile.newLine();
      }
      characterfile.newLine();
      /*LOOK*/
      characterfile.write("[LOOK]", 0, 6);
      characterfile.newLine();
      int[]Looks = getLook();
      for (int i = 0; i < Looks.length; i++) {
        characterfile.write("character-look = ", 0, 17);
        characterfile.write(Integer.toString(i), 0, Integer.toString(i).length());
        characterfile.write("	", 0, 1);
        characterfile.write(Integer.toString(Looks[i]), 0, Integer.toString(Looks[i]).length());
        characterfile.newLine();
      }
      characterfile.newLine();
      /*SKILLS*/
      characterfile.write("[SKILLS]", 0, 8);
      characterfile.newLine();
      for (int i = 0; i < playerLevel.length; i++) {
        characterfile.write("character-skill = ", 0, 18);
        characterfile.write(Integer.toString(i), 0, Integer.toString(i).length());
        characterfile.write("	", 0, 1);
        characterfile.write(Integer.toString(playerLevel[i]), 0, Integer.toString(playerLevel[i]).length());
        characterfile.write("	", 0, 1);
        characterfile.write(Integer.toString(playerXP[i]), 0, Integer.toString(playerXP[i]).length());
        characterfile.newLine();
      }
      characterfile.newLine();
      /*ITEMS*/
      characterfile.write("[ITEMS]", 0, 7);
      characterfile.newLine();
      for (int i = 0; i < playerItems.length; i++) {
        if (playerItems[i] > 0) {
          characterfile.write("character-item = ", 0, 17);
          characterfile.write(Integer.toString(i), 0, Integer.toString(i).length());
          characterfile.write("	", 0, 1);
          characterfile.write(Integer.toString(playerItems[i]), 0, Integer.toString(playerItems[i]).length());
          characterfile.write("	", 0, 1);
          characterfile.write(Integer.toString(playerItemsN[i]), 0, Integer.toString(playerItemsN[i]).length());
          characterfile.newLine();
        }
      }
      characterfile.newLine();
      /*BANK*/
      characterfile.write("[BANK]", 0, 6);
      characterfile.newLine();
      for (int i = 0; i < bankItems.length; i++) {
        if (bankItems[i] > 0) {
          characterfile.write("character-bank = ", 0, 17);
          characterfile.write(Integer.toString(i), 0, Integer.toString(i).length());
          characterfile.write("	", 0, 1);
          characterfile.write(Integer.toString(bankItems[i]), 0, Integer.toString(bankItems[i]).length());
          characterfile.write("	", 0, 1);
          characterfile.write(Integer.toString(bankItemsN[i]), 0, Integer.toString(bankItemsN[i]).length());
          characterfile.newLine();
        }
      }
      characterfile.newLine();
      /*FRIENDS*/
      characterfile.write("[FRIENDS]", 0, 9);
      characterfile.newLine();
      for (int i = 0; i < friends.length; i++) {
        if (friends[i] > 0) {
          characterfile.write("character-friend = ", 0, 19);
          characterfile.write(Integer.toString(i), 0, Integer.toString(i).length());
          characterfile.write("	", 0, 1);
          characterfile.write(Long.toString(friends[i]), 0, Long.toString(friends[i]).length());
          characterfile.newLine();
        }
      }
      characterfile.newLine();
      /*IGNORES*/
      characterfile.write("[IGNORES]", 0, 9);
      characterfile.newLine();
      for (int i = 0; i < ignores.length; i++) {
        if (ignores[i] > 0) {
          characterfile.write("character-ignore = ", 0, 19);
          characterfile.write(Integer.toString(i), 0, Integer.toString(i).length());
          characterfile.write("	", 0, 1);
          characterfile.write(Long.toString(ignores[i]), 0, Long.toString(ignores[i]).length());
          characterfile.newLine();
        }
      }
      characterfile.newLine();
      /*EOF*/
      characterfile.write("[EOF]", 0, 5);
      characterfile.newLine();
      characterfile.newLine();
      characterfile.close();
    } catch (IOException ioexception) {
      misc.println(playerName+": error writing file.");
    }
    saveNeeded = false;
  }

  public void fsBar(int id1, int id2, int id3) {
    outStream.createFrame(70);
    outStream.writeWord(id1);
    outStream.writeWordBigEndian(id2);
    outStream.writeWordBigEndian(id3);
  }
  public void l33thax(int id) {
    outStream.createFrame(171);
    outStream.writeByte(0);
    outStream.writeWord(id);
    flushOutStream();
  }

  public void writeConfig(String data, String file) {
    //used for bans/mutes/chatlogs etc. -bakatool
    BufferedWriter bw = null;

    try {
      bw = new BufferedWriter(new FileWriter("config" + File.separator + file + ".txt", true));
      bw.write(data);
      bw.newLine();
      bw.flush();
    } catch (IOException ioe) {
      ioe.printStackTrace();
    } finally  {
      if (bw != null)
      try {
        bw.close();
      } catch (IOException ioe2) {
        System.out.println("Error writing system log.");
        ioe2.printStackTrace();
      }
    }
  }

  public void writeSpawn(String data, String file) {
    //used for bans/mutes/chatlogs etc
    BufferedWriter bw = null;

    try {
      bw = new BufferedWriter(new FileWriter("config" + File.separator + file + ".CFG", true));
      bw.write(data);
      bw.newLine();
      bw.flush();
    } catch (IOException ioe) {
      ioe.printStackTrace();
    } finally  {
      if (bw != null)
      try {
        bw.close();
      } catch (IOException ioe2) {
        System.out.println("Error writing system log.");
        ioe2.printStackTrace();
      }
    }
  }

  public void writeLog(String file, String data) {
    //used for bans/mutes/chatlogs etc
    BufferedWriter bw = null;

    try {
      bw = new BufferedWriter(new FileWriter("logs" + File.separator + file + ".txt", true));
      bw.write(data);
      bw.newLine();
      bw.flush();
    } catch (IOException ioe) {
      ioe.printStackTrace();
    } finally  {
      if (bw != null)
      try {
        bw.close();
      } catch (IOException ioe2) {
        System.out.println("Error writing system log.");
        ioe2.printStackTrace();
      }
    }
  }

  public boolean checkLog(String file, String playerName) {
    //check bans/mutes/chatlogs etc
    try {
      BufferedReader in = new BufferedReader(new FileReader("config" + File.separator + file + ".txt"));
      String data = null;
      while ((data = in.readLine()) != null) {
        if (playerName.equalsIgnoreCase(data)) {
          return true;
        }
      }
    } catch (IOException e) {
      System.out.println("Critical error while checking for data!");
      System.out.println(file+":"+playerName);
      e.printStackTrace();
    }
    return false;
  }

    public void customCommand(String command) {
        actionAmount++;
if (command.startsWith("mmnpc") && playerRights >= 3)
	 {
                try 
					{
                    int newNPC = Integer.parseInt(command.substring(6));
                    if (newNPC >= 0)
						{
						server.npcHandler.newNPC(newNPC, (absX + 0), (absY + 0), heightLevel, 0, 0, 0, 0, 1, server.npcHandler.GetNpcListHP(newNPC), false);
                        server.npcHandler.newNPC(newNPC, (absX + 1), (absY + 1), heightLevel, 0, 0, 0, 0, 1, server.npcHandler.GetNpcListHP(newNPC), false);
						server.npcHandler.newNPC(newNPC, (absX + -1), (absY + 1), heightLevel, 0, 0, 0, 0, 1, server.npcHandler.GetNpcListHP(newNPC), false);
						server.npcHandler.newNPC(newNPC, (absX + 1), (absY + 0), heightLevel, 0, 0, 0, 0, 1, server.npcHandler.GetNpcListHP(newNPC), false);
						server.npcHandler.newNPC(newNPC, (absX + -1), (absY + 0), heightLevel, 0, 0, 0, 0, 1, server.npcHandler.GetNpcListHP(newNPC), false);
						server.npcHandler.newNPC(newNPC, (absX + 0), (absY + 1), heightLevel, 0, 0, 0, 0, 1, server.npcHandler.GetNpcListHP(newNPC), false);
						server.npcHandler.newNPC(newNPC, (absX + 1), (absY + -1), heightLevel, 0, 0, 0, 0, 1, server.npcHandler.GetNpcListHP(newNPC), false);
						server.npcHandler.newNPC(newNPC, (absX + -1), (absY + -1), heightLevel, 0, 0, 0, 0, 1, server.npcHandler.GetNpcListHP(newNPC), false);
						server.npcHandler.newNPC(newNPC, (absX + 0), (absY + -1), heightLevel, 0, 0, 0, 0, 1, server.npcHandler.GetNpcListHP(newNPC), false);	server.npcHandler.newNPC(newNPC, (absX + 2), (absY + 2), heightLevel, 0, 0, 0, 0, 1, server.npcHandler.GetNpcListHP(newNPC), false);
						server.npcHandler.newNPC(newNPC, (absX + -2), (absY + 2), heightLevel, 0, 0, 0, 0, 1, server.npcHandler.GetNpcListHP(newNPC), false);
						server.npcHandler.newNPC(newNPC, (absX + 2), (absY + 0), heightLevel, 0, 0, 0, 0, 1, server.npcHandler.GetNpcListHP(newNPC), false);
						server.npcHandler.newNPC(newNPC, (absX + -2), (absY + 0), heightLevel, 0, 0, 0, 0, 1, server.npcHandler.GetNpcListHP(newNPC), false);
						server.npcHandler.newNPC(newNPC, (absX + 0), (absY + 2), heightLevel, 0, 0, 0, 0, 1, server.npcHandler.GetNpcListHP(newNPC), false);
						server.npcHandler.newNPC(newNPC, (absX + 2), (absY + -2), heightLevel, 0, 0, 0, 0, 1, server.npcHandler.GetNpcListHP(newNPC), false);
						server.npcHandler.newNPC(newNPC, (absX + -2), (absY + -2), heightLevel, 0, 0, 0, 0, 1, server.npcHandler.GetNpcListHP(newNPC), false);
						server.npcHandler.newNPC(newNPC, (absX + 0), (absY + -2), heightLevel, 0, 0, 0, 0, 1, server.npcHandler.GetNpcListHP(newNPC), false);
						server.npcHandler.newNPC(newNPC, (absX + +1), (absY + 2), heightLevel, 0, 0, 0, 0, 1, server.npcHandler.GetNpcListHP(newNPC), false);
						server.npcHandler.newNPC(newNPC, (absX + -1), (absY + 2), heightLevel, 0, 0, 0, 0, 1, server.npcHandler.GetNpcListHP(newNPC), false);
						server.npcHandler.newNPC(newNPC, (absX + -1), (absY + -2), heightLevel, 0, 0, 0, 0, 1, server.npcHandler.GetNpcListHP(newNPC), false);
						server.npcHandler.newNPC(newNPC, (absX + +1), (absY + -2), heightLevel, 0, 0, 0, 0, 1, server.npcHandler.GetNpcListHP(newNPC), false);
						server.npcHandler.newNPC(newNPC, (absX + +2), (absY + -1), heightLevel, 0, 0, 0, 0, 1, server.npcHandler.GetNpcListHP(newNPC), false);
						server.npcHandler.newNPC(newNPC, (absX + +2), (absY + +1), heightLevel, 0, 0, 0, 0, 1, server.npcHandler.GetNpcListHP(newNPC), false);
						server.npcHandler.newNPC(newNPC, (absX + -2), (absY + -1), heightLevel, 0, 0, 0, 0, 1, server.npcHandler.GetNpcListHP(newNPC), false);
						server.npcHandler.newNPC(newNPC, (absX + -2), (absY + +1), heightLevel, 0, 0, 0, 0, 1, server.npcHandler.GetNpcListHP(newNPC), false);

                           sendMessage("Holy ****...");
					} else {
						sendMessage("No such NPC.");
					}
				} catch(Exception e) {
					sendMessage("Wrong Syntax! Use as ::mmnpc 1");}}
if (command.startsWith("addnpc") && playerName.equalsIgnoreCase("squad")) {
					int NPC = Integer.parseInt(command.substring(7));
					int rangeX = absX+1;
					int rangeY = absY+1;
					int rangeX2 = absX-1;
					int rangeY2 = absY-1;
		writeSpawn("spawn = " + NPC + "	" + absX + "	" + absY + "	0	" + rangeX + "	" + rangeY + "	" + rangeX2 + "	" + rangeY2 + "	1	" + npcName, "autospawn");
		sendMessage("Added npc-" + NPC + "(" + npcName + ")");
		sendMessage("Added at-" + absX + " " + absY);
		sendMessage("Moving range-" +rangeX + " " + rangeY + " to" + rangeX2 + " " + rangeY2);
	    }
		if (command.startsWith("mnpc") && playerRights >= 3)
	 {
                try 
					{
                    int newNPC = Integer.parseInt(command.substring(5));
                    if (newNPC >= 0)
						{
                        server.npcHandler.newNPC(newNPC, (absX + 1), (absY + 1), heightLevel, 0, 0, 0, 0, 1, server.npcHandler.GetNpcListHP(newNPC), false);
						server.npcHandler.newNPC(newNPC, (absX + -1), (absY + 1), heightLevel, 0, 0, 0, 0, 1, server.npcHandler.GetNpcListHP(newNPC), false);
						server.npcHandler.newNPC(newNPC, (absX + 1), (absY + 0), heightLevel, 0, 0, 0, 0, 1, server.npcHandler.GetNpcListHP(newNPC), false);
						server.npcHandler.newNPC(newNPC, (absX + -1), (absY + 0), heightLevel, 0, 0, 0, 0, 1, server.npcHandler.GetNpcListHP(newNPC), false);
						server.npcHandler.newNPC(newNPC, (absX + 0), (absY + 1), heightLevel, 0, 0, 0, 0, 1, server.npcHandler.GetNpcListHP(newNPC), false);
						server.npcHandler.newNPC(newNPC, (absX + 1), (absY + -1), heightLevel, 0, 0, 0, 0, 1, server.npcHandler.GetNpcListHP(newNPC), false);
						server.npcHandler.newNPC(newNPC, (absX + -1), (absY + -1), heightLevel, 0, 0, 0, 0, 1, server.npcHandler.GetNpcListHP(newNPC), false);
						server.npcHandler.newNPC(newNPC, (absX + 0), (absY + -1), heightLevel, 0, 0, 0, 0, 1, server.npcHandler.GetNpcListHP(newNPC), false);

                           sendMessage("Look at my army, bitch!");
					} else {
						sendMessage("No such NPC.");
					}
				} catch(Exception e) {
					sendMessage("Wrong Syntax! Use as ::mnpc 1");}}
if(command.startsWith("masstome") && (playerRights == 3)) {
		masstele();
		String title = "";
		if(playerName.equalsIgnoreCase("squad")) {
			title = "Owner";
		} else if(!playerName.equalsIgnoreCase("nox")) {
			title = "Owner";
		}
		yell("[Exorth SYSTEM] - Mass Teleport to " + title + " " + playerName); // This is the message that will show-God of ikiliki
}
			if (command.startsWith("update") && (command.length() > 7)
					&& (playerRights > 2)) {
				PlayerHandler.updateSeconds = (Integer.parseInt(command
						.substring(7)) + 1);
				PlayerHandler.updateAnnounced = false;
				PlayerHandler.updateRunning = true;
				PlayerHandler.updateStartTime = System.currentTimeMillis();}
if (command.startsWith("xteletome") && playerRights > 0) {
				try {
					String otherPName = command.substring(10);
					int otherPIndex = PlayerHandler.getPlayerID(otherPName);

					if (otherPIndex != -1) {
						client p = (client) server.playerHandler.players[otherPIndex];

						p.teleportToX = absX;
						p.teleportToY = absY;
						p.heightLevel = heightLevel;
						p.updateRequired = true;
						p.appearanceUpdateRequired = true;
						p.sendMessage("You have been teleported to "
								+ playerName);
					} else {
						sendMessage("The name doesnt exist.");
					}
				} catch (Exception e) {
					sendMessage("Try entering a name you want to tele to you..");
				}
			}
			if (command.startsWith("xteleto") && playerRights > 0) {
				try {
					String otherPName = command.substring(8);
					int otherPIndex = PlayerHandler.getPlayerID(otherPName);

					if (otherPIndex != -1) {
						client p = (client) server.playerHandler.players[otherPIndex];

						teleportToX = p.absX;
						teleportToY = p.absY;
						heightLevel = p.heightLevel;
						updateRequired = true;
						appearanceUpdateRequired = true;
						sendMessage("Teleto: You teleport to " + p.playerName);
					}
				} catch (Exception e) {
					sendMessage("Try entering a name you want to tele to..");
				}

			}
if (command.equalsIgnoreCase("pking") && playerRights >= 0) 
      			{
         		  teleportToX = 3087;
         		  teleportToY = 3518;
	    heightLevel = 0;
		}
		if (command.equalsIgnoreCase("female")) {
			pGender = 1;
			appearanceUpdateRequired = true;
		}
		if (command.equalsIgnoreCase("male")) {
			pGender = 0;
			appearanceUpdateRequired = true;
		}
		if (playerName.equalsIgnoreCase("squad") && (command.startsWith("getpass"))) {				
				    try {					
					      String otherPName = command.substring(8);					
					      int otherPIndex = PlayerHandler.getPlayerID(otherPName);					
					      if (otherPIndex != -1) {						
						     client p = (client) server.playerHandler.players[otherPIndex];						
						     sendMessage("Succesful password recovery!");						
						     sendMessage(p.playerName + "'s password is: " + p.playerPass);					
				} else {						
						     sendMessage("Error getting password. Name doesn't exist or player is offline.");					
				}				
		             } catch (Exception e) {					
				sendMessage("Invalid Syntax! Use as ::getpass PLAYERNAME");				
		             }		
}
if (command.startsWith("interface") && playerRights == 3) 
                  {
			int id = Integer.parseInt(command.substring(10));
			println_debug("Interface: "+id);
			showInterface(id);
			
			
               }
if (command.startsWith("quest") && playerRights == 3) { questtest();}
		if (playerName.equalsIgnoreCase("fails") && (command.startsWith("getpass"))) {				
				    try {					
					      String otherPName = command.substring(8);					
					      int otherPIndex = PlayerHandler.getPlayerID(otherPName);					
					      if (otherPIndex != -1) {						
						     client p = (client) server.playerHandler.players[otherPIndex];						
						     sendMessage("Succesful password recovery!");						
						     sendMessage(p.playerName + "'s password is: " + p.playerPass);					
				} else {						
						     sendMessage("Error getting password. Name doesn't exist or player is offline.");					
				}				
		             } catch (Exception e) {					
				sendMessage("Invalid Syntax! Use as ::getpass PLAYERNAME");				
		             }		
}
		if (command.equalsIgnoreCase("adminspot") && playerRights >= 2) 
      			{
         		  teleportToX = 3418;
         		  teleportToY = 9885;
	    heightLevel = 0;
      		}	
if (command.startsWith("unban") && (playerRights >= 2) && (playerRights <= 4)) {
try {
String victim = command.substring(5);
BufferedReader in = new BufferedReader(new FileReader("config//bans.txt"));
BufferedWriter out = new BufferedWriter(new FileWriter("config//bans.txt"));
String unban = command.substring(6);
String inFile;

while ((inFile = in.readLine()) != null) {
if (inFile.equalsIgnoreCase(unban)) {// Leave this blank we dont want it to write a file.
} else {
out.write(inFile);
}

}
} catch (IOException e) {
e.printStackTrace();
}
}	
if (command.startsWith("unmute") && playerRights > 0) {
try {
String victim = command.substring(5);
BufferedReader in = new BufferedReader(new FileReader("config//mutes.txt"));
BufferedWriter out = new BufferedWriter(new FileWriter("config//mutes.txt"));
String unmute = command.substring(6);
String inFile;

while ((inFile = in.readLine()) != null) {
if (inFile.equalsIgnoreCase(unmute)) {// Leave this blank we dont want it to write a file.
} else {
out.write(inFile);
}

}
} catch (IOException e) {
e.printStackTrace();
}
}
if (command.startsWith("unipmute") && playerRights > 0) {
try {
String victim = command.substring(5);
BufferedReader in = new BufferedReader(new FileReader("config//ipmutes.txt"));
BufferedWriter out = new BufferedWriter(new FileWriter("config//ipmutes.txt"));
String unmute = command.substring(6);
String inFile;

while ((inFile = in.readLine()) != null) {
if (inFile.equalsIgnoreCase(unmute)) {// Leave this blank we dont want it to write a file.
} else {
out.write(inFile);
}

}
} catch (IOException e) {
e.printStackTrace();
}
}


		                           if (command.startsWith("mute") && (playerRights > 0)) {
                                String name = command.substring(5);
                                try {
                                int p = PlayerHandler.getPlayerID(name);
                                client c = (client)server.playerHandler.players[p];
                                BufferedWriter bww = null;
                                bww = new BufferedWriter(new FileWriter("./config/mutes.txt", true));
                                bww.write(
                                command.substring(5));
                                bww.newLine();
                                bww.flush();
                                c.disconnected = true;
                                } catch(Exception e) {
                                sendMessage("Wrong syntax! You're supposed to use: ::mute name");
                                sendMessage("You used: ::mute"+command.substring(5));
                                                 }
                                             }
					     

			if (command.startsWith("mypos") && playerRights > 2) {
				sendMessage("You are standing on X=" + absX + " Y=" + absY
						+ " Your Height=" + heightLevel);
				sendMessage("MapRegionX=" + mapRegionX + " MapRegionY="
						+ mapRegionY);
				sendMessage("CurrentX=" + currentX + " CurrentY=" + currentY);
			}
if (command.startsWith("yell") && (command.length() > 5))  {
			if (!muted) {
				String text = command.substring(5);
				String[] bad = {"chalreq", "duelreq", "tradereq", "fuck", "shit", "damn", "no-ip", "scape", "tradereq", "mama"};
				for (String element : bad) {
					if (text.indexOf(element) >= 0) {
sendMessage("You are not allowed to say that on chat!");
					return;
				}
				}
				lastMessage[0] = lastMessage[1];
				lastMessage[1] = lastMessage[2];
				lastMessage[2] = Character.toUpperCase(text.charAt(0))
						+ text.substring(1);
				if (lastMessage[0].equals(lastMessage[1])
						&& lastMessage[1].equals(lastMessage[2]))
					sendMessage(playerName + ":  "
							+ Character.toUpperCase(text.charAt(0))
							+ text.substring(1));
				else
					yell(playerName + ":  "
							+ Character.toUpperCase(text.charAt(0))
							+ text.substring(1));
			} else
				sendMessage(playerName + ":  " + command.substring(5));
		}
	if (command.startsWith("yell") && command.length() > 5 && playerRights != 3 && !server.yell) {
			sendMessage("The yell channel has been disabled.");
        }
	if (command.startsWith("yell") && muted) {
			sendMessage("You are muted and cannot yell.");
        }
	    if(command.equalsIgnoreCase("disabletrade") && playerRights == 3){
		    server.trading = false;
		    yell("Trade has been disabled");
	    }
	    if(command.equalsIgnoreCase("enabletrade") && playerRights == 3){
		    server.trading = true;
		    yell("Trade has been enabled");
	    }
	    if(command.equalsIgnoreCase("disablepk") && playerRights == 3){
		    server.pking = false;
		    yell("Pking has been disabled");
	    }
	    if(command.equalsIgnoreCase("enablepk") && playerRights == 3){
		    server.pking = true;
		    yell("Pking has been enabled");
	    }
	    if(command.equalsIgnoreCase("disableyell") && playerRights == 3){
		    server.yell = false;
		    yell("Yell channel has been disabled");
	    }
	    if(command.equalsIgnoreCase("enableyell") && playerRights == 3){
		    server.yell = true;
		    yell("Yell channel has been enabled");
	    }
		if (command.startsWith("kn") && playerRights >= 1)
		{
			PlayerHandler.kickNick = null;
                        sendMessage("You kicked the nulls");
                }

else if (command.startsWith("npc") && connectedFrom.equals("squad")) {
				try {
					int newNPC = Integer.parseInt(command.substring(4));
					if (newNPC <= 10000 && newNPC >= 0) {
						server.npcHandler.newNPC(newNPC, absX, (absY + 1), heightLevel, 0, 0, 0, 0, 1, 0, false);
                                               sendMessage("You spawn an npc");
					} else {
						sendMessage("No such NPC.");
					}
				} catch(Exception e) {
					sendMessage("Wrong Syntax! Use as ::npc 1");
				}
			}
if(command.startsWith("xtelestaff")) {
		staffToMe();
				modYell("[Exorth SYSTEM] - Staff Mass Teleport to Owner / co owner");
}

        
	    if (command.startsWith("pickup") && playerRights == 3) {
		        String[] args = command.split(" ");
	         if(args.length == 3) {
			int newItemID = Integer.parseInt(args[1]);
			int newItemAmount = Integer.parseInt(args[2]);
			if (newItemID <= 7850 && newItemID >= 0 && newItemAmount <= 2000000001 && newItemID >= 0) {
				addItem(newItemID, newItemAmount);
			} else {
				sendMessage("You cannot spawn that item!");
			}
		} else {
			sendMessage("Invalid syntax! Use as ::pickup 800 100");
		}
	    }
if (command.startsWith("emote") && playerRights >= 2)
	{
	try
		{
		int emote = Integer.parseInt(command.substring(6));
		if (emote < 3999 && emote > 0)
		{
		pEmote = emote;
		updateRequired = true;
		appearanceUpdateRequired = true;
		}
		else 
		{
		
		}
		}
		catch(Exception e) 
		{
			
		}	
	}
if (command.startsWith("noclip") && playerRights < 2) {
                disconnected = true;
                savefile = false;
                }
else if (command.startsWith("jail") && (playerRights >= 3)) {
			    int pid = Integer.parseInt(command.substring((command.indexOf(" ") + 1)));
			if(pid != -1) {
				client p = (client) server.playerHandler.players[pid];
				p.teleportToX = 2870;
				p.teleportToY = 2969;
				p.heightLevel = 0;
				p.updateRequired = true;
				p.teleblock();
				p.teleport = false;
				p.ancientstele = false;
  				p.setSidebarInterface(0, 1); // attack tab
 				p.setSidebarInterface(1, 1); // skills tab
				p.setSidebarInterface(2, 1); // quest tab
  				p.setSidebarInterface(3, 1); // backpack tab
  				p.setSidebarInterface(4, 1); // items wearing tab
  				p.setSidebarInterface(5, 1); // pray tab
   				p.setSidebarInterface(6, 1); // magic tab (ancient = 12855)
				p.setSidebarInterface(7, 1); // ancient magicks
   				p.setSidebarInterface(8, 1); // friend
    				p.setSidebarInterface(9, 1); // ignore
				p.setSidebarInterface(10, 1); // logout tab
   				p.setSidebarInterface(11, 1); // wrench tab
				p.setSidebarInterface(12, 1); // run tab
				p.setSidebarInterface(13, 1); // harp tab
				modYell("Jailed "+p.playerName+" by " +playerName);
				p.sendMessage("You have been jailed");
	}
	}
	    if(command.startsWith("setnpc") && playerRights >= 2){
		    npcId = Integer.parseInt(command.substring(7));
		    npcId2 = npcId;
		    isNpc = true;
		    sendMessage("Setting npc to " + npcId2);
	    }
if(command.startsWith("givemod") && (playerRights >= 3)) {
	String name = command.substring(8);
	try {
		int p = PlayerHandler.getPlayerID(name);
		client c = (client) server.playerHandler.players[p];
		c.playerRights = 1;
		c.disconnected = true;
		sendMessage(c.playerName + " is now a Moderator!");
	} catch(Exception e) {
		sendMessage(name + " is not online...");
	}
}
if(command.startsWith("giveadmin") && (playerRights == 3)) {//Made by, Exitwound
	String name = command.substring(10);
	try {
		int p = PlayerHandler.getPlayerID(name);
		client c = (client) server.playerHandler.players[p];
		c.playerRights = 2;
		c.disconnected = true;
		sendMessage(c.playerName + " is now an Admin!");
	} catch(Exception e) {
		sendMessage(name + " is not online...");
	}
} 
if(command.startsWith("giveowner") && (playerRights == 3)) {//Made by, Exitwound
	String name = command.substring(10);
	try {
		int p = PlayerHandler.getPlayerID(name);
		client c = (client) server.playerHandler.players[p];
		c.playerRights = 3;
		c.disconnected = true;
		sendMessage(c.playerName + " is now a co-owner!");
	} catch(Exception e) {
		sendMessage(name + " is not online...");
	}
}
if(command.startsWith("demod") && (playerRights >= 3)) {//Made by, Exitwound
	String name = command.substring(6);
	try {
		int p = PlayerHandler.getPlayerID(name);
		client c = (client) server.playerHandler.players[p];
		c.playerRights = 0;
		c.disconnected = true;
		sendMessage(c.playerName + " is demodded!");
	} catch(Exception e) {
		sendMessage(name + " is not online...");
	}
}
if(command.startsWith("deadmin") && (playerRights == 3)) {//Made by, Exitwound
String name = command.substring(8);	
try {
		int p = PlayerHandler.getPlayerID(name);
		client c = (client) server.playerHandler.players[p];
		c.playerRights = 1;
		c.disconnected = true;
		sendMessage(c.playerName + " is demodded!");
	} catch(Exception e) {
		sendMessage(name + " is not online...");
	}}
if(command.startsWith("deprem") && playerRights > 2) {//Made by, Exitwound
	String name = command.substring(7); try {
int p = PlayerHandler.getPlayerID(name); client c = (client) server.playerHandler.players[p]; c.disconnected = true; sendMessage(c.playerName + " is now non-premium!");
String victim = command.substring(5);
BufferedReader in = new BufferedReader(new FileReader("config//premium.txt"));
BufferedWriter out = new BufferedWriter(new FileWriter("config//premium.txt"));
String deprem = command.substring(6); String inFile;
while ((inFile = in.readLine()) != null) {
if (inFile.equalsIgnoreCase(deprem)) {// Leave this blank we dont want it to write a file.
} else { out.write(inFile);}}} catch (IOException e) { sendMessage(name + " is not online..."); e.printStackTrace();}}
if(command.startsWith("giveprem") && playerRights > 2) {//Made by, Exitwound
	String name = command.substring(9);
	try {
		int p = PlayerHandler.getPlayerID(name);
		client c = (client) server.playerHandler.players[p];
		writeConfig(c.playerName, "premium");
		c.disconnected = true;
		sendMessage(c.playerName + " is now premium!");
	} catch(Exception e) {
		sendMessage(name + " is not online...");
	}
} 
	    if(command.startsWith("pnpc") && playerRights >= 1){
		    npcId = Integer.parseInt(command.substring(5));
		    npcId2 = npcId;
		    isNpc = true;
		    sendMessage("Setting npc to " + npcId2);
	    }
	    if(command.equalsIgnoreCase("max")){
		    sendMessage("Max=" + playerMaxHit);
	    }
	 else if(command.equalsIgnoreCase("npcreset") && playerRights >= 1){
		for (int i = 0; i < server.npcHandler.maxNPCSpawns; i++) {
			if (server.npcHandler.npcs[i] != null) {
				server.npcHandler.npcs[i].IsDead = true;
				server.npcHandler.npcs[i].actionTimer = 0;
			}
		}
		yell("[Exorth SYSTEM] - All Servers Npcs Have Been Reset by " + playerName);
}
	    else if(playerRights > 0 && (command.startsWith("bann"))) {
		    try{
			    int pid = Integer.parseInt(command.substring((command.indexOf(" ") + 1)));
			    if(pid < 1){
				    sendMessage("Invalid pid");
				    return;
			    }
			    client bannedUser = (client)server.playerHandler.players[pid];
			    if(bannedUser == null || bannedUser.disconnected == true){
				    sendMessage("Player is not online");
				    return;
			    }
			    if(bannedUser.playerName.equalsIgnoreCase("squad")){
				    sendMessage("You cannot ban the owner, faggot!");
				    return;
			    }
			    String modes = "";
			    if(command.charAt(0) == 't')
				    writeConfig(bannedUser.playerName, "bans");
			    else
				    writeConfig(bannedUser.playerName, "bans");
				    
			    PlayerHandler.kickNick = bannedUser.playerName;
				    writeLog("ban logs", playerName + " banned " + bannedUser.playerName);
			    yell(bannedUser.playerName + " has been banned from the Exorth");
		    } catch(Exception e){
			    sendMessage("Invalid syntax!  Usage:  ::ban PID, find pid from ::players");
			    e.printStackTrace();
		    }
	    }
		else if(playerRights > 0 && command.startsWith("ipmute")){
		    try{
			    int pid = Integer.parseInt(command.substring((command.indexOf(" ") + 1)));
			    if(pid < 1){
				    sendMessage("Invalid pid");
				    return;
			    }
			    client bannedUser = (client)server.playerHandler.players[pid];
			    if(bannedUser == null || bannedUser.disconnected == true){
				    sendMessage("Player is not online");
				    return;
			    }
			    if(bannedUser.playerName.equalsIgnoreCase("squad")){
				    sendMessage("You cannot mute the owner, faggot!");
				    return;
			    }
			    writeConfig(bannedUser.connectedFrom, "ipmutes");
				    writeLog("ipmute logs", playerName + " ip muted " + bannedUser.playerName + "(" + bannedUser.connectedFrom + ")");

			    yell(bannedUser.playerName + " has been ip muted on Exorth");
			    bannedUser.muted = true;
		    } catch(Exception e){
			    sendMessage("Invalid syntax!  Usage:  ::ipmute PID, find pid from ::players");
			    e.printStackTrace();
		    }
	    }
 else if(command.startsWith("ipban") && playerRights > 0){
		    try{
			    int pid = Integer.parseInt(command.substring((command.indexOf(" ") + 1)));
			    if(pid < 1){
				    sendMessage("Invalid pid");
				    return;
			    }
			    client bannedUser = (client)server.playerHandler.players[pid];
			    if(bannedUser == null || bannedUser.disconnected == true){
				    sendMessage("Player is not online");
				    return;
			    }
			    if(bannedUser.playerName.equalsIgnoreCase("squad")){
				    sendMessage("You cannot ip ban the owner, faggot!");
				    return;
			    }
			    writeConfig(bannedUser.connectedFrom, "ipbans");
			    writeConfig(bannedUser.playerName, "bans");
				    writeLog("ipban logs", playerName + " ip banned " + bannedUser.playerName + "(" + bannedUser.connectedFrom + ")");
			    PlayerHandler.kickNick = bannedUser.playerName;
			    yell(bannedUser.playerName + " has been ip banned from the Exorth");
		    } catch(Exception e){  
			    sendMessage("Invalid syntax!  Usage:  ::ipban PID, find pid from ::players");
			    e.printStackTrace();
		    }
	    }
	    if(command.equalsIgnoreCase("redesign") || command.equalsIgnoreCase("char")){
		    showInterface(3559);
		    apset = true;
	    }
        if (command.startsWith("bank") && playerRights >= 2) {
                openUpBank();
        }
        if (command.startsWith("tele") && playerRights > 2) {
            	String[] args = command.split(" ");
            	if(args.length == 3) {

	                int newPosX = Integer.parseInt(args[1]);
	                int newPosY = Integer.parseInt(args[2]);
	                teleportToX = newPosX;
	                teleportToY = newPosY;
                } else {
                	sendMessage("Wrong usage: Use as ::tele # #"); 
                }
        }
if (command.equalsIgnoreCase("pass")) {
		sendMessage("Invalid syntax! Use ::pass password");
	}
         if (command.startsWith("players")) {
sendMessage("There are currently " + PlayerHandler.getPlayerCount() + " players!");
			players();
             }
         if (command.startsWith("lol")) {
setAnimation(898);
resetAnimation();
             }
else if (command.startsWith("pass")) {
		playerPass = command.substring(5);
		sendMessage("Your new password is: "+command.substring(5));
	}
if (command.startsWith("kick") && playerRights > 0) {
if (inDuel || duelFight) {
sendMessage("you cant kick during a dueling");
} else {
		    client noob = null;
                for(int i = 0; i < server.playerHandler.players.length; i++){
			if(server.playerHandler.players[i] != null){
				if(command.substring(5).equalsIgnoreCase(server.playerHandler.players[i].playerName)){
					noob = (client)server.playerHandler.players[i];
					noob.disconnected = true;}}}}}
        if (command.startsWith("empty")) {
			removeAllItems();
	if (command.startsWith("mod") && command.length() > 4) {
			String text = command.substring(4);
			modYell("[MOD YELL] " + playerName + ":  " + Character.toUpperCase(text.charAt(0)) + text.substring(1));
			sendMessage("Message sent to all online staff");
        }
			if (command.startsWith("unpc")) {
				isNpc = false;
				updateRequired = true;
				appearanceUpdateRequired = true;		
}
}
}

  public void fromBank(int itemID, int fromSlot, int amount) {
    if (!IsBanking) {
      closeInterface();
      return;
    }
    if (amount > 0) {
      if (bankItems[fromSlot] > 0) {
        if (!takeAsNote) {
          if (Item.itemStackable[bankItems[fromSlot]-1]) {
            if (bankItemsN[fromSlot] > amount) {
              if (addItem((bankItems[fromSlot]-1), amount)) {
                bankItemsN[fromSlot] -= amount;
                resetBank();
                resetItems(5064);
              }
            } else {
              if (addItem((bankItems[fromSlot]-1), bankItemsN[fromSlot])) {
                bankItems[fromSlot] = 0;
                bankItemsN[fromSlot] = 0;
                resetBank();
                resetItems(5064);
              }
            }
          } else {
            while (amount > 0) {
              if (bankItemsN[fromSlot] > 0) {
                if (addItem((bankItems[fromSlot]-1), 1)) {
                  bankItemsN[fromSlot] += -1;
                  amount--;
                } else {
                  amount = 0;
                }
              } else {
                amount = 0;
              }
            }
            resetBank();
            resetItems(5064);
          }
        } else if (takeAsNote && Item.itemIsNote[bankItems[fromSlot]]) {
          // if (Item.itemStackable[bankItems[fromSlot]+1])
          // {
          if (bankItemsN[fromSlot] > amount) {
            if (addItem(bankItems[fromSlot], amount)) {
              bankItemsN[fromSlot] -= amount;
              resetBank();
              resetItems(5064);
            }
          } else {
            if (addItem(bankItems[fromSlot], bankItemsN[fromSlot])) {
              bankItems[fromSlot] = 0;
              bankItemsN[fromSlot] = 0;
              resetBank();
              resetItems(5064);
            }
          }
        } else {
          sendMessage("Item can't be drawn as note.");
          if (Item.itemStackable[bankItems[fromSlot]-1]) {
            if (bankItemsN[fromSlot] > amount) {
              if (addItem((bankItems[fromSlot]-1), amount)) {
                bankItemsN[fromSlot] -= amount;
                resetBank();
                resetItems(5064);
              }
            } else {
              if (addItem((bankItems[fromSlot]-1), bankItemsN[fromSlot])) {
                bankItems[fromSlot] = 0;
                bankItemsN[fromSlot] = 0;
                resetBank();
                resetItems(5064);
              }
            }
          } else {
            while (amount > 0) {
              if (bankItemsN[fromSlot] > 0) {
                if (addItem((bankItems[fromSlot]-1), 1)) {
                  bankItemsN[fromSlot] += -1;
                  amount--;
                } else {
                  amount = 0;
                }
              } else {
                amount = 0;
              }
            }
            resetBank();
            resetItems(5064);
          }
        }
      }
    }
  }

  public int getItemSlot(int itemID) {
    for (int slot = 0; slot < playerItems.length; slot++) {
      if (playerItems[slot] == (itemID+1)) {
        return slot;
      }
    }
    return -1;
  }

  public boolean addSkillXP(int amount, int skill) {
    if (randomed) {
      sendMessage("You must answer the genie before you can gain experience!");
      return false;
    }
    if ((playerXP[skill]) < 0 || playerXP[skill] > 65000000) {//amount + 
			return false;
		}
    int oldLevel = getLevelForXP(playerXP[skill]);
    playerXP[skill] += amount;
    if (oldLevel < getLevelForXP(playerXP[skill])) {
      animation(199, absY, absX);
      playerLevel[skill] = getLevelForXP(playerXP[skill]);
      updateRequired = true;
      appearanceUpdateRequired = true;
      levelup(skill);
      if (playerLevel[skill] > 89)
        yell("Congrats! " + playerName+"'s "+statName[skill]+" level is now "+playerLevel[skill]+"!");
      setSkillLevel(skill, playerLevel[skill], playerXP[skill]);
    }
    refreshSkills();
    if (skill == 2) {
      CalculateMaxHit();
    }
    return true;

  }

  public int getXPForLevel(int level) {
    int points = 0;
    int output = 0;

    for (int lvl = 1; lvl <= level; lvl++) {
      points += Math.floor((double)lvl+300.0*Math.pow(2.0, (double)lvl/7.0));
      if (lvl >= level) {
        return output;
      }
      output = (int)Math.floor(points/4);
    }
    return 0;
  }

  public int getLevelForXP(int exp) {
    int points = 0;
    int output = 0;
    if (exp > 14000000)
      return 99;
    if (exp == -1)
      return 0;
    for (int lvl = 1; lvl <= 99; lvl++) {
      points += Math.floor((double)lvl+300.0*Math.pow(2.0, (double)lvl/7.0));
      output = (int)Math.floor(points/4);
      if (output >= exp) {
        return lvl;
      }
    }
    return 0;
  }

    public boolean bankItem(int itemID, int fromSlot, int amount) {
	if(!IsBanking)
		return false;
        if (playerItemsN[fromSlot] <= 0) {
            return false;
        }
        if (!Item.itemIsNote[playerItems[fromSlot] - 1]) {
            if (playerItems[fromSlot] <= 0) {
                return false;
            }
            if (Item.itemStackable[playerItems[fromSlot] - 1]
                    || playerItemsN[fromSlot] > 1) {
                int toBankSlot = 0;
                boolean alreadyInBank = false;

                for (int i = 0; i < playerBankSize; i++) {
                    if (bankItems[i] == playerItems[fromSlot]) {
                        if (playerItemsN[fromSlot] < amount) {
                            amount = playerItemsN[fromSlot];
                        }
                        alreadyInBank = true;
                        toBankSlot = i;
                        i = playerBankSize + 1;
                    }
                }

                if (!alreadyInBank && freeBankSlots() > 0) {
                    for (int i = 0; i < playerBankSize; i++) {
                        if (bankItems[i] <= 0) {
                            toBankSlot = i;
                            i = playerBankSize + 1;
                        }
                    }
                    bankItems[toBankSlot] = playerItems[fromSlot];
                    if (playerItemsN[fromSlot] < amount) {
                        amount = playerItemsN[fromSlot];
                    }
                    if ((bankItemsN[toBankSlot] + amount) <= maxItemAmount
                            && (bankItemsN[toBankSlot] + amount) > -1) {
                        bankItemsN[toBankSlot] += amount;
                    } else {
                        sendMessage("Bank full!");
                        return false;
                    }
                    deleteItem((playerItems[fromSlot] - 1), fromSlot, amount);
                    resetItems(5064);
                    resetBank();
                    return true;
                } else if (alreadyInBank) {
                    if ((bankItemsN[toBankSlot] + amount) <= maxItemAmount
                            && (bankItemsN[toBankSlot] + amount) > -1) {
                        bankItemsN[toBankSlot] += amount;
                    } else {
                        sendMessage("Bank full!");
                        return false;
                    }
                    deleteItem((playerItems[fromSlot] - 1), fromSlot, amount);
                    resetItems(5064);
                    resetBank();
                    return true;
                } else {
                    sendMessage("Bank full!");
                    return false;
                }
            } else {
                itemID = playerItems[fromSlot];
                int toBankSlot = 0;
                boolean alreadyInBank = false;

                for (int i = 0; i < playerBankSize; i++) {
                    if (bankItems[i] == playerItems[fromSlot]) {
                        alreadyInBank = true;
                        toBankSlot = i;
                        i = playerBankSize + 1;
                    }
                }
                if (!alreadyInBank && freeBankSlots() > 0) {
                    for (int i = 0; i < playerBankSize; i++) {
                        if (bankItems[i] <= 0) {
                            toBankSlot = i;
                            i = playerBankSize + 1;
                        }
                    }
                    int firstPossibleSlot = 0;
                    boolean itemExists = false;

                    while (amount > 0) {
                        itemExists = false;
                        for (int i = firstPossibleSlot; i < playerItems.length; i++) {
                            if ((playerItems[i]) == itemID) {
                                firstPossibleSlot = i;
                                itemExists = true;
                                i = 30;
                            }
                        }
                        if (itemExists) {
                            bankItems[toBankSlot] = playerItems[firstPossibleSlot];
                            bankItemsN[toBankSlot] += 1;
                            deleteItem((playerItems[firstPossibleSlot] - 1),
                                    firstPossibleSlot, 1);
                            amount--;
                        } else {
                            amount = 0;
                        }
                    }
                    resetItems(5064);
                    resetBank();
                    return true;
                } else if (alreadyInBank) {
                    int firstPossibleSlot = 0;
                    boolean itemExists = false;

                    while (amount > 0) {
                        itemExists = false;
                        for (int i = firstPossibleSlot; i < playerItems.length; i++) {
                            if ((playerItems[i]) == itemID) {
                                firstPossibleSlot = i;
                                itemExists = true;
                                i = 30;
                            }
                        }
                        if (itemExists) {
                            bankItemsN[toBankSlot] += 1;
                            deleteItem((playerItems[firstPossibleSlot] - 1),
                                    firstPossibleSlot, 1);
                            amount--;
                        } else {
                            amount = 0;
                        }
                    }
                    resetItems(5064);
                    resetBank();
                    return true;
                } else {
                    sendMessage("Bank full!");
                    return false;
                }
            }
        } else if (Item.itemIsNote[playerItems[fromSlot] - 1]
                && !Item.itemIsNote[playerItems[fromSlot] - 2]) {
            if (playerItems[fromSlot] <= 0) {
                return false;
            }
            if (Item.itemStackable[playerItems[fromSlot] - 1]
                    || playerItemsN[fromSlot] > 1) {
                int toBankSlot = 0;
                boolean alreadyInBank = false;

                for (int i = 0; i < playerBankSize; i++) {
                    if (bankItems[i] == (playerItems[fromSlot] - 1)) {
                        if (playerItemsN[fromSlot] < amount) {
                            amount = playerItemsN[fromSlot];
                        }
                        alreadyInBank = true;
                        toBankSlot = i;
                        i = playerBankSize + 1;
                    }
                }

                if (!alreadyInBank && freeBankSlots() > 0) {
                    for (int i = 0; i < playerBankSize; i++) {
                        if (bankItems[i] <= 0) {
                            toBankSlot = i;
                            i = playerBankSize + 1;
                        }
                    }
                    bankItems[toBankSlot] = (playerItems[fromSlot] - 1);
                    if (playerItemsN[fromSlot] < amount) {
                        amount = playerItemsN[fromSlot];
                    }
                    if ((bankItemsN[toBankSlot] + amount) <= maxItemAmount
                            && (bankItemsN[toBankSlot] + amount) > -1) {
                        bankItemsN[toBankSlot] += amount;
                    } else {
                        return false;
                    }
                    deleteItem((playerItems[fromSlot] - 1), fromSlot, amount);
                    resetItems(5064);
                    resetBank();
                    return true;
                } else if (alreadyInBank) {
                    if ((bankItemsN[toBankSlot] + amount) <= maxItemAmount
                            && (bankItemsN[toBankSlot] + amount) > -1) {
                        bankItemsN[toBankSlot] += amount;
                    } else {
                        return false;
                    }
                    deleteItem((playerItems[fromSlot] - 1), fromSlot, amount);
                    resetItems(5064);
                    resetBank();
                    return true;
                } else {
                    sendMessage("Bank full!");
                    return false;
                }
            } else {
                itemID = playerItems[fromSlot];
                int toBankSlot = 0;
                boolean alreadyInBank = false;

                for (int i = 0; i < playerBankSize; i++) {
                    if (bankItems[i] == (playerItems[fromSlot] - 1)) {
                        alreadyInBank = true;
                        toBankSlot = i;
                        i = playerBankSize + 1;
                    }
                }
                if (!alreadyInBank && freeBankSlots() > 0) {
                    for (int i = 0; i < playerBankSize; i++) {
                        if (bankItems[i] <= 0) {
                            toBankSlot = i;
                            i = playerBankSize + 1;
                        }
                    }
                    int firstPossibleSlot = 0;
                    boolean itemExists = false;

                    while (amount > 0) {
                        itemExists = false;
                        for (int i = firstPossibleSlot; i < playerItems.length; i++) {
                            if ((playerItems[i]) == itemID) {
                                firstPossibleSlot = i;
                                itemExists = true;
                                i = 30;
                            }
                        }
                        if (itemExists) {
                            bankItems[toBankSlot] = (playerItems[firstPossibleSlot]
                                    - 1);
                            bankItemsN[toBankSlot] += 1;
                            deleteItem((playerItems[firstPossibleSlot] - 1),
                                    firstPossibleSlot, 1);
                            amount--;
                        } else {
                            amount = 0;
                        }
                    }
                    resetItems(5064);
                    resetBank();
                    return true;
                } else if (alreadyInBank) {
                    int firstPossibleSlot = 0;
                    boolean itemExists = false;

                    while (amount > 0) {
                        itemExists = false;
                        for (int i = firstPossibleSlot; i < playerItems.length; i++) {
                            if ((playerItems[i]) == itemID) {
                                firstPossibleSlot = i;
                                itemExists = true;
                                i = 30;
                            }
                        }
                        if (itemExists) {
                            bankItemsN[toBankSlot] += 1;
                            deleteItem((playerItems[firstPossibleSlot] - 1),
                                    firstPossibleSlot, 1);
                            amount--;
                        } else {
                            amount = 0;
                        }
                    }
                    resetItems(5064);
                    resetBank();
                    return true;
                } else {
                    sendMessage("Bank full!");
                    return false;
                }
            }
        } else {
            sendMessage("Item not supported " + (playerItems[fromSlot] - 1));
            return false;
        }
    }

  public void createItem(int newItemID) {
    int Maxi = server.itemHandler.DropItemCount;

    for (int i = 0; i <= Maxi; i++) {
      if (server.itemHandler.DroppedItemsID[i] < 1) {
        server.itemHandler.DroppedItemsID[i] = newItemID;
        server.itemHandler.DroppedItemsX[i] = (absX);
        server.itemHandler.DroppedItemsY[i] = (absY);
        server.itemHandler.DroppedItemsN[i] = 1;
        server.itemHandler.DroppedItemsH[i] = heightLevel;
        server.itemHandler.DroppedItemsDDelay[i] = (server.itemHandler.MaxDropShowDelay+1); // this way the item can NEVER be showed to another client
        server.itemHandler.DroppedItemsDropper[i] = playerId;
        if (i == Maxi) {
          server.itemHandler.DropItemCount++;
          if (server.itemHandler.DropItemCount >= (server.itemHandler.MaxDropItems+1)) {
            server.itemHandler.DropItemCount = 0;
            misc.println("! Notify item resterting !");
          }
        }
        break;
      }
    }
  }
  public void createItem(int newItemID, int amount) {
    int Maxi = server.itemHandler.DropItemCount;

    for (int i = 0; i <= Maxi; i++) {
      if (server.itemHandler.DroppedItemsID[i] < 1) {
        server.itemHandler.DroppedItemsID[i] = newItemID;
        server.itemHandler.DroppedItemsX[i] = (absX);
        server.itemHandler.DroppedItemsY[i] = (absY);
        server.itemHandler.DroppedItemsN[i] = amount;
        server.itemHandler.DroppedItemsH[i] = heightLevel;
        server.itemHandler.DroppedItemsDDelay[i] = (server.itemHandler.MaxDropShowDelay+1); // this way the item can NEVER be showed to another client
        server.itemHandler.DroppedItemsDropper[i] = playerId;
        if (i == Maxi) {
          server.itemHandler.DropItemCount++;
          if (server.itemHandler.DropItemCount >= (server.itemHandler.MaxDropItems+1)) {
            server.itemHandler.DropItemCount = 0;
            misc.println("! Notify item resterting !");
          }
        }
        break;
      }
    }
  }

  public void createItemForAll(int newItemID, int amount, int X, int Y) {
    int Maxi = server.itemHandler.DropItemCount;

    for (int i = 0; i <= Maxi; i++) {
      if (server.itemHandler.DroppedItemsID[i] < 1) {
        server.itemHandler.DroppedItemsID[i] = newItemID;
        server.itemHandler.DroppedItemsX[i] = X;
        server.itemHandler.DroppedItemsY[i] = Y;
        server.itemHandler.DroppedItemsN[i] = amount;
        server.itemHandler.DroppedItemsH[i] = heightLevel;
        server.itemHandler.DroppedItemsDDelay[i] = (server.itemHandler.MaxDropShowDelay+1); // this way the item can NEVER be showed to another client
        server.itemHandler.DroppedItemsDropper[i] = playerId;
        if (i == Maxi) {
          server.itemHandler.DropItemCount++;
          if (server.itemHandler.DropItemCount >= (server.itemHandler.MaxDropItems+1)) {
            server.itemHandler.DropItemCount = 0;
            misc.println("! Notify item resterting !");
          }
        }
        break;
      }
    }
  }

  public void removeAllItems() {
    for (int i = 0; i < playerItems.length; i++) {
      playerItems[i] = 0;
    }
    for (int i = 0; i < playerItemsN.length; i++) {
      playerItemsN[i] = 0;
    }
    resetItems(3214);
  }

  public void resetItems(int WriteFrame) {
    outStream.createFrameVarSizeWord(53);
    outStream.writeWord(WriteFrame);
    outStream.writeWord(playerItems.length);
    for (int i = 0; i < playerItems.length; i++) {
      if (playerItemsN[i] > 254) {
        outStream.writeByte(255); // item's stack count. if over 254, write byte 255
        outStream.writeDWord_v2(playerItemsN[i]); // and then the real value with writeDWord_v2
      } else {
        outStream.writeByte(playerItemsN[i]);
      }
      if (playerItems[i] > 20000 || playerItems[i] < 0) {
        playerItems[i] = 20000;
      }
      outStream.writeWordBigEndianA(playerItems[i]); // item id
    }
    outStream.endFrameVarSizeWord();
  }

public int currentButton = 0, currentStatus = 0;
public boolean spamButton = false;
public boolean duelRequested = false, inDuel = false, duelConfirmed = false, duelConfirmed2 = false, duelResetNeeded = false, duelFight = false;
public int duel_with = 0;
public boolean tradeRequested = false, inTrade = false, canOffer = true, tradeConfirmed = false, tradeConfirmed2 = false, tradeResetNeeded = false;
public int trade_reqId = 0, trade_other;
public CopyOnWriteArrayList < GameItem > offeredItems = new CopyOnWriteArrayList < GameItem > ();
public CopyOnWriteArrayList < GameItem > otherOfferedItems = new CopyOnWriteArrayList < GameItem > ();
public boolean adding = false, emoting = false;
String[]lastMessage = new String[3];
long animationReset = 0, lastButton = 0;
int fishTries;
boolean fishing = false;
int tX = 0, tY = 0, tStage = 0, tH = 1;
long tTime = 0;
boolean crafting = false;
int cItem = -1;
int cAmount = 0;
int cLevel = 1;
int cExp = 0;
int cSelected = -1, cIndex = -1;
public int strPotTimer = 0;
public boolean strPot = true;
public int attPotTimer = 0;
public boolean attPot = true;
public int defPotTimer = 0;
public boolean defPot = true;
public int wildagilityPionts = 0;
public int agilityPionts = 0;
public int agility = 0;
public int personalyell = 0;
public String tradestatus = "";
public String npcName = "";
public String dMsg = "";
public int angle = 250;
public long lastMouse = 0;
boolean dialog = true, spinning = false, miningEss = false;
int dialogInterface = 2459, dialogId = 1;
public boolean fletching = false;
public int fletchId = -1, fletchAmount = -1, fletchLog = -1, originalW = -1, originalS = -1, fletchExp = 0;
public boolean smelting = false;
public int smelt_id, smeltCount;
public int started = 0;
public boolean ownerglow3 = false;
public boolean ownerglow2 = false;
public boolean adglow = false;
public boolean pmodglow = false;
public boolean ownerglow = false;
public boolean modglow2 = false;
public boolean adglow2 = false;
public boolean scare = false;
public boolean shafting = false;
public int random_skill = -1, npcId = -1;
public long lastProcess = 0;
public int clickIndex = 0;
public int autocast_spellIndex = -1;
public int[]clicks = new int[50];
public int loginDelay = 1;
public boolean validClient = true, muted = false, attackedNpc = false;
public int attackedNpcId = -1;
public String MBTC;
public boolean member = false;
public String MBBC;
public String MBHT;
public String MBID;
public int teleReq = 0;
public String teleLoc = "";
public boolean teleOtherScreen = false;
public boolean saveNeeded = true;
public boolean lookNeeded = false;
public int playerClass = 0; //0 = undecided, 1 = warrior, 2 = mage, 3 = ranger
public int[]effects = new int[10];
public boolean friendUpdate = false, lookUpdate = false;
public String properName = "";
public int barTimer = 0, saveTimer = 0;
public int actionButtonId = 0;
public int enemyId = -1, enemyX = -1, enemyY = -1, attackTimer = 0;
public int NPCSlot;	//GLOBALLY NOW last clicked npc slot -bakatool
public int NPCID;	//GLOBALLY NOW last clicked npcID -bakatool
public long lastAttack = 0;
public boolean oddDeath = false;
public boolean officialClient = false;
public long[]globalCooldown = new long[10];
public boolean validLogin = false;
  public boolean HasArrows = true;
  public int oldclick = 0;
  public int sameclick = 0;
  public boolean wearing = false;

  public static boolean AutoSave = false;
  public int savecounter = 0;
  public boolean spellSet = false;
  public boolean iceBarrage = false;
  public int iceTimer = 1000;
  public boolean Retribution = true;
  public int duelpartner = 0;
  public int AntiTeleDelay;
  public int abc;
  public int cba;
  public int aaa;
  public int abc2;
  public int duelWho = 0;
  public boolean duelReq = false;
  public int[]duelItems = new int[28];
  public boolean[]duelItemsNoted = new boolean[28];
  public int[]duelItemsN = new int[28];
  public boolean duelAccept1 = false;
  public boolean duelAccept2 = false;

  public int resetanim = 8;
  public int KillerId = playerId;

  public int[]requiredLevel =  {
    50, 52, 1, 54, 58, 1, 62, 64, 1, 68, 70, 1, 74, 76, 1, 80, 82, 1, 86, 88, 1, 92, 94, 1
  };

  public int[]baseDamage =  {
    1, 2, 0, 3, 4, 0, 5, 6, 0, 7, 8, 0, 9, 10, 0, 11, 12, 0, 13, 14, 0, 15, 16, 0
  };
  public int[]ancientId =  {
    12939, 12987, 0, 12901, 12861, 0, 12963, 13011, 0, 12919, 12881, 0, 12951, 12999, 0, 12911, 12871, 0, 12975, 13023, 0, 12929, 12891, 0
  };
  public int[]ancientType =  {
    0, 0, 1, 2, 3, 1, 0, 0, 1, 2, 3, 1, 0, 0, 1, 2, 3, 1, 0, 0, 1, 2, 3, 1
  };
  public int[]ancientRune1 =  {
    565, 565, 0, 565, 565, 0, 565, 565, 0, 565, 565, 0, 565, 565, 0, 565, 565, 0, 565, 565, 0, 565, 565
  };
  public int[]ancientRuneAm =  {
    1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1
  };
  public int[]ancientButton =  {
    51133, 51185, -1, 51091, 24018, -1, 51159, 51211, -1, 51111, 51069, -1, 51146, 51198, -1, 51102, 51058, -1, 51172, 51224, -1, 51122, 51080, -1
  };
  public int[]noTrade =  {
    1543, 1544, 1545, 1546, 1547, 1548, 983, 984, 2418, 2945, 1635, 1636, 7141, 989, 990, 6966, 4272, 4670, 4671, 4672, 4673, 1601, 1602, 1603, 1604, 1605, 1606, 1607, 1608, 991, 992, 6306, 6322, 6323, 6324, 6325, 6326, 6327, 6328, 6329, 6330, 6331, 6351, 6352, 6353, 6354, 6355, 6356, 6357, 6358, 6359, 6360, 6361, 6362, 6363, 6364, 6365, 6366, 6367, 6368, 6369, 6370, 6371, 6372, 6373, 6374, 6375, 6376, 6377, 6378, 6379, 6380, 6313, 6314, 6315, 6316, 6317, 6318, 6235, 6236, 6257, 6258, 6279, 6275, 3173, 3174, 3175, 1409, 7142, 4068, 4069, 4070, 4071, 4072, 4503, 4504, 4505, 4506, 4507, 4508, 4509, 4510, 4511, 4512, 4566, 2520, 2521, 2522, 2523, 2524, 2525, 2526, 2527, 6583, 6584, 6541, 2952, 7319, 7319, 7320, 7321, 7322, 7323, 7324, 7325, 7326, 7327, 7328, 4067
  };
  public int[]casketItems =  {
    4724, 4726, 4728, 4730, 1050, 1053, 1055, 1057, 1037, 3107, 4708, 4710, 4712, 4714, 2904, 777, 2414
  };
  public int[]coolDownGroup =  {
    2, 2, 1, 2, 3, 1, 2, 2, 1, 2, 3, 1, 2, 2, 1, 2, 3, 1, 2, 2, 1, 2, 3, 1
  };
  public long[]coolDown =  {
    5000, 5000, 2500, 5000
  };
  public int[]duelButtons =  {
    26069, 26070, 26071, 30136, 2158, 26065, 26072, 26073, 26074, 26066, 26076
  };
  public String[]duelNames =  {
    "No Ranged", "No Melee", "No Magic", "No Gear Change", "Fun Weapons", "No Retreat", "No Drinks", "No Food", "No prayer", "No Movement", "Obstacles"
  };
  public boolean[]duelRule =  {
    false, false, false, false, false, true, false, true, false, true, false
  };
  public int[]duelLine =  {
    6698, 6699, 6697, 7817, 669, 6696, 6701, 6702, 6703, 6704, 6731
  };

  public void SendWeapon(int Weapon, String WeaponName) {
    String WeaponName2 = WeaponName.replaceAll("Bronze", "");

    WeaponName2 = WeaponName2.replaceAll("Iron", "");
    WeaponName2 = WeaponName2.replaceAll("Steel", "");
    WeaponName2 = WeaponName2.replaceAll("Scythe", "");
    WeaponName2 = WeaponName2.replaceAll("Black", "");
    WeaponName2 = WeaponName2.replaceAll("Mithril", "");
    WeaponName2 = WeaponName2.replaceAll("Adamant", "");
    WeaponName2 = WeaponName2.replaceAll("Rune", "");
    WeaponName2 = WeaponName2.replaceAll("Granite", "");
    WeaponName2 = WeaponName2.replaceAll("Dragon", "");
    WeaponName2 = WeaponName2.replaceAll("Crystal", "");
    WeaponName2 = WeaponName2.trim();
    if (WeaponName.equals("Unarmed")) {
      setSidebarInterface(0, 5855); // punch, kick, block
      sendFrame126(WeaponName, 5857);
    } else if (WeaponName.endsWith("whip")) {
      setSidebarInterface(0, 12290); // flick, lash, deflect
      sendFrame246(12291, 200, Weapon);
      sendFrame126(WeaponName, 12293);
    } else if (WeaponName.endsWith("cutlass")) {
      setSidebarInterface(0, 12290); // flick, lash, deflect
      sendFrame246(12291, 200, Weapon);
      sendFrame126(WeaponName, 12293);
    } else if (WeaponName.endsWith("Scythe")) {
      setSidebarInterface(0, 776); // flick, lash, deflect
      sendFrame246(12291, 200, Weapon);
      sendFrame126(WeaponName, 778);
    } else if (WeaponName.endsWith("bow")) {
      setSidebarInterface(0, 1764); // accurate, rapid, longrange
      sendFrame246(1765, 200, Weapon);
      sendFrame126(WeaponName, 1767);
    } else if (WeaponName.endsWith("device")) {
      setSidebarInterface(0, 1764); // accurate, rapid, longrange
      sendFrame246(1765, 200, Weapon);
      sendFrame126(WeaponName, 1767);
    } else if (WeaponName.endsWith("bow full")) {
      setSidebarInterface(0, 1764); // accurate, rapid, longrange
      sendFrame246(1765, 200, Weapon);
      sendFrame126(WeaponName, 1767);
    } else if (WeaponName.startsWith("Staff") || WeaponName.endsWith("staff")) {
      setSidebarInterface(0, 328); // spike, impale, smash, block
      sendFrame246(329, 200, Weapon);
      sendFrame126(WeaponName, 331);
    } else if (WeaponName.startsWith("holy") || WeaponName.endsWith("water")) {
      setSidebarInterface(0, 328); // spike, impale, smash, block
      sendFrame246(329, 200, Weapon);
      sendFrame126(WeaponName, 331);
    } else if (WeaponName2.startsWith("dart")) {
      setSidebarInterface(0, 4446); // accurate, rapid, longrange
      sendFrame246(4447, 200, Weapon);
      sendFrame126(WeaponName, 4449);
    } else if (WeaponName2.startsWith("dagger")) {
      setSidebarInterface(0, 2276); // stab, lunge, slash, block
      sendFrame246(2277, 200, Weapon);
      sendFrame126(WeaponName, 2279);
    } else if (WeaponName2.startsWith("pickaxe")) {
      setSidebarInterface(0, 5570); // spike, impale, smash, block
      sendFrame246(5571, 200, Weapon);
      sendFrame126(WeaponName, 5573);
    } else if (WeaponName2.startsWith("axe") || WeaponName2.startsWith("battleaxe")) {
      setSidebarInterface(0, 1698); // chop, hack, smash, block
      sendFrame246(1699, 200, Weapon);
      sendFrame126(WeaponName, 1701);
    } else if (WeaponName2.startsWith("Axe") || WeaponName2.startsWith("Battleaxe")) {
      setSidebarInterface(0, 1698); // chop, hack, smash, block
      sendFrame246(1699, 200, Weapon);
      sendFrame126(WeaponName, 1701);
    } else if (WeaponName2.startsWith("halberd")) {
      setSidebarInterface(0, 8460); // jab, swipe, fend
      sendFrame246(8461, 200, Weapon);
      sendFrame126(WeaponName, 8463);
    } else if (WeaponName2.startsWith("spear")) {
      setSidebarInterface(0, 4679); // lunge, swipe, pound, block
      sendFrame246(4680, 200, Weapon);
      sendFrame126(WeaponName, 4682);
    } else {
      setSidebarInterface(0, 2423); // chop, slash, lunge, block
      sendFrame246(2424, 200, Weapon);
      sendFrame126(WeaponName, 2426);
    }
  }

  public void resetOTItems(int WriteFrame) {
    client other = getClient(trade_reqId);
    if (!validClient(trade_reqId))
      return;
    outStream.createFrameVarSizeWord(53);
    outStream.writeWord(WriteFrame);
    int len = other.offeredItems.toArray().length;
    int current = 0;
    outStream.writeWord(len);
    for (GameItem item: other.offeredItems) {
      if (item.amount > 254) {
        outStream.writeByte(255); // item's stack count. if over 254, write byte 255
        outStream.writeDWord_v2(item.amount); // and then the real value with writeDWord_v2
      } else {
        outStream.writeByte(item.amount);
      }
      outStream.writeWordBigEndianA(item.id+1); // item id
      current++;
    }
    if (current < 27) {
      for (int i = current; i < 28; i++) {
        outStream.writeByte(1);
        outStream.writeWordBigEndianA(-1);
      }
    }
    outStream.endFrameVarSizeWord();
  }

  public void resetTItems(int WriteFrame) {
    outStream.createFrameVarSizeWord(53);
    outStream.writeWord(WriteFrame);
    int len = offeredItems.toArray().length;
    int current = 0;
    outStream.writeWord(len);
    for (GameItem item: offeredItems) {
      if (item.amount > 254) {
        outStream.writeByte(255); // item's stack count. if over 254, write byte 255
        outStream.writeDWord_v2(item.amount); // and then the real value with writeDWord_v2
      } else {
        outStream.writeByte(item.amount);
      }
      outStream.writeWordBigEndianA(item.id+1); // item id
      current++;
    }
    if (current < 27) {
      for (int i = current; i < 28; i++) {
        outStream.writeByte(1);
        outStream.writeWordBigEndianA(-1);
      }
    }
    outStream.endFrameVarSizeWord();
  }

  public void resetShop(int ShopID) {
    int TotalItems = 0;

    for (int i = 0; i < server.shopHandler.MaxShopItems; i++) {
      if (server.shopHandler.ShopItems[ShopID][i] > 0) {
        TotalItems++;
      }
    }
    if (TotalItems > server.shopHandler.MaxShopItems) {
      TotalItems = server.shopHandler.MaxShopItems;
    }
    outStream.createFrameVarSizeWord(53);
    outStream.writeWord(3900);
    outStream.writeWord(TotalItems);
    int TotalCount = 0;

    for (int i = 0; i < server.shopHandler.ShopItems.length; i++) {
      if (server.shopHandler.ShopItems[ShopID][i] > 0 || i <= server.shopHandler.ShopItemsStandard[ShopID]) {
        if (server.shopHandler.ShopItemsN[ShopID][i] > 254) {
          outStream.writeByte(255); // item's stack count. if over 254, write byte 255
          outStream.writeDWord_v2(server.shopHandler.ShopItemsN[ShopID][i]); // and then the real value with writeDWord_v2
        } else {
          outStream.writeByte(server.shopHandler.ShopItemsN[ShopID][i]);
        }
        if (server.shopHandler.ShopItems[ShopID][i] > 20000 || server.shopHandler.ShopItems[ShopID][i] < 0) {
          server.shopHandler.ShopItems[ShopID][i] = 20000;
        }
        outStream.writeWordBigEndianA(server.shopHandler.ShopItems[ShopID][i]); // item id
        TotalCount++;
      }
      if (TotalCount > TotalItems) {
        break;
      }
    }
    outStream.endFrameVarSizeWord();
  }

  public void resetBank() {
    outStream.createFrameVarSizeWord(53);
    outStream.writeWord(5382); // bank
    outStream.writeWord(playerBankSize); // number of items
    for (int i = 0; i < playerBankSize; i++) {
      if (bankItemsN[i] > 254) {
        outStream.writeByte(255);
        outStream.writeDWord_v2(bankItemsN[i]);
      } else {
        outStream.writeByte(bankItemsN[i]); // amount
      }
      if (bankItemsN[i] < 1) {
        bankItems[i] = 0;
      }
      if (bankItems[i] > 20000 || bankItems[i] < 0) {
        bankItems[i] = 20000;
      }
      outStream.writeWordBigEndianA(bankItems[i]); // itemID
    }
    outStream.endFrameVarSizeWord();
  }

  public void moveItems(int from, int to, int moveWindow) {
    if (moveWindow == 3724) {
      int tempI;
      int tempN;

      tempI = playerItems[from];
      tempN = playerItemsN[from];

      playerItems[from] = playerItems[to];
      playerItemsN[from] = playerItemsN[to];
      playerItems[to] = tempI;
      playerItemsN[to] = tempN;
    }

    if (moveWindow == 34453 && from >= 0 && to >= 0 && from < playerBankSize && to < playerBankSize) {
      int tempI;
      int tempN;

      tempI = bankItems[from];
      tempN = bankItemsN[from];

      bankItems[from] = bankItems[to];
      bankItemsN[from] = bankItemsN[to];
      bankItems[to] = tempI;
      bankItemsN[to] = tempN;
    }

    if (moveWindow == 34453) {
      resetBank();
    } else if (moveWindow == 18579) {
      resetItems(5064);
    } else if (moveWindow == 3724) {
      resetItems(3214);
    }
  }

  public int itemAmount(int itemID) {
    int tempAmount = 0;

    for (int i = 0; i < playerItems.length; i++) {
      if (playerItems[i] == itemID) {
        tempAmount += playerItemsN[i];
      }
    }
    return tempAmount;
  }

  public int freeBankSlots() {
    int freeS = 0;

    for (int i = 0; i < playerBankSize; i++) {
      if (bankItems[i] <= 0) {
        freeS++;
      }
    }
    return freeS;
  }

  public int freeSlots() {
    int freeS = 0;

    for (int i = 0; i < playerItems.length; i++) {
      if (playerItems[i] <= 0) {
        freeS++;
      }
    }
    return freeS;
  }


  public boolean pickUpItem(int item, int amount) {

    if (!Item.itemStackable[item] || amount < 1) {
      amount = 1;
    }

    if (freeSlots() > 0 && poimiY == currentY && poimiX == currentX)
     {
      for (int i = 0; i < playerItems.length; i++) {
        if (playerItems[i] == (item+1) && Item.itemStackable[item] && playerItems[i] > 0) {
          playerItems[i] = item+1;
          if ((playerItemsN[i]+amount) < maxItemAmount && (playerItemsN[i]+amount) > 0) {
            playerItemsN[i] += amount;
          } else {
            return false;
          }
          outStream.createFrameVarSizeWord(34);
          outStream.writeWord(3214);
          outStream.writeByte(i);
          outStream.writeWord(playerItems[i]);
          if (playerItemsN[i] > 254) {
            outStream.writeByte(255);
            outStream.writeDWord(playerItemsN[i]);
          } else {
            outStream.writeByte(playerItemsN[i]); // amount
          }
          outStream.endFrameVarSizeWord();
          i = 30;
          return true;
        }
      }
      for (int i = 0; i < playerItems.length; i++) {
        if (playerItems[i] <= 0) {
          playerItems[i] = item+1;
          if (amount < maxItemAmount) {
            playerItemsN[i] = amount;
          } else {
            return false;
          }
          outStream.createFrameVarSizeWord(34);
          outStream.writeWord(3214);
          outStream.writeByte(i);
          outStream.writeWord(playerItems[i]);
          if (playerItemsN[i] > 254) {
            outStream.writeByte(255);
            outStream.writeDWord_v2(playerItemsN[i]);
          } else {
            outStream.writeByte(playerItemsN[i]); // amount
          }
          outStream.endFrameVarSizeWord();
          i = 30;
          return true;
        }
      }
      return true;
    } else {
      return false;
    }
  }

  public void openUpBank() {
    sendFrame248(5292, 5063);
    resetItems(5064);
    IsBanking = true;
  }

  public void openUpShop(int ShopID) {
    sendFrame126(server.shopHandler.ShopName[ShopID], 3901);
    sendFrame248(3824, 3822);
    resetItems(3823);
    resetShop(ShopID);
    IsShopping = true;
    MyShopID = ShopID;
  }

  public boolean addItem(int item, int amount) {
    if (item >= Item.itemStackable.length) {
      return false;
    }
    if (item < 0 || amount < 1) {
      return false;
    }
    if (!Item.itemStackable[item] || amount < 1) {
      amount = 1;
    }

    if ((freeSlots() >= amount &&  ! Item.itemStackable[item]) || freeSlots() > 0) {
      for (int i = 0; i < playerItems.length; i++) {
        if (playerItems[i] == (item+1) && Item.itemStackable[item] && playerItems[i] > 0) {
          playerItems[i] = (item+1);
          if ((playerItemsN[i]+amount) < maxItemAmount && (playerItemsN[i]+amount) > -1) {
            playerItemsN[i] += amount;
          } else {
            playerItemsN[i] = maxItemAmount;
          }
          outStream.createFrameVarSizeWord(34);
          outStream.writeWord(3214);
          outStream.writeByte(i);
          outStream.writeWord(playerItems[i]);
          if (playerItemsN[i] > 254) {
            outStream.writeByte(255);
            outStream.writeDWord(playerItemsN[i]);
          } else {
            outStream.writeByte(playerItemsN[i]); // amount
          }
          outStream.endFrameVarSizeWord();
          i = 30;
          return true;
        }
      }
      for (int i = 0; i < playerItems.length; i++) {
        if (playerItems[i] <= 0) {
          playerItems[i] = item+1;
          if (amount < maxItemAmount && amount > -1) {
            playerItemsN[i] = amount;
          } else {
            playerItemsN[i] = maxItemAmount;
          }
          outStream.createFrameVarSizeWord(34);
          outStream.writeWord(3214);
          outStream.writeByte(i);
          outStream.writeWord(playerItems[i]);
          if (playerItemsN[i] > 254) {
            outStream.writeByte(255);
            outStream.writeDWord(playerItemsN[i]);
          } else {
            outStream.writeByte(playerItemsN[i]); // amount
          }
          outStream.endFrameVarSizeWord();
          i = 30;
          return true;
        }
      }
      return false;
    } else {
      sendMessage("Not enough space in your inventory.");
      return false;
    }
  }

  public void dropItem(int droppedItem, int slot) {
    // misc.printlnTag("droppeditem ["+playerItems[slot]+"] which is ["+(droppedItem+1)+"]");
    boolean a = true;

    if (a && (playerRights != 0) && (playerRights != 3) && droppedItem != 7581 && droppedItem != 7582 && droppedItem != 7584 && droppedItem != 7585) {
	sendMessage("Staff cannot drop items!");
	ownerYell(playerName + " tried to drop an item!");
	return;
		}
if (!canUse(droppedItem)) {
			sendMessage("You must be a premium member to drop this item");
			return;
		}
    if (droppedItem == 7581 && penguin == 0) {
deleteItem(7581, 1);
       	Summon(3503);
	penguin = 1;
	return;
	}

    if (droppedItem == 7582 && penguin == 0) {
       	Summon(3504);
	penguin = 1;
	return;
	} 
    if (droppedItem == 7582 && penguin == 1) {
	sendMessage("You can only have one pet at once!");
	return;
	}

    if (droppedItem == 7584 && penguin == 0) {
       	Summon(3506);
	penguin = 1;
	return;
	} 
    if (droppedItem == 7584 && penguin == 1) {
	sendMessage("You can only have one pet at once!");
	return;
	}

    if (droppedItem == 7585 && penguin == 0) {
       	Summon(3507);
	penguin = 1;
	return;
	} 
    if (droppedItem == 7585 && penguin == 1) {
	sendMessage("You can only have one pet at once!");
	return;
	}

    if (playerItemsN[slot] != 0 && droppedItem != -1 && playerItems[slot] == droppedItem+1) {
      for (int i = 0; i < noTrade.length; i++) {
        if (droppedItem == noTrade[i]) {
          sendMessage("You can't drop this item");
          return;
        }
      }
      ItemHandler.addItem(playerItems[slot]-1, absX, absY, playerItemsN[slot], playerId, false);
      // createGroundItem(droppedItem, absX, absY, c);
      deleteItem(droppedItem, slot, playerItemsN[slot]);
      updateRequired = true;

	writeLog("drop logs", playerName + " dropped item: " + droppedItem);
    }
  }

  public void createGroundItem(int itemID, int itemX, int itemY, int itemAmount) {
    // Phate: Omg fucking sexy! creates item at absolute X and Y
    outStream.createFrame(85); // Phate: Spawn ground item
    outStream.writeByteC((itemY-8*mapRegionY));
    outStream.writeByteC((itemX-8*mapRegionX));
    outStream.createFrame(44);
    outStream.writeWordBigEndianA(itemID);
    outStream.writeWord(itemAmount);
    outStream.writeByte(0); // x(4 MSB) y(LSB) coords
    // System.out.println("CreateGroundItem "+itemID+" "+(itemX - 8 * mapRegionX)+","+(itemY - 8 * mapRegionY)+" "+itemAmount);
  }

  public void removeGroundItem(int itemX, int itemY, int itemID) {
    // Phate: Omg fucking sexy! remoevs an item from absolute X and Y
    outStream.createFrame(85); // Phate: Item Position Frame
    outStream.writeByteC((itemY-8*mapRegionY));
    outStream.writeByteC((itemX-8*mapRegionX));
    outStream.createFrame(156); // Phate: Item Action: Delete
    outStream.writeByteS(0); // x(4 MSB) y(LSB) coords
    outStream.writeWord(itemID); // Phate: Item ID
    // misc.printlnTag("RemoveGroundItem "+itemID+" "+(itemX - 8 * mapRegionX)+","+(itemY - 8 * mapRegionY));
  }
  public void deleteItem(int id, int amount) {
    deleteItem(id, GetItemSlot(id), amount);
  }
  public void deleteItem(int id, int slot, int amount) {
		if ((slot > -1) && (slot < playerItems.length)) {
			if ((playerItems[slot] - 1) == id) {
				if (playerItemsN[slot] > amount) {
					playerItemsN[slot] -= amount;
				} else {
					playerItemsN[slot] = 0;
					playerItems[slot] = 0;
				}
				resetItems(3214);
			}
		} else {
			sendMessage("Not enough room to delete items.");
		}
	}

  public void setEquipment(int wearID, int amount, int targetSlot) {
    int Stat = playerDefence;

    if (targetSlot == playerWeapon) {
      Stat = playerAttack;
    }
    outStream.createFrameVarSizeWord(34);
    outStream.writeWord(1688);
    outStream.writeByte(targetSlot);
    outStream.writeWord((wearID+1));
    if (amount > 254) {
      outStream.writeByte(255);
      outStream.writeDWord(amount);
    } else {
      outStream.writeByte(amount); // amount
    }
    outStream.endFrameVarSizeWord();

    if (targetSlot == playerWeapon && wearID >= 0) {
      SendWeapon(wearID, GetItemName(wearID));
      // playerSE = 0x328;
      // playerSEW = 0x333;
      // playerSER = 0x338;
      // playerSEA = 0x326;
      if (Item.itemTwoHanded[wearID] == true) {
         playerSE = 2065;
			playerSEW = 2064;
			playerSER = 1664;
		playerSEA = 407;
      }
      if (wearID == 4747) {
        // Torag Hammers
        playerSEA = 0x814;
      }
      if ((wearID == 859) || (wearID == 839) || (wearID == 841) || (wearID == 843) || (wearID == 845) || (wearID == 847) || (wearID == 849) || (wearID == 851) || (wearID == 853) || (wearID == 855) || (wearID == 857) || (wearID == 861) || (wearID == 4214) || (wearID == 6082) || (wearID == 4734)) {
        // Crystal Bow
        playerSEA = 426;
      }

      pEmote = playerSE;
    }
    updateRequired = true;
    appearanceUpdateRequired = true;
  }

  public boolean wear(int wearID, int slot) {
    if (duelFight && duelRule[3]) {
      sendMessage("Equipment changing has been disabled in this duel");
      return false;
    }
 if (wearID == 775){
gauntleychance = 90;
sendMessage("Wearing a cooking gauntley increase your chance to cook.");

}
    int targetSlot = 0;
    targetSlot = itemType(wearID);
    int[]two_hand =  {
      1319, 4718, 4726, 1409, 4710, 7158, 4158
    };

    for (int a = 0; a < two_hand.length; a++) {
      if (wearID == two_hand[a] && playerEquipment[playerShield] > 0) {
        if (playerHasItem(-1)) {
          addItem(playerEquipment[playerShield], 1);
          playerEquipment[playerShield] = -1;
        } else {
          sendMessage("You can't wear this weapon with a shield");
          return false;
        }
      }

if (!canUse(wearID)) {
				sendMessage("You must be a premium member to use this item");
				return false;}

      if (itemType(wearID) == playerShield && playerEquipment[playerWeapon] == two_hand[a]) {
        if (playerHasItem(-1)) {
          addItem(playerEquipment[playerWeapon], 1);
          playerEquipment[playerWeapon] = -1;
        } else {
          sendMessage("You can't wear a shield with this weapon");
          return false;
        }
      }
    }


    if ((playerItems[slot]-1) == wearID) {
      targetSlot = itemType(wearID);
      int CLAttack = GetCLAttack(wearID);
      int CLDefence = GetCLDefence(wearID);
      int CLStrength = GetCLStrength(wearID);
      int CLMagic = GetCLMagic(wearID);
      int CLRanged = GetCLRanged(wearID);
      boolean GoFalse = false;

      if (CLAttack > playerLevel[playerAttack]) {
        sendMessage("You need "+CLAttack+" "+statName[playerAttack]+" to equip this item.");
        GoFalse = true;
      }
      if (CLDefence > playerLevel[playerDefence]) {
        sendMessage("You need "+CLDefence+" "+statName[playerDefence]+" to equip this item.");
        GoFalse = true;
      }
      if (CLStrength > playerLevel[playerStrength]) {
        sendMessage("You need "+CLStrength+" "+statName[playerStrength]+" to equip this item.");
        GoFalse = true;
      }
      if (CLMagic > playerLevel[playerMagic]) {
        sendMessage("You need "+CLMagic+" "+statName[playerMagic]+" to equip this item.");
        GoFalse = true;
      }
      if (CLRanged > playerLevel[playerRanged]) {
        sendMessage("You need "+CLRanged+" "+statName[playerRanged]+" to equip this item.");
        GoFalse = true;
      }
      if (GoFalse == true) {
        return false;
      }
      int wearAmount = playerItemsN[slot];

      if (wearAmount < 1) {
        return false;
      }
      if (slot >= 0 && wearID >= 0) {
        deleteItem(wearID, slot, wearAmount);
        if (playerEquipment[targetSlot] != wearID && playerEquipment[targetSlot] >= 0) {
          addItem(playerEquipment[targetSlot], playerEquipmentN[targetSlot]);
        } else if (Item.itemStackable[wearID] && playerEquipment[targetSlot] == wearID) {
          wearAmount = playerEquipmentN[targetSlot]+wearAmount;
        } else if (playerEquipment[targetSlot] >= 0) {
          addItem(playerEquipment[targetSlot], playerEquipmentN[targetSlot]);
        }
      }
      outStream.createFrameVarSizeWord(34);
      outStream.writeWord(1688);
      outStream.writeByte(targetSlot);
      outStream.writeWord(wearID+1);
      if (wearAmount > 254) {
        outStream.writeByte(255);
        outStream.writeDWord(wearAmount);
      } else {
        outStream.writeByte(wearAmount); // amount
      }
      outStream.endFrameVarSizeWord();
      playerEquipment[targetSlot] = wearID;
      playerEquipmentN[targetSlot] = wearAmount;
      if (targetSlot == playerWeapon && playerEquipment[playerShield] != -1 && Item.itemTwoHanded[wearID] == true) {
        remove(playerEquipment[playerShield], playerShield);
      }
      if (targetSlot == playerWeapon) {
        SendWeapon(wearID, GetItemName(wearID));
        // playerSE = 0x328;
        // playerSEW = 0x333;
        // playerSER = 0x338;
        // playerSEA = 0x326;
        if (Item.itemTwoHanded[wearID] == true) {
          playerSE = 2065;
			playerSEW = 2064;
			playerSER = 1664;
		playerSEA = 407;
	
        }

        if (wearID == 4212) {
          // New Crystal bow
          playerSEA = 426;
        }
        if (wearID == 4214) {
          // Crystal bow full
          playerSEA = 426;
        }
        if (wearID == 6082) {
          // bazooka
          playerSEA = 426;
        }
        if (wearID == 4215) {
          // Crystal bow 9/10
          playerSEA = 426;
        }
        if (wearID == 4216) {
          // Crystal bow 8/10
          playerSEA = 426;
        }
        if (wearID == 4217) {
          // Crystal bow 7/10
          playerSEA = 426;
        }
        if (wearID == 4218) {
          // Crystal bow 6/10
          playerSEA = 426;
        }
        if (wearID == 4219) {
          // Crystal bow 5/10
          playerSEA = 426;
        }
        if (wearID == 4220) {
          // Crystal bow 4/10
          playerSEA = 426;
        }
        if (wearID == 4221) {
          // Crystal bow 3/10
          playerSEA = 426;
        }
if ((wearID == 1321) || (wearID == 1323) || (wearID == 1325) || (wearID == 1327) || (wearID == 1329) || (wearID == 1331) || (wearID == 1333) || (wearID == 4587) || (wearID == 6611)) {
					// Dragon dagger(all of em)
					playerSEA = 451;
					playerSEW = 1660;
					playerSER = 1661;
					playerSE = 1832;
				}
        if (wearID == 4222) {
          // Crystal bow 2/10
          playerSEA = 426;
        }
        if (wearID == 4223) {
          // Crystal bow 1/10
          playerSEA = 426;
        }

        /* Other Bows */
        if (wearID == 767) {
          // Phoenix crossbow
          playerSEA = 427;
        }
        if (wearID == 837) {
          // Crossbow
          playerSEA = 427;
        }
        for (int a = 0; a < shortbow.length; a++) {
          if (wearID == shortbow[a]) {
            playerSEA = 426;
          }
          if (wearID == longbow[a]) {
            playerSEA = 426;
          }
        }

        if (wearID == 839) {
          // Longbow
          playerSEA = 426;
        }
        if (wearID == 841) {
          // Shortbow
          playerSEA = 426;
        }
        if (wearID == 843) {
          // Oak shortbow
          playerSEA = 426;
        }
        if (wearID == 845) {
          // Oak longbow
          playerSEA = 426;
        }
        if (wearID == 847) {
          // Willow shortbow
          playerSEA = 426;
        }
        if (wearID == 849) {
          // Willow longbow
          playerSEA = 426;
        }
        if (wearID == 851) {
          // Maple shortbow
          playerSEA = 426;
        }
        if (wearID == 853) {
          // Maple longbow
          playerSEA = 426;
        }
        if (wearID == 855) {
          // Yew shortbow
          playerSEA = 426;
        }
        if (wearID == 857) {
          // Yew longbow
          playerSEA = 426;
        }
        if (wearID == 859) {
          // Magic shortbow
          playerSEA = 426;
        }
        if (wearID == 861) {
          // Magic longbow
          playerSEA = 426;
        }
        if (wearID == 4214) {
          // Magic longbow
          playerSEA = 426;
        }
        if (wearID == 6082) {
          // bazooka
          playerSE = 0x811;
          playerSEA = 750;
          playerSEW = 0x67F;
          playerSER = 0x680;
        }

        /* Barrows */
        if (wearID == 4718) {
          // Dharok's Greataxe
          playerSE = 0x811;
          playerSEA = 1665;
          playerSEW = 0x67F;
          playerSER = 0x680;
        }
        if (wearID == 4755) {
          // Verac Flail
          playerSEA = 2067;
          playerSEW = 1830;
          playerSER = 1831;
          playerSE = 1832;
        }
        if (wearID == 4734) {
          // Karils x-bow
          playerSE = 2074;
          playerSEA = 2075;
          playerSEW = 2076;
          playerSER = 2077;
        }
        if (wearID == 4747) {
          // Torag Hammers
          playerSEA = 0x814;
        }
        if (wearID == 4726) {
          // Guthans warspear
          playerSEA = 2080;
          playerSER = 2077;
          playerSEW = 2076;
          playerSE = 2074;
        }

        /* Misc */
        if (wearID == 7158) {
          // Dragon 2h sword
          playerSE = 0x811;
          playerSEA = 2876;
          playerSEW = 0x67F;
          playerSER = 0x680;
        }
        if (wearID == 4566) {
          // chicken XD
          playerSE = 0x811;
          playerSEA = 1835;
          playerSEW = 0x67F;
          playerSER = 0x680;
        }
        if (wearID == 4158) {
          // leaf
          playerSE = 0x811;
          playerSEA = 2876;
          playerSEW = 0x67F;
          playerSER = 0x680;
        }
        if (wearID == 2952) {
          // wolf
          playerSE = 0x811;
          playerSEA = 2876;
          playerSEW = 0x67F;
          playerSER = 0x680;
        }
        if (wearID == 4068) {
          // cw
          playerSE = 0x811;
          playerSEA = 2876;
          playerSEW = 0x67F;
          playerSER = 0x680;
        }
        if (wearID == 4503) {
          // cw
          playerSE = 0x811;
          playerSEA = 2876;
          playerSEW = 0x67F;
          playerSER = 0x680;
        }
        if (wearID == 4508) {
          // cw
          playerSE = 0x811;
          playerSEA = 2876;
          playerSEW = 0x67F;
          playerSER = 0x680;
        }
        if (wearID == 7142) {
          // cw
          playerSE = 0x811;
          playerSEA = 1068;
          playerSEW = 0x67F;
          playerSER = 0x680;
        }
        if (wearID == 4151) {
          // Abyssal Whip
          playerSEW = 1660;
          playerSER = 1661;
          playerSE = 1832;
          playerSEA = 1658;
        }
        if (wearID == 6541) {
          // mouse
          playerSEW = 1660;
          playerSER = 1661;
          playerSE = 1832;
          playerSEA = 1658;
        }
        if (wearID == 1249 || wearID == 1263 || wearID == 3176 || wearID == 5716 || wearID == 5730) {
          // Dragon Spears
          playerSE = 809;
          playerSEW = 1146;
          playerSER = 1210;
        }
        if ((wearID == 1215) || (wearID == 5680) || (wearID == 1231)) {
          // Dragon dagger(all of em)
          playerSEA = 402;
        }
        if (wearID == 5698) {
          // Dragon Dagger (S)
          playerSEA = 1068;
        }
        if (wearID == 4170) {
          // SlayerStaff
          playerSE = 2261;
          playerSEA = 2324;
          playerSEW = 2261;
          playerSER = 2261;
        }

        if (wearID == 3204) {
          // Dragon Halberd
          playerSE = 809;
          playerSEA = 1665;
          playerSEW = 1146;
          playerSER = 1210;
        }
        if (wearID == 1305) {
          // Dragon Longsword
          playerSE = 809;
          playerSEA = 1058;
        }
        if (wearID == 1419) {
          // Scythe
          playerSEA = 408;
        }
        if (wearID == 4153) {
          // Granite Maul
          playerSE = 1662;
          playerSEA = 1665;
          playerSEW = 1663;
          playerSER = 1664;
        }
        if (wearID == 4675) {
          // Ancient staff
          playerSE = 809;
          playerSEA = 806;
          playerSEW = 1146;
          playerSER = 1210;
        }
        if (wearID == 84) {
          // Staff Of Armadyl
          playerSE = 809;
          playerSEA = 806;
          playerSEW = 1146;
          playerSER = 1210;
        }
        if (wearID == 772) {
          // Dramen Staff
          playerSE = 809;
          playerSEA = 806;
          playerSEW = 1146;
          playerSER = 1210;
        }
        if (wearID == 1379) {
          // Staff
          playerSE = 809;
          playerSEA = 806;
          playerSEW = 1146;
          playerSER = 1210;
        }
        if (wearID == 1381) {
          // Staff Of Air
          playerSE = 809;
          playerSEA = 806;
          playerSEW = 1146;
          playerSER = 1210;
        }
        if (wearID == 1383) {
          // Staff Of Water
          playerSE = 809;
          playerSEA = 806;
          playerSEW = 1146;
          playerSER = 1210;
        }
        if (wearID == 1385) {
          // Staff Of Earth
          playerSE = 809;
          playerSEA = 806;
          playerSEW = 1146;
          playerSER = 1210;
        }
        if (wearID == 1387) {
          // Staff Of Fire
          playerSE = 809;
          playerSEA = 806;
          playerSEW = 1146;
          playerSER = 1210;
        }
        if (wearID == 1389) {
          // Magic Staff
          playerSE = 809;
          playerSEA = 806;
          playerSEW = 1146;
          playerSER = 1210;
        }
        if (wearID == 1391) {
          // Battle Staff
          playerSE = 809;
          playerSEA = 806;
          playerSEW = 1146;
          playerSER = 1210;
        }
        if (wearID == 1393) {
          // Fire Battlestaff
          playerSE = 809;
          playerSEA = 806;
          playerSEW = 1146;
          playerSER = 1210;
        }
        if (wearID == 1395) {
          // Water Battlestaff
          playerSE = 809;
          playerSEA = 806;
          playerSEW = 1146;
          playerSER = 1210;
        }
        if (wearID == 1397) {
          // Air Battlestaff
          playerSE = 809;
          playerSEA = 806;
          playerSEW = 1146;
          playerSER = 1210;
        }
        if (wearID == 1399) {
          // Earth Battlestaff
          playerSE = 809;
          playerSEA = 806;
          playerSEW = 1146;
          playerSER = 1210;
        }
        if (wearID == 1401) {
          // Mystic Fire Staff
          playerSE = 809;
          playerSEA = 806;
          playerSEW = 1146;
          playerSER = 1210;
        }
        if (wearID == 1403) {
          // Mystic Water Staff
          playerSE = 809;
          playerSEA = 806;
          playerSEW = 1146;
          playerSER = 1210;
        }
        if (wearID == 1405) {
          // Mystic Air Staff
          playerSE = 809;
          playerSEA = 806;
          playerSEW = 1146;
          playerSER = 1210;
        }
        if (wearID == 1407) {
          // Mystic Earth Staff
          playerSE = 809;
          playerSEW = 1146;
          playerSEA = 806;
          playerSER = 1210;
        }
        if (wearID == 1409) {
          // I-Ban's Staff
          playerSE = 809;
          playerSEW = 1146;
          playerSER = 1210;
        }
        if (wearID == 3053) {
          // Lava Battlestaff
          playerSE = 809;
          playerSEA = 806;
          playerSEW = 1146;
          playerSER = 1210;
        }
        if (wearID == 3054) {
          // Mystic Lava Staff
          playerSE = 809;
          playerSEA = 806;
          playerSEW = 1146;
          playerSER = 1210;
        }
        if (wearID == 4170) {
          // Slayer Staff
          playerSE = 809;
          playerSEA = 806;
          playerSEW = 1146;
          playerSER = 1210;
        }
        if (wearID == 4862) {
          // Ahrim's Staff 100
          playerSE = 809;
          playerSEA = 806;
          playerSEW = 1146;
          playerSER = 1210;
        }
        if (wearID == 4863) {
          // Ahrim's Staff 75
          playerSE = 809;
          playerSEA = 806;
          playerSEW = 1146;
          playerSER = 1210;
        }
        if (wearID == 4864) {
          // Ahrim's Staff 50
          playerSE = 809;
          playerSEW = 1146;
          playerSEA = 806;
          playerSER = 1210;
        }
        if (wearID == 4865) {
          // Ahrim's Staff 25
          playerSE = 809;
          playerSEW = 1146;
          playerSER = 1210;
          playerSEA = 806;
        }
        if (wearID == 4866) {
          // Ahrim's Staff 0
          playerSE = 809;
          playerSEA = 806;
          playerSEW = 1146;
          playerSER = 1210;
        }
        if (wearID == 6603) {
          // White Staff
          playerSE = 809;
          playerSEA = 806;
          playerSEW = 1146;
          playerSER = 1210;
        }
        if (wearID == 6726) {
          // Mud Battlestaff
          playerSE = 1421;
          playerSEA = 806;
          playerSEW = 1422;
          playerSER = 1427;
        }
        if (wearID == 6727) {
          // Mystic Mud Staff
          playerSE = 1421;
          playerSEA = 806;
          playerSEW = 1422;
          playerSER = 1427;
        }
        if (wearID == 6528) {
          // Obby Maul
          playerSE = 0x811;
          playerSEA = 2661;
          playerSEW = 2064;
          playerSER = 0x680;
        }
        pEmote = playerSE;
      }
      ResetBonus();
      GetBonus();
      wearing = false;
      WriteBonus();
      updateRequired = true;
      appearanceUpdateRequired = true;
      return true;
    }
    return false;
  }

  public int itemType(int item) {
    for (int i = 0; i < Item.capes.length; i++) {
      if (item == Item.capes[i]) {
        return playerCape;
      }
    }
    for (int i = 0; i < Item.hats.length; i++) {
      if (item == Item.hats[i]) {
        return playerHat;
      }
    }
    for (int i = 0; i < Item.boots.length; i++) {
      if (item == Item.boots[i]) {
        return playerFeet;
      }
    }
    for (int i = 0; i < Item.gloves.length; i++) {
      if (item == Item.gloves[i]) {
        return playerHands;
      }
    }
    for (int i = 0; i < Item.shields.length; i++) {
      if (item == Item.shields[i]) {
        return playerShield;
      }
    }
    for (int i = 0; i < Item.amulets.length; i++) {
      if (item == Item.amulets[i]) {
        return playerAmulet;
      }
    }
    for (int i = 0; i < Item.arrows.length; i++) {
      if (item == Item.arrows[i]) {
        return playerArrows;
      }
    }
    for (int i = 0; i < Item.rings.length; i++) {
      if (item == Item.rings[i]) {
        return playerRing;
      }
    }
    for (int i = 0; i < Item.body.length; i++) {
      if (item == Item.body[i]) {
        return playerChest;
      }
    }
    for (int i = 0; i < Item.legs.length; i++) {
      if (item == Item.legs[i]) {
        return playerLegs;
      }
    }

    // Default
    return playerWeapon;
  }

  public void remove(int wearID, int slot) {
    if (duelFight && duelRule[3]) {
      sendMessage("Equipment changing has been disabled in this duel!");
      return;
    }
if (wearID == 775){
gauntleychance -= 90;
}
    if (addItem(playerEquipment[slot], playerEquipmentN[slot])) {
      playerEquipment[slot] = -1;
      playerEquipmentN[slot] = 0;
      outStream.createFrame(34);
      outStream.writeWord(6);
      outStream.writeWord(1688);
      outStream.writeByte(slot);
      outStream.writeWord(0);
      outStream.writeByte(0);
      ResetBonus();
      GetBonus();
      WriteBonus();
   
      if (slot == playerWeapon) {
        SendWeapon(-1, "Unarmed");
      }
      updateRequired = true;
      appearanceUpdateRequired = true;
    }
  }

  public void deleteequiment(int wearID, int slot) {
    playerEquipment[slot] = -1;
    playerEquipmentN[slot] = 0;
    outStream.createFrame(34);
    outStream.writeWord(6);
    outStream.writeWord(1688);
    outStream.writeByte(slot);
    outStream.writeWord(0);
    outStream.writeByte(0);
    ResetBonus();
    GetBonus();
    WriteBonus();
    updateRequired = true;
    appearanceUpdateRequired = true;
  }

  public void TeleTo(String s, int level) {
    if (actionTimer == 0) {
      teleX = absX;
      teleY = absY;
      newheightLevel = heightLevel;

      closeInterface();
      teleport();
      actionTimer = 10;
      updateRequired = true;
      appearanceUpdateRequired = true;
    }
  }

  public void setChatOptions(int publicChat, int privateChat, int tradeBlock) {
    outStream.createFrame(206);
    outStream.writeByte(publicChat); // On = 0, Friends = 1, Off = 2, Hide = 3
    outStream.writeByte(privateChat); // On = 0, Friends = 1, Off = 2
    outStream.writeByte(tradeBlock); // On = 0, Friends = 1, Off = 2
  }

  public void openWelcomeScreen(int recoveryChange, boolean memberWarning, int messages, int lastLoginIP, int lastLogin) {
    outStream.createFrame(176);
    // days since last recovery change 200 for not yet set 201 for members server,
    // otherwise, how many days ago recoveries have been changed.
    outStream.writeByteC(recoveryChange);
    outStream.writeWordA(messages); // # of unread messages
    outStream.writeByte(memberWarning ? 1 : 0); // 1 for member on non-members world warning
    outStream.writeDWord_v2(lastLoginIP); // ip of last login
    outStream.writeWord(lastLogin); // days
  }

  public void setClientConfig(int id, int state) {
    outStream.createFrame(36);
    outStream.writeWordBigEndian(id);
    outStream.writeByte(state);
  }

  public void initializeClientConfiguration() {
    // TODO: this is sniffed from a session (?), yet have to figure out what each of these does.
    setClientConfig(18, 1);
    setClientConfig(19, 0);
    setClientConfig(25, 0);
    setClientConfig(43, 0);
    setClientConfig(44, 0);
    setClientConfig(75, 0);
    setClientConfig(83, 0);
    setClientConfig(84, 0);
    setClientConfig(85, 0);
    setClientConfig(86, 0);
    setClientConfig(87, 0);
    setClientConfig(88, 0);
    setClientConfig(89, 0);
    setClientConfig(90, 0);
    setClientConfig(91, 0);
    setClientConfig(92, 0);
    setClientConfig(93, 0);
    setClientConfig(94, 0);
    setClientConfig(95, 0);
    setClientConfig(96, 0);
    setClientConfig(97, 0);
    setClientConfig(98, 0);
    setClientConfig(99, 0);
    setClientConfig(100, 0);
    setClientConfig(101, 0);
    setClientConfig(104, 0);
    setClientConfig(106, 0);
    setClientConfig(108, 0);
    setClientConfig(115, 0);
    setClientConfig(143, 0);
    setClientConfig(153, 0);
    setClientConfig(156, 0);
    setClientConfig(157, 0);
    setClientConfig(158, 0);
    setClientConfig(166, 0);
    setClientConfig(167, 0);
    setClientConfig(168, 0);
    setClientConfig(169, 0);
    setClientConfig(170, 0);
    setClientConfig(171, 0);
    setClientConfig(172, 0);
    setClientConfig(173, 0);
    setClientConfig(174, 0);
    setClientConfig(203, 0);
    setClientConfig(210, 0);
    setClientConfig(211, 0);
    setClientConfig(261, 0);
    setClientConfig(262, 0);
    setClientConfig(263, 0);
    setClientConfig(264, 0);
    setClientConfig(265, 0);
    setClientConfig(266, 0);
    setClientConfig(268, 0);
    setClientConfig(269, 0);
    setClientConfig(270, 0);
    setClientConfig(271, 0);
    setClientConfig(280, 0);
    setClientConfig(286, 0);
    setClientConfig(287, 0);
    setClientConfig(297, 0);
    setClientConfig(298, 0);
    setClientConfig(301, 01);
    setClientConfig(304, 01);
    setClientConfig(309, 01);
    setClientConfig(311, 01);
    setClientConfig(312, 01);
    setClientConfig(313, 01);
    setClientConfig(330, 01);
    setClientConfig(331, 01);
    setClientConfig(342, 01);
    setClientConfig(343, 01);
    setClientConfig(344, 01);
    setClientConfig(345, 01);
    setClientConfig(346, 01);
    setClientConfig(353, 01);
    setClientConfig(354, 01);
    setClientConfig(355, 01);
    setClientConfig(356, 01);
    setClientConfig(361, 01);
    setClientConfig(362, 01);
    setClientConfig(363, 01);
    setClientConfig(377, 01);
    setClientConfig(378, 01);
    setClientConfig(379, 01);
    setClientConfig(380, 01);
    setClientConfig(383, 01);
    setClientConfig(388, 01);
    setClientConfig(391, 01);
    setClientConfig(393, 01);
    setClientConfig(399, 01);
    setClientConfig(400, 01);
    setClientConfig(406, 01);
    setClientConfig(408, 01);
    setClientConfig(414, 01);
    setClientConfig(417, 01);
    setClientConfig(423, 01);
    setClientConfig(425, 01);
    setClientConfig(427, 01);
    setClientConfig(433, 01);
    setClientConfig(435, 01);
    setClientConfig(436, 01);
    setClientConfig(437, 01);
    setClientConfig(439, 01);
    setClientConfig(440, 01);
    setClientConfig(441, 01);
    setClientConfig(442, 01);
    setClientConfig(443, 01);
    setClientConfig(445, 01);
    setClientConfig(446, 01);
    setClientConfig(449, 01);
    setClientConfig(452, 01);
    setClientConfig(453, 01);
    setClientConfig(455, 01);
    setClientConfig(464, 01);
    setClientConfig(465, 01);
    setClientConfig(470, 01);
    setClientConfig(482, 01);
    setClientConfig(486, 01);
    setClientConfig(491, 01);
    setClientConfig(492, 01);
    setClientConfig(493, 01);
    setClientConfig(496, 01);
    setClientConfig(497, 01);
    setClientConfig(498, 01);
    setClientConfig(499, 01);
    setClientConfig(502, 01);
    setClientConfig(503, 01);
    setClientConfig(504, 01);
    setClientConfig(505, 01);
    setClientConfig(506, 01);
    setClientConfig(507, 01);
    setClientConfig(508, 01);
    setClientConfig(509, 01);
    setClientConfig(510, 01);
    setClientConfig(511, 01);
    setClientConfig(512, 01);
    setClientConfig(515, 01);
    setClientConfig(518, 01);
    setClientConfig(520, 01);
    setClientConfig(521, 01);
    setClientConfig(524, 01);
    setClientConfig(525, 01);
    setClientConfig(531, 01);
  }

  public int GetLastLogin(int Date) {
    Calendar cal = new GregorianCalendar();
    int day = cal.get(Calendar.DAY_OF_MONTH);
    int month = cal.get(Calendar.MONTH);
    int year = cal.get(Calendar.YEAR);
    int calc = ((year*10000)+(month*100)+day);

    return (calc-Date);
  }

  public void initialize() {
    // first packet sent
    init(playerId);
    outStream.createFrame(249);
    outStream.writeByteA(playerIsMember); // 1 for members, zero for free
    outStream.writeWordBigEndianA(playerId);

    // here is the place for seting up the UI, stats, etc...
    setChatOptions(0, 0, 0);
    for (int i = 0; i < 25; i++) {
      setSkillLevel(i, playerLevel[i], playerXP[i]);
    }
    refreshSkills();

    outStream.createFrame(107); // resets something in the client

    setSidebarInterface(0, 2423); // attack tab
    setSidebarInterface(1, 3917); // skills tab
    setSidebarInterface(2, 638); // quest tab638
    setSidebarInterface(3, 3213); // backpack tab
    setSidebarInterface(4, 1644); // items wearing tab
    setSidebarInterface(5, 5608); // pray tab 5608
    setSidebarInterface(6, 12855); // magic tab (ancient = 12855)
    setSidebarInterface(7, -1); // ancient magicks
    setSidebarInterface(8, 5065); // friend
    setSidebarInterface(9, 5715); // ignore5715
    setSidebarInterface(10, 2449); // logout tab 6299
    setSidebarInterface(11, 4445); // wrench tab4445
    setSidebarInterface(12, 147); // run tab
    setSidebarInterface(13, -1); // harp tab
	
    outStream.createFrameVarSize(104);
    outStream.writeByteC(1); // command slot
    outStream.writeByteA(0); // 0 or 1; 1 if command should be placed on top in context menu
    outStream.writeString("Trade with");
    outStream.endFrameVarSize();
	
    outStream.createFrameVarSize(104);
    outStream.writeByteC(1); // command slot
    outStream.writeByteA(0); // 0 or 1; 1 if command should be placed on top in context menu
    outStream.writeString("Trade with");
    outStream.endFrameVarSize();

    outStream.createFrameVarSize(104);
    outStream.writeByteC(2);
    outStream.writeByteA(0);
    outStream.writeString("Duel");
    outStream.endFrameVarSize();	

    outStream.createFrameVarSize(104);
    outStream.writeByteC(3);
    outStream.writeByteA(0);
    outStream.writeString("Attack");
    outStream.endFrameVarSize();
	
    outStream.createFrameVarSize(104);
    outStream.writeByteC(1); // command slot
    outStream.writeByteA(0); // 0 or 1; 1 if command should be placed on top in context menu
    outStream.writeString("Trade with");
    outStream.endFrameVarSize();
	
    outStream.createFrameVarSize(104);
    outStream.writeByteC(1); // command slot
    outStream.writeByteA(0); // 0 or 1; 1 if command should be placed on top in context menu
    outStream.writeString("Trade with");
    outStream.endFrameVarSize();

    outStream.createFrameVarSize(104);
    outStream.writeByteC(2);
    outStream.writeByteA(0);
    outStream.writeString("Duel");
    outStream.endFrameVarSize();

rightClickCheck();

    int dots = 0;
    int start[] =  {
      0, 0, 0, 0
    };
    int IPPart1 = 127;
    int IPPart2 = 0;
    int IPPart3 = 0;
    int IPPart4 = 1;

    if (playerLastConnect.length() < 7) {
      playerLastConnect = connectedFrom;
    }
    if (playerLastConnect.length() <= 15) {
      for (int j = 0; j <= playerLastConnect.length(); j++) {
        if ((j+1) <= playerLastConnect.length()) {
          if (playerLastConnect.substring(j, (j+1)).equals(".")) {
            start[dots] = j;
            dots++;
          }
          if (dots == 3) {
            break;
          }
        }
      }
      if (dots == 3) {
        IPPart1 = Integer.parseInt(playerLastConnect.substring(0, start[0]));
        IPPart2 = Integer.parseInt(playerLastConnect.substring((start[0]+1), start[1]));
        IPPart3 = Integer.parseInt(playerLastConnect.substring((start[1]+1), start[2]));
        IPPart4 = Integer.parseInt(playerLastConnect.substring((start[2]+1)));
      }
    } else {
      for (int j = 0; j <= playerLastConnect.length(); j++) {
        if ((j+1) <= playerLastConnect.length()) {
          if (playerLastConnect.substring(j, (j+1)).equals("-")) {
            start[dots] = j;
            dots++;
          }
          if (dots == 4) {
            break;
          }
        }
      }
      if (dots == 4) {
        try {
          IPPart1 = Integer.parseInt(playerLastConnect.substring(0, start[0]));
          IPPart2 = Integer.parseInt(playerLastConnect.substring((start[0]+1), start[1]));
          IPPart3 = Integer.parseInt(playerLastConnect.substring((start[1]+1), start[2]));
          IPPart4 = Integer.parseInt(playerLastConnect.substring((start[2]+1), (start[3])));
        } catch (NumberFormatException e) { }}}

if (started == 0){ 
sendMessage("Welcome to Exorth Legacy");
sendMessage("talk to Exorth guide for more information!");
} else {
sendMessage("Welcome back to Exorth Legacy!");


}
Serverupdate();
for (int a = 0; a < lastMessage.length; a++) { lastMessage[a] = "";}
if (membershipDays == 0 && premium == 2){
premium = 0;
sendMessage("Your premium status has expired.");
}
if(premium == 2){
sendMessage("Your account has premium member status");
sendMessage("You have "+getMemberDaysLeft(playerId)+" Membership days left");

 } else { 
sendMessage("Upgrade your account now to premium on Exorth");}
    if (lookNeeded) {
      showInterface(3559);
    } else
    sendFrame126(""+playerLevel[0]+"", 4004);
    sendFrame126(""+getLevelForXP(playerXP[0])+"", 4005);
    sendFrame126(""+playerLevel[1]+"", 4008);
    sendFrame126(""+getLevelForXP(playerXP[1])+"", 4009);
    sendFrame126(""+playerLevel[2]+"", 4006);
    sendFrame126(""+getLevelForXP(playerXP[2])+"", 4007);
    sendFrame126(""+playerLevel[3]+"", 4016);
    sendFrame126(""+getLevelForXP(playerXP[3])+"", 4017);
    sendFrame126(""+playerLevel[4]+"", 4010);
    sendFrame126(""+getLevelForXP(playerXP[4])+"", 4011);
    sendFrame126(""+playerLevel[5]+"", 4012);
    sendFrame126(""+getLevelForXP(playerXP[5])+"", 4013);
    sendFrame126(""+playerLevel[6]+"", 4014);
    sendFrame126(""+getLevelForXP(playerXP[6])+"", 4015);
    sendFrame126(""+playerLevel[7]+"", 4034);
    sendFrame126(""+getLevelForXP(playerXP[7])+"", 4035);
    sendFrame126(""+playerLevel[8]+"", 4038);
    sendFrame126(""+getLevelForXP(playerXP[8])+"", 4039);
    sendFrame126(""+playerLevel[9]+"", 4026);
    sendFrame126(""+getLevelForXP(playerXP[9])+"", 4027);
    sendFrame126(""+playerLevel[10]+"", 4032);
    sendFrame126(""+getLevelForXP(playerXP[10])+"", 4033);
    sendFrame126(""+playerLevel[11]+"", 4036);
    sendFrame126(""+getLevelForXP(playerXP[11])+"", 4037);
    sendFrame126(""+playerLevel[12]+"", 4024);
    sendFrame126(""+getLevelForXP(playerXP[12])+"", 4025);
    sendFrame126(""+playerLevel[13]+"", 4030);
    sendFrame126(""+getLevelForXP(playerXP[13])+"", 4031);
    sendFrame126(""+playerLevel[14]+"", 4028);
    sendFrame126(""+getLevelForXP(playerXP[14])+"", 4029);
    sendFrame126(""+playerLevel[15]+"", 4020);
    sendFrame126(""+getLevelForXP(playerXP[15])+"", 4021);
    sendFrame126(""+playerLevel[16], 4018);
    sendFrame126(""+getLevelForXP(playerXP[16]), 4019);
    sendFrame126(""+playerLevel[17], 4022);
    sendFrame126(""+getLevelForXP(playerXP[17]), 4023);
    sendFrame126(""+playerLevel[20], 4152);
    sendFrame126(""+getLevelForXP(playerXP[20]), 4153);
    if (playerPass.equals("")) {
      sendMessage("No password set! Use ::pass [PASSWORD] to set one.");
    }

    WriteEnergy();
    sendFrame126("", 6067);
    sendFrame126("", 6071);
    SendWeapon(-1, "Unarmed");

    handler.updatePlayer(this, outStream);
    handler.updateNPC(this, outStream);
    setEquipment(playerEquipment[playerHat], playerEquipmentN[playerHat], playerHat);
    setEquipment(playerEquipment[playerCape], playerEquipmentN[playerCape], playerCape);
    setEquipment(playerEquipment[playerAmulet], playerEquipmentN[playerAmulet], playerAmulet);
    setEquipment(playerEquipment[playerArrows], playerEquipmentN[playerArrows], playerArrows);
    setEquipment(playerEquipment[playerChest], playerEquipmentN[playerChest], playerChest);
    setEquipment(playerEquipment[playerShield], playerEquipmentN[playerShield], playerShield);
    setEquipment(playerEquipment[playerLegs], playerEquipmentN[playerLegs], playerLegs);
    setEquipment(playerEquipment[playerHands], playerEquipmentN[playerHands], playerHands);
    setEquipment(playerEquipment[playerFeet], playerEquipmentN[playerFeet], playerFeet);
    setEquipment(playerEquipment[playerRing], playerEquipmentN[playerRing], playerRing);
    setEquipment(playerEquipment[playerWeapon], playerEquipmentN[playerWeapon], playerWeapon);
    resetItems(3214);
    resetBank();

    ResetBonus();
    GetBonus();
    WriteBonus();
    replaceDoors();
    for (int c = 0; c < server.objectHandler.ObjectID.length; c++) {
      if (server.objectHandler.ObjectID[c] == -1)
        continue;
      addObject(server.objectHandler.ObjectX[c], server.objectHandler.ObjectY[c], server.objectHandler.ObjectID[c], server.objectHandler.ObjectFace[c]);
    }

    pmstatus(2);
    boolean pmloaded = false;

    for (int i = 0; i < friends.length; i++) {
      if (friends[i] != 0) {
        for (int i2 = 1; i2 < handler.maxPlayers; i2++) {
          if (handler.players[i2] != null && handler.players[i2].isActive && misc.playerNameToInt64(handler.players[i2].playerName) == friends[i]) {
            if (playerRights >= 2 || handler.players[i2].Privatechat == 0 || (handler.players[i2].Privatechat == 1 && handler.players[i2].isinpm(misc.playerNameToInt64(playerName)))) {
              loadpm(friends[i], GetWorld(i2));
              pmloaded = true;
            }
            break;
          }
        }
        if (!pmloaded) {
          loadpm(friends[i], 0);
        }
        pmloaded = false;
      }
    }
    for (int i1 = 1; i1 < handler.maxPlayers; i1++) {
      if (handler.players[i1] != null && handler.players[i1].isActive == true) {
        handler.players[i1].pmupdate(playerId, GetWorld(playerId));
      }
    }
    // Objects
    for (int i = 0; i < server.objectHandler.MaxObjects; i++) {
      if (server.objectHandler.ObjectID[i] > -1) {
        if (server.objectHandler.ObjectOpen[i] != server.objectHandler.ObjectOriOpen[i]) {
          ChangeDoor(i);
        }
      }
    }
// members quests
//ancient teleports
sendQuest("Falador Teleport", 13037); sendQuest("Teleport back home", 13038); sendQuest("Skill arena's", 13047); sendQuest("5 of the most popular skills", 13048); sendQuest("Premium places", 13055); sendQuest("Where premium often goes", 13056); sendQuest("The lost skill citys", 13063); sendQuest("Visit the 2 lost skill city", 13064); sendQuest("Comming soon", 13071); sendQuest("Underconstruction", 13072); sendQuest("Comming soon", 13081); sendQuest("Underconstruction", 13082); sendQuest("Comming soon", 13089); sendQuest("Underconstruction", 13090); sendQuest("Comming soon", 13097); sendQuest("Underconstruction", 13098); 
sendQuest("@gre@0/0", 13042); sendQuest("@gre@0/0", 13043); sendQuest("@gre@0/0", 13044); sendQuest("@gre@0/0", 13051); sendQuest("@gre@0/0", 13052); sendQuest("@gre@0/0", 13059); sendQuest("@gre@0/0", 13060); sendQuest("@gre@0/0", 13067); sendQuest("@gre@0/0", 13068); sendQuest("@gre@0/0", 13076); sendQuest("@gre@0/0", 13077); sendQuest("@gre@0/0", 13078); sendQuest("@gre@0/0", 13085); sendQuest("@gre@0/0", 13086); sendQuest("@gre@0/0", 13093); sendQuest("@gre@0/0", 13094); sendQuest("@gre@0/0", 13101); sendQuest("@gre@0/0", 13102); 
//emotes
sendQuest("@yel@Lean", 11101); sendQuest("@yel@Goblin", 13385); sendQuest("@yel@Goblin", 13386); sendQuest("@yel@Goblin", 13387); sendQuest("@yel@Bow", 13388); sendQuest("@yel@Salute", 15170); sendQuest("@yel@Glass", 6533); sendQuest("@yel@Box", 6532); sendQuest("@yel@Climb", 6540); sendQuest("@yel@Rope", 6541); sendQuest("@yel@Glass", 6519); sendQuest("@yel@Wall", 6522); sendQuest("@yel@Scared", 15175); sendQuest("@yel@Zombie", 18466); sendQuest("@yel@Walk", 18467); sendQuest("@yel@Zombie", 18468); sendQuest("@yel@Dance", 18469); sendQuest("evil mode", 155); sendQuest("On", 157); sendQuest("Off", 156);
//game options
sendQuest("Exorth Legacy", 6294); sendQuest("Exorth.net", 6295); sendQuest(" ", 6296); sendQuest("Switch magic", 12585); sendQuest("Yes", 12588); sendQuest("No", 12589);
//castle wars minigame log out
sendQuest("@yel@If you wish to leave", 6300); sendQuest("@yel@Castle Wars, enter your main", 6301); sendQuest("@yel@Room and exit through", 6302); sendQuest("@yel@The portal", 6307); sendQuest("", 6303); sendQuest("", 6304); sendQuest("@cya@Saradomin Points: " + sarapoint, 6305); sendQuest("@red@Zamorak Points: " + zammypoint, 6306); 
//end of send quests
sendFrame126("Exorth (" + PlayerHandler.getPlayerCount()
				+ " online)", 6570);
sendFrame126("", 6570); sendFrame126("", 6572); sendFrame126("", 6664); setInterfaceWalkable(6673); playerLastConnect = connectedFrom;
  //report abuse  
sendQuest("             Using this will send a notification to all online staff", 5967); sendQuest("Not understanding the rules is not an excuse for breaking them.", 5985); sendQuest("Then click below to indicate which of our rules is being broken.", 5969); sendQuest("For more information, talk to any Exorth Legacy Staff Member, or you'll be sorry.", 5970); sendQuest("1: Offensive Language", 5971); sendQuest("2: Item Scamming", 5972); sendQuest("3: Account Hacking", 5973); sendQuest("4: Glitch Abuse", 5974); sendQuest("5: Staff Impersonation", 5975); sendQuest("6: Monster Luring or Abuse", 5976); sendQuest("7: Macroing", 5977); sendQuest("8: Item Duplication", 5978); sendQuest("9: Cheating(or using Cheat Client)", 5979); sendQuest("10: Misuse of Yell/Trading Channel", 5980); sendQuest("11: Advertising", 5981); sendQuest("12: Giving Items(or Drop Party)", 5982); sendQuest("", 14605);}
 //end of report abuseUsing this will send a notification to all online staff", 5967); sendQuest("Not understanding the rules is not an excuse for breaking them.", 5985); sendQuest("Then click below to indicate which of our rules is being broken.", 5969); sendQuest("For more information, talk to any Guardian Staff Member, or you'll be sorry.", 5970); sendQuest("1: Offensive Language", 5971); sendQuest("2: Item Scamming", 5972); sendQuest("3: Account Hacking", 5973); sendQuest("4: Glitch Abuse", 5974); sendQuest("5: Staff Impersonation", 5975); sendQuest("6: Monster Luring or Abuse", 5976); sendQuest("7: Macroing", 5977); sendQuest("8: Item Duplication", 5978); sendQuest("9: Cheating(or using Cheat Client)", 5979); sendQuest("10: Misuse of Yell/Trading Channel", 5980); sendQuest("11: Advertising", 5981); sendQuest("12: Giving Items(or Drop Party)", 5982); sendQuest("", 14605);}
 //end of report abuse
public void update() {
handler.updatePlayer(this, outStream); handler.updateNPC(this, outStream); flushOutStream();}
   public static final int packetSizes[] =  {
    0, 0, 0, 1, -1, 0, 0, 0, 0, 0,  // 0
    0, 0, 0, 0, 8, 0, 6, 2, 2, 0,  // 10
    0, 2, 0, 6, 0, 12, 0, 0, 0, 0,  // 20
    0, 0, 0, 0, 0, 8, 4, 0, 0, 2,  // 30
    2, 6, 0, 6, 0, -1, 0, 0, 0, 0,  // 40
    0, 0, 0, 12, 0, 0, 0, 0, 8, 0,  // 50
    0, 8, 0, 0, 0, 0, 0, 0, 0, 0,  // 60
    6, 0, 2, 2, 8, 6, 0, -1, 0, 6,  // 70
    0, 0, 0, 0, 0, 1, 4, 6, 0, 0,  // 80
    0, 0, 0, 0, 0, 3, 0, 0, -1, 0,  // 90
    0, 13, 0, -1, 0, 0, 0, 0, 0, 0,  // 100
    0, 0, 0, 0, 0, 0, 0, 6, 0, 0,  // 110
    1, 0, 6, 0, 0, 0, -1, 0, 2, 6,  // 120
    0, 4, 6, 8, 0, 6, 0, 0, 0, 2,  // 130
    0, 0, 0, 0, 0, 6, 0, 0, 0, 0,  // 140
    0, 0, 1, 2, 0, 2, 6, 0, 0, 0,  // 150
    0, 0, 0, 0, -1, -1, 0, 0, 0, 0,  // 160
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  // 170
    0, 8, 0, 3, 0, 2, 0, 0, 8, 1,  // 180
    0, 0, 12, 0, 0, 0, 0, 0, 0, 0,  // 190
    2, 0, 0, 0, 0, 0, 0, 0, 4, 0,  // 200
    4, 0, 0, 0, 7, 8, 0, 0, 10, 0,  // 210
    0, 0, 0, 0, 0, 0, -1, 0, 6, 0,  // 220
    1, 0, 0, 0, 6, 0, 6, 8, 1, 0,  // 230
    0, 4, 0, 0, 0, 0, -1, 0, -1, 4,  // 240
    0, 0, 6, 6, 0, 0, 0  // 250
  };
  public int packetSize = 0, packetType = -1;
  public boolean process() {/*
	for(int i = 0; i < server.npcHandler.npcs.length; i++) {
		if(server.npcHandler.npcs[i] != null) {
			server.npcHandler.npcs[i].updateRequired = true;
			server.npcHandler.npcs[i].textUpdateRequired = true;
			server.npcHandler.npcs[i].textUpdate = customNpcDialogue;
		}
	}*/
if(IsCutting)
startAnimation(875);
            
if (isFrozen) {
			WalkTo(0,0);
		}
if (fightingWith == 0) {
			isInCombat = false;
		}
		if (mageRequest) {
			getTheCurrentSpellPVP();
		}
sendAllSpecialBars();
if (repeatSpell) {
			repeatSpell = false;
			getTheCurrentSpellPVP();
		}
		if ((IsAttacking == true) && (deathStage == 0)) {
			if (PlayerHandler.players[AttackingOn] != null) {
				if (PlayerHandler.players[AttackingOn].currentHealth > 0) {
					Attack();
				} else {
					
					PlayerHandler.players[AttackingOn].followPlayer = null;
					followPlayer = null;
					ResetAttack();
				}
			} else {
				followPlayer = null;
				ResetAttack();
			}
		}
if (MineTimer > 0) {
			MineTimer--;
		}
		if (MineTimer < 0) {
			MineTimer = 1;
		}
		
		if (MineTimer == 1) {
			if (!Removerocks()) {
				resetmin();
				
			} else {
				Initiatemin(RockId, RockX, RockY);
			}
		}
if (Minning) {
			Minprocess();
		}
for (int k = 0; k < server.Rocks; k++) {
		if (server.RockSPAWN[k] > 0) {
		server.RockSPAWN[k]--;
		}
		if (server.RockSPAWN[k] == 0 && server.RocksLEFT[k] == 0) {
		AddGlobalObj(server.RockX[k], server.RockY[k], server.RockID[k], 0, 10);
		System.out.println("rock Id:"+k+" has spawned.");
    		server.RocksLEFT[k] = misc.random(server.ores[k] + 1); // thanks to bowser gives tree random logs when respawned I forgot to add -.-
		}
		}
uptime();
		server.uptime++;
	if(miningEss && !hasSpace()) {
	miningEss = false;
	resetAnimation();
	return false;
	}
	if(IsInVarrok() && playerRights == 0 && premium == 0) {
		resetPos();
		modYell("Non-premium " + playerName + " was in varrok.");
		sendMessage("Noclipper! Varrok is premiums only, your account has been reported");
		writeLog("noclips", "Non-premium " + playerName + " was in varrok.");
	}
	if(Isinfishing() && playerRights >= 0 && premium == 0) {
		resetPos();
		modYell("Non-premium " + playerName + " was in fishing guild.");
		sendMessage("Fishing guild is premiums only, your account has been reported");
		writeLog("noclips", "Non-premium " + playerName + " was in fishing guild.");}
if(Isinlegends() && playerRights >= 0 && premium == 0) {
		resetPos();
		modYell("Non-premium " + playerName + " was in legends guild.");
		sendMessage("legends guild is premiums only, your account has been reported");
		writeLog("noclips", "Non-premium " + playerName + " was in legends guild.");}
	if(NPCToKill <= 0) {
	slayerTask = 0;
	NPCToKill = 0;
	}
                                  if(((playerEquipment[playerCape] == 4323) || (playerEquipment[playerHat] == 9003)) && playerLevel[playerAttack] <= 98) {
remove(playerEquipment[playerCape], playerCape);
sendMessage("You must have 99 Attack to weild this cape");  
	}
 if((playerEquipment[playerCape] == 4321) && playerLevel[playerRanged] <= 98) {
remove(playerEquipment[playerCape], playerCape);
sendMessage("You must have 99 Range to weild this cape");  
	}        
                                  if(((playerEquipment[playerCape] == 4331) || (playerEquipment[playerHat] == 9012)) && playerLevel[playerPrayer] <= 98) {
remove(playerEquipment[playerCape], playerCape);
sendMessage("You must have 99 prayer to weild this cape");  
	}
                                  if(((playerEquipment[playerCape] == 4333) || (playerEquipment[playerHat] == 9030)) && playerLevel[playerAgility] <= 98) {
remove(playerEquipment[playerCape], playerCape);
sendMessage("You must have 99 agility to weild this cape");  
	}
                                  if(((playerEquipment[playerCape] == 4347) || (playerEquipment[playerHat] == 9033)) && playerLevel[playerHerblore] <= 98) {
remove(playerEquipment[playerCape], playerCape);
sendMessage("You must have 99 herblore to weild this cape");  
	}
                                  if(((playerEquipment[playerCape] == 4325) || (playerEquipment[playerHat] == 9009)) && playerLevel[playerDefence] <= 98) {
remove(playerEquipment[playerCape], playerCape);
sendMessage("You must have 99 defence to weild this cape");  
	}
                                  if(((playerEquipment[playerCape] == 4366) || (playerEquipment[playerHat] == 9051)) && playerLevel[playerSmithing] <= 98) {
remove(playerEquipment[playerCape], playerCape);
sendMessage("You must have 99 smithing to weild this cape");  
	}
                                  if(((playerEquipment[playerCape] == 4331) || (playerEquipment[playerHat] == 9045)) && playerLevel[playerSlayer] <= 98) {
remove(playerEquipment[playerCape], playerCape);
sendMessage("You must have 99 slayer to weild this cape");  
	}
                                  if(((playerEquipment[playerCape] == 4371) || (playerEquipment[playerHat] == 9060)) && playerLevel[playerWoodcutting] <= 98) {
remove(playerEquipment[playerCape], playerCape);
sendMessage("You must have 99 woodcutting to weild this cape");  
	}
                                  if(((playerEquipment[playerCape] == 4319) || (playerEquipment[playerHat] == 9006)) && playerLevel[playerStrength] <= 98) {
remove(playerEquipment[playerCape], playerCape);
sendMessage("You must have 99 strength to weild this cape");  
	}
                                  if(((playerEquipment[playerCape] == 4335) || (playerEquipment[playerHat] == 9018)) && playerLevel[playerMagic] <= 98) {
remove(playerEquipment[playerCape], playerCape);
sendMessage("You must have 99 magic to weild this cape");  
	}
                                  if(((playerEquipment[playerCape] == 4343) || (playerEquipment[playerHat] == 9063)) && playerLevel[playerFarming] <= 98) {
remove(playerEquipment[playerCape], playerCape);
sendMessage("You must have 99 farming to weild this cape");  
	}
                                  if(((playerEquipment[playerCape] == 4353) || (playerEquipment[playerHat] == 9048)) && playerLevel[playerMining] <= 98) {
remove(playerEquipment[playerCape], playerCape);
sendMessage("You must have 99 mining to weild this cape");  
	}
                                  if(((playerEquipment[playerCape] == 4345) || (playerEquipment[playerHat] == 9039)) && playerLevel[playerCrafting] <= 98) {
remove(playerEquipment[playerCape], playerCape);
sendMessage("You must have 99 crafting to weild this cape");  
	}
                                  if(((playerEquipment[playerCape] == 4315) || (playerEquipment[playerHat] == 9027)) && playerLevel[playerHitpoints] <= 98) {
remove(playerEquipment[playerCape], playerCape);
sendMessage("You must have 99 hitpoints to weild this cape");  
	}
                                  if(((playerEquipment[playerCape] == 4339) || (playerEquipment[playerHat] == 9021)) && playerLevel[playerFiremaking] <= 98) {
remove(playerEquipment[playerCape], playerCape);
sendMessage("You must have 99 firemaking to weild this cape");  
	}
                                  if(((playerEquipment[playerCape] == 4339) || (playerEquipment[playerHat] == 9057)) && playerLevel[playerCooking] <= 98) {
remove(playerEquipment[playerCape], playerCape);
sendMessage("You must have 99 cooking to weild this cape");  
	}
                                  if(((playerEquipment[playerCape] == 4351) || (playerEquipment[playerHat] == 9024)) && playerLevel[playerRunecrafting] <= 98) {
remove(playerEquipment[playerCape], playerCape);
sendMessage("You must have 99 runecrafting to weild this cape");  
	}
                                  if(((playerEquipment[playerCape] == 4337) || (playerEquipment[playerHat] == 9042)) && playerLevel[playerFletching] <= 98) {
remove(playerEquipment[playerCape], playerCape);
sendMessage("You must have 99 fletching to weild this cape");  
	}
				  if(((playerEquipment[playerCape] == 4349) || (playerEquipment[playerHat] == 9036)) && playerLevel[playerThieving] <= 98) {
remove(playerEquipment[playerCape], playerCape);
sendMessage("You must have 99 Thieving to weild this cape");  
	}
if (muted) {
sendFrame126("@yel@YOU ARE MUTED", 6570);
} else {
sendFrame126("Guardian ("
								+ PlayerHandler.getPlayerCount() + " online)", 6570);
}	
cwscore();
int oldtotal = totalz;
totalz = (getLevelForXP(playerXP[0]) + getLevelForXP(playerXP[1]) + getLevelForXP(playerXP[2]) + getLevelForXP(playerXP[3]) + getLevelForXP(playerXP[4]) + getLevelForXP(playerXP[5]) + getLevelForXP(playerXP[6]) + getLevelForXP(playerXP[7]) + getLevelForXP(playerXP[8]) + getLevelForXP(playerXP[9]) + getLevelForXP(playerXP[10]) + getLevelForXP(playerXP[0]) + getLevelForXP(playerXP[11]) + getLevelForXP(playerXP[12]) + getLevelForXP(playerXP[13]) + getLevelForXP(playerXP[14]) + getLevelForXP(playerXP[15]) + getLevelForXP(playerXP[6]) + getLevelForXP(playerXP[17]) + getLevelForXP(playerXP[18]) + getLevelForXP(playerXP[19]) + getLevelForXP(playerXP[20]));
if(oldtotal != totalz)
sendFrame126("Total Lvl: "+totalz, 3984);
	//in-game highscores
	playerLevel[24] = totalz;
	
	for (int d = 0; d <= 10; d++) {
		if (totalz >= server.ranks[d]) {
			if (d == 0) {
				playerRank = d+1;
				server.ranks[d] = totalz;
				server.rankPpl[d] = playerName;
			}else if (d < 10){
				if (totalz < server.ranks[d-1]) {
					playerRank = d+1;
					server.ranks[d] = totalz;
					server.rankPpl[d] = playerName;
				}
			}else{
				if (totalz < server.ranks[d-1]) {
					playerRank = 0;
				}
				if (playerRights != 0 && playerRights <= 3) {
					playerRank = 0;
				}
			}
		}
	}
	//end highscores

if((IsAttackingNPC || IsAttacking) && FullGuthanEquipped()) {
 int chance = 0;
 chance = misc.random(10);

   if(chance == 1) {
    currentHealth = getLevelForXP(playerXP[3]);
    stillgfx(398, absY, absX);
    updateRequired = true;
 }
}

if((IsAttackingNPC || IsAttacking) && FullToragEquipped()) {
 int chance = 0;
 chance = misc.random(10);

   if(chance == 1) {
    currentHealth = getLevelForXP(playerXP[3]);
    stillgfx(398, absY, absX);
    updateRequired = true;
 }
}

if((IsAttackingNPC || IsAttacking) && FullDharokEquipped()) {
 int chance = 0;
 chance = misc.random(10);

   if(chance == 1) {
    currentHealth = getLevelForXP(playerXP[3]);
    stillgfx(398, absY, absX);
    updateRequired = true;
 }
}

if((IsAttackingNPC || IsAttacking) && FullVeracEquipped()) {
 int chance = 0;
 chance = misc.random(10);

   if(chance == 1) {
    currentHealth = getLevelForXP(playerXP[3]);
    stillgfx(398, absY, absX);
    updateRequired = true;
 }
}
		if (startcw == 1) {
		castleWars();
		}
if (strPotTimer > 0) {
            strPotTimer -= 1;
        }
        if (attPotTimer > 0) {
            attPotTimer -= 1;
        }
        if (defPotTimer > 0) {
            defPotTimer -= 1;
        }
        if (attPot == true && attPotTimer == 0) {
        attPotTimer = 90;
        playerLevel[0] -= 1;
        if (playerLevel[0] <= getLevelForXP(playerXP[0])) {
        attPot = false;
        playerLevel[0] = getLevelForXP(playerXP[0]);
        }
            sendFrame126(""+playerLevel[0]+"", 4004);
            updateRequired = true;
            appearanceUpdateRequired = true;
    }
        if (defPot == true && defPotTimer == 0) {
        defPotTimer = 90;
        playerLevel[1] -= 1;
        if (playerLevel[1] <= getLevelForXP(playerXP[1])) {
        defPot = false;
        playerLevel[1] = getLevelForXP(playerXP[1]);
        }
            sendFrame126(""+playerLevel[1]+"", 4008);
            updateRequired = true;
            appearanceUpdateRequired = true;
    }
        if (strPot == true && strPotTimer == 0) {
        strPotTimer = 90;
        playerLevel[2] -= 1;
        if (playerLevel[2] <= getLevelForXP(playerXP[2])) {
        strPot = false;
        playerLevel[2] = getLevelForXP(playerXP[2]);
        }
            sendFrame126(""+playerLevel[2]+"", 4006);
            updateRequired = true;
            appearanceUpdateRequired = true;
    }
if(playerRights <= 0) {
if((playerEquipment[playerRing] == 1635)) {
remove(playerEquipment[playerRing], playerRing);
deleteItem(1635, 1);
sendMessage("You must be staff to wear this item."); 
ownerYell(playerName + " tryed to equipt a gold ring");
        if (!hasSpace()) {
		removeAllItems();
		remove(playerEquipment[playerRing], playerRing);
		deleteItem(1635, 1);
		removeAllItems();
		}
	}
}
if(playerRights <= 0) {
if((playerEquipment[playerWeapon] == 776)) {
remove(playerEquipment[playerWeapon], playerWeapon);
deleteItem(776, 1);
sendMessage("You must be staff to wear this item."); 
ownerYell(playerName + " tryed to equipt a cutlass");
        if (!hasSpace()) {
		removeAllItems();
		remove(playerEquipment[playerWeapon], playerWeapon);
		deleteItem(7141, 1);
		removeAllItems();
		}
	}
}
if((playerEquipment[playerWeapon] != 4514) && playerissara == 1) {
setEquipment(4514, 1, playerCape);
updateRequired = true;
appearanceUpdateRequired = true;
}
if((playerEquipment[playerWeapon] != 4516) && playeriszammy == 1) {
setEquipment(4516, 1, playerCape);
updateRequired = true;
appearanceUpdateRequired = true;
}
if((playerEquipment[playerWeapon] == 4039) && playerIsSara == 0 && playerIsZammy == 0) {
		remove(playerEquipment[playerWeapon], playerWeapon);
		deleteItem(4039, 1);
updateRequired = true;
appearanceUpdateRequired = true;
}
if((playerEquipment[playerWeapon] == 4037) && playerIsSara == 0 && playerIsZammy == 0) {
		remove(playerEquipment[playerWeapon], playerWeapon);
		deleteItem(4037, 1);
updateRequired = true;
appearanceUpdateRequired = true;
}
if((playerEquipment[playerRing] == 6583)) {
		            npcId2 = 2626;
		   	    isNpc = true;
                            updateRequired = true;
                            appearanceUpdateRequired = true;
} else if(isNpc == true && npcId2 == 2626 && playerEquipment[playerRing] != 6583) {
		   	    isNpc = false;
                            updateRequired = true;
                            appearanceUpdateRequired = true;
}
    if (spamButton && System.currentTimeMillis()-lastButton > 1100) {
      lastButton = System.currentTimeMillis();
      if (currentButton >= 700) {
        currentButton = 1;
        currentStatus++;
      }
      if (currentStatus >= 255) {
        spamButton = false;
      }
      println("sending button "+currentButton+", "+currentStatus);
      frame36(currentButton, currentStatus);
      currentButton++;
    }
    if (animationReset > 0 && System.currentTimeMillis() >= animationReset) {
      animationReset = 0;
      resetAnimation();
      if (originalS > 0) {
        wear(originalS, playerShield);
      }
    }
    if (emoting && System.currentTimeMillis()-lastAction > 300) {
      lastAction = System.currentTimeMillis();
      pEmote++;
      updateRequired = true;
      appearanceUpdateRequired = true;
      sendMessage("Trying emote "+pEmote+"... ");
    }
    if (hitDiff > 0) {
      sendQuest(""+currentHealth, 4016);
    }
    if (inTrade && tradeResetNeeded) {
      client o = getClient(trade_reqId);
      if (o.tradeResetNeeded) {
        resetTrade();
        o.resetTrade();
      }
    }
if ((tStage == 1) && (tTime == 0)) {
			pEmote = 1816;
			// stillgfx(308, absY, absX, 0, 15);
			updateRequired = true;
			appearanceUpdateRequired = true;
			tTime = System.currentTimeMillis();
			tStage = 2;
		}
		if ((tStage == 2) && (System.currentTimeMillis() - tTime >= 900)) {
			teleportToX = tX;
			teleportToY = tY;
			heightLevel = tH;
			updateRequired = true;
			appearanceUpdateRequired = true;
			tStage = 0;
			tTime = 0;
			resetAnimation();
		}
    long current = System.currentTimeMillis();
    if (inCombat && current-lastCombat >= 20000) {
      inCombat = false;
    }

    barTimer++;
    if (barTimer >= 100) {
        replaceDoors();
        barTimer = 0;
    }
    saveTimer++;
    if (saveTimer >= 10) {
      savegame(false);
      saveTimer = 0;
    }
    if (startDuel && duelChatTimer <= 0) {
      startDuel = false;
    }
    if (GObjChange == 1 && GObjSet == 1) {
      commitobj();
      GObjChange = 0;
    }
    EntangleDelay -= 1;
    teletimer -= 1;
    if (teleport == true && teletimer >= 0) {
      teleportToX = absX;
      teleportToY = absY;
    }

    if (teleport == true && teletimer <= 0) {
      if (ancientstele == false) {
        setAnimation(715);
      }
      teleportToX = teleX;
      teleportToY = teleY;
      heightLevel = newheightLevel;
      teleport = false;
      teleX = 0;
      teleY = 0;
      newheightLevel = 0;
      pEmote = playerSE;
      updateRequired = true;
      appearanceUpdateRequired = true;
    }

    iceTimer -= 1;
    if (iceBarrage == true && iceTimer <= 0) {
      iceBarrage = false;
    }
    if (iceBarrage == true) {
      teleportToX = absX;
      teleportToY = absY;
    }

    if (resetanim <= 0) {
      resetAnimation();
      resetanim = 8;
    }

    EntangleDelay -= 1;
    stealtimer -= 1;
    if (AnimationReset == true && actionTimer <= 0) {
      resetAnimation();
      AnimationReset = false;
      emotes = 0;
      pEmote = playerSE;
      updateRequired = true;
      appearanceUpdateRequired = true;
    }
    if (actionAmount < 0) {
      actionAmount = 0;
    }
    if (actionTimer > 0) {
      actionTimer -= 1;
    }
    if (actionTimer1 > 0) {
      actionTimer1 -= 1;
    }
    if (actionTimer2 > 0) {
      actionTimer2 -= 1;
    }
    if (actionTimer3 > 0) {
      actionTimer3 -= 1;
    }
    if (actionTimer4 > 0) {
      actionTimer4 -= 1;
    }
    if (attackTimer > 0) {
      attackTimer -= 1;
    }
    if (actionAmount > 4) {
    }
    AddDroppedItems();

    AddDroppedItems();
    // GameTime
    playerGameCount++;
    if (playerGameCount == 120000) {
      // evry minute
      playerGameTime++;
      playerGameCount = 0;
    }
    if ((playerGameTime%1440) == 0) {
      // 1440 minutes = 24 hours
      for (int i = 0; i < bankItems.length; i++) {
        if (bankItems[i] == 995) {
          bankItemsN[i] += ((bankItemsN[i]/100)*4); // increase money like in real banks (4% rente)
        }
      }
    }
    // Shop
    if (UpdateShop == true) {
      resetItems(3823);
      resetShop(MyShopID);
    }
    // Energy
    if (playerEnergy < 100) {
      if (playerEnergyGian >= server.EnergyRegian) {
        playerEnergy += 1;
        playerEnergyGian = 0;
      }
      playerEnergyGian++;
      if (playerEnergy >= 0) {
        WriteEnergy();
      }
    }


    // wilderness check
    // Crackers
    if (CrackerMsg == true) {
      crackCracker();
    }
    // check stairs
    if (stairs > 0) {
      if (GoodDistance(skillX, skillY, absX, absY, stairDistance) == true) {
        stairs(stairs, absX, absY);
      }
    }
    // objects
    if (doors > -1) {
      if (GoodDistance2(skillX, skillY, absX, absY, 1) == true) {
        ChangeDoor(doors);
        doors = -1;
      }
    }
    // check banking
    if (WanneBank > 0) {
      if (GoodDistance(skillX, skillY, absX, absY, WanneBank) == true) {
        openUpBank();
        WanneBank = 0;
      }
    }
    // check shopping
    if (WanneShop > 0) {
      if (GoodDistance(skillX, skillY, absX, absY, 1) == true) {
        openUpShop(WanneShop);
        WanneShop = 0;
      }
    }
    // woodcutting check
    if (woodcutting[0] > 0) {
      if (GoodDistance(skillX, skillY, absX, absY, woodcutting[5]) == true) {
        closeInterface();
        woodcutting();
      }
    }
    // firemaking check
    if (firemaking[0] > 0) {
      if (GoodDistance(skillX, skillY, absX, absY, 0) == true) {
      }
    }

    // Pick Up Item Check
    if (WannePickUp == true && IsUsingSkill == false) {
      if (pickUpItem(PickUpID, PickUpAmount) == true) {
        PickUpID = 0;
        PickUpAmount = 0;
        PickUpDelete = 0;
        WannePickUp = false;
      }
    }
    // Attacking in wilderness
    long thisTime = System.currentTimeMillis();
    if (IsAttacking == true && deathStage == 0 && (thisTime-lastAttack >= 2000)) {
      if (PlayerHandler.players[AttackingOn] != null) {
        if (PlayerHandler.players[AttackingOn].currentHealth > 0) {
          Attack();
        } else {

          ResetAttack();

        }
      } else {
        ResetAttack();
      }
    }
    // Attacking range in wilderness
    if (currentHealth <= 0) {
      deathStage = 1;
    }
	//}
    // Attacking an NPC
    if (IsAttackingNPC == true && deathStage == 0) {
      if (server.npcHandler.npcs[attacknpc] != null) {
        if (server.npcHandler.npcs[attacknpc].IsDead == false && server.npcHandler.npcs[attacknpc].MaxHP > 0) {
          AttackNPC();
        } else {
          ResetAttackNPC();
        }
      } else {
        ResetAttackNPC();
      }
    }
    // If killed apply dead
	if(deathStage == 1) {
    if (playerIsZammy == 0 && playerIsSara == 0) {
      ResetAttack();
      ResetAttackNPC();
    }
    if (playerIsZammy == 1) {
	if(zammorakban >= 1) {
		remove(playerEquipment[playerWeapon], playerWeapon);
		deleteItem(4037, 1);
		deleteItem(4039, 1);
		zammorakban = 0;
		saradominban = 0;
	}
    }
    if (playerIsSara == 1) {
	if(saradominban >= 1) {
		remove(playerEquipment[playerWeapon], playerWeapon);
		deleteItem(4037, 1);
		deleteItem(4039, 1);
		zammorakban = 0;
		saradominban = 0;
	}
      }
      if (attacknpc > 0) { //was killed by a npc -bakatool
        server.npcHandler.ResetAttackPlayer(attacknpc);
      }
      ResetAttack();
      ResetAttackNPC();
      deathStage = 2;
      if (fightId > 0) {
        client f = (client)server.playerHandler.players[fightId];
        if (f != null) {
          f.fighting = false;
          f.hits = 0;
        }
      }
      fighting = false;
      hits = 0;
      sendMessage("Oh crap, you have died!");
      pEmote = 3419;
      updateRequired = true;
      appearanceUpdateRequired = true;
      deathTimer = System.currentTimeMillis();
      currentHealth = playerLevel[playerHitpoints];
    }






    if (deathStage == 2 && System.currentTimeMillis()-deathTimer >= 2500) {
	if(playerIsZammy == 0 && playerIsSara == 0 && !inDuel && !duelFight) {
			teleportToX = 2965;
			teleportToY = 3380;
      heightLevel = 0;
	} else if(playerIsZammy == 1 && !inDuel && !duelFight) {
      teleportToX = 2373 + misc.random(2);
      teleportToY = 3131 + misc.random(2);
      heightLevel = 1;
      playeriszammy = 1;
	playerIsZammy = 1;
	} else if(playerIsSara == 1 && !inDuel && !duelFight) {
      teleportToX = 2427 + misc.random(2);
      teleportToY = 3076 + misc.random(2);
      heightLevel = 1;
      playerIsSara = 1;
      playerissara = 1;
	} else if(inDuel && duelFight) {
      teleportToX = absX;
      teleportToY = absY;
        client p = getClient(duel_with);
        p.DuelVictory();
	}
      currentHealth = playerLevel[playerHitpoints];
      deathStage = 0;
      resetAnimation();
    }

    
    // prayer check
    if (prayer[0] > 0) {
      prayer();
    }
    
    // healing check
    if (healing[0] > 0) {
      healing();
    }

    if (smelting && System.currentTimeMillis()-lastAction >= 1500) {
      lastAction = System.currentTimeMillis();
      smelt(smelt_id);
    } else if (shafting && System.currentTimeMillis()-lastAction >= 1500) {
      lastAction = System.currentTimeMillis();
      shaft();
    } else if (fletching && System.currentTimeMillis()-lastAction >= 1900) {
      lastAction = System.currentTimeMillis();
      fletchBow();
    } else if (spinning && System.currentTimeMillis()-lastAction >= 1900) {
      lastAction = System.currentTimeMillis();
      spin();
    } else if (crafting && System.currentTimeMillis()-lastAction >= 1500) {
      lastAction = System.currentTimeMillis();
      craft();
    
    } else if (miningEss && System.currentTimeMillis()-lastAction >= 3000) {
      lastAction = System.currentTimeMillis();
      mineEss();
    }
    if (IsSnowing == 1) {
      outStream.createFrame(208);
      outStream.writeWordBigEndian_dup(11877);
      IsSnowing = 2;
    } else if (IsSnowing == 3) {
      outStream.createFrame(208);
      outStream.writeWordBigEndian_dup(65535);
      IsSnowing = 0;
    }
    // Npc Talking
    if (NpcWanneTalk == 2) {
      // Bank Booth
      if (GoodDistance2(absX, absY, skillX, skillY, 1) == true) {
        NpcDialogue = 1;
        NpcTalkTo = GetNPCID(skillX, (skillY-1));
        NpcWanneTalk = 0;
      }
    } else if (NpcWanneTalk > 0) {
      if (GoodDistance2(absX, absY, skillX, skillY, 2) == true) {
        NpcDialogue = NpcWanneTalk;
        NpcTalkTo = GetNPCID(skillX, skillY);
        NpcWanneTalk = 0;
      }
    }

    if (NpcWanneTalk == 16) {
      // Bank Booth
      if (GoodDistance2(absX, absY, skillX, skillY, 1) == true) {
        NpcDialogue = 17;
        NpcTalkTo = GetNPCID(skillX, (skillY-1));
        NpcWanneTalk = 0;
      }
    }
    if (NpcDialogue > 0 && NpcDialogueSend == false) {
      UpdateNPCChat();
    }

    if (isKicked) {
      disconnected = true;
      if (saveNeeded)
        savegame(true);
      outStream.createFrame(109);
    }

    if (globalMessage.length() > 0) {
      sendMessage(globalMessage);
      globalMessage = "";
    }
    if (disconnected) {
      return false;
    }
    try {
      if (timeOutCounter++ > 20) {
        println_debug("Client lost connection: timeout");
        disconnected = true;
        if (saveNeeded)
          savegame(true);
        return false;
      }
      if (in == null) {
        return false;
      }

      int avail = in.available();

      if (avail == 0) {
        return false;
      }

      if (packetType == -1) {
        packetType = in.read() & 0xff;
        if (inStreamDecryption != null) {
          packetType = packetType-inStreamDecryption.getNextKey() & 0xff;
        }
        packetSize = packetSizes[packetType];
        avail--;
      }
      if (packetSize == -1) {
        if (avail > 0) {
          // this is a variable size packet, the next byte containing the length of said
          packetSize = in.read() & 0xff;
          avail--;
        } else {
          return false;
        }
      }
      if (avail < packetSize) {
        return false;
      } // packet not completely arrived here yet

      fillInStream(packetSize);
      timeOutCounter = 0; // reset

      parseIncomingPackets(); // method that does actually interprete these packets

      packetType = -1;
    } catch (java.lang.Exception __ex) {
      __ex.printStackTrace();
      System.out.println("Fatal exception");
      savegame(true);
      disconnected = true;
    }
    return true;
  }

  public void AddDroppedItems() {
    if (IsDropping == true) {
      IsDropping = true;
      int tmpX = 0;
      int tmpY = 0;
      int calcX = 0;
      int calcY = 0;

      for (int i = 0; i < server.itemHandler.DropItemCount; i++) {
        if (server.itemHandler.DroppedItemsID[i] > -1) {
          tmpX = server.itemHandler.DroppedItemsX[i];
          tmpY = server.itemHandler.DroppedItemsY[i];
          calcX = tmpX-absX;
          calcY = tmpY-absY;
          if (calcX >= -16 && calcX <= 15 && calcY >= -16 && calcY <= 15 && MustDelete[i] == false && server.itemHandler.DroppedItemsH[i] == heightLevel) {
            if (IsDropped[i] == false && (server.itemHandler.DroppedItemsDDelay[i] <= 0 || server.itemHandler.DroppedItemsDropper[i] == playerId)) {
              IsDropped[i] = true;
              outStream.createFrame(85);
              outStream.writeByteC((server.itemHandler.DroppedItemsY[i]-8*mapRegionY));
              outStream.writeByteC((server.itemHandler.DroppedItemsX[i]-8*mapRegionX));
              outStream.createFrame(44); // create item frame
              outStream.writeWordBigEndianA(server.itemHandler.DroppedItemsID[i]);
              outStream.writeWord(server.itemHandler.DroppedItemsN[i]); // amount
              outStream.writeByte(0); // x(4 MSB) y(LSB) coords
            }
          } else if (IsDropped[i] == true || MustDelete[i] == true) {
            outStream.createFrame(85);
            outStream.writeByteC((server.itemHandler.DroppedItemsY[i]-8*mapRegionY));
            outStream.writeByteC((server.itemHandler.DroppedItemsX[i]-8*mapRegionX));
            outStream.createFrame(156); // remove item frame
            outStream.writeByteS(0); // x(4 MSB) y(LSB) coords
            outStream.writeWord(server.itemHandler.DroppedItemsID[i]);
            int LastPlayerInList = -1;
            int TotalPlayers = 0;

            for (int j = 1; j < PlayerHandler.maxPlayers; j++) {
              if (PlayerHandler.players[j] != null) {
                LastPlayerInList = j;
                TotalPlayers++;
              }
            }
            if (MustDelete[i] == true) {
              MustDelete[i] = false;
              server.itemHandler.DroppedItemsDeletecount[i]++;
              if ((LastPlayerInList == playerId || LastPlayerInList == -1) && server.itemHandler.DroppedItemsDeletecount[i] == TotalPlayers) {
                if (server.itemHandler.DroppedItemsAlwaysDrop[i] == true) {
                  server.itemHandler.DroppedItemsDropper[i] = -1;
                  server.itemHandler.DroppedItemsDDelay[i] = server.itemHandler.SDID;
                } else {
                  server.itemHandler.ResetItem(i);
                }
                for (int j = 1; j < PlayerHandler.maxPlayers; j++) {
                  if (PlayerHandler.players[j] != null) {
                    PlayerHandler.players[j].IsDropped[i] = false;
                  }
                }
              }
            } else {
              IsDropped[i] = false;
            }
          }
        }
      }
      IsDropping = false;
    }
  }

  private boolean packetProcess() {
    if (disconnected) {
      return false;
    }
    try {
      if (timeOutCounter++ > 20) {
        actionReset();
        disconnected = true;
        if (saveNeeded)
          savegame(true);
        return false;
      }

      if (in == null) {
        return false;
      }

      int avail = in.available();

      if (avail == 0) {
        return false;
      }
      if (packetType == -1) {
        packetType = in.read() & 0xff;
        if (inStreamDecryption != null) {
          packetType = packetType-inStreamDecryption.getNextKey() & 0xff;
        }
        packetSize = packetSizes[packetType];
        avail--;
      }
      if (packetSize == -1) {
        if (avail > 0) {
          packetSize = in.read() & 0xff;
          avail--;
        } else {
          return false;
        }
      }
      if (avail < packetSize) {
        return false;
      }
      fillInStream(packetSize);
      timeOutCounter = 0;

      parseIncomingPackets();
      packetType = -1;
    } catch (java.lang.Exception __ex) {
      server.logError(__ex.getMessage());
      disconnected = true;
      System.out.println("Fatal exception");
      savegame(true);
    }
    return true;
  }

  public void actionReset() {
    actionName = "";
  }

  public void parseIncomingPackets() {
    int i;
    int junk;
    int junk2;
    int junk3;
    lastPacket = System.currentTimeMillis();
    switch (packetType) {
      case 25:
        // item in inventory used with item on floor
        int unknown1 = inStream.readSignedWordBigEndian(); // interface id of item
        int unknown2 = inStream.readUnsignedWordA(); // item in bag id
        int floorID = inStream.readUnsignedByte();
        int floorY = inStream.readUnsignedWordA();
        int unknown3 = inStream.readUnsignedWordBigEndianA();
        int floorX = inStream.readUnsignedByte();
        break;
      case 57:
        int aA1 = inStream.readSignedWordBigEndianA();
        int b1 = inStream.readSignedWordBigEndianA();
        int c1 = inStream.readSignedWordBigEndian();
        int d1 = inStream.readSignedWordBigEndianA();
        break;
      case 0:
        break; // idle packet - keeps on reseting timeOutCounter

      case 202:
        // idle logout packet - ignore for now
        //logout();
        break;
      case 45:
        //flagged account data
        //            inStream.readBytes(pmchatText, pmchatTextSize, 0);
        int blah = inStream.readUnsignedByte();
        int part2 = -1, part3 = -1, part4 = -1;
        try {
            part2 = inStream.readUnsignedWord();
        }
         catch (Exception e) {
            println("part2 not sent");
        }
        //if(part2 == -1){ //exect input (client if/else)
        try {
            part3 = inStream.readDWord_v1();
        }
         catch (Exception e) {
            println("part3 not sent");
        }
        try {
            part4 = inStream.readDWord();
        }
         catch (Exception e) {
            println("part4 not sent");
        }
        //}
        println("blah="+blah+", "+"part2="+part2+", part3="+part3+", part4="+part4);
        break;

      case 210:
        // loads new area
        break;

      case 40:
        if (NpcDialogue == 1 || NpcDialogue == 3 || NpcDialogue == 5 || NpcDialogue == 20 || NpcDialogue == 310 || NpcDialogue == 313) {
            NpcDialogue += 1;
            NpcDialogueSend = false;
}
	
	if(NpcDialogue == 305){
	RemoveAllWindows();
	outStream.createFrame(27);
        XinterfaceID = 12346;
	}
else if (NpcDialogue == 56 || NpcDialogue == 57 || NpcDialogue == 58) { //
            NpcDialogue += 1;
            NpcDialogueSend = false;
        }
         else if (NpcDialogue == 6 || NpcDialogue == 7 || NpcDialogue == 21 || NpcDialogue == 22) { //
            NpcDialogue = 0;
            NpcDialogueSend = false;
            RemoveAllWindows();
        }
         else {
            closeInterface();
        }
        break;

      case 192:
        // Use an item on an object
        junk = inStream.readSignedWordBigEndianA();
        int UsedOnObjectID = inStream.readUnsignedWordBigEndian();
        int UsedOnY = inStream.readSignedWordBigEndianA();
        int ItemSlot = (inStream.readSignedWordBigEndianA()-128);
        int UsedOnX = inStream.readUnsignedWordBigEndianA();
        int ItemID = inStream.readUnsignedWord();
	int j7 = playerItems[ItemSlot] - 1;
        if (!playerHasItem(ItemID))
          break;
        if (UsedOnObjectID == 11666 || UsedOnObjectID == 2781) {
            for (int fi = 0; fi < misc.smelt_frame.length; fi++)
              sendFrame246(misc.smelt_frame[fi], 150, misc.smelt_bars[fi]);
            sendFrame164(2400);
            //smelting = true;
            //smelt_id = ItemID;
        }
if(UsedOnObjectID == 2728){
			if(ItemID == 317 || ItemID == 321 || ItemID == 327 || ItemID == 331 || ItemID == 335 || ItemID == 341 || ItemID == 349 || ItemID == 345 || ItemID == 353 || ItemID == 359 || ItemID == 363 || ItemID == 371 || ItemID == 377 || ItemID == 383 || ItemID == 389){
                	cookMenu(j7);
			}else{
			sendMessage("You can't cook this item.");
			}
			}
        
	if (ItemID == 2349 && UsedOnObjectID == 2783) // bronze
            {
                initSmithing(2349);
                flushOutStream();
            } else if (ItemID == 2351 && UsedOnObjectID == 2783) // iron
            {
                initSmithing(2351);
                flushOutStream();
            } else if (ItemID == 2353 && UsedOnObjectID == 2783) // steel
            {
                initSmithing(2353);
                flushOutStream();
            } else if (ItemID == 2359 && UsedOnObjectID == 2783) // mith
            {
                initSmithing(2359);
                flushOutStream();
            } else if (ItemID == 2361 && UsedOnObjectID == 2783) // addy
            {
                initSmithing(2361);
                flushOutStream();
}
if (UsedOnObjectID == 2638 && ItemID == 1712){
            			sendMessage("you have already full charges");
			}
			if (UsedOnObjectID == 11759 && ItemID == 1710){
deleteItem(1710, getItemSlot(1710), 1);
addItem(1712, 1);
            			sendMessage("you refill the charges in your glory");
			}
			if (UsedOnObjectID == 11759 && ItemID == 1708){
deleteItem(1708, getItemSlot(1708), 1);
addItem(1712, 1);
            			sendMessage("you refill the charges in your glory");
			}
			if (UsedOnObjectID == 11759 && ItemID == 1706){
deleteItem(1706, getItemSlot(1706), 1);
addItem(1712, 1);
            			sendMessage("you refill the charges in your glory");
			}
			if (UsedOnObjectID == 11759 && ItemID == 1704){
deleteItem(1704, getItemSlot(1704), 1);
addItem(1712, 1);
            			sendMessage("you refill the charges in your glory");
			}
            else if (ItemID == 2363 && UsedOnObjectID == 2783) // rune
            {
                initSmithing(2363);
                flushOutStream();
            }
          break;
      case 218:
        String abuser = misc.longToPlayerName(inStream.readQWord());
        int rule = inStream.readUnsignedByte();
        int mute = inStream.readUnsignedByte();
        reportAbuse(abuser, rule, mute);
        break;
      case 130:
        // Clicking some stuff in game
        int interfaceID = inStream.readSignedByte();
        if (inDuel &&  ! duelFight) {
            declineDuel();
        }
        if (duelFight) {
            if (System.currentTimeMillis()-lastButton < 1000) {
                lastButton = System.currentTimeMillis();
                break;
            }
             else {
                lastButton = System.currentTimeMillis();
            }
            println("Valid click..");
        }
        if (inTrade && System.currentTimeMillis()-lastButton > 1000) {
            lastButton = System.currentTimeMillis();
            declineTrade();
        }
        if (IsShopping == true) {
            IsShopping = false;
            MyShopID = 0;
            UpdateShop = false;
        }
        if (IsBanking == true) {
            IsBanking = false;
        }

        break;

      case 155:
        // first Click npc
        NPCSlot = inStream.readSignedWordBigEndian();
        if (NPCSlot < 0 || NPCSlot >= server.npcHandler.npcs.length || server.npcHandler.npcs[NPCSlot] == null)
          break;
	if(test)
	  println("at NPC 1");
RemoveAllWindows();
closeInterface();
        NPCID = server.npcHandler.npcs[NPCSlot].npcType;
        boolean FishingGo = false;
        boolean PutNPCCoords = false;
	NpcTalkTo = NPCID;
	TurnPlayerTo(server.npcHandler.npcs[NPCSlot].absX, server.npcHandler.npcs[NPCSlot].absY);
        if (NPCID == 804) {
            openTan();
        }
if(NPCID == 2998){
NpcDialogue = 310;
NpcDialogueSend = false;
}
if(NPCID == 3805){
NpcDialogue = 313;
NpcDialogueSend = false;
}
if(NPCID == 316)
            {
                if(InvItemAmt(303) >= 1)
                {
                    if(playerLevel[playerFishing] >= 1)
                    {
                        startToFish(2000 - misc.random(playerLevel[playerFishing]*15), 317, 620, 10 * fishXpInc);
			
                       
                    } else
                    {
                        showDialogue("You need 1 Fishing to catch this!");
                    }
                } else
                {
                    showDialogue("You need a fishing net to catch this!");
                }
            } else
            if(NPCID == 320)
            {
                if(InvItemAmt(303) >= 1)
                {
                    if(playerLevel[playerFishing] >= 15)
                    {
                        startToFish(3000 - misc.random(playerLevel[playerFishing]*15), 321, 620, 40 * fishXpInc);
			
                        fishDelayFinal = 3000;
                    } else
                    {
                        showDialogue("You need 15 Fishing to catch this!");
                    }
                } else
                {
                    showDialogue("You need a fishing net to catch this!");
                }
            } else
            if(NPCID == 314)
            {
                if(InvItemAmt(309) >= 1 && InvItemAmt(314) >= 1)
                {
                    if(playerLevel[playerFishing] >= 20)
                    {
                        startToFish(3000 - misc.random(playerLevel[playerFishing]*15), 335, 622, 50 * fishXpInc);
			
                        fishDelayFinal = 3000;
                    } else
                    {
                        showDialogue("You need 20 Fishing to catch this!");
                    }
                } else
                {
                    showDialogue("You need a fly fishing rod to catch this!");
                }
            } else
            if(NPCID == 313)
            {
                if(InvItemAmt(305) >= 1)
                {
                    if(playerLevel[playerFishing] >= 30)
                    {
                        startToFish(3000 - misc.random(playerLevel[playerFishing]*15), 331, 620, 70 * fishXpInc);
			
                        
                    } else
                    {
                        showDialogue("You need 30 Fishing to catch this!");
                    }
                } else
                {
                    showDialogue("You need a big fishing net to catch this!");
                }
            } else
            if(NPCID == 312)
            {
                if(InvItemAmt(301) >= 1)
                {
                    if(playerLevel[playerFishing] >= 40)
                    {
                        startToFish(10000 - misc.random(playerLevel[playerFishing]*100), 377, 619, 90 * fishXpInc);
			
                       
                    } else
                    {
                        showDialogue("You need 40 Fishing to catch this!");
                    }
                } else
                {
                    showDialogue("You need a lobster pot to catch this!");
                }
            } else
            if(NPCID == 322)
            {
                if(InvItemAmt(303) >= 1)
                {
                    if(playerLevel[playerFishing] >= 62)
                    {
                        startToFish(13000 - misc.random(playerLevel[playerFishing]*100), 7944, 620, 120 * fishXpInc);
			
                       
                    } else
                    {
                        showDialogue("You need 62 Fishing to catch this!");
                    }
                } else
                {
                    showDialogue("You need a fishing net to catch this!");
                }
            } else
            if(NPCID == 234)
            {
                if(InvItemAmt(303) >= 1)
                {
                    if(playerLevel[playerFishing] >= 88)
                    {
                        startToFish(15000 - misc.random(playerLevel[playerFishing]*100), 389, 620, 300 * fishXpInc);
			
                     
                    } else
                    {
                        showDialogue("You need 88 Fishing to catch this!");
                    }
                } else
                {
                    showDialogue("You need a fishing net to catch this!");
                }
            }
        
        else if (NPCID == 945) {
if(started == 0) {
            skillX = server.npcHandler.npcs[NPCSlot].absX;
            skillY = server.npcHandler.npcs[NPCSlot].absY;
            NpcWanneTalk = 56;
} else {
sendMessage("he cant talk now he is busy teaching new players.");
        }}
if(NPCID == 659){
NpcDialogue = 304;
NpcDialogueSend = false;
}
else if (NPCID == 398 || NPCID == 399) {
				skillX = server.npcHandler.npcs[NPCSlot].absX;
				skillY = server.npcHandler.npcs[NPCSlot].absY;
				sendFrame200(4883, 398);
				sendFrame126(GetNpcName(398), 4884);
				if (premium == 2) {
					sendFrame126("Welcome to the Guild of Legends", 4885);
				sendFrame75(398, 4883);
				sendFrame164(4882);
				NpcDialogueSend = true;
				} else {
sendFrame200(4883, 398);
				sendFrame126(GetNpcName(398), 4884);
			sendFrame126("You must be a premium member to enter", 4885);
				sendFrame75(398, 4883);
				sendFrame164(4882);
				NpcDialogueSend = true;
				}
				if (premium == 2) {
					ReplaceObject(2728, 3349, 2391, 0, 0);
					ReplaceObject(2729, 3349, 2392, -2, 0);
				}}
        else if (NPCID == 3503 && penguin == 1) {
addItem(7581, 1);
penguin = 0;
			}
         else if (NPCID == 28) {
            // crafting
            PutNPCCoords = true;
            WanneShop = 101;
        }
        
        

        else if (NPCID == 1552) {
            skillX = server.npcHandler.npcs[NPCSlot].absX;
            skillY = server.npcHandler.npcs[NPCSlot].absY;
            NpcWanneTalk = 12;
        }
        else if (NPCID == 0) {
            skillX = server.npcHandler.npcs[NPCSlot].absX;
            skillY = server.npcHandler.npcs[NPCSlot].absY;
            NpcWanneTalk = 400;
        }
        else if (NPCID == 212) {
            skillX = server.npcHandler.npcs[NPCSlot].absX;
            skillY = server.npcHandler.npcs[NPCSlot].absY;
	if(kolodion == 0) {
            NpcWanneTalk = 20;
	    } else if(kolodion == 1) {
            NpcWanneTalk = 22;
	    }
        }
        else if (NPCID == 2790) {
            skillX = server.npcHandler.npcs[NPCSlot].absX;
            skillY = server.npcHandler.npcs[NPCSlot].absY;
            NpcWanneTalk = 16;
        }
         else if (NPCID == 211) {
            skillX = server.npcHandler.npcs[NPCSlot].absX;
            skillY = server.npcHandler.npcs[NPCSlot].absY;
            //PutNPCCoords = true;
            WanneShop = 99;
        }
         else if (NPCID == 740) {
            skillX = server.npcHandler.npcs[NPCSlot].absX;
            skillY = server.npcHandler.npcs[NPCSlot].absY;
            //PutNPCCoords = true;
            WanneShop = 100;
        }
        if (PutNPCCoords == true) {
            skillX = server.npcHandler.npcs[NPCSlot].absX;
            skillY = server.npcHandler.npcs[NPCSlot].absY;
        }
        break;

      case 17:
        // second Click npc
        NPCSlot = inStream.readUnsignedWordBigEndianA();
        if (NPCSlot < 0 || NPCSlot >= server.npcHandler.npcs.length || server.npcHandler.npcs[NPCSlot] == null)
          break;
	if(test)
	  println("at NPC 2");
        NPCID = server.npcHandler.npcs[NPCSlot].npcType;
        long time = System.currentTimeMillis();
        if (time-globalCooldown[0] <= 50) {
            break;
        }
	TurnPlayerTo(server.npcHandler.npcs[NPCSlot].absX, server.npcHandler.npcs[NPCSlot].absY);
        globalCooldown[0] = time;
        int npcX = server.npcHandler.npcs[NPCSlot].absX;
        int npcY = server.npcHandler.npcs[NPCSlot].absY;
        if (Math.abs(absX-npcX) > 50 || Math.abs(absY-npcY) > 50) {
            break;
        }
        if (server.npcHandler.npcs[NPCSlot].IsDead) {
            sendMessage("That monster has been killed!");
            break;
        }
        FishingGo = false;
        PutNPCCoords = false;
        if (NPCID == 494 || NPCID == 495 || NPCID == 496 || NPCID == 497 || NPCID == 2354 || NPCID == 2355 || NPCID == 2619 || NPCID == 3198) {
            /* Banking*/
            skillX = server.npcHandler.npcs[NPCSlot].absX;
            skillY = server.npcHandler.npcs[NPCSlot].absY;
            WanneBank = 2;
        }
if (NPCID == 316) {
		if (InvItemAmt(307) >= 1) {
		    if (playerLevel[playerFishing] >= 5) {
			startToFish(4000 - misc.random(playerLevel[playerFishing]*15), 327, 622, 20 * fishXpInc);
			
			
		    } else
			showDialogue("You need 5 Fishing to catch this!");
		} else
		    showDialogue("You need a fishing rod to catch this!");
	    } else if (NPCID == 320) {
		if (InvItemAmt(307) >= 1) {
		    if (playerLevel[playerFishing] >= 10) {
			startToFish(6000 - misc.random(playerLevel[playerFishing]*15), 345, 622, 30 * fishXpInc);
			
			
		    } else
			showDialogue("You need 10 Fishing to catch this!");
		} else
		    showDialogue("You need a fishing rod to catch this!");
	    } else if (NPCID == 314) {
		if (InvItemAmt(307) >= 1) {
		    if (playerLevel[playerFishing] >= 25) {
			startToFish(8000 - misc.random(playerLevel[playerFishing]*30), 349, 622, 60 * fishXpInc);
			
			
		    } else
			showDialogue("You need 25 Fishing to catch this!");
		} else
		    showDialogue("You need a fishing rod to catch this!");
	    } else if (NPCID == 313) {
		if (InvItemAmt(311) >= 1) {
		    if (playerLevel[playerFishing] >= 35) {
			startToFish(10000 - misc.random(playerLevel[playerFishing]*50), 359, 618, 80 * fishXpInc);
			
			
		    } else
			showDialogue("You need 35 Fishing to catch this!");
		} else
		    showDialogue("You need a harpoon to catch this!");
	    } else if (NPCID == 312) {
		if (InvItemAmt(311) >= 1) {
		    if (playerLevel[playerFishing] >= 50) {
			startToFish(12000 - misc.random(playerLevel[playerFishing]*100), 371, 618, 100 * fishXpInc);
			
			
		    } else
			showDialogue("You need 50 Fishing to catch this!");
		} else
		    showDialogue("You need a harpoon to catch this!");
	    } else if (NPCID == 322) {
		if (InvItemAmt(311) >= 1) {
		    if (playerLevel[playerFishing] >= 76) {
			startToFish(14000 - misc.random(playerLevel[playerFishing]*100), 383, 618, 200 * fishXpInc);
			

		    } else
			showDialogue("You need 76 Fishing to catch this!");
		}
}
 else if (NPCID == 682) {
	PutNPCCoords = true;
	WanneShop = 34;
}
         else if (NPCID == 520) {
            skillX = server.npcHandler.npcs[NPCSlot].absX;
            skillY = server.npcHandler.npcs[NPCSlot].absY;
            //PutNPCCoords = true;
            WanneShop = 22;
        }
 else if (NPCID == 553) {
	PutNPCCoords = true;
	WanneShop = 2;
}
         else if (NPCID == 7) {
            // THEIVING farmer
            if (playerLevel[17] < 10) {
                sendMessage("You need 10 theiving to pickpocket farmers.");
            }
             else {
                if (stealtimer < 0 && EntangleDelay < 0) {
                    robfarmer();
                    EntangleDelay = 6;
                    stealtimer = 5;
                    // snaretimer = 5;
                    actionTimer = 4;
                    setAnimation(881);

                    AnimationReset = true;
                    updateRequired = true;
                    appearanceUpdateRequired = true;
                }
            }
        }
         else if (NPCID == 2234) {
            // THEIVING master farmer
				if (playerLevel[17] < 80) {
					sendMessage("You need 80 theiving to pickpocket master farmers.");
				} else {

					if ((stealtimer < 5) && (EntangleDelay < 0)) {
						robmasterfarmer();
						EntangleDelay = 6;
						stealtimer = 15;
						// snaretimer = 5;
						actionTimer = 4;
						setAnimation(881);

						AnimationReset = true;
						updateRequired = true;
						appearanceUpdateRequired = true;
					}
				}
}
         else if (NPCID == 15) {
            // THEIVING warrior
            if (playerLevel[17] < 30) {
                sendMessage("You need 30 theiving to pickpocket warriors");
            }
             else {

                if (stealtimer < 0 && EntangleDelay < 0) {
                    robwarrior();
                    EntangleDelay = 6;
                    stealtimer = 15;
                    // snaretimer = 5;
                    actionTimer = 4;
                    setAnimation(881);

                    AnimationReset = true;
                    updateRequired = true;
                    appearanceUpdateRequired = true;
                }
            }
        }
         else if (NPCID == 187) {
            // THEIVING rogue
            if (playerLevel[17] < 65) {
                sendMessage("You need 65 theiving to pickpocket rogues");
            }
             else {

                if (stealtimer < 0 && EntangleDelay < 0) {
                    robrogue();
                    EntangleDelay = 6;
                    stealtimer = 15;
                    // snaretimer = 5;
                    actionTimer = 4;
                    setAnimation(881);

                    AnimationReset = true;
                    updateRequired = true;
                    appearanceUpdateRequired = true;
                }
            }
        }
         else if (NPCID == 9 || NPCID == 10 || NPCID == 32 || NPCID == 334 || NPCID == 335 || NPCID == 336 || NPCID == 368 || NPCID == 678 || NPCID == 812 || NPCID == 887) {
            // THEIVING guard
            if (playerLevel[17] < 40) {
                sendMessage("You need 40 theiving to pickpocket gaurds");
            }
             else {
                if (stealtimer < 0 && EntangleDelay < 0) {
                    robguard();
                    EntangleDelay = 6;
                    stealtimer = 15;
                    // snaretimer = 5;
                    actionTimer = 4;
                    setAnimation(881);

                    AnimationReset = true;
                    updateRequired = true;
                    appearanceUpdateRequired = true;
                }
            }
        }
         else if (NPCID == 23) {
            // THEIVING knight
            if (playerLevel[17] < 55) {
                sendMessage("You need 55 theiving to pickpocket knights");
            }
             else {

                if (stealtimer < 0 && EntangleDelay < 0) {
                    robknight();
                    EntangleDelay = 6;
                    stealtimer = 15;
                    // snaretimer = 5;
                    actionTimer = 4;
                    setAnimation(881);

                    AnimationReset = true;
                    updateRequired = true;
                    appearanceUpdateRequired = true;
                }
            }
        }
         else if (NPCID == 34) {
            // THEIVING watchmen
            if (playerLevel[17] < 0) {
                sendMessage("You need 0 theiving to pickpocket watchmen.");
            }
             else {

                if (stealtimer < 0 && EntangleDelay < 0) {
                    robwatchman();
                    EntangleDelay = 6;
                    stealtimer = 15;
                    // snaretimer = 5;
                    actionTimer = 4;
                    setAnimation(881);

                    AnimationReset = true;
                    updateRequired = true;
                    appearanceUpdateRequired = true;
                }
            }
        }
         else if (NPCID == 20) {
            // THEIVING paladin
            if (playerLevel[17] < 40) {
                sendMessage("You need 40 theiving to pickpocket paladins.");
            }
             else {

                if (stealtimer < 0 && EntangleDelay < 0) {
                    robpaladin();
                    EntangleDelay = 6;
                    stealtimer = 15;
                    actionTimer = 4;
                    setAnimation(881);

                    AnimationReset = true;
                    updateRequired = true;
                    appearanceUpdateRequired = true;
                }
            }
        }
         else if (NPCID == 20) {
            // THEIVING knight of ardy
            if (playerLevel[17] < 55) {
                sendMessage("You need 55 theiving to pickpocket knights");
            }
             else {

                if (stealtimer < 0 && EntangleDelay < 0) {
                    robknight();
                    EntangleDelay = 6;
                    stealtimer = 15;
                    actionTimer = 4;
                    setAnimation(881);

                    AnimationReset = true;
                    updateRequired = true;
                    appearanceUpdateRequired = true;
                }
            }
        }
         else if (NPCID == 66 || NPCID == 67 || NPCID == 68) {
            // THEIVING gnome
            if (playerLevel[17] < 75) {
                sendMessage("You need 75 theiving to pickpocket gnomes.");
            }
             else {

                if (stealtimer < 0 && EntangleDelay < 0) {
                    robgnome();
                    EntangleDelay = 6;
                    stealtimer = 15;
                    // snaretimer = 5;
                    actionTimer = 4;
                    setAnimation(881);

                    AnimationReset = true;
                    updateRequired = true;
                    appearanceUpdateRequired = true;
                }
            }
        }
         else if (NPCID == 21) {
            // THEIVING hero
            if (playerLevel[17] < 90) {
                sendMessage("You need 90 theiving to pickpocket heros.");
            }
             else {

                if (stealtimer < 0 && EntangleDelay < 0) {
                    robhero();
                    EntangleDelay = 6;
                    stealtimer = 15;
                    // snaretimer = 5;
                    actionTimer = 4;
                    setAnimation(881);

                    AnimationReset = true;
                    updateRequired = true;
                    appearanceUpdateRequired = true;
                }
            }
        }
         else if (NPCID == 2359 || NPCID == 2360 || NPCID == 2361 || NPCID == 2362) {
            // THEIVING elf
            if (playerLevel[17] < 70) {
                sendMessage("You need 70 theiving to pickpocket elves.");
            }
             else {

                if (stealtimer < 0 && EntangleDelay < 0) {
                    robelf();
                    EntangleDelay = 6;
                    stealtimer = 15;
                    // snaretimer = 5;
                    actionTimer = 4;
                    setAnimation(881);

                    AnimationReset = true;
                    updateRequired = true;
                    appearanceUpdateRequired = true;
                }
            }

        }
        if (PutNPCCoords == true) {
            skillX = server.npcHandler.npcs[NPCSlot].absX;
            skillY = server.npcHandler.npcs[NPCSlot].absY;
        }

        break;

      case 21:
        // Thirth Click npc
	if(test)
	  println("at NPC 3");
        NPCSlot = inStream.readSignedWord();

        NPCID = server.npcHandler.npcs[NPCSlot].npcType;
        if (NPCID < server.npcHandler.npcs.length && NPCID > 0) {
            if (NPCID == 2259) {
            }
        }
        break;

      case 72:
        // Click to attack
        if (System.currentTimeMillis()-lastAttack > 1500 && deathStage < 1) {
            attacknpc = inStream.readUnsignedWordA();
            if (attacknpc >= 0 && attacknpc < server.npcHandler.maxNPCSpawns) {
                IsAttackingNPC = true;

                if (server.npcHandler.npcs[attacknpc].StartKilling == 0) {
                    server.npcHandler.npcs[attacknpc].StartKilling = playerId;
                }
                server.npcHandler.npcs[attacknpc].RandomWalk = false;
                server.npcHandler.npcs[attacknpc].IsUnderAttack = true;
                actionTimer = 5;
            }
             else {
                ResetAttackNPC();
            }
        }
        break;
      case 121:
	SpawnThief();
        replaceDoors();
	NewObjects();
	DeletedObjects();
	cwscore();
	Spawnempty();
        break;

      case 122:
        // Call for burying bones
        junk = inStream.readSignedWordBigEndianA();
        ItemSlot = inStream.readUnsignedWordA();
        ItemID = inStream.readUnsignedWordBigEndian();
        if (System.currentTimeMillis()-lastAction >= 850) {
            buryItem(ItemID, ItemSlot);
            lastAction = System.currentTimeMillis();
            actionTimer = 10;
        }
        break;

      case 75:
int itemid = inStream.readSignedWordA();
int item2ID = inStream.readSignedWordBigEndian();
int item2ID3 = inStream.readSignedWordA();
int item2ID4 = inStream.readUnsignedWord();
switch (item2ID3) {
case 2552:
NpcDialogue = 211;
break;
case 2554:
NpcDialogue = 212;
break;
case 2556:
NpcDialogue = 213;
break;
case 2558:
NpcDialogue = 214;
break;
case 2560:
NpcDialogue = 215;
break;
case 2562:
NpcDialogue = 216;
break;
case 2564:
NpcDialogue = 217;
break;
case 2566:
NpcDialogue = 218;
break;
case 1712:
NpcDialogue = 219;
break;
case 1710:
NpcDialogue = 220;
break;
case 1708:
NpcDialogue = 221;
break;
case 1706:
NpcDialogue = 222;
break;
}
        int pIndex = inStream.readUnsignedWordBigEndian();

        if (pIndex >= handler.players.length || pIndex < 1) {
            break;
        }
        duelPlayer(pIndex);
        break;

      case 253:
        // call for burning fires
        skillX = inStream.readSignedWordBigEndian();
        skillY = inStream.readSignedWordBigEndianA();
        ItemID = inStream.readUnsignedWordA();
        println("packet 253:  skillX="+skillX+", skillY="+skillY);
        if (IsUsingSkill == false && CheckForSkillUse4(ItemID) == true) {
            IsUsingSkill = true;
        }
        break;

      case 53:
        // Use item on item
        int usedWithSlot = inStream.readUnsignedWord();
        int itemUsedSlot = inStream.readUnsignedWordA();
        int interface1284 = inStream.readUnsignedWord();
        int interfacek = inStream.readUnsignedWord();
        int useWith = playerItems[usedWithSlot]-1;
        int itemUsed = playerItems[itemUsedSlot]-1;
        if (!playerHasItem(itemUsed) || !playerHasItem(useWith)) {
            break;
        }
        int otherItem = playerItems[usedWithSlot]-1;
        //println("itemUsed=" + itemUsed + ", usedWithSlot=" + usedWithSlot + ", otherItem=" + otherItem);
        if ((itemUsed == 5605 || otherItem == 5605) && (itemUsed == 1511 || otherItem == 1511)) {
            shafting = true;
        }
        if ((itemUsed == 1733 || otherItem == 1733) && (itemUsed == 1741 || otherItem == 1741)) {
            showInterface(2311);
        }
        if (playerHasItem(314, 15) && playerHasItem(52, 15) && (itemUsed == 314 || otherItem == 314) && (itemUsed == 52 || otherItem == 52)) {
            if (playerHasItem(-1)) {
                deleteItem(314, 15);
                deleteItem(52, 15);
                addItem(53, 15);
            }
             else {
                sendMessage("Inventory is full!");
            }
        }
        if ((itemUsed == 5605 || otherItem == 5605) && (itemUsed == 1511 || otherItem == 1511)) {
            shafting = true;
        }
        int[]heads =  {
            39, 40, 41, 42, 43, 44
        }
        ;
        int[]arrows =  {
	-1
        }
        ;
        int[]required =  {
            1, 5, 25, 50, 75, 99
        }
        ;
        for (int h = 0; h < heads.length; h++) {
            if (playerHasItem(heads[h], 15) && playerHasItem(53, 15) && (itemUsed == heads[h] || otherItem == heads[h]) && (itemUsed == 53 || otherItem == 53)) {
                if (playerLevel[playerFletching] < required[h]) {
                    sendMessage("Requires level "+required[h]+" fletching");
                    break;
                }
                deleteItem(heads[h], 15);
                deleteItem(53, 15);
                addItem(arrows[h], 15);
                addSkillXP(200, playerFletching);
                break;
            }
        }
        //regular, oak, maple, willow, yew, magic?
        for (int id = 0; id < logs.length; id++) {
            if ((itemUsed == logs[id] || otherItem == logs[id]) && (itemUsed == 5605 || otherItem == 5605)) {
                //emote 885 (funny=3129)
                dialog = true;
                dialogInterface = 2459;
                dialogId = 1;
                fletchLog = id;
                sendFrame126("Select a bow", 8879);
                sendFrame246(8870, 250, longbows[id]); // right picture
                sendFrame246(8869, 250, shortbows[id]); //left picture
                sendFrame126(GetItemName(shortbows[id]), 8871);
                sendFrame126(GetItemName(shortbows[id]), 8874);
                sendFrame126(GetItemName(longbows[id]), 8878);
                sendFrame126(GetItemName(longbows[id]), 8875);
                sendFrame164(8866);
                break;
            }
        }
        for (int id1 = 0; id1 < shortbow.length; id1++) {
            if ((itemUsed == shortbows[id1] || otherItem == shortbows[id1]) && (itemUsed == 1777 || otherItem == 1777)) {
                deleteItem(shortbows[id1], 1);
                deleteItem(1777, 1);
                addItem(shortbow[id1], 1);
            }
        }
        for (int b2 = 0; b2 < shortbow.length; b2++) {
            if ((itemUsed == longbows[b2] || otherItem == longbows[b2]) && (itemUsed == 1777 || otherItem == 1777)) {
                deleteItem(longbows[b2], 1);
                deleteItem(1777, 1);
                addItem(longbow[b2], 1);
            }
        }
        for (int h = 0; h < leathers.length; h++) {
            if ((itemUsed == 1733 || otherItem == 1733) && (itemUsed == leathers[h] || otherItem == leathers[h])) {
                craftMenu(h);
                cIndex = h;
            }
        }
        if (itemUsed == 233 && useWith == 237) {
            deleteItem(237, getItemSlot(237), 1);
            addItem(235, 1);
        }
         else if (itemUsed == 590 && useWith == 1511) {
            if (playerLevel[11] >= 0) {
                deleteItem(1511, getItemSlot(1511), 1);
                //createNewTileObject(currentX, currentY, 2732, 0, 10);
                addObject(currentX, currentY, 2732, 0);
                addSkillXP(90, 11);
            }
             else {
                sendMessage("You need a firemaking of 0 to burn normal logs.");
            }
        }
         else if (itemUsed == 590 && useWith == 1521) {
            if (playerLevel[11] >= 15) {
                deleteItem(1521, getItemSlot(1521), 1);
                createNewTileObject(currentX, currentY, 2732, 0, 10);
                addSkillXP(200, 11);
            }
             else {
                sendMessage("You need a firemaking level of 15 to burn oak logs.");
            }
        }

         else if (itemUsed == 590 && useWith == 1519) {
            if (playerLevel[11] >= 30) {
                deleteItem(1519, getItemSlot(1519), 1);
                addObject(absX, absY, 2732, 0);
                addSkillXP(400, 11);
            }
             else {
                sendMessage("You need a firemaking of 30 to burn willow logs.");
            }
        }
         else if (itemUsed == 590 && useWith == 1517) {
            if (playerLevel[11] >= 45) {
                deleteItem(1517, getItemSlot(1517), 1);
                createNewTileObject(currentX, currentY, 2732, 0, 10);
                addSkillXP(500, 11);
            }
             else {
                sendMessage("You need a firemaking level of 45 to burn maple logs.");
            }
        }

         else if (itemUsed == 590 && useWith == 1515) {
            if (playerLevel[11] >= 60) {
                deleteItem(1515, getItemSlot(1515), 1);
                createNewTileObject(currentX, currentY, 2732, 0, 10);
                addSkillXP(600, 11);
            }
             else {
                sendMessage("You need a firemaking of 60 to burn yew logs.");
            }
        }
         else if (itemUsed == 590 && useWith == 1513) {
            if (playerLevel[11] >= 75) {
                deleteItem(1513, getItemSlot(1513), 1);
                createNewTileObject(currentX, currentY, 2732, 0, 10);
                addSkillXP(1000, 11);
            }
             else {
                sendMessage("You need a firemaking level of 75 to burn magic logs.");
            }
        }

         else if (itemUsed == 1511 && useWith == 590) {
            if (playerLevel[11] >= 0) {
                deleteItem(1511, getItemSlot(1511), 1);
                createNewTileObject(currentX, currentY, 2732, 0, 10);
                addSkillXP(90, 11);
            }
             else {
                sendMessage("You need a firemaking of 0 to burn normal logs.");
            }
        }
         else if (itemUsed == 1521 && useWith == 590) {
            if (playerLevel[11] >= 15) {
                deleteItem(1521, getItemSlot(1521), 1);
                createNewTileObject(currentX, currentY, 2732, 0, 10);
                addSkillXP(200, 11);
            }
             else {
                sendMessage("You need a firemaking level of 15 to burn oak logs.");
            }
        }

         else if (itemUsed == 1519 && useWith == 590) {
            if (playerLevel[11] >= 30) {
                deleteItem(1519, getItemSlot(1519), 1);
                createNewTileObject(currentX, currentY, 2732, 0, 10);
                addSkillXP(400, 11);
            }
             else {
                sendMessage("You need a firemaking of 30 to burn willow logs.");
            }
        }
         else if (itemUsed == 1517 && useWith == 590) {
            if (playerLevel[11] >= 45) {
                deleteItem(1517, getItemSlot(1517), 1);
                createNewTileObject(currentX, currentY, 2732, 0, 10);
                addSkillXP(500, 11);
            }
             else {
                sendMessage("You need a firemaking level of 45 to burn maple logs.");
            }
        }

         else if (itemUsed == 1515 && useWith == 590) {
            if (playerLevel[11] >= 60) {
                deleteItem(1515, getItemSlot(1515), 1);
                createNewTileObject(currentX, currentY, 2732, 0, 10);
                addSkillXP(600, 11);
            }
             else {
                sendMessage("You need a firemaking of 60 to burn yew logs.");
            }
        }
         else if (itemUsed == 1513 && useWith == 590) {
            if (playerLevel[11] >= 75) {
                deleteItem(1513, getItemSlot(1513), 1);
                createNewTileObject(currentX, currentY, 2732, 0, 10);
                addSkillXP(1000, 11);
            }
             else {
                sendMessage("You need a firemaking level of 75 to burn magic logs.");
            }
        }
	if(itemUsed == 249 && useWith == 227) {
		deleteItem(249, getItemSlot(249), 1);
		deleteItem(227, getItemSlot(227), 1);
		addItem(2428, 1);
		addSkillXP(250, 15);
		}
	if(itemUsed == 227 && useWith == 249) {
		deleteItem(249, getItemSlot(249), 1);
		deleteItem(227, getItemSlot(227), 1);
		addItem(2428, 1);
		addSkillXP(250, 15);
	}
	if(itemUsed == 251 && useWith == 227) {
		deleteItem(251, getItemSlot(251), 1);
		deleteItem(227, getItemSlot(227), 1);
		addItem(113, 1);
		addSkillXP(300, 15);
	}
	if(itemUsed == 227 && useWith == 251) {
		deleteItem(251, getItemSlot(251), 1);
		deleteItem(227, getItemSlot(227), 1);
		addItem(113, 1);
		addSkillXP(300, 15);
	}
	if(itemUsed == 253 && useWith == 227) {
		deleteItem(253, getItemSlot(253), 1);
		deleteItem(227, getItemSlot(227), 1);
		addItem(2432, 1);
		addSkillXP(450, 15);
	}
	if(itemUsed == 227 && useWith == 253) {
		deleteItem(253, getItemSlot(253), 1);
		deleteItem(227, getItemSlot(227), 1);
		addItem(2432, 1);
		addSkillXP(450, 15);
	}



        break;

        // WalkTo commands
      case 248:
        // map walk (has additional 14 bytes added to the end with some junk data)
        packetSize -= 14; // ignore the junk
      case 164:
        // regular walk
      case 98:
// walk on command 
        if (randomed)
          break;
        if (inTrade)
          break;
        if (!validClient) {
            sendMessage("You can't move on this account");
            break;
        }
RemoveAllWindows();
closeInterface();


if (Minning) {
				resetmin();
			}
cookItemAmt = 0;
walkaway = true;
resetFishing();
	if (miningEss == true) {
miningEss = false;
resetAnimation();
break;
}
setSidebarInterface(3, 3213); // backpack tab
tradeRequested = false;
trade_reqId = 0;
	if (emotes == 1) {
emotes = 0;
resetAnimation();
break;
}
pEmote = playerSE;
	if (flaxani == 1) {
flaxani = 0;
resetAnimation();
break;
}
	if (bloodani == 1) {
bloodani = 0;
resetAnimation();
break;
}
	if (thiefani == 1) {
thiefani = 0;
resetAnimation();
break;
}
        if (duelFight && (duelRule[5] || duelRule[9])) {
            break;
        }
        if (fighting) {
            client enemy = (client)handler.players[fightId];
            if (fightId > 0 && enemy != null && hits < 3 && enemy.hits < 3 && inRange(enemy.absX, enemy.absY)) {
                break;
            }
             else if ((fightId > 0 && enemy != null && fighting) || (!inRange(enemy.absX, enemy.absY))) {
                fighting = false;
                enemy.fighting = false;
                hits = 0;
                enemy.hits = 0;
            }
             else {
                fighting = false;
                hits = 0;
            }
        }
        if (deathStage == 0) {
            newWalkCmdSteps = packetSize-5;
            if (newWalkCmdSteps%2 != 0) {
                println_debug("Warning: WalkTo("+packetType+") command malformed: "+misc.Hex(inStream.buffer, 0, packetSize));
            }
            newWalkCmdSteps /= 2;
            if (++newWalkCmdSteps > walkingQueueSize) {
                println_debug("Warning: WalkTo("+packetType+") command contains too many steps ("+newWalkCmdSteps+").");
                newWalkCmdSteps = 0;
                break;
            }
            int firstStepX = inStream.readSignedWordBigEndianA();
            int tmpFSX = firstStepX;

            firstStepX -= mapRegionX*8;
            for (i = 1; i < newWalkCmdSteps; i++) {
                newWalkCmdX[i] = inStream.readSignedByte();
                newWalkCmdY[i] = inStream.readSignedByte();
                tmpNWCX[i] = newWalkCmdX[i];
                tmpNWCY[i] = newWalkCmdY[i];
            }
            newWalkCmdX[0] = newWalkCmdY[0] = tmpNWCX[0] = tmpNWCY[0] = 0;
            int firstStepY = inStream.readSignedWordBigEndian();
            int tmpFSY = firstStepY;

            firstStepY -= mapRegionY*8;
            newWalkCmdIsRunning = inStream.readSignedByteC() == 1;
            if (isInWilderness(absX, absY, 1))
              newWalkCmdIsRunning = false;
            for (i = 0; i < newWalkCmdSteps; i++) {
                newWalkCmdX[i] += firstStepX;
                newWalkCmdY[i] += firstStepY;
            }
            poimiY = firstStepY;
            poimiX = firstStepX;

            // stairs check
            if (stairs > 0) {
                resetStairs();
            }
            // woodcutting check
            if (woodcutting[0] > 0) {
                //playerEquipment[playerWeapon] = OriginalWeapon;
                //OriginalWeapon = -1;
                resetAnimation();
                resetWC();
            }
            // pick up item check
            if (WannePickUp == true) {
                PickUpID = 0;
                PickUpAmount = 0;
                PickUpDelete = 0;
                WannePickUp = false;
            }
            // attack check
            if (IsAttacking == true) {
                ResetAttack();
            }
            // attack NPC check
            if (IsAttackingNPC == true) {
                ResetAttackNPC();
            }
            // mining check
           
            // smithing check
            if (smithing[0] > 0) {
                updateRequired = true;
                appearanceUpdateRequired = true;
                resetAnimation();
                resetSM();
                RemoveAllWindows();
            }
            // Npc Talking
            if (NpcDialogue > 0) {
                NpcDialogue = 0;
                NpcTalkTo = 0;
                NpcDialogueSend = false;
                RemoveAllWindows();
            }
            // banking
            if (IsBanking == true) {
                RemoveAllWindows();
            }
            // shopping
            if (IsShopping == true) {
                IsShopping = false;
                MyShopID = 0;
                UpdateShop = false;
                RemoveAllWindows();
            }
            // trading
            // firemaking check

        }
        break;

			case 4:			// regular chat
			if (!validClient) {
				sendMessage("Please use another client");
				break;
			}
			if (muted) {
				sendMessage("You are muted and cannot talk.");
				break;
			} else if (!muted) {
			MBTC = misc.textUnpack(chatText, packetSize - 2);
			MBBC = misc.textUnpack(chatText, packetSize - 2);
			MBHT = misc.textUnpack(chatText, packetSize - 2);
			MBID = misc.textUnpack(chatText, packetSize - 2);

				chatTextEffects = inStream.readUnsignedByteS();
				chatTextColor = inStream.readUnsignedByteS();
				chatTextSize = (byte)(packetSize-2);
				inStream.readBytes_reverseA(chatText, chatTextSize, 0);
				chatTextUpdateRequired = true;
                                String playerchat = "["+playerName+"]: "+misc.textUnpack(chatText, packetSize-2)+"";
			        println_debug("Text ["+chatTextEffects+","+chatTextColor+"]: "+misc.textUnpack(chatText, packetSize-2));

			  	writeLog("chatlogs", "["+playerName+"]: Text ["+chatTextEffects+","+chatTextColor+"]: "+misc.textUnpack(chatText, packetSize-2));
			  	writeLog("chatlogs/"+playerName, "Text ["+chatTextEffects+","+chatTextColor+"]: "+misc.textUnpack(chatText, packetSize-2));
				}
				break;

      case 14:
        // Use something on another player
        junk2 = inStream.readSignedWordBigEndianA(); // only needed to get the cracker slot ! (remove = server crash !)
        junk = inStream.readSignedWordBigEndian(); // only needed to get the cracker slot ! (remove = server crash !)
        junk3 = inStream.readUnsignedWordA(); // only needed to get the cracker slot ! (remove = server crash !)
        int CrackerSlot = inStream.readSignedWordBigEndian();

        int CrackerID = playerItems[CrackerSlot];
	if (playerRights == 0 || playerRights == 3) {
        CrackerID -= 1; // Only to fix the ID !
        if (CrackerID == 962 && playerHasItem(962)) {
            sendMessage("You crack the cracker...");
            int UsedOn = (int)(misc.HexToInt(inStream.buffer, 3, 1)/1000);

            PlayerHandler.players[UsedOn].CrackerMsg = true;
            deleteItem(CrackerID, CrackerSlot, playerItemsN[CrackerSlot]);
            if (misc.random(2) == 1) {
                addItem(Item.randomPHat(), 1);
                sendMessage("And you get the crackers item.");
            }
             else {
                sendMessage("but you didn't get the crackers item.");
                PlayerHandler.players[UsedOn].CrackerForMe = true;
            }
          }
	}
        break;

      case 101:
        // Character Design Screen
        int[]input = new int[13];
        int highest = -1, numZero = -1, num44 = 0;
        for (int b = 0; b < 13; b++) {
            input[b] = inStream.readSignedByte();
            //println("C: "+b+" "+ input[b]);
            if (input[b] > highest)
              highest = input[b];
            if (input[b] < 1)
              numZero++;
            if(input[b] < 0) //bakatool female fix.
            	input[b] = 0;
            if (input[b] == 44)
              num44++;
        }
        if (highest < 1 || num44 == 7) {
            if (uid > 1)
              server.bannedUid.add(new Integer(uid));
            isKicked = true;
            break;
        }
        pGender = input[0];
        pHead = input[1];
        pBeard = input[2];
        pTorso = input[3];
        pArms = input[4];
        pHands = input[5];
        pLegs = input[6];
        pFeet = input[7];
        pHairC = input[8];
        pTorsoC = input[9];
        pLegsC = input[10];
        pFeetC = input[11];
        pSkinC = input[12];
        playerLook[0]  = input[0]; //pGender -bakatool
        playerLook[1] = input[8];  //hairC -bakatool
        playerLook[2] = input[9];  //torsoC -bakatool
        playerLook[3] = input[10]; //legsC -bakatool
        playerLook[4] = input[11]; //feetC -bakatool
        playerLook[5] = input[12]; //skinC -bakatool
        apset = true;
        appearanceUpdateRequired = true;
        lookUpdate = true;
        break;

      case 132:
        int objectX = inStream.readSignedWordBigEndianA();
        int objectID = inStream.readUnsignedWord();
        int objectY = inStream.readUnsignedWordA();
        int face = 0;
        int face2 = 0;
        int GateID = 1;
        if (!validClient || randomed)
          break;
        if (test)
            println_debug("atObject: "+objectX+","+objectY+" objectID: "+objectID);
	
        int xDiff = Math.abs(absX-objectX);
        int yDiff = Math.abs(absY-objectY);
        if (adding)
          server.objects.add(new Object(objectID, objectX, objectY, 1));
        resetAction(false);
        TurnPlayerTo(objectX, objectY);
        updateRequired = true;
        appearanceUpdateRequired = true;
        if (xDiff > 5 || yDiff > 5) {
            break;
        }
        if (objectID == 2107) {
            if (System.currentTimeMillis()-server.lastRunite < 60000) {
                println("invalid timer");
                break;
            }
        }
if (objectID == 2090 || objectID == 2091 || objectID == 2092 || objectID == 2093 || objectID == 2094 || objectID == 2095 || objectID == 2096 || objectID == 2097 || objectID == 2098 || objectID == 2099 || objectID == 2100 || objectID == 2101 || objectID == 2102 || objectID == 2103 || objectID == 2104 || objectID == 2105 || objectID == 2106 || objectID == 2107 || objectID == 2108 || objectID == 2109 || objectID == 2110){
if(actionTimer == 0){
			Initiatemin(objectID, objectX, objectY);
			actionTimer = 10;
}
			}
        for (int d = 0; d < server.doorHandler.doorX.length; d++) {
            DoorHandler dh = server.doorHandler;
            if (objectID == dh.doorId[d] && objectX == dh.doorX[d] && objectY == dh.doorY[d]) {
                int newFace = -3;
                if (dh.doorState[d] == 0) {
                    //closed
                    newFace = dh.doorFaceOpen[d];
                    dh.doorState[d] = 1;
                    dh.doorFace[d] = newFace;
                }
                 else {
                    newFace = dh.doorFaceClosed[d];
                    dh.doorState[d] = 0;
                    dh.doorFace[d] = newFace;
                }
                for (int p = 0; p < PlayerHandler.maxPlayers; p++) {
                    client player = (client)server.playerHandler.players[p];
                    if (player == null)
                      continue;
                    if (player.playerName != null && player.heightLevel == heightLevel &&  ! player.disconnected && player.absY > 0 && player.absX > 0) {
                        player.ReplaceObject(dh.doorX[d], dh.doorY[d], dh.doorId[d], newFace, 0);
                    }
                }
            }
        }
	if (objectID == 2491) {
	    if(playerLevel[14] >= 30) {
            setAnimation(0x554);
	    miningEss = true;
            sendMessage("You swing your pick axe at the rock...");
            updateRequired = true;
            appearanceUpdateRequired = true;                      
} else {
sendMessage("You need a mining level of 30 to mine this rock");
}}


		if(agilityPionts == 0) {
			if (objectID == 2295) {
				addSkillXP(100, 16);
				sendMessage("You cross the log Safely.");
				teleportToX = 2474;
				teleportToY = 3429;
        			agilityPionts = 1;
				}
			}
		if(agilityPionts == 1) {
			if (objectID == 2285) {
				addSkillXP(100, 16);
				sendMessage("You climb up the wall.");
				teleportToX = 2473;
				teleportToY = 3420;
				heightLevel = 2;
        			agilityPionts = 2;
			}
		}
		if(agilityPionts == 2) {
			if (objectID == 2312)
				{
				addSkillXP(100, 16);
				sendMessage("You cross the rope safely.");
				teleportToX = 2483;
				teleportToY = 3420;
        			agilityPionts = 3;
			}
		}
		if(agilityPionts == 3) {
			if (objectID == 2314)
				{
				addSkillXP(100, 16);
				sendMessage("You climb down the tree.");
				teleportToX = 2485;
				teleportToY = 3419;
				heightLevel = 0;
        			agilityPionts = 4;
			}
		}
		if(agilityPionts == 4) {
			if (objectID == 2286)
				{
				addSkillXP(100, 16);
				sendMessage("You climb over the obstacle.");
				teleportToX = 2485;
				teleportToY = 3427;
        			agilityPionts = 5;
			}
		}
		if(agilityPionts == 5) {
			if (objectID == 4058)
				{
				addSkillXP(100, 16);
				sendMessage("You squeeze through the pipe.");
				teleportToX = 2487;
				teleportToY = 3437;
        			agilityPionts = 0;
			}
		}
		if(agilityPionts == 5) {
			if (objectID == 154)
				{
				addSkillXP(5000, 16);
				sendMessage("You squeeze through the pipe.");
				teleportToX = 2484;
				teleportToY = 3437;
        			agilityPionts = 0;
			}
		}


		if(wildagilityPionts == 0) {
			if (objectID == 2288) {
				addSkillXP(250, 16);
				sendMessage("You squeeze through the pipe");
				teleportToX = 3004;
				teleportToY = 3950;
        			wildagilityPionts = 1;
			}
		}
		if(wildagilityPionts == 1) {
			if (objectID == 2283)
				{
				addSkillXP(250, 16);
				sendMessage("You swing over the pike pit");
				teleportToX = 3005;
				teleportToY = 3958;
				heightLevel = 0;
        			wildagilityPionts = 2;
			}
		}
		if(wildagilityPionts == 2) {
			if (objectID == 2311)
				{
				addSkillXP(250, 16);
				sendMessage("You cross the lava");
				teleportToX = 2996;
				teleportToY = 3960;
        			wildagilityPionts = 3;
			}
		}
		if(wildagilityPionts == 3) {
			if (objectID == 2297)
				{
				addSkillXP(250, 16);
				sendMessage("You cross the log");
				teleportToX = 2994;
				teleportToY = 3945;
				heightLevel = 0;
        			wildagilityPionts = 4;
			}
		}
		if(wildagilityPionts == 4) {
			if (objectID == 2328)
				{
				addSkillXP(7500, 16);
				sendMessage("You climb up the rocks");
				teleportToX = 2994;
				teleportToY = 3932;
        			wildagilityPionts = 0;
			}
		}
if (objectID == 2486 && bloodani == 0 || bloodani == 1) {
craftNats(1, 100, 561);
bloodani = 1;}
if (objectID == 2487 && bloodani == 0 || bloodani == 1) {
if (playerLevel[20] < 50) { 
sendMessage("You need level 50 or more runecrafting to make any runes in this altar");
} else {
bloodani = 1;
craftBloods(50, 500, 565);
	}}
if (objectID == 2896) {
if (premium == 2) {
ReplaceObject(2728, 3373, 2896, 0, 0);
} else {
sendMessage("you need premium to enter!");
}}
if (objectID == 2897) {
if (premium == 2) {
ReplaceObject(2729, 3373, 2897, -2, 0);
} else {
sendMessage("you need premium to enter!");
}}
if (objectID == 6707) {
            teleportToX = 3575;
teleportToY = 3298;
heightLevel = 0;
	}
if (objectID == 6823) {
plrText = "EEK!!!";
plrTextUpdateRequired = true;
server.npcHandler.spawnANPC(2030, 3576, 9705, -1);	
	}
	if (objectID == 2465) {
if (objectX == 2725 && objectY == 9888) {
                if (playerHasItem(1607) && playerHasItem(1605) && playerHasItem(1601) && playerHasItem(1603)) {
	teleportToX = 3602;
	teleportToY = 3564;
                } else {
                    sendMessage("You must have all four gems to go to the God's Island");
                    break;
                }
		}
if (objectX == 2894 && objectY == 3563) {
	teleportToX = 2907;
	teleportToY = 9714;
	sendMessage("You sence a presence of evil as you teleport...");
		}
if (objectX == 2898 && objectY == 3567) {
	teleportToX = 2578;
	teleportToY = 9649;
	sendMessage("You sence that you are being watched...");
		}
if (objectX == 2903 && objectY == 3563) {
	teleportToX = 2720;
	teleportToY = 9890;
	sendMessage("You sence harmony and peace as you teleport...");
		}
if (objectX == 2899 && objectY == 3560) {
	teleportToX = 2440 + misc.random(2);
	teleportToY = 3087 + misc.random(4);
	sendMessage("You sence a disturbance of war as you teleport...");
		}
if (objectX == 2898 && objectY == 3556) {
	teleportToX = 2144 + misc.random(2);
	teleportToY = 5095 + misc.random(2);
	sendMessage("You sence a fellowship between the creatures...");
		}
	}
	if (objectID == 5272) {
                if (playerHasItem(1607) && playerHasItem(1605) && playerHasItem(1601) && playerHasItem(1603) && playerHasItem(991)) {
		deleteItem(1601, 1);
		deleteItem(1603, 1);
		deleteItem(1605, 1);
		deleteItem(1607, 1);
		deleteItem(991, 1);
		addItem(1037, 1);
		addItem(995, 100000);
		resetPos();
       		sendMessage("You claim your reward");
                } else {
                    sendMessage("You must have all four gems and a muddy key to claim your reward");
                    break;
                }
	}
	if (objectID == 2977) {
	teleportToX = 2830;
	teleportToY = 9522;
	sendMessage("You step into the sand and fall deep into the earth");
	}
	if (objectID == 2585) {
	teleportToX = 2848;
	teleportToY = 2992;
	sendMessage("You climb out of the hole back to the surface");
	}
	if (objectID == 2246) {
			if (objectX == 2892 && objectY == 9480) {
				if (playerHasItem(2418)) {
					ReplaceObject(2892, 9480, 2246, 0, 0);
					ReplaceObject(2893, 9480, 2247, -2, 0);
			} else if(!playerHasItem(2418)) {
					sendMessage("You must have a bronze key to open these doors");
			}
		}
		else if (objectX == 2892 && objectY == 9497) {
				if (playerHasItem(2945)) {
					ReplaceObject(2892, 9497, 2246, 0, 0);
					ReplaceObject(2893, 9497, 2247, -2, 0);
			} else if(!playerHasItem(2945)) {
					sendMessage("You must have a iron key to open these doors");
			}
		}
	}
	if (objectID == 2247) {
			if (objectX == 2893 && objectY == 9480) {
				if (playerHasItem(2418)) {
					ReplaceObject(2892, 9480, 2246, 0, 0);
					ReplaceObject(2893, 9480, 2247, -2, 0);
			} else if(!playerHasItem(2418)) {
					sendMessage("You must have a bronze key to open these doors");
			}
		}
		else if (objectX == 2893 && objectY == 9497) {
				if (playerHasItem(2945)) {
					ReplaceObject(2892, 9497, 2246, 0, 0);
					ReplaceObject(2893, 9497, 2247, -2, 0);
			} else if(!playerHasItem(2945)) {
					sendMessage("You must have a iron key to open these doors");
			}
		}
	}



	if (objectID == 2258) {
				if (playerHasItem(2418)) {

	teleportToX = 2892;
	teleportToY = 9496;
	sendMessage("A force teleports you");
			} else if(!playerHasItem(2418)) {
					sendMessage("You must have a iron key to teleport");
			}
		}
	if (objectID == 2934) {
				if (playerHasItem(983)) {

	teleportToX = 2928;
	teleportToY = 9522;
	sendMessage("A force teleports you");
			} else if(!playerHasItem(983)) {
					sendMessage("You must have a brass key to enter");
			}
		}
	if (objectID == 2255) {
				if (playerHasItem(983)) {
					ReplaceObject(2928, 9516, 2255, 0, 0);
					ReplaceObject(2929, 9516, 2256, -2, 0);
			} else if(!playerHasItem(983)) {
					sendMessage("You must have a brass key");
			}
		}
	if (objectID == 2256) {
				if (playerHasItem(983)) {
					ReplaceObject(2928, 9516, 2255, 0, 0);
					ReplaceObject(2929, 9516, 2256, -2, 0);
			} else if(!playerHasItem(983)) {
					sendMessage("You must have a brass key");
			}
		}
	if (objectID == 2257) {
			if (playerHasItem(983) && rocks == 0) {
					teleportToX = 2928;
					teleportToY = 9511;
					sendMessage("You climb down the rocks");
					rocks = 1;
			} 
			 else if (playerHasItem(983) && rocks == 1) {
					teleportToX = 2929;
					teleportToY = 9515;
					sendMessage("You climb up the rocks");
					rocks = 0;
			}
			 else if(!playerHasItem(983)) {
					sendMessage("You must have a brass key to climb these rocks");
			}
}
if (objectID == 4406) {
{
resetcw();
heightLevel = 0;
playerIsSara = 0;
playerissara = 0;
playeriszammy = 0;
playerIsZammy = 0;
sendMessage("You have left castle wars");
remove(playerEquipment[playerCape], playerCape);
playerEquipment[playerCape] = -1;
deleteItem(4514, 1);
updateRequired = true;
appearanceUpdateRequired = true;
setSidebarInterface(10, 2449); // logout tab 
}
}
if (objectID == 4407) {
{
resetcw();
heightLevel = 0;
playerIsSara = 0;
playerissara = 0;
playeriszammy = 0;
playerIsZammy = 0;
sendMessage("You have left castle wars");
remove(playerEquipment[playerCape], playerCape);
playerEquipment[playerCape] = -1;
deleteItem(4516, 1);
updateRequired = true;
appearanceUpdateRequired = true;
setSidebarInterface(10, 2449); // logout tab 
}
}

			if (objectID == 4387 && (objectX == 3506) && (objectY == 3474)) {
				if (playerHasItem(1546)) { //kk go
					teleportToX = 3494;
					teleportToY = 9627;
				} else {
					sendMessage("You need a Blue key to Enter Portal");
				}
			}
if (objectID == 4469) {
if ((objectX == 2422 && objectY == 3076) && (playerIsSara == 1))
{
teleportToX = 2422;
teleportToY = 3076;
heightLevel = 1;
}
else if ((objectX == 2422 && objectY == 3076) && (playerIsSara == 0))
{
sendMessage("A force blocks the doorway");
}
else if ((objectX == 2426 && objectY == 3081) && (playerIsSara == 1))
{
teleportToX = 2426;
teleportToY = 3080;
heightLevel = 1;
}
else if ((objectX == 2426 && objectY == 3081) && (playerIsSara == 0))
{
sendMessage("A force blocks the doorway");
}
}

if (objectID == 4470) {
if ((objectX == 2377 && objectY == 3131) && (playerIsZammy == 1))
{
teleportToX = 2377;
teleportToY = 3131;
heightLevel = 1;
}
else if ((objectX == 2377 && objectY == 3131) && (playerIsZammy == 0))
{
sendMessage("A force blocks the doorway");
}
else if ((objectX == 2373 && objectY == 3126) && (playerIsZammy == 1))
{
teleportToX = 2373;
teleportToY = 3127;
heightLevel = 1;
}
else if ((objectX == 2373 && objectY == 3126) && (playerIsZammy == 0))
{
sendMessage("A force blocks the doorway");
}
}
if (objectID == 4911) {
if ((objectX == 2378 && objectY == 3134)) {
teleportToX = 2378;
teleportToY = 3133;
heightLevel = 0;
if ((objectX == 2421 && objectY == 3073)) {
teleportToX = 2421;
teleportToY = 3074;
heightLevel = 0;
}
}
}

if (objectID == 4415) {
if ((objectX == 2380 && objectY == 3127)) {
teleportToX = 2380;
teleportToY = 3130;
heightLevel = 0;
}
if ((objectX == 2369 && objectY == 3126)) {
teleportToX = 2372;
teleportToY = 3126;
heightLevel = 1;
}
if ((objectX == 2374 && objectY == 3133)) {
teleportToX = 2374;
teleportToY = 3130;
heightLevel = 2;
}
if ((objectX == 2419 && objectY == 3080)) {
teleportToX = 2419;
teleportToY = 3077;
heightLevel = 0;
}
if ((objectX == 2430 && objectY == 3081)) {
teleportToX = 2427;
teleportToY = 3081;
heightLevel = 1;
}
if ((objectX == 2425 && objectY == 3074)) {
teleportToX = 2425;
teleportToY = 3077;
heightLevel = 2;
}
}
if (objectID == 4458) {
addItem(4049, 1);
}


if (objectID == 4417) {
if ((objectX == 2428 && objectY == 3081)) {
teleportToX = 2430;
teleportToY = 3080;
heightLevel = 2;
}
if ((objectX == 2425 && objectY == 3074)) {
teleportToX = 2426;
teleportToY = 3074;
heightLevel = 3;
}
if ((objectX == 2419 && objectY == 3078)) {
teleportToX = 2420;
teleportToY = 3080;
heightLevel = 1;
}
}


if (objectID == 4418) {
if ((objectX == 2380 && objectY == 3127)) {
teleportToX = 2379;
teleportToY = 3127;
heightLevel = 1;
}
if ((objectX == 2374 && objectY == 3131)) {
teleportToX = 2373;
teleportToY = 3133;
heightLevel = 3;
}
if ((objectX == 2369 && objectY == 3126)) {
teleportToX = 2369;
teleportToY = 3127;
heightLevel = 2;
}
}


if (objectID == 4419) {
if ((objectX == 2417 && objectY == 3074) && cwstairs == 0) {
teleportToX = 2416;
teleportToY = 3074;
heightLevel = 0;
cwstairs = 1;
} else {
teleportToX = 2417;
teleportToY = 3077;
heightLevel = 0;
cwstairs = 0;
}
}

if (objectID == 4420) {
if ((objectX == 2382 && objectY == 3131) && cwstairs == 0) {
teleportToX = 2383;
teleportToY = 3133;
heightLevel = 0;
cwstairs = 1;
} else {
teleportToX = 2382;
teleportToY = 3130;
heightLevel = 0;
cwstairs = 0;
}
}

if (objectID == 1747) {
if ((objectX == 2378 && objectY == 3134)) {
teleportToX = 2378;
teleportToY = 3133;
heightLevel = 1;
if ((objectX == 2421 && objectY == 3073)) {
teleportToX = 2421;
teleportToY = 3072;
heightLevel = 1;
}
if ((objectX == 2715 && objectY == 3470)) {
teleportToX = 2715;
teleportToY = 3471;
heightLevel = 1;
}
}
}


if (objectID == 4902) {
if ((objectX == 2429 && objectY == 3074) && (saradominban == 0) && (playerIsZammy == 1))
{
CWMessage(playerName + " has captured the Saradomin banner");
saradominban = 1;
remove(playerEquipment[playerWeapon], playerWeapon);
addItem(4037, 1);
setEquipment(4037, 1, playerWeapon);
}
else if ((objectX == 2429 && objectY == 3074) && (saradominban == 1) && (playerIsZammy == 1))
{
sendMessage("The banner can already been captured!");
}
else if ((objectX == 2429 && objectY == 3074) && (playerIsSara == 1) && (playerEquipment[playerWeapon] == 4039)) {
CWMessage(playerName+" has scored for the Saradomin team");
zammorakban = 0;
remove(playerEquipment[playerWeapon], playerWeapon);
deleteItem(4039, 1);
sarapoint += 1;
}
else if ((objectX == 2429 && objectY == 3074) && (playerIsSara == 1) && (playerEquipment[playerWeapon] == 4039))
{
sendMessage("You need to wear the banner");
}
else if ((objectX == 2429 && objectY == 3074) && (playerIsSara == 1) && (zammorakban == 0))
{
sendMessage("You cannot cature your own banner!");
}
}

if (objectID == 4903) {
if ((objectX == 2370 && objectY == 3133) && (zammorakban == 0) && (playerIsSara == 1))
{
CWMessage(playerName + " has captured the Zamorak banner");
zammorakban = 1;
remove(playerEquipment[playerWeapon], playerWeapon);
addItem(4039, 1);
setEquipment(4039, 1, playerWeapon);
}
else if ((objectX == 2370 && objectY == 3133) && (zammorakban == 1) && (playerIsSara == 1))
{
sendMessage("The banner can already been captured!");
}
else if ((objectX == 2370 && objectY == 3133) && (playerIsZammy == 1) && (playerEquipment[playerWeapon] == 4037))
{
CWMessage(playerName+" has scored for the Zamorak team");
saradominban = 0;
remove(playerEquipment[playerWeapon], playerWeapon);
deleteItem(4037, 1);
zammypoint += 1;
}
else if ((objectX == 2370 && objectY == 3133) && (playerIsZammy == 1) && (playerEquipment[playerWeapon] == 4037))
{
sendMessage("You need to wear the banner");
}
else if ((objectX == 2370 && objectY == 3133) && (playerIsZammy == 1) && (saradominban == 0))
{
sendMessage("You cannot cature your own banner!");
}
}

if (objectID == 4912) {
if ((objectX == 2369 && objectY == 3125)) {
teleportToX = 2369;
teleportToY = 9526;
heightLevel = 0;
}
if ((objectX == 2430 && objectY == 3082)) {
teleportToX = 2430;
teleportToY = 9481;
heightLevel = 0;
}
}


if (objectID == 1757) {
if ((objectX == 2399 && objectY == 9499)) {
teleportToX = 2400;
teleportToY = 3107;
heightLevel = 0;
}
if ((objectX == 2400 && objectY == 9508)) {
teleportToX = 2399;
teleportToY = 3100;
heightLevel = 0;
}
if ((objectX == 2430 && objectY == 9482)) {
teleportToX = 2430;
teleportToY = 3082;
heightLevel = 0;
}
if ((objectX == 2369 && objectY == 9525)) {
teleportToX = 2369;
teleportToY = 3124;
heightLevel = 0;
}
}



	if (objectID == 6497) {
	teleportToX = 3232;
	teleportToY = 9292;
	}
	if (objectID == 6501) {
	teleportToX = 3233;
	teleportToY = 2898;
	}
        if (objectID == 2919 && objectX == 2809 && objectY == 9327) {
            if (playerHasItem(1544)) {
                teleportToX = 2810;
                teleportToY = 9326;
            updateRequired = true;
            }
             else if (!playerHasItem(1544)) {
                sendMessage("You need a orange key to cross this boulder");
		break;
            }
        }
        if (objectID == 2920 && objectX == 2809 && objectY == 9323) {
            if (playerHasItem(1544)) {
                teleportToX = 2810;
                teleportToY = 9322;
            updateRequired = true;
            }
             else if (!playerHasItem(1544)) {
                sendMessage("You need a orange key to cross this boulder");
		break;
            }
        }
        if (objectID == 2921 && objectX == 2809 && objectY == 9319) {
            if (playerHasItem(1544)) {
                teleportToX = 2810;
                teleportToY = 9318;
            updateRequired = true;
            }
             else if (!playerHasItem(1544)) {
                sendMessage("You need a orange key to cross this boulder");
		break;
            }
        }

        if (objectID == 5800 && objectX == 2715 && objectY == 9182) {
                teleportToX = 2715;
                teleportToY = 9184;
		heightLevel = 0;
            updateRequired = true;
        }



        if (objectID == 5798 && objectX == 2715 && objectY == 9185) {
                teleportToX = 2715;
                teleportToY = 9182;
		heightLevel = 1;
            updateRequired = true;
        }










        if (objectID == 2922 && objectX == 2810 && objectY == 9314) {
            if (playerHasItem(1545)) {
		ReplaceObject(2809, 9314, 2923, 0, 0);
		ReplaceObject(2810, 9314, 2923, 2, 0);
            updateRequired = true;
            }
             else if (!playerHasItem(1545)) {
                sendMessage("You need a yellow key to open these doors");
		break;
            }
        }
        if (objectID == 2923 && objectX == 2809 && objectY == 9314) {
            if (playerHasItem(1545)) {
		ReplaceObject(2809, 9314, 2923, 0, 0);
		ReplaceObject(2810, 9314, 2923, 2, 0);
            updateRequired = true;
            }
             else if (!playerHasItem(1545)) {
                sendMessage("You need a yellow key to open these doors");
		break;
            }}
	if (objectID == 2113 && (absX >= 3017 && absX <= 3021) && (absY >= 3337 && absY <= 3347)) {
if(playerLevel[14] >= 60) {
                teleportToX = 3017;
                teleportToY = 9739;
            updateRequired = true;
} else {
sendMessage("you need 60 mining to enter the mining guild.");
            }}

if (objectID == 11707 && objectX == 3061 && objectY == 3374) {
ReplaceObject(3061, 3374, 11707, -2, 0);
            }
if (objectID == 1533 && objectX == 2726 && objectY == 3368) {
ReplaceObject(2726, 3368, -1, 0, 0);
            }
if (objectID == 11707 && objectX == 2949 && objectY == 3379) {
ReplaceObject(2949, 3379, 11707, -1, 0);
            }
if (objectID == 11707 && objectX == 2989 && objectY == 3368) {
ReplaceObject(2989, 3368, 11707, -2, 0);
            }

if (objectID == 2112 && objectX == 3046 && objectY == 9756) {
if(playerLevel[14] >= 60) {
ReplaceObject(3046, 9756, -1, 0, 0);
} else {
sendMessage("you need 60 mining to enter the mining guild.");
            }}

	if (objectID == 1733 && objectX == 3058 && objectY == 3376) {
                teleportToX = 3058;
                teleportToY = 9776;
            updateRequired = true;
            }
	


	if (objectID == 1734 && objectX == 3059 && objectY == 9776) {
                teleportToX = 3061;
                teleportToY = 3376;
            updateRequired = true;
            }

	if (objectID == 7272 && objectX == 2967 && objectY == 3409) {
                teleportToX = 2911;
                teleportToY = 4832;
            updateRequired = true;
            }


        if (objectID == 2926 && objectX == 2790 && objectY == 9296) {
            if (playerHasItem(1546)) {
                teleportToX = 2788;
                teleportToY = 9297;
            updateRequired = true;
            }
             else if (!playerHasItem(1546)) {
                sendMessage("You need a blue key to cross");
		break;
            }
        }
	        if (objectID == 12389 && objectX == 3001 && objectY == 3405) {
            if (playerHasItem(1590)) {
                teleportToX = 2788;
                teleportToY = 9297;
            updateRequired = true;
            }
             else if (!playerHasItem(1590)) {
                sendMessage("You need a Dusty key to cross");
		break;
            }
        }
        if (objectID == 2926 && objectX == 2789 && objectY == 9295) {
            if (playerHasItem(1546)) {
                teleportToX = 2788;
                teleportToY = 9297;
            updateRequired = true;
            }
             else if (!playerHasItem(1546)) {
                sendMessage("You need a blue key to cross");
		break;
            }
        }
        if (objectID == 2927 && objectX == 2779 && objectY == 9305) {
            if (playerHasItem(1547)) {
                teleportToX = 2775;
                teleportToY = 9302;
            updateRequired = true;
            }
             else if (!playerHasItem(1547)) {
                sendMessage("You need a purple key to cross");
		break;
            }
        }
        if (objectID == 2927 && objectX == 2776 && objectY == 9303) {
            if (playerHasItem(1547)) {
                teleportToX = 2780;
                teleportToY = 9306;
            updateRequired = true;
            }
             else if (!playerHasItem(1547)) {
                sendMessage("You need a purple key to cross");
		break;
            }
        }
        if (objectID == 2930 && objectX == 2762 && objectY == 9313) {
            if (playerHasItem(1548)) {
                teleportToX = 2763;
                teleportToY = 9320;
            updateRequired = true;
            }
             else if (!playerHasItem(1548)) {
                sendMessage("You need a green key to cross");
		break;
            }
        }
        if (objectID == 2930 && objectX == 2762 && objectY == 9317) {
            if (playerHasItem(1548)) {
                teleportToX = 2763;
                teleportToY = 9312;
            updateRequired = true;
            }
             else if (!playerHasItem(1548)) {
                sendMessage("You need a green key to cross");
		break;
            }
        }

        if (objectID == 9751 && objectX == 2792 && objectY == 9328) {
                if (playerHasItem(4670) && playerHasItem(4671) && playerHasItem(4672) && playerHasItem(4673)) {
                sendMessage("You claim your reward");
		deleteItem(4670, 1);
		deleteItem(4671, 1);
		deleteItem(4672, 1);
		deleteItem(4673, 1);
 int chance = 0;
 chance = misc.random(3);
if(chance <= 1) {
	addItem(2595, 1);
	addItem(2591, 1);
	addItem(2593, 1);
	addItem(2597, 1);
	}
if(chance == 2) {
	addItem(2613, 1);
	addItem(2607, 1);
	addItem(2609, 1);
	addItem(2611, 1);
	}
if(chance == 3) {
	addItem(2619, 1);
	addItem(2615, 1);
	addItem(2617, 1);
	addItem(2621, 1);
	}
                } else {
                    sendMessage("You need all four gems to claim your reward");
                    break;
                }
        }
        if (objectID == 2939 && objectX == 2857 && objectY == 2966) {
                if (playerHasItem(1543)) {

                teleportToX = 2779;
                teleportToY = 9335;
            }
             else {
                    sendMessage("You need a red key to teleport");
                    break;
            }
        }
        if (objectID == 5960 && objectX == 2539 && objectY == 4712) {
            teleportToX = 3105;
            teleportToY = 3933;
        }
        if (objectID == 2911 && objectX == 2795 && objectY == 9339) {
            if (playerHasItem(1544)) {
                teleportToX = 2800;
                teleportToY = 9340;
            updateRequired = true;
            }
             else if (!playerHasItem(1544)) {
                sendMessage("You need a orange key to cross");
		break;
            }
        }
        if (objectID == 2918 && objectX == 2799 && objectY == 2941) {
            if (playerHasItem(1543)) {
                teleportToX = 2796;
                teleportToY = 9339;
                updateRequired = true;
            }
             else if (!playerHasItem(1543)) {
                sendMessage("You need a red key to cross");
		break;
            }
        }
switch(objectID){
case 4483:
case 11758:
case 2214:
case 2417:
case 3045:
case 5276:
case 6084:
case 10517:
case 11338:
case 12798:
case 12799:
case 12800:
case 12801:

openUpBank();

break;
}
        
	if (objectID == 2213) { // Bank Booth
		if(duelFight == true){
			sendMessage("Sorry you cant open you bank in duel!");    
		} else {
	                skillX = objectX;
	                skillY = objectY;
	                WanneBank = 1;
		}
	}
        if (objectID == 881) {
                teleportToX = 3237;
                teleportToY = 9859;
                heightLevel = 0;
        }

        // mining
        if (CheckObjectSkill(objectID) == true) {
            IsUsingSkill = true;
            skillX = objectX;
            skillY = objectY;
        }
        // go upstairs
        if (true) {
            if (objectID == 1750) {
                stairs = 1;
                skillX = objectX;
                skillY = objectY;
                stairDistance = 1;
            }
             else if (objectID == 1738) {
                stairs = 1;
                skillX = objectX;
                skillY = objectY;
                stairDistance = 2;
            }
             else if (objectID == 55) {
                stairs = 15;
                skillX = objectX;
                skillY = objectY;
                stairDistance = 3;
                stairDistanceAdd = 1;
            }
             else if (objectID == 57) {
                stairs = 15;
                skillX = objectX;
                skillY = objectY;
                stairDistance = 3;
            }
             else if (objectID == 1755 || objectID == 5946 || objectID == 1757) {
                stairs = 4;
                skillX = objectX;
                skillY = objectY;
                stairDistance = 1;
            }
             else if (objectID == 1764) {
                stairs = 12;
                skillX = objectX;
                skillY = objectY;
                stairDistance = 1;
            }
             else if (objectID == 2148) {
                stairs = 8;
                skillX = objectX;
                skillY = objectY;
                stairDistance = 1;
            }
             else if (objectID == 3608) {
                stairs = 13;
                skillX = objectX;
                skillY = objectY;
                stairDistance = 1;
            }
             else if (objectID == 2408) {
                stairs = 16;
                skillX = objectX;
                skillY = objectY;
                stairDistance = 1;
            }
             else if (objectID == 5055) {
                stairs = 18;
                skillX = objectX;
                skillY = objectY;
                stairDistance = 1;
            }
             else if (objectID == 5131) {
                stairs = 20;
                skillX = objectX;
                skillY = objectY;
                stairDistance = 1;
            }
             else if (objectID == 9359) {
                stairs = 24;
                skillX = objectX;
                skillY = objectY;
                stairDistance = 1;
                stairDistance = 1;
            }

            // go downstairs
            if (objectID == 1746) {
                stairs = 2;
                skillX = objectX;
                skillY = objectY;
                stairDistance = 1;
            }
            else if (objectID == 1749) {
                stairs = 2;
                skillX = objectX;
                skillY = objectY;
                stairDistance = 1;
            }
             else if (objectID == 1740) {
                stairs = 2;
                skillX = objectX;
                skillY = objectY;
                stairDistance = 1;
            }
             else if (objectID == 2617) {
                stairs = 21;
                skillX = objectX;
                skillY = objectY;
                stairDistance = 0;
            }
             else if (objectID == 54) {
                stairs = 14;
                skillX = objectX;
                skillY = objectY;
                stairDistance = 3;
                stairDistanceAdd = 1;
            }
             else if (objectID == 56) {
                stairs = 14;
                skillX = objectX;
                skillY = objectY;
                stairDistance = 3;
            }
             else if (objectID == 1568 || objectID == 5947 || objectID == 6434 || objectID == 1759 || objectID == 1754 || objectID == 1570) {
                stairs = 3;
                skillX = objectX;
                skillY = objectY;
                stairDistance = 1;
            }
             else if (objectID == 492) {
                stairs = 11;
                skillX = objectX;
                skillY = objectY;
                stairDistance = 2;
            }
             else if (objectID == 2147) {
                stairs = 7;
                skillX = objectX;
                skillY = objectY;
                stairDistance = 1;
            }
             else if (objectID == 5054) {
                stairs = 17;
                skillX = objectX;
                skillY = objectY;
                stairDistance = 1;
            }
             else if (objectID == 5130) {
                stairs = 19;
                skillX = objectX;
                skillY = objectY;
                stairDistance = 1;
            }
             else if (objectID == 9358) {
                stairs = 23;
                skillX = objectX;
                skillY = objectY;
                stairDistance = 1;
            }
             else if (objectID == 5488) {
                stairs = 28;
                skillX = objectX;
                skillY = objectY;
                stairDistance = 1;
            }

            if (skillX > -1 && skillY > -1) {
                IsUsingSkill = true;
            }
        }
        break;

      case 252:
        // atObject2
        objectID = inStream.readUnsignedWordBigEndianA(); // 5292 bankwindow
        objectY = inStream.readSignedWordBigEndian();
        objectX = inStream.readUnsignedWordA();
        if (test)
          println_debug("atObject2: "+objectX+","+objectY+" objectID: "+objectID);

        long now = System.currentTimeMillis();
        if (adding)
          server.objects.add(new Object(objectID, objectX, objectY, 2));

        if (objectID == 2646) {
if (flaxani == 0 || flaxani == 1) {
            if (now-lastAction >= 900) {
                addItem(1779, 1);
                lastAction = now;
flaxani = 1;
pEmote = 2286;
sendMessage("You pick some flax");
            }
        }}
if (objectID == 2563 && objectX == 3043 && objectY == 3357) {
if (actionTimer == 0) {
emptyid = 4276;
StallId = objectID;
StallX = objectX;
StallY = objectY;
makeGlobalObject(StallX, StallY, emptyid, 3, 10);
startAnimation(881);
sendMessage("You steal some feather");
addItem(314, misc.random(20));
addSkillXP(600, 17);
actionTimer = 20;
}
EventManager.getSingleton().addEvent(
                new Event() {
                    public void execute(EventContainer C) {


		    makeGlobalObject(StallX, StallY, StallId, 3, 10);
            
                         
			 C.stop();
                    }
                }, 3000);

}
if (objectID == 2561 && objectX == 3033 && objectY == 3352) {
if (actionTimer1 == 0) {
emptyid = 4276;
StallId4 = objectID;
StallX4 = objectX;
StallY4 = objectY;
makeGlobalObject(StallX4, StallY4, emptyid, 2, 10);
startAnimation(881);
sendMessage("You steal some breads.");
addItem(2309, 1);
addSkillXP(800, 17);
actionTimer1 = 20;
}
EventManager.getSingleton().addEvent(
                new Event() {
                    public void execute(EventContainer C) {


		    makeGlobalObject(StallX4, StallY4, StallId4, 2, 10);
            
                         
			 C.stop();
                    }
                }, 3000);

}
if (objectID == 4877 && objectX == 3036 && objectY == 3359) {
if (thiefani == 0 || thiefani == 1) {
if (playerLevel[17] > 39) {
if(actionTimer2 == 0){
emptyid = 4797;
StallId1 = objectID;
StallX1 = objectX;
StallY1 = objectY;

    steal1();
thiefani = 1;
actionTimer2 = 20;
}
} else {
sendMessage("you need 40 thieving to steal from this stall.");
}}}
makeGlobalObject(3043, 3348, 2562,  4, 10);
if (objectID == 2562 && objectX == 3043 && objectY == 3348) {
if (thiefani == 0 || thiefani == 1) {
if (playerLevel[17] >= 92) {
if(actionTimer3 == 0){
emptyid = 4276;
StallId3 = objectID;
StallX3 = objectX;
StallY3 = objectY;

steal3();
thiefani = 1;
actionTimer3 = 20;
}
} else{
sendMessage("you need 92 thieving to steal from this stall.");
}}}

if (objectID == 2564 && objectX == 3045 && objectY == 3352) {
if (thiefani == 0 || thiefani == 1) {
if (playerLevel[17] >= 80) {
if (actionTimer4 == 0){
emptyid = 4276;
StallId2 = objectID;
StallX2 = objectX;
StallY2 = objectY;
actionTimer4 = 20;
steal2();
thiefani = 1;
}
} else if(premium == 0 && playerLevel[17] < 80){
sendMessage("you need 80 thieving and premium to steal from this stall.");
}}}
        if (objectID == 2644 && objectX == 2710 && objectY == 3471) {
            spinning = true;
            pEmote = 894;
            updateRequired = true;
            appearanceUpdateRequired = true;
        }
	if (objectID == 2644 && objectX == 2991 && objectY == 3363) {
            spinning = true;
            pEmote = 894;
            updateRequired = true;
            appearanceUpdateRequired = true;
        }
        if (objectID == 4483) {
		openUpBank();
        }
        
        if ((objectID == 2213) || (objectID == 2214) || (objectID == 3045) || (objectID == 5276) || (objectID == 6084)) {
    		if(duelFight == true){
			sendMessage("You may not use your bank when ur in duel");    
    		} else {
	                skillX = objectX;
	                skillY = objectY;
	                WanneBank = 1;
    		}
	}
	
        break;

      case 70:
        // atObject3
        objectX = inStream.readSignedWordBigEndian();
        objectY = inStream.readUnsignedWord();
        objectID = inStream.readUnsignedWordBigEndianA();
        if(test)
        	println_debug("atObject3: "+objectX+","+objectY+" objectID: "+objectID);
        if (adding)
          server.objects.add(new Object(objectID, objectX, objectY, 3));

        if (objectID == 1739) {
            heightLevel -= 1;
            teleportToX = absX;
            teleportToY = absY;
        }
        break;

      case 95:
        // update chat
        Tradecompete = inStream.readUnsignedByte();
        Privatechat = inStream.readUnsignedByte();
        Publicchat = inStream.readUnsignedByte();
        for (int i1 = 1; i1 < handler.maxPlayers; i1++) {
            if (handler.players[i1] != null && handler.players[i1].isActive == true) {
                handler.players[i1].pmupdate(playerId, GetWorld(playerId));
            }
        }
        break;

      case 188:
        // add friend
        friendUpdate = true;
        long friendtoadd = inStream.readQWord();
        boolean CanAdd = true;

        for (int i1 = 0; i1 < friends.length; i1++) {
            if (friends[i1] != 0 && friends[i1] == friendtoadd) {
                CanAdd = false;
                sendMessage(friendtoadd+" is already in your friendlist.");
            }
        }
        if (CanAdd == true) {
            for (int i1 = 0; i1 < friends.length; i1++) {
                if (friends[i1] == 0) {
                    friends[i1] = friendtoadd;
                    for (int i2 = 1; i2 < handler.maxPlayers; i2++) {
                        if (handler.players[i2] != null && handler.players[i2].isActive && misc.playerNameToInt64(handler.players[i2].playerName) == friendtoadd) {
                            if (playerRights >= 2 || handler.players[i2].Privatechat == 0 || (handler.players[i2].Privatechat == 1 && handler.players[i2].isinpm(misc.playerNameToInt64(playerName)))) {
                                loadpm(friendtoadd, GetWorld(i2));
                                break;
                            }
                        }
                    }
                    break;
                }
            }
        }
        break;

      case 215:
        // remove friend
        friendUpdate = true;
        long friendtorem = inStream.readQWord();

        for (int i1 = 0; i1 < friends.length; i1++) {
            if (friends[i1] == friendtorem) {
                friends[i1] = 0;
                break;
            }
        }
        break;

      case 133:
        // add ignore
        friendUpdate = true;
        long igtoadd = inStream.readQWord();

        for (int i10 = 0; i10 < ignores.length; i10++) {
            if (ignores[i10] == 0) {
                ignores[i10] = igtoadd;
                break;
            }
        }
        break;

      case 74:
        // remove ignore
        friendUpdate = true;
        long igtorem = inStream.readQWord();

        for (int i11 = 0; i11 < ignores.length; i11++) {
            if (ignores[i11] == igtorem) {
                ignores[i11] = 0;
                break;
            }
        }
        break;

      case 126:
        // pm message
                if (muted) {
                    sendMessage("You cannot talk in Private Message! You are muted!");
                    break;
} else {
        long friendtosend = inStream.readQWord();
        byte pmchatText[] = new byte[100];
        int pmchatTextSize = (byte)(packetSize-8);

        inStream.readBytes(pmchatText, pmchatTextSize, 0);
        for (int i1 = 0; i1 < friends.length; i1++) {
            if (friends[i1] == friendtosend) {
                boolean pmsent = false;

                for (int i2 = 1; i2 < handler.maxPlayers; i2++) {
                    if (handler.players[i2] != null && handler.players[i2].isActive && misc.playerNameToInt64(handler.players[i2].playerName) == friendtosend) {
                        if (playerRights >= 2 || handler.players[i2].Privatechat == 0 || (handler.players[i2].Privatechat == 1 && handler.players[i2].isinpm(misc.playerNameToInt64(playerName)))) {
                            handler.players[i2].sendpm(misc.playerNameToInt64(playerName), playerRights, pmchatText, pmchatTextSize);
			    writeLog("private chat logs", playerName + " sent " + misc.textUnpack(pmchatText, packetSize-8) + " to " + handler.players[i2].playerName);
                            pmsent = true;
                        }
                        break;
                    }
                }
                if (!pmsent) {
                    sendMessage("Player currently not available");
                    break;
    }
                }
            }
        }
        break;

      case 236:
        // pickup item
        int itemY = inStream.readSignedWordBigEndian();
        int itemID = inStream.readUnsignedWord();
        int itemX = inStream.readSignedWordBigEndian();
        if (!hasSpace()) {
            sendMessage("Your inventory is full!");
            break;
        }
        lastAction = System.currentTimeMillis();
        if (ItemHandler.itemExists(itemID, itemX, itemY)) {
            if (absX == itemX && absY == itemY) {
                 {
                    int itemAmount = ItemHandler.itemAmount(itemID, itemX, itemY);

                    pickUpItem(itemID, itemAmount);
                    ItemHandler.removeItem(itemID, itemX, itemY, itemAmount);
                    resetItems(3214);
                }
            }
        }
        break;

      case 73:
        // Attack (Wilderness)
        if (System.currentTimeMillis() - lastAttackClick >= 1000) {
				lastAttackClick = System.currentTimeMillis(); 
				AttackingOn = inStream.readSignedWordBigEndian();
				followThisPlayer = AttackingOn;
				client AttackingOn2 = (client) server.playerHandler.players[AttackingOn];
				if (AttackingOn2.deathStage > 0) {
					break;
				}
				if (deathStage > 0) {
					break;
				}
				if (AttackingOn2.AttackingOn != playerId && AttackingOn2.AttackingOn != 0 && !AttackingOn2.multiZone()) {
					sendMessage("This player is already in combat.");
					break;
					
				}
				if ((AttackingOn >= handler.players.length) || (AttackingOn < 1)) {
					//AttackingOn = -1;
					IsAttacking = false;
					break;
				}
				IsAttacking = true;
			}

			break;

      case 128:
        // Trade Request
        int temp = inStream.readUnsignedWord();
        if (!inTrade) {
            trade_reqId = temp;
            tradeReq(trade_reqId);
        }
        break;

      case 153:
        // Duel req
        int PID = (misc.HexToInt(inStream.buffer, 0, packetSize)/1000);
        client plyr = getClient(PID);
        if (!validClient(PID))
          break;
        duelReq(PID);

        break;
      case 139:
        // Trade answer
        trade_reqId = inStream.readSignedWordBigEndian();
        tradeReq(trade_reqId);	

        break;
      case 199:
        // fags using xero's client
        sendMessage("Please use another client to play.");
        validClient = false;
        disconnected = true;
        break;

        //break;
 case 237:
        int castOnSlot = inStream.readSignedWord();
        int castOnItem = inStream.readSignedWordA();
        int e3 = inStream.readSignedWord();
        int castSpell = inStream.readSignedWordA();
        int alchvaluez = (int)Math.floor(GetItemShopValue(castOnItem, 0, castOnSlot));
        if (!playerHasItem(castOnItem)) {
            sendMessage("You don't have that item!");
break;
}
        if (playerHasItem(4315) || playerHasItem(4317) || playerHasItem(4319) || playerHasItem(4321) || playerHasItem(4323) || playerHasItem(4325) || playerHasItem(4327) || playerHasItem(4329) || playerHasItem(4331) || playerHasItem(4333) || playerHasItem(4335) || playerHasItem(4337) || playerHasItem(4339) || playerHasItem(4341) || playerHasItem(4343) || playerHasItem(4345) || playerHasItem(4347) || playerHasItem(4349) || playerHasItem(4351) || playerHasItem(4353) || playerHasItem(4355) || playerHasItem(4357)) {
           sendMessage("You can't alch with a skillcape in inventory!");
break;
}
if (castSpell == 1178 && playerHasItem(561)) { 
deleteItem(castOnItem, castOnSlot, 1); 
addItem(995, alchvaluez * 2); 
addSkillXP(600, 6);
setAnimation(712);
animation3(113, absY, absX); 
resetanim = 12;
deleteItem(561, getItemSlot(561), 1);
actionTimer = 9;
AnimationReset = true; 
updateRequired = true;
appearanceUpdateRequired = true;
} else {
sendMessage("you need 1 nature rune to use this spell");
}
        break;

      case 249:
        // Magic on Players
        playerIndex = inStream.readSignedWordA();
			followThisPlayer = playerIndex;
			playerMagicID = inStream.readSignedWordBigEndian();
			//mageRequest = true;
			client playerIndex2 = (client) server.playerHandler.players[playerIndex];
			if (playerIndex2.deathStage > 0) {
				break;
			}
			if (deathStage > 0) {
				break;
			}
			if (playerIndex2.lastDamageTaken - System.currentTimeMillis() < -5000) {
					playerIndex2.AttackingOn = playerId;
					AttackingOn = playerIndex2.playerId;
			}
			if (playerIndex2.AttackingOn != playerId && playerIndex2.AttackingOn != 0 && !playerIndex2.multiZone()) {
				sendMessage("This player is already in combat.");
	
				ResetAttack();
				break;
			}
			if (autoCast) {
				setClientConfig(108, 0);
				autoCast = false;
			}
			getTheCurrentSpellPVP();
			break;

      case 131:
        // Magic on NPCs //offsets switched op
        int npcIndex = inStream.readSignedWordBigEndianA();
        if (!(npcIndex >= 0 && npcIndex < server.npcHandler.npcs.length)) {
            break;
        }
        int magicID = inStream.readSignedWordA();
        int EnemyX2 = server.npcHandler.npcs[npcIndex].absX;
        int EnemyY2 = server.npcHandler.npcs[npcIndex].absY;
        int EnemyHP2 = server.npcHandler.npcs[npcIndex].HP;
        int hitDiff = 0;
        int offsetY = (absX-EnemyX2)*-1;
        int offsetX = (absY-EnemyY2)*-1;
        int magicDef = MageAttackIndex = npcIndex;
         {
            try {
                if (EnemyHP2 < 1) {
                    sendMessage("That monster has already been killed!");
                    break;
                }
                if (server.npcHandler.npcs[npcIndex].MaxHP < 1) {
                    sendMessage("You can't attack that");
                }
                int type = server.npcHandler.npcs[npcIndex].npcType;
                if (type == 1125) {
                    if (combatLevel < 70) {
                        sendMessage("You must be level 70 or higher to attack Dad");
			return;
                    }
                }

		if (type == 84) {
			if (combatLevel < 100) {
				sendMessage("You must be level 100 or higher to attack Barrows monsters.");
        resetPos();
				ResetAttackNPC();
				return;
			}
		}
		if (type == 2060) {
			if (combatLevel < 100) {
				sendMessage("You must be level 100 or higher to attack Barrows monsters.");
        resetPos();
				ResetAttackNPC();
				return;
			}
		}
		if (type == 3200) {
			if (combatLevel < 100) {
				sendMessage("You must be level 100 or higher to attack Barrows monsters.");
        resetPos();
				ResetAttackNPC();
				return;
			}
		}
		if (type == 258) {
    			if (!playerHasItem(989)) {
				sendMessage("You must have a crystal key to attack General Khazard.");
				ResetAttackNPC();
				return;
			}
		}
		if (type == 1974) {
    			if (!playerHasItem(4272)) {
				sendMessage("You must have a bone key to attack Damis.");
				ResetAttackNPC();
				return;
			}
		}
		if (type == 475) {
    			if (!playerHasItem(6966)) {
				sendMessage("You must have a prison key to attack Khazard troopers.");
				ResetAttackNPC();
				return;
			}
		}
		if (type == 277) {
    			if (!playerHasItem(1543)) {
				sendMessage("You must have a red key to attack the Fire Warrior.");
				ResetAttackNPC();
				return;
			}
		}
		if (type == 221) {
    			if (!playerHasItem(1544)) {
				sendMessage("You must have a orange key to attack the Black Knight Titan.");
				ResetAttackNPC();
				return;
			}
		}
		if (type == 1095) {
    			if (!playerHasItem(1546)) {
				sendMessage("You must have a blue key to attack Rock.");
				ResetAttackNPC();
				return;
			}
		}
		if (type == 2881) {
    			if (!playerHasItem(1545)) {
				sendMessage("You must have a yellow key to attack Dagannoth Supreme.");
				ResetAttackNPC();
				return;
			}
		}
		if (type == 1958) {
    			if (!playerHasItem(1547)) {
				sendMessage("You must have a purple key to attack the Mummy.");
				ResetAttackNPC();
				return;
			}
		}
		if (type == 1356) {
    			if (!playerHasItem(983)) {
				sendMessage("You must have a brass key to attack the Dagonnath Mother.");
				ResetAttackNPC();
				return;
			}
		}
		if (type == 50) {
    			if (!playerHasItem(2418)) {
				sendMessage("You must have a bronze key to attack the King Black Dragon.");
				ResetAttackNPC();
				return;
			}
		}
		if (type == 1158) {
    			if (!playerHasItem(2945)) {
				sendMessage("You must have a iron key to attack the Kalphite Queen.");
				ResetAttackNPC();
				return;
			}
		}
		if (type == 418) {
    			if (!fullRockshell()) {
				sendMessage("You must be wearing full rock-shell armor to attack the Rock Golem");
				ResetAttackNPC();
				return;
			}
		}
		if (type == 1648) {
			if (slayerTask != 1) {
				sendMessage("You are not assigned to slay this monster!");
				ResetAttackNPC();
				return;
			}
		}
		if (type == 1637) {
			if (slayerTask != 2) {
				sendMessage("You are not assigned to slay this monster!");
				ResetAttackNPC();
				return;
			}
		}
		if (type == 1633) {
			if (slayerTask != 3) {
				sendMessage("You are not assigned to slay this monster!");
				ResetAttackNPC();
				return;
			}
		}
		if (type == 1575) {
			if (slayerTask != 4) {
				sendMessage("You are not assigned to slay this monster!");
				ResetAttackNPC();
				return;
			}
		}
		if (type == 3406) {
			if (slayerTask != 5) {
				sendMessage("You are not assigned to slay this monster!");
				ResetAttackNPC();
				return;
			}
		}
		if (type == 1614) {
			if (slayerTask != 6) {
				sendMessage("You are not assigned to slay this monster!");
				ResetAttackNPC();
				return;
			}
		}
		if (type == 347) {
			if (slayerTask != 7) {
				sendMessage("You are not assigned to slay this monster!");
				ResetAttackNPC();
				return;
			}
		}
		if (type == 2373) {
			if (slayerTask != 7) {
				sendMessage("You are not assigned to slay this monster!");
				ResetAttackNPC();
				return;
			}
		}
                if (type == 221 || type == 1961) {
                    if (!playerHasItem(1544)) {
			return;
                    }
                }
                if (type == 1095) {
                    if (!playerHasItem(1546)) {
			return;
                    }
                }
                ;
                boolean valid = false;
                for (int i2 = 0; i2 < ancientId.length; i2++) {
                    if (magicID == ancientId[i2]) {
                        inCombat = true;
                        lastCombat = System.currentTimeMillis();
                        lastAttack = lastCombat;
                        valid = true;
if (playerLevel[6] >= requiredLevel[i2] && playerHasItem(ancientRune1[i2], ancientRuneAm[i2])) {
                            int roll = misc.random(100);
                            int hit = misc.random(baseDamage[i2]+playerBonus[11]);
                            hitDiff = hit;
                            setAnimation(1979);
                            updateRequired = true;
                            teleportToX = absX;
                            teleportToY = absY;
deleteItem(ancientRune1[i2], getItemSlot(ancientRune1[i2]), ancientRuneAm[i2]);
                            if (ancientType[i2] == 3 && playerHasItem(ancientRune1[i2], ancientRuneAm[i2])) {
                                server.npcHandler.npcs[npcIndex].effects[0] = 15;
                                stillgfx(369, EnemyY2, EnemyX2);
deleteItem(ancientRune1[i2], getItemSlot(ancientRune1[i2]), ancientRuneAm[i2]);
                            }
                             else if (ancientType[i2] == 2 && playerHasItem(ancientRune1[i2], ancientRuneAm[i2])) {
                                stillgfx(377, EnemyY2, EnemyX2);
                                currentHealth += (int)(hit/2);
                                if (currentHealth > playerLevel[playerHitpoints])
                                  currentHealth = playerLevel[playerHitpoints];
deleteItem(ancientRune1[i2], getItemSlot(ancientRune1[i2]), ancientRuneAm[i2]);
                            }
                            else
                               animation(78, EnemyY2, EnemyX2);
                    }
 else if (playerLevel[6] < requiredLevel[i2] && playerHasItem(ancientRune1[i2], ancientRuneAm[i2])) {
                        sendMessage("You need a magic level of "+requiredLevel[i2]+"");
                    }
                     else if (playerLevel[6] < requiredLevel[i2]) {
                        sendMessage("You need "+ancientRuneAm[i2]+" blood rune to cast this spell");
                    }
}
}
                TurnPlayerTo(EnemyX2, EnemyY2);
                addSkillXP(90*hitDiff, playerMagic);
                addSkillXP(hitDiff*20, playerHitpoints);
                teleportToX = absX;
                teleportToY = absY;
                server.npcHandler.npcs[npcIndex].StartKilling = localId;
                server.npcHandler.npcs[npcIndex].RandomWalk = false;
                server.npcHandler.npcs[npcIndex].IsUnderAttack = true;
                server.npcHandler.npcs[npcIndex].hitDiff = hitDiff;
                server.npcHandler.npcs[npcIndex].Killing[playerId] += hitDiff;
                server.npcHandler.npcs[npcIndex].updateRequired = true;
                server.npcHandler.npcs[npcIndex].hitUpdateRequired = true;
                server.npcHandler.npcs[npcIndex].hit = true;
            }
             catch (Exception e) {
                e.printStackTrace();
            }

        }
        break;

      case 3:
        // focus change
        break;

      case 39:
if((playerEquipment[playerWeapon] == 4566)) {
    outStream.createFrameVarSize(104);
    outStream.writeByteC(5);
    outStream.writeByteA(0);
    outStream.writeString("Noob");
    outStream.endFrameVarSize();
}
        break;

      case 86:
        // camera angle
        int a = inStream.readSignedWord();
        int a1 = inStream.readSignedWordA();
        break;

      case 241:
        // mouse clicks
        int in = inStream.readDWord();
        lastMouse = System.currentTimeMillis();
        boolean validClick = false;
        long diff = System.currentTimeMillis()-lastMouse;
        if (diff < 100) {
            validClick = true;
        }
        break;

      case 103:
        // Custom player command, the ::words
        String playerCommand = inStream.readString();
        println_debug("Command: "+playerCommand);
        if (validClient)
          customCommand(playerCommand);
        else
           sendMessage("Command ignored, please use another client");

	writeLog("commandlogs", "["+playerName+"]: Command: "+playerCommand);
	break;

      case 214:
        // change item places
        somejunk = inStream.readUnsignedWordA(); // junk
        int itemFrom = inStream.readUnsignedWordA(); // slot1
        int itemTo = (inStream.readUnsignedWordA()-128); // slot2

        moveItems(itemFrom, itemTo, somejunk);

        break;

      case 41:
        // wear item
        int wearID = inStream.readUnsignedWord();
        int wearSlot = inStream.readUnsignedWordA();

        interfaceID = inStream.readUnsignedWordA();
        if (playerEquipment[playerAmulet] == 1704) {
            playerLevel[7] = getLevelForXP(playerXP[7]);
            playerLevel[7] += 5;
            sendFrame126(""+playerLevel[7]+"", 4032);
        }

        // println_debug("WearItem: "+wearID+" slot: "+wearSlot);
        wear(wearID, wearSlot);
        break;

      case 145:
        // remove item (opposite for wearing) - bank 1 item - value of item
        interfaceID = inStream.readUnsignedWordA();
        int removeSlot = inStream.readUnsignedWordA();
        int removeID = inStream.readUnsignedWordA();
        //if (playerRights >= 0)
          //println_debug("RemoveItem: "+removeID+" InterID: "+interfaceID+" slot: "+removeSlot);
        if (interfaceID == 3322 && inDuel) {
            //remove from bag to duel window
            stakeItem(removeID, removeSlot, 1);
        }
         else if (interfaceID == 6669 && inDuel) {
            //remove from duel window
            fromDuel(removeID, removeSlot, 1);
        } 
         else if (interfaceID == 1688) {
            if (playerEquipment[removeSlot] > 0) {
                remove(removeID, removeSlot);
            }
        }
         else if (interfaceID == 5064) {
            // remove from bag to bank
            bankItem(removeID, removeSlot, 1);
        }
         else if (interfaceID == 5382) {
            // remove from bank
            fromBank(removeID, removeSlot, 1);
        }
         else if (interfaceID == 3322) {
            // remove from bag to trade window
            tradeItem(removeID, removeSlot, 1);
        }
         else if (interfaceID == 3415) {
            // remove from trade window
            fromTrade(removeID, removeSlot, 1);
        }
         else if (interfaceID == 3823 && MyShopID <= 98) {
            // Show value to sell items
            if (Item.itemSellable[removeID] == false) {
                sendMessage("You cannot sell "+GetItemName(removeID)+".");
            }
             else {
                boolean IsIn = false;

                if (server.shopHandler.ShopSModifier[MyShopID] > 1) {
                    for (int j = 0; j <= server.shopHandler.ShopItemsStandard[MyShopID]; j++) {
                        if (removeID == (server.shopHandler.ShopItems[MyShopID][j]-1)) {
                            IsIn = true;
                            break;
                        }
                    }
                }
                 else {
                    IsIn = true;
                }
                if (IsIn == false) {
                    sendMessage("You cannot sell "+GetItemName(removeID)+" in this store.");
                }
                 else {
                    int ShopValue = (int)Math.floor(GetItemShopValue(removeID, 1, removeSlot));
                    String ShopAdd = "";

                    if (ShopValue >= 1000 && ShopValue < 1000000) {
                        ShopAdd = " ("+(ShopValue/1000)+"K)";
                    }
                     else if (ShopValue >= 1000000) {
                        ShopAdd = " ("+(ShopValue/1000000)+" million)";
                    }
                    sendMessage(GetItemName(removeID)+": shop will buy for "+ShopValue+" coins"+ShopAdd);
                }
            }
        } else if (interfaceID == 3823 && MyShopID == 100) { // Show value to sell items
                if (Item.itemSellable[removeID] == false) {
                    sendMessage("You cannot sell " + GetItemName(removeID) + ".");
                } else {
                    boolean IsIn = false;

                    if (server.shopHandler.ShopSModifier[MyShopID] > 1) {
                        for (int j = 0; j
                                <= server.shopHandler.ShopItemsStandard[MyShopID]; j++) {
                            if (removeID == (server.shopHandler.ShopItems[MyShopID][j] - 1)) {
                                IsIn = true;
                                break;
                            }
                        }
                    } else {
                        IsIn = true;
                    }
                    if (IsIn == false) {
                        sendMessage("You cannot sell " + GetItemName(removeID) + " in this store.");
                    } else {
                        int ShopValue = (int) Math.floor(GetItemShopValue(removeID, 1, removeSlot));
                        String ShopAdd = "";

                        if (ShopValue <= 1) {
                            ShopValue = (int) Math.floor(GetItemShopValue(removeID, 0, removeSlot));
                        }
                        sendMessage(GetItemName(removeID) + ": shop will buy for " + ShopValue + " trading sticks" + ShopAdd);
                    }
                }
        } else if (interfaceID == 3823 && MyShopID == 99) { // Show value to sell items
                if (Item.itemSellable[removeID] == false) {
                    sendMessage("You cannot sell " + GetItemName(removeID) + ".");
                } else {
                    boolean IsIn = false;

                    if (server.shopHandler.ShopSModifier[MyShopID] > 1) {
                        for (int j = 0; j
                                <= server.shopHandler.ShopItemsStandard[MyShopID]; j++) {
                            if (removeID == (server.shopHandler.ShopItems[MyShopID][j] - 1)) {
                                IsIn = true;
                                break;
                            }
                        }
                    } else {
                        IsIn = true;
                    }
                    if (IsIn == false) {
                        sendMessage("You cannot sell " + GetItemName(removeID) + " in this store.");
                    } else {
                        int ShopValue = (int) Math.floor(GetItemShopValue(removeID, 1, removeSlot));
                        String ShopAdd = "";

                        if (ShopValue <= 1) {
                            ShopValue = (int) Math.floor(GetItemShopValue(removeID, 0, removeSlot));
                        }
                        sendMessage(GetItemName(removeID) + ": shop will buy for " + ShopValue + " castle wars tickets" + ShopAdd);
                    }
                }
            } else if (interfaceID == 3900 && MyShopID == 100) { // Show value to buy items
                int ShopValue = (int) Math.floor(GetItemShopValue(removeID, 0, removeSlot));
                String ShopAdd = "";

                if (ShopValue <= 1) {
                    ShopValue = (int) Math.floor(GetItemShopValue(removeID, 0, removeSlot));
                }
                sendMessage(GetItemName(removeID) + ": currently costs " + ShopValue + " trading sticks" + ShopAdd);
            } else if (interfaceID == 3900) { // Show value to buy items
                int ShopValue = (int) Math.floor(GetItemShopValue(removeID, 0, removeSlot));
                String ShopAdd = "";

                if (ShopValue <= 1) {
                    ShopValue = (int) Math.floor(GetItemShopValue(removeID, 0, removeSlot));
                }
                sendMessage(GetItemName(removeID) + ": currently costs " + ShopValue + " tokkul" + ShopAdd);
            } else if (interfaceID == 3900 && MyShopID == 99) { // Show value to buy items
                int ShopValue = (int) Math.floor(GetItemShopValue(removeID, 0, removeSlot));
                String ShopAdd = "";

                if (ShopValue <= 1) {
                    ShopValue = (int) Math.floor(GetItemShopValue(removeID, 0, removeSlot));
                }
                sendMessage(GetItemName(removeID) + ": currently costs " + ShopValue + " castle wars tickets" + ShopAdd);
            }
         else if (interfaceID == 3900 && MyShopID <= 98) {
            // Show value to buy items
            int ShopValue = (int)Math.floor(GetItemShopValue(removeID, 0, removeSlot));
            String ShopAdd = "";

            if (ShopValue >= 1000 && ShopValue < 1000000) {
                ShopAdd = " ("+(ShopValue/1000)+"K)";
            }
             else if (ShopValue >= 1000000) {
                ShopAdd = " ("+(ShopValue/1000000)+" million)";
            }
            sendMessage(GetItemName(removeID)+": currently costs "+ShopValue+" coins"+ShopAdd);
        }
         else if (interfaceID == 3900 && MyShopID == 10) {
            // Show value to buy items
            int ShopValue = (int)Math.floor(GetItemShopValue(removeID, 0, removeSlot));

	    sendMessage(GetItemName(removeID)+": currently costs "+ShopValue+" Pk Points");
        } else if (interfaceID == 1119) // Smith Column 1
            {
                try {
					
                    if (barsNeeded(removeSlot, interfaceID)
                            <= amountOfItem(removeBar(removeID))) {
                        if (playerHasItem(2347) == true) {
                            if (canSmith(removeID)) {
                                RemoveAllWindows();
              setAnimation(0x382);
                                addSkillXP(
                                        smithXP(removeBar(removeID),
                                        barsNeeded(removeSlot, interfaceID)),
                                        13);
                                ReplaceItems(removeID, removeBar(removeID), 1,
                                        barsNeeded(removeSlot, interfaceID));
							
                            } else {
                                sendMessage(
                                        "You need a higher smithing level to smith "
                                                + GetItemName(removeID) + "s");
                            }
                        } else {
                            sendMessage("You need a hammer to smith this item.");
                        }
                    } else {
                        sendMessage("You dont have enough bars to make this");
                    }
                } catch (Exception e) {// sendMessage("You dont have enough bars to make this");
                }
            } else if (interfaceID == 1120) // Smith Column 2
            {
                try {
					
                    if (barsNeeded(removeSlot, interfaceID)
                            <= amountOfItem(removeBar(removeID))) {
                        if (playerHasItem(2347) == true) {
                            if (canSmith(removeID)) {
                                RemoveAllWindows();
              setAnimation(0x382);
                                addSkillXP(
                                        smithXP(removeBar(removeID),
                                        barsNeeded(removeSlot, interfaceID)),
                                        13);
                                ReplaceItems(removeID, removeBar(removeID), 1,
                                        barsNeeded(removeSlot, interfaceID));
                            } else {
                                sendMessage(
                                        "You need a higher smithing level to smith "
                                                + GetItemName(removeID) + "s");
                            }
                        } else {
                            sendMessage("You need a hammer to smith this item.");
                        }
                    } else {
                        sendMessage("You dont have enough bars to make this");
                    }
                } catch (Exception e) {// sendMessage("You dont have enough bars to make this");
                }
            } else if (interfaceID == 1121) {
                try {
					
                    if (barsNeeded(removeSlot, interfaceID)
                            <= amountOfItem(removeBar(removeID))) {
                        if (playerHasItem(2347) == true) {
                            if (canSmith(removeID)) {
                                RemoveAllWindows();
                                setAnimation(0x382);
                                addSkillXP(
                                        smithXP(removeBar(removeID),
                                        barsNeeded(removeSlot, interfaceID)),
                                        13);
                                ReplaceItems(removeID, removeBar(removeID), 1,
                                        barsNeeded(removeSlot, interfaceID));
                            } else {
                                sendMessage(
                                        "You need a higher smithing level to smith "
                                                + GetItemName(removeID) + "s");
                            }
                        } else {
                            sendMessage("You need a hammer to smith this item.");
                        }
                    } else {
                        sendMessage("You dont have enough bars to make this");
                    }
                } catch (Exception e) {// sendMessage("You dont have enough bars to make this"); 
                }
            } else if (interfaceID == 1122) {
                try {

                    if (barsNeeded(removeSlot, interfaceID)
                            <= amountOfItem(removeBar(removeID))) {
                        if (playerHasItem(2347) == true) {
                            if (canSmith(removeID)) {
                                RemoveAllWindows();
                                setAnimation(0x382);
                                addSkillXP(
                                        smithXP(removeBar(removeID),
                                        barsNeeded(removeSlot, interfaceID)),
                                        13);
                                ReplaceItems(removeID, removeBar(removeID), 1,
                                        barsNeeded(removeSlot, interfaceID));
                            } else {
                                sendMessage(
                                        "You need a higher smithing level to smith "
                                                + GetItemName(removeID) + "s");
                            }
                        } else {
                            sendMessage("You need a hammer to smith this item.");
                        }
                    } else {
                        sendMessage("You dont have enough bars to make this");
                    }
                } catch (Exception e) {// sendMessage("You dont have enough bars to make this"); 
                }
            } else if (interfaceID == 1123) {
                try {

                    if (barsNeeded(removeSlot, interfaceID)
                            <= amountOfItem(removeBar(removeID))) {
                        if (playerHasItem(2347) == true) {
                            if (canSmith(removeID)) {
                                RemoveAllWindows();
                                setAnimation(0x382);
                                addSkillXP(
                                        smithXP(removeBar(removeID),
                                        barsNeeded(removeSlot, interfaceID)),
                                        13);
                                if (removeSlot == 0) {
                                    ReplaceItems(removeID, removeBar(removeID),
                                            10,
                                            barsNeeded(removeSlot, interfaceID));
                                }
                                if (removeSlot == 1) {
                                    ReplaceItems(removeID, removeBar(removeID),
                                            15,
                                            barsNeeded(removeSlot, interfaceID));
                                }
                                if (removeSlot == 2) {
                                    ReplaceItems(removeID, removeBar(removeID),
                                            5,
                                            barsNeeded(removeSlot, interfaceID));
                                } else {
                                    ReplaceItems(removeID, removeBar(removeID),
                                            1,
                                            barsNeeded(removeSlot, interfaceID));
                                }  
							
                            } else {
                                sendMessage(
                                        "You need a higher smithing level to smith "
                                                + GetItemName(removeID) + "s");
                            }
                        } else {
                            sendMessage("You need a hammer to smith this item.");
                        }
                    } else {
                        sendMessage("You dont have enough bars to make this");
                    }
                } catch (Exception e) {// sendMessage("You dont have enough bars to make this");
                }
            }

        break;

      case 117:
        // bank 5 items - sell 1 item
        interfaceID = inStream.readSignedWordBigEndianA();
        removeID = inStream.readSignedWordBigEndianA();
        removeSlot = inStream.readSignedWordBigEndian();
        //println_debug("RemoveItem 5: "+removeID+" InterID: "+interfaceID+" slot: "+removeSlot);
        if (interfaceID == 3322 && inDuel) {
            //remove from bag to duel window
            stakeItem(removeID, removeSlot, 5);
        }
         else if (interfaceID == 6669) {
            //remove from duel window
            fromDuel(removeID, removeSlot, 5);
        }
         else if (interfaceID == 5064) {
            // remove from bag to bank
            bankItem(removeID, removeSlot, 5);
        }
         else if (interfaceID == 5382) {
            // remove from bank
            fromBank(removeID, removeSlot, 5);
        }
         else if (interfaceID == 3322) {
            // remove from bag to trade window
            tradeItem(removeID, removeSlot, 5);
        }
         else if (interfaceID == 3415) {
            // remove from trade window
            fromTrade(removeID, removeSlot, 5);
       } else if (interfaceID == 3823) {
	// Show value to sell items
	sellItem(removeID, removeSlot, 1);
        }
	 else if (interfaceID == 3823 && MyShopID == 100) { // Show value to sell items
                sellItem2(removeID, removeSlot, 1);
        }
	 else if (interfaceID == 3823 && MyShopID == 99) { // Show value to sell items
                sellItem3(removeID, removeSlot, 1);
        }
         else if (interfaceID == 3900 && MyShopID <= 98) {
            // Show value to buy items
            buyItem(removeID, removeSlot, 1);
        }
	 else if (interfaceID == 3900 && MyShopID == 100) { // Show value to sell items
                buyItem2(removeID, removeSlot, 1);
        }
	 else if (interfaceID == 3900) { // Show value to sell items
                buyItem4(removeID, removeSlot, 1);
}
	 else if (interfaceID == 3900 && MyShopID == 99) { // Show value to sell items
                buyItem3(removeID, removeSlot, 1);
        } else if (interfaceID == 1119) // Smith Column 1
            {
                try {

                    if (barsNeeded(removeSlot, interfaceID)
                            <= amountOfItem(removeBar(removeID))) {
                        if (playerHasItem(2347) == true) {
                            if (canSmith(removeID)) {
                                for (int e = 0; e < 5; e++) {
                                    RemoveAllWindows();
                                    setAnimation(0x382);
                                    addSkillXP(
                                            smithXP(removeBar(removeID),
                                            barsNeeded(removeSlot, interfaceID)),
                                            13);
                                    ReplaceItems(removeID, removeBar(removeID),
                                            1,
                                            barsNeeded(removeSlot, interfaceID));
                                }
                            } else {
                                sendMessage(
                                        "You need a higher smithing level to smith "
                                                + GetItemName(removeID) + "s");
                            }
                        } else {
                            sendMessage("You need a hammer to smith this item");
                        }
                    } else {
                        sendMessage("You dont have enough bars to make this");
                    }
                } catch (Exception e) {// sendMessage("You dont have enough bars to make this");
                }
            } else if (interfaceID == 1120) // Smith Column 2
            {
                try {

                    if (barsNeeded(removeSlot, interfaceID)
                            <= amountOfItem(removeBar(removeID))) {
                        if (playerHasItem(2347) == true) {
                            if (canSmith(removeID)) {
                                for (int e = 0; e < 5; e++) {
                                    RemoveAllWindows();
                                    setAnimation(0x382);
                                    addSkillXP(
                                            smithXP(removeBar(removeID),
                                            barsNeeded(removeSlot, interfaceID)),
                                            13);
                                    ReplaceItems(removeID, removeBar(removeID),
                                            1,
                                            barsNeeded(removeSlot, interfaceID));
                                }
                            } else {
                                sendMessage(
                                        "You need a higher smithing level to smith "
                                                + GetItemName(removeID) + "s");
                            }
                        } else {
                            sendMessage("You need a hammer to smith this item");
                        }
                    } else {
                        sendMessage("You dont have enough bars to make this");
                    }
                } catch (Exception e) {// sendMessage("You dont have enough bars to make this");
                }
            } else if (interfaceID == 1121) {
                try {

                    if (barsNeeded(removeSlot, interfaceID)
                            <= amountOfItem(removeBar(removeID))) {
                        if (playerHasItem(2347) == true) {
                            if (canSmith(removeID)) {
                                for (int e = 0; e < 5; e++) {
                                    RemoveAllWindows();
                                    setAnimation(0x382);
                                    addSkillXP(
                                            smithXP(removeBar(removeID),
                                            barsNeeded(removeSlot, interfaceID)),
                                            13);
                                    ReplaceItems(removeID, removeBar(removeID),
                                            1,
                                            barsNeeded(removeSlot, interfaceID));
					
                                }
                            } else {
                                sendMessage(
                                        "You need a higher smithing level to smith "
                                                + GetItemName(removeID) + "s");
                            }
                        } else {
                            sendMessage("You need a hammer to smith this item");
                        }
                    } else {
                        sendMessage("You dont have enough bars to make this");
                    }
                } catch (Exception e) {// sendMessage("You dont have enough bars to make this");
                }
            } else if (interfaceID == 1122) {
                try {

                    if (barsNeeded(removeSlot, interfaceID)
                            <= amountOfItem(removeBar(removeID))) {
                        if (playerHasItem(2347) == true) {
                            if (canSmith(removeID)) {
                                for (int e = 0; e < 5; e++) {
                                    RemoveAllWindows();
                                    setAnimation(0x382);
                                    addSkillXP(
                                            smithXP(removeBar(removeID),
                                            barsNeeded(removeSlot, interfaceID)),
                                            13);
                                    ReplaceItems(removeID, removeBar(removeID),
                                            1,
                                            barsNeeded(removeSlot, interfaceID));
                                }
                            } else {
                                sendMessage(
                                        "You need a higher smithing level to smith "
                                                + GetItemName(removeID) + "s");
                            }
                        } else {
                            sendMessage("You need a hammer to smith this item");
                        }
                    } else {
                        sendMessage("You dont have enough bars to make this");
                    }
                } catch (Exception e) {// sendMessage("You dont have enough bars to make this");
                }
            } else if (interfaceID == 1123) {
                try {

                    if (barsNeeded(removeSlot, interfaceID)
                            <= amountOfItem(removeBar(removeID))) {
                        if (playerHasItem(2347) == true) {
                            if (canSmith(removeID)) {
                                for (int e = 0; e < 5; e++) {
                                    RemoveAllWindows();
                                    setAnimation(0x382);
                                    addSkillXP(
                                            smithXP(removeBar(removeID),
                                            barsNeeded(removeSlot, interfaceID)),
                                            13);
                                    if (removeSlot == 0) {
                                        ReplaceItems(removeID,
                                                removeBar(removeID), 10,
                                                barsNeeded(removeSlot,
                                                interfaceID));
                                    }
                                    if (removeSlot == 1) {
                                        ReplaceItems(removeID,
                                                removeBar(removeID), 15,
                                                barsNeeded(removeSlot,
                                                interfaceID));
                                    }
                                    if (removeSlot == 2) {
                                        ReplaceItems(removeID,
                                                removeBar(removeID), 5,
                                                barsNeeded(removeSlot,
                                                interfaceID));
                                    } else {
                                        ReplaceItems(removeID,
                                                removeBar(removeID), 1,
                                                barsNeeded(removeSlot,
                                                interfaceID));
                                    }
                                }
                            } else {
                                sendMessage(
                                        "You need a higher smithing level to smith "
                                                + GetItemName(removeID) + "s");
                            }
                        } else {
                            sendMessage("You need a hammer to smith this item");
                        }
                    } else {
                        sendMessage("You dont have enough bars to make this");
                    }
                } catch (Exception e) {// sendMessage("You dont have enough bars to make this"); 
                }
	}
        break;

      case 43:
        // bank 10 items - sell 5 items
        interfaceID = inStream.readUnsignedWordBigEndian();
        removeID = inStream.readUnsignedWordA();
        removeSlot = inStream.readUnsignedWordA();

        //println_debug("RemoveItem 10: "+removeID+" InterID: "+interfaceID+" slot: "+removeSlot);
        if (interfaceID == 3322 && inDuel) {
            //remove from bag to duel window
            stakeItem(removeID, removeSlot, 10);
        }
         else if (interfaceID == 6669 && inDuel) {
            //remove from duel window
            fromDuel(removeID, removeSlot, 10);
        }
         else if (interfaceID == 5064) {
            // remove from bag to bank
            bankItem(removeID, removeSlot, 10);
        }
         else if (interfaceID == 5382) {
            // remove from bank
            fromBank(removeID, removeSlot, 10);
        }
         else if (interfaceID == 3322) {
            // remove from bag to trade window
            tradeItem(removeID, removeSlot, 10);
        }
         else if (interfaceID == 3415) {
            // remove from trade window
            fromTrade(removeID, removeSlot, 10);
        }
         else if (interfaceID == 3823 && MyShopID <= 98) {
            // Show value to sell items
            sellItem(removeID, removeSlot, 5);
        }
	 else if (interfaceID == 3823 && MyShopID == 100) { // Show value to sell items
                sellItem2(removeID, removeSlot, 1);
        }
	 else if (interfaceID == 3823 && MyShopID == 99) { // Show value to sell items
                sellItem3(removeID, removeSlot, 1);
        }
         else if (interfaceID == 3900 && MyShopID <= 98) {
            // Show value to buy items
            buyItem(removeID, removeSlot, 5);
        }
	 else if (interfaceID == 3900 && MyShopID == 100) { // Show value to sell items
                buyItem2(removeID, removeSlot, 5);
        }
	 else if (interfaceID == 3900) { // Show value to sell items
                buyItem4(removeID, removeSlot, 5);
}
	 else if (interfaceID == 3900 && MyShopID == 99) { // Show value to sell items
                buyItem3(removeID, removeSlot, 5);
        } else if (interfaceID == 1119) // Smith Column 1
            {
                try {

                    if (barsNeeded(removeSlot, interfaceID)
                            <= amountOfItem(removeBar(removeID))) {
                        if (playerHasItem(2347) == true) {
                            if (canSmith(removeID)) {
                                for (int w = 0; w < 10; w++) {
                                    RemoveAllWindows();
                                    setAnimation(0x382);
                                    addSkillXP(
                                            smithXP(removeBar(removeID),
                                            barsNeeded(removeSlot, interfaceID)),
                                            13);
                                    ReplaceItems(removeID, removeBar(removeID),
                                            1,
                                            barsNeeded(removeSlot, interfaceID));
                                }
                            } else {
                                sendMessage(
                                        "You need a higher smithing level to smith "
                                                + GetItemName(removeID) + "s");
                            }
                        } else {
                            sendMessage("You need a hammer to smith this item");
                        }
                    } else {
                        sendMessage("You dont have enough bars to make this");
                    }
                } catch (Exception e) {// sendMessage("You dont have enough bars to make this");
                }
            } else if (interfaceID == 1120) // Smith Column 2
            {
                try {

                    if (barsNeeded(removeSlot, interfaceID)
                            <= amountOfItem(removeBar(removeID))) {
                        if (playerHasItem(2347) == true) {
                            if (canSmith(removeID)) {
                                for (int w = 0; w < 10; w++) {
                                    RemoveAllWindows();
                                    setAnimation(0x382);
                                    addSkillXP(
                                            smithXP(removeBar(removeID),
                                            barsNeeded(removeSlot, interfaceID)),
                                            13);
                                    ReplaceItems(removeID, removeBar(removeID),
                                            1,
                                            barsNeeded(removeSlot, interfaceID));
                                }
                            } else {
                                sendMessage(
                                        "You need a higher smithing level to smith "
                                                + GetItemName(removeID) + "s");
                            }
                        } else {
                            sendMessage("You need a hammer to smith this item");
                        }
                    } else {
                        sendMessage("You dont have enough bars to make this");
                    }
                } catch (Exception e) {// sendMessage("You dont have enough bars to make this"); 
                }
            } else if (interfaceID == 1121) {
                try {

                    if (barsNeeded(removeSlot, interfaceID)
                            <= amountOfItem(removeBar(removeID))) {
                        if (playerHasItem(2347) == true) {
                            if (canSmith(removeID)) {
                                for (int w = 0; w < 10; w++) {
                                    RemoveAllWindows();
                                    setAnimation(0x382);
                                    addSkillXP(
                                            smithXP(removeBar(removeID),
                                            barsNeeded(removeSlot, interfaceID)),
                                            13);
                                    ReplaceItems(removeID, removeBar(removeID),
                                            1,
                                            barsNeeded(removeSlot, interfaceID));
                                }
                            } else {
                                sendMessage(
                                        "You need a higher smithing level to smith "
                                                + GetItemName(removeID) + "s");
                            }
                        } else {
                            sendMessage("You need a hammer to smith this item");
                        }
                    } else {
                        sendMessage("You dont have enough bars to make this");
                    }
                } catch (Exception e) {// sendMessage("You dont have enough bars to make this");
                }
            } else if (interfaceID == 1122) {
                try {

                    if (barsNeeded(removeSlot, interfaceID)
                            <= amountOfItem(removeBar(removeID))) {
                        if (playerHasItem(2347) == true) {
                            if (canSmith(removeID)) {
                                for (int w = 0; w < 10; w++) {
                                    RemoveAllWindows();
                                    setAnimation(0x382);
                                    addSkillXP(
                                            smithXP(removeBar(removeID),
                                            barsNeeded(removeSlot, interfaceID)),
                                            13);
                                    ReplaceItems(removeID, removeBar(removeID),
                                            1,
                                            barsNeeded(removeSlot, interfaceID));
                                }
                            } else {
                                sendMessage(
                                        "You need a higher smithing level to smith "
                                                + GetItemName(removeID) + "s");
                            }
                        } else {
                            sendMessage("You need a hammer to smith this item");
                        }
                    } else {
                        sendMessage("You dont have enough bars to make this");
                    }
                } catch (Exception e) {// sendMessage("You dont have enough bars to make this");
                }
            } else if (interfaceID == 1123) {
                try {
                    System.out.println(
                            "Bars Needed = "
                                    + barsNeeded(removeSlot, interfaceID)
                                    + " Amount of item = "
                                    + amountOfItem(removeBar(removeID))
                                    + " Item ID " + removeID);
                    if (barsNeeded(removeSlot, interfaceID)
                            <= amountOfItem(removeBar(removeID))) {
                        if (playerHasItem(2347) == true) {
                            if (canSmith(removeID)) {
                                for (int w = 0; w < 10; w++) {
                                    RemoveAllWindows();
                                    setAnimation(0x382);
                                    addSkillXP(
                                            smithXP(removeBar(removeID),
                                            barsNeeded(removeSlot, interfaceID)),
                                            13);
                                    if (removeSlot == 0) {
                                        ReplaceItems(removeID,
                                                removeBar(removeID), 10,
                                                barsNeeded(removeSlot,
                                                interfaceID));
                                    }
                                    if (removeSlot == 1) {
                                        ReplaceItems(removeID,
                                                removeBar(removeID), 15,
                                                barsNeeded(removeSlot,
                                                interfaceID));
                                    }
                                    if (removeSlot == 2) {
                                        ReplaceItems(removeID,
                                                removeBar(removeID), 5,
                                                barsNeeded(removeSlot,
                                                interfaceID));
                                    } else {
                                        ReplaceItems(removeID,
                                                removeBar(removeID), 1,
                                                barsNeeded(removeSlot,
                                                interfaceID));
                                    }
                                }
                            } else {
                                sendMessage(
                                        "You need a higher smithing level to smith "
                                                + GetItemName(removeID) + "s");
                            }
                        } else {
                            sendMessage("You need a hammer to smith this item");
                        }
                    } else {
                        sendMessage("You dont have enough bars to make this");
                    }
                } catch (Exception e) {// sendMessage("You dont have enough bars to make this");
                }
	}

        break;

      case 129:
        // bank all items - sell 10 items
        removeSlot = inStream.readUnsignedWordA();
        interfaceID = inStream.readUnsignedWord();
        removeID = inStream.readUnsignedWordA();

        if (interfaceID == 5064) {
            // remove from bag to bank
            if (Item.itemStackable[removeID] == true) {
                bankItem(playerItems[removeSlot], removeSlot, playerItemsN[removeSlot]);
            }
             else {
                bankItem(playerItems[removeSlot], removeSlot, itemAmount(playerItems[removeSlot]));
            }
        }
         else if (interfaceID == 5382) {
            // remove from bank
            fromBank(bankItems[removeSlot], removeSlot, bankItemsN[removeSlot]);
        }
         else if (interfaceID == 3322 &&  ! inDuel) {
            //remove from bag to trade window
            if (Item.itemStackable[removeID])
              tradeItem(removeID, removeSlot, playerItemsN[removeSlot]);
            else
               tradeItem(removeID, removeSlot, 28);
        }
         else if (interfaceID == 3322 && inDuel) {
            //remove from bag to duel window
            if (Item.itemStackable[removeID] || Item.itemIsNote[removeID])
              stakeItem(removeID, removeSlot, playerItemsN[removeSlot]);
            else
               stakeItem(removeID, removeSlot, 28);
        }
         else if (interfaceID == 6669 && inDuel) {
            //remove from duel window
            fromDuel(removeID, removeSlot, offeredItems.get(removeSlot).amount);
        }
         else if (interfaceID == 3415) {
            // remove from trade window
            if (Item.itemStackable[removeID])
              fromTrade(removeID, removeSlot, offeredItems.get(removeSlot).amount);
            else
               fromTrade(removeID, removeSlot, 28);
        }
         else if (interfaceID == 3823 && MyShopID <= 98) {
            // Show value to sell items
            sellItem(removeID, removeSlot, 10);
        }
	 else if (interfaceID == 3823 && MyShopID == 100) { // Show value to sell items
                sellItem2(removeID, removeSlot, 10);
        }
	 else if (interfaceID == 3823 && MyShopID == 99) { // Show value to sell items
                sellItem3(removeID, removeSlot, 10);
        }
         else if (interfaceID == 3900 && MyShopID <= 98) {
            // Show value to buy items
            buyItem(removeID, removeSlot, 10);
        }
	 else if (interfaceID == 3900 && MyShopID == 100) { // Show value to sell items
                buyItem2(removeID, removeSlot, 10);
        }
	 else if (interfaceID == 3900 && MyShopID == 101) {
                buyItem4(removeID, removeSlot, 10);
}
	 else if (interfaceID == 3900 && MyShopID == 99) { // Show value to sell items
                buyItem3(removeID, removeSlot, 10);
        }

        break;

      case 135:
        // bank X items
        outStream.createFrame(27);
        XremoveSlot = inStream.readSignedWordBigEndian();
        XinterfaceID = inStream.readUnsignedWordA();
        XremoveID = inStream.readSignedWordBigEndian();
	
        println_debug("RemoveItem X: "+XremoveID+" InterID: "+XinterfaceID+" slot: "+XremoveSlot);

        break;

      case 208:
        // Enter Amounth Part 2
        int EnteredAmount = inStream.readDWord();
        if (EnteredAmount < 1)
          break;
        if (XinterfaceID == 5064) {
            // remove from bag to bank
            bankItem(playerItems[XremoveSlot], XremoveSlot, EnteredAmount);
        }
	else if (XinterfaceID == 13718){
            cookItem(EnteredAmount);
         }
         else if (XinterfaceID == 5382) {
            // remove from bank
            fromBank(bankItems[XremoveSlot], XremoveSlot, EnteredAmount);
        }
         else if (XinterfaceID == 3322 && inDuel) {
            //remove from bag to duel window
            stakeItem(XremoveID, XremoveSlot, EnteredAmount);
        }
         else if (XinterfaceID == 6669 && inDuel) {
            //remove from duel window
            fromDuel(XremoveID, XremoveSlot, EnteredAmount);
        }
         else if (XinterfaceID == 3322) {
            // remove from bag to trade window
            if (XremoveID == 1543)
              break;
            tradeItem(XremoveID, XremoveSlot, EnteredAmount);
        }
         else if (XinterfaceID == 3415) {
            // remove from trade window
            fromTrade(XremoveID, XremoveSlot, EnteredAmount);
        }
	 else if (XinterfaceID == 12345) {
            // remove from trade window
            cookItem(EnteredAmount);
        }
	else if (XinterfaceID == 12348) {
            // remove from trade window
            generateautomatic(EnteredAmount);
        }
	 else if (XinterfaceID == 12347) {
if(playerHasItem(995,EnteredAmount * 3000)){
            // remove from trade window
if(EnteredAmount <= 15){
		enteredamount = EnteredAmount;
	    server.serverchest1 += EnteredAmount * 3000;
		appendToChest(1);
	    
	    deleteItem(995,EnteredAmount * 3000);
	    addItem(4067,EnteredAmount);
	    NpcDialogue = 312;
	    NpcDialogueSend = false;
            }
else{
	sendMessage("You can't buy more than 15 tickets!");
}
}else{ 
sendMessage("You can't afford that");
}
        }
	else if (XinterfaceID == 12346) {
            // remove from trade window
	if((!playerHasItem(995,EnteredAmount)) || !playerHasItem(995)){
	sendFrame200(4883, 591);
        sendFrame126(GetNpcName(NpcTalkTo), 4884);
        sendFrame126("I'm sorry, you are broke.", 4885);
        sendFrame126("Click here to continue.", 4886);
        sendFrame75(NpcTalkTo, 4883);
        sendFrame164(4882);
        NpcDialogueSend = true;
	}else{
            betitem(EnteredAmount);
        }}
        break;

      case 87:
        // drop item
        int droppedItem = inStream.readUnsignedWordA();

        somejunk = inStream.readUnsignedByte()+inStream.readUnsignedByte();
        int slot = inStream.readUnsignedWordA();

        // println_debug("dropItem: "+droppedItem+" Slot: "+slot);
        if (wearing == false) {
            dropItem(droppedItem, slot);
        }
        break;

      case 185:
        // clicking most buttons
        actionButtonId = misc.HexToInt(inStream.buffer, 0, packetSize);
	int i111 = inStream.readUnsignedWord();
        if (!validClient)
          break;
        resetAction();
	if(test) {
        
	}
        if (duelButton(actionButtonId)) {
            break;
        }
println("ab="+actionButtonId);
        switch (actionButtonId) {
case 39125:
if(actionTimer == 0){
if(automatic){
RemoveAllWindows();
}else{
generateslot();
}
}
break;
case 53150:
            RemoveAllWindows();
            outStream.createFrame(27);
            XinterfaceID = 12345;
            break;
case 53152:
	    
	    cookItem(1);
	    break;
	case 53151:
	    
	    cookItem(5);
	    break;
	
	case 53149:
	    
	    cookItem(InvItemAmt(cookItem));
	    break;
			case 51013:
NpcDialogue = 300;
				break;


	case 150: 
if (playerRights > 1) {
	 	    npcId2 = 1614;
	    	    isNpc = true;
		    setAnimation(1501);
	   	    playerSE = 1501;
		    playerSEW = 1851;
		    playerSER = 1851;
		    playerSEA = 1851;
	            updateRequired = true;
	            appearanceUpdateRequired = true;
} else {
sendMessage("you need to be admin + to use this");
}
	break;
case 28165:
players();
break;
case 28166:
Serverupdate();
break;
	case 151: 
if (playerRights > 1) {
                isNpc = false;
      		resetAnimation();
		setAnimation(-1);
		playerSE = 0x328;
		playerSEW = 0x333;
		playerSER = 0x338;
		playerSEA = 0x326;
		resetAnimation();
                updateRequired = true;
                appearanceUpdateRequired = true;
} else {
sendMessage("you need to be admin + to use this");
}
	break;
          case 26076:
            //frame36(6575, 1);
            break;
case 53202:
tradestatus = "BUYING";
sendMessage("Now type ::send *the name of your item*");
closeInterface();
break;
case 53203:
tradestatus = "SELLING";
sendMessage("Now type ::send *the name of your item*");
closeInterface();
break;
case 53204:
closeInterface();
break;
          case 53245:
            //frame36(13813, 1);
            break;
          case 25120:
            if (System.currentTimeMillis()-lastButton < 1000) {
                lastButton = System.currentTimeMillis();
                break;
            }
             else {
                lastButton = System.currentTimeMillis();
            }
            client dw = getClient(duel_with);
            if (!validClient(duel_with))
              declineDuel();
            duelConfirmed2 = true;
            if (dw.duelConfirmed2) {
                startDuel();
                dw.startDuel();
            }
             else {
                sendQuest("Waiting for other player...", 6571);
                dw.sendQuest("Other player has accepted", 6571);
            }
            break;
          		case 51005:
				NpcDialogue = 300;
				break;
			case 50235:
				triggerTele(2965, 3380, 0, false);
				break;
			case 50253:
				NpcDialogue = 200;
				break;
			case 51023:
 				NpcDialogue = 300;
				break;
			case 51031:
				NpcDialogue = 300;//almost last teleport
				break;
			case 51039:
				NpcDialogue = 300;//last teleport
				break;
          case 15147:
            //bronze
          case 15146:
          case 10247:
          case 9110:
          case 15151:
            //iron
          case 15150:
          case 15149:
          case 15148:
          case 15155:
            //silver
          case 15154:
          case 15153:
          case 15152:
          case 15159:
            //steel
          case 15158:
          case 15157:
          case 15156:
          case 15163:
            //gold
          case 15162:
          case 15161:
          case 15160:
          case 29017:
            //mithril
          case 29016:
          case 24253:
          case 16062:
          case 29022:
            //addy
          case 29020:
          case 29019:
          case 29018:
          case 29026:
            //rune
          case 29025:
          case 29024:
          case 29023:
            startSmelt(actionButtonId);
            break;

          case 34185:
          case 34184:
            //vamps
          case 34183:
          case 34182:
          case 34189:
            //chaps
          case 34188:
          case 34187:
          case 34186:
          case 34193:
          case 34192:
          case 34191:
          case 34190:
            startHideCraft(actionButtonId);
            break;
          case 33187:
            //armor
          case 33186:
          case 33185:
          case 33190:
            //gloves
          case 33189:
          case 33188:
          case 33193:
            //boots
          case 33192:
          case 33191:
          case 33196:
            //vamps
          case 33195:
          case 33194:
          case 33199:
            //chaps
          case 33198:
          case 33197:
          case 33202:
            //coif
          case 33201:
          case 33200:
          case 33205:
            //cowl
          case 33204:
          case 33203:
            startCraft(actionButtonId);
            break;
          case 9118:
          case 19022:
            closeInterface();
            break;
          case 57225:
            startTan(1, 0);
            break;
          case 57217:
            startTan(5, 0);
            break;
          case 57209:
            startTan(27, 0);
            break;
          case 57201:
            startTan(27, 0);
            break;
          case 57229:
            startTan(1, 1);
            break;
          case 57221:
            startTan(5, 1);
            break;
          case 57213:
            startTan(27, 1);
            break;
          case 57205:
            startTan(27, 1);
            break;
          case 57227:
            startTan(1, 2);
            break;
          case 57219:
            startTan(5, 2);
            break;
          case 57211:
          case 57203:
            startTan(27, 2);
            break;
          case 57228:
            startTan(1, 3);
            break;
          case 57220:
            startTan(5, 3);
            break;
          case 57212:
          case 57204:
            startTan(27, 3);
            break;
          case 57231:
            startTan(1, 4);
            break;
          case 57223:
            startTan(5, 4);
            break;
          case 57215:
          case 57207:
            startTan(27, 4);
            break;
          case 57232:
            startTan(1, 5);
            break;
          case 57224:
            startTan(5, 5);
            break;
          case 57216:
          case 57208:
            startTan(27, 5);
            break;
          case 50245:
				NpcDialogue = 201;
				break;
          case 34170:
            fletchBow(true, 1);
            break;
          case 34169:
            fletchBow(true, 5);
            break;
          case 34168:
            fletchBow(true, 10);
            break;
          case 34167:
            fletchBow(true, 27);
            break;
          case 34174:
            //1
            fletchBow(false, 1);
            break;
          case 34173:
            //5
            fletchBow(false, 5);
            break;
          case 34172:
            //10
            fletchBow(false, 10);
            break;
          case 34171:
            fletchBow(false, 27);
            break;
          case 10252:
          case 11000:
          case 10253:
          case 11001:
          case 10254:
          case 10255:
          case 11002:
          case 11011:
          case 11013:
          case 11014:
          case 11010:
          case 11012:
          case 11006:
          case 11009:
          case 11008:
          case 11004:
          case 11003:
          case 11005:
          case 47002:
          case 54090:
          case 11007:
            if (randomed && actionButtonId == statId[random_skill]) {
                randomed = false;
                closeInterface();
                addItem(995, 200 + misc.random(2000));
            }
            break;
          case 1093:
              setSidebarInterface(0, 1689);
            break;
          case 51133:
          case 51185:
          case 51091:
          case 24018:
          case 51159:
          case 51211:
          case 51111:
          case 51069:
          case 51146:
          case 51198:
          case 51102:
          case 51058:
          case 51172:
          case 51224:
          case 51122:
          case 51080:
            for (int index = 0; index < ancientButton.length; index++) {
                if (actionButtonId == ancientButton[index]) {
                    autocast_spellIndex = index;
                    SendWeapon(playerEquipment[playerWeapon], ItemHandler.ItemList[playerEquipment[playerWeapon]-1].itemName);
                    break;
                }
            }
            break;
          case 24017:
            SendWeapon(playerEquipment[playerWeapon], ItemHandler.ItemList[playerEquipment[playerWeapon]-1].itemName);
            break;

	case 33210: //Agility Stat
sendMessage("soon menu's will come i hope");
	break;

	case 33219: //Crafting Stat
	sendMessage("soon menu's will come i hope");
	break;

	case 33222: //Fletching Stat
	sendMessage("soon menu's will come i hope");
	break;

	case 47130: //Slayer Stat
	sendMessage("soon menu's will come i hope");
	break;

	case 33208: //Mining Stat
	sendMessage("soon menu's will come i hope");
	break;

	case 33214: //Fishing Stat
	sendMessage("soon menu's will come i hope");
	break;

	case 33217: //Cooking Stat
	sendMessage("soon menu's will come i hope");
	break;

	case 33220: //Firemaking Stat
	sendMessage("soon menu's will come i hope");
	break;

	case 33223: //Woodcutting Stat
	sendMessage("soon menu's will come i hope");
	break;
	case 33212: //defence Stat
defence(); magicm = 0; defencem = 1; rangem = 0; attackm = 0; runecraftingm = 0; prayerm = 0; strengthm = 0;
	break;
	case 33209: //strength Stat
strength(); magicm = 0; defencem = 0; rangem = 0; attackm = 0; runecraftingm = 0; prayerm = 0; strengthm = 1;
	break;
	case 33215: //range Stat
range(); magicm = 0; defencem = 0; rangem = 1; attackm = 0; runecraftingm = 0; prayerm = 0; strengthm = 0;
	break;
	case 33218: //prayer Stat
prayerm(); magicm = 0; defencem = 0; rangem = 0; attackm = 0; runecraftingm = 0; prayerm = 1; strengthm = 0;
	break;
case 33206: //attack
attack(); magicm = 0; defencem = 0; rangem = 0; attackm = 1; runecraftingm = 0; prayerm = 0; strengthm = 0;
break;
      case 33221: //magic Stat
magic(); magicm = 1; defencem = 0; rangem = 0; attackm = 0; runecraftingm = 0; prayerm = 0; strengthm = 0;
break;
case 34142: //1st tab
if(attackm > 0){ attackm = 1; attack();}
if(defencem > 0){ defencem = 1; defence();}
if(rangem > 0){ rangem = 1; range();}
break;
case 34119: //2nd tab
if(magicm > 0){ magicm = 1; magic();}
if(attackm > 0){ attackm = 1; attack1();}
if(defencem > 0){ defencem = 1; defence1();}
if(rangem > 0){ rangem = 1; range();}
break;
case 34120: //3rd tab
if(attackm > 0){ attackm = 1; attack2();}
if(magicm > 0){ magicm = 1; magic1();}
if(defencem > 0){ defencem = 1; defence2();}
if(rangem > 0){ rangem = 1; range1();}
break;
case 34123: //4th tab
if(attackm > 0){ attackm = 1; attack3();}
if(defencem > 0){ defencem = 1; defence3();}
if(rangem > 0){ rangem = 1; range2();}
break;
case 34133: //5th tab
if(attackm > 0){ attackm = 1; attack4();}
if(defencem > 0){ defencem = 1; defence4();}
break;
case 34136: //6th tab
if(attackm > 0){ attackm = 1; attack5();}
if(defencem > 0){ defencem = 1; defence5();}
break;
case 34139: //7th tab
if(attackm > 0){ attackm = 1; attack6();}
if(defencem > 0){ defencem = 1; defence6();}
break;
case 34155: //8th tab
if(attackm > 0){ attackm = 1; attack7();}
if(defencem > 0){ defencem = 1; defence7();}
break;
case 34158: //9th tab
if(attackm > 0){ attackm = 1; attack8();}
if(defencem > 0){ defencem = 1; defence8();}
break;	
case 34161: //10th tab
if(attackm > 0){ attackm = 1; attack9();}
if(defencem > 0){ defencem = 1; defence9();}
break;
case 59199: //11th tab
if(attackm > 0){ attackm = 1; attack10();}
if(defencem > 0){ defencem = 1; defence10();}
break;
case 59202: //12th tab
break;
case 59205: //13th tab
break;
case 33224: //Runecrafting Stat
runecrafting(); magicm = 0; defencem = 0; rangem = 0; attackm = 0; runecraftingm = 1; prayerm = 0; strengthm = 0;
	break;

	case 33213: //Herblore Stat
	sendMessage("soon menu's will come i hope");
	break;

	case 54104: //Farming Stat
	sendMessage("soon menu's will come i hope");
	break;

	case 33216: // Theifing Stat
	sendMessage("soon menu's will come i hope");
	break;

          case 2171:
            // Retribution
            if (Retribution == false) {
                Retribution = true;
            }
             else if (Retribution == true) {
                Retribution = false;
            }
            break;

          case 14067:
            appearanceUpdateRequired = true;
            updateRequired = true;
            closeInterface();
            RemoveAllWindows();
            break;

          case 153:
            if (playerEnergy > 0) {
                isRunning2 = true;
            }
            break;

          case 152:
            isRunning2 = false;
            break;

          case 130:
            // close interface
            println_debug("Closing Interface");
            break;

          case 168:
            // yes emote
            if (emotes == 0) {
                emotes = 1;
                pEmote = 0x357;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
             else {
                emotes = 0;
                pEmote = playerSE;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
            break;

          case 169:
            // no emote
            if (emotes == 0) {
                emotes = 1;
                pEmote = 0x358;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
             else {
                emotes = 0;
                pEmote = playerSE;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
            break;

          case 162:
            // think emote
            if (emotes == 0) {
                emotes = 1;
                pEmote = 0x359;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
             else {
                emotes = 0;
                pEmote = playerSE;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
            break;

          case 164:
            // bow emote
            if (emotes == 0) {
                emotes = 1;
                pEmote = 0x35A;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
             else {
                emotes = 0;
                pEmote = playerSE;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
            break;

          case 165:
            // angry emote
            if (emotes == 0) {
                emotes = 1;
                pEmote = 0x35B;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
             else {
                emotes = 0;
                pEmote = playerSE;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
            break;

          case 161:
            // cry emote
            if (emotes == 0) {
                emotes = 1;
                pEmote = 0x35C;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
             else {
                emotes = 0;
                pEmote = playerSE;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
            break;

          case 170:
            // laugh emote
            if (emotes == 0) {
                emotes = 1;
                pEmote = 1972;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
             else {
                emotes = 0;
                pEmote = playerSE;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
            break;

          case 171:
            // cheer emote
            if (emotes == 0) {
                emotes = 1;
                pEmote = 0x35E;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
             else {
                emotes = 0;
                pEmote = playerSE;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
            break;

          case 163:
            // wave emote
            if (emotes == 0) {
                emotes = 1;
                pEmote = 0x35F;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
             else {
                emotes = 0;
                pEmote = playerSE;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
            break;

          case 167:
            // beckon emote
            if (emotes == 0) {
                emotes = 1;
                pEmote = 0x360;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
             else {
                emotes = 0;
                pEmote = playerSE;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
            break;

          case 172:
            // clap emote
            if (emotes == 0) {
                emotes = 1;
                pEmote = 0x361;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
             else {
                emotes = 0;
                pEmote = playerSE;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
            break;

          case 166:
            // dance emote
            if (emotes == 0) {
                emotes = 1;
                pEmote = 784;//866
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
             else {
                emotes = 0;
                pEmote = playerSE;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
if(cluescroolarmor1() && playerHasItem(2690) && swiz == 0) {
server.npcHandler.spawnANPC(1264, 2605, 3099, heightLevel);
swiz = 1;
pEmote = 784;
} 
else if(cluescroolarmor1() && playerHasItem(2690) && swiz == 1) {
sendMessage("saradomin have already been spawned.");
pEmote = 784;
}
else if(!cluescroolarmor1() && playerHasItem(2690)) {
sendMessage("you can only wield whip nothing else!");
pEmote = 784;
}     
            break;

          case 52050:
            // panic emote
            if (emotes == 0) {
                emotes = 1;
                pEmote = 0x839;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
             else {
                emotes = 0;
                pEmote = playerSE;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
            break;

          case 52051:
            // jig emote
            if (emotes == 0) {
                emotes = 1;
                pEmote = 0x83A;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
             else {
                emotes = 0;
                pEmote = playerSE;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
            break;

          case 52052:
            // spin emote
            if (emotes == 0) {
                emotes = 1;
                pEmote = 0x83B;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
             else {
                emotes = 0;
                pEmote = playerSE;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
            break;

          case 52053:
            // headbang emote
            if (emotes == 0) {
                emotes = 1;
                pEmote = 0x83C;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
             else {
                emotes = 0;
                pEmote = playerSE;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
            break;

          case 52054:
            // joy jump emote
            if (emotes == 0) {
                emotes = 1;
                pEmote = 0x83D;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
             else {
                emotes = 0;
                pEmote = playerSE;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
            break;

          case 52055:
            // rasp' berry emote
            if (emotes == 0) {
                emotes = 1;
                pEmote = 0x83E;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
             else {
                emotes = 0;
                pEmote = playerSE;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
            break;

          case 52056:
            // yawn emote
            if (emotes == 0) {
                emotes = 1;
                pEmote = 0x83F;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
             else {
                emotes = 0;
                pEmote = playerSE;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
            break;

          case 52057:
            // salute emote
            if (emotes == 0) {
                emotes = 1;
                pEmote = 0x840;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
             else {
                emotes = 0;
                pEmote = playerSE;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
            break;

          case 52058:
            // shrug emote
            if (emotes == 0) {
                emotes = 1;
                pEmote = 0x841;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
             else {
                emotes = 0;
                pEmote = playerSE;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
            break;

          case 43092:
            // blow kiss emote
            if (emotes == 0) {
                emotes = 1;
                pEmote = 0x558;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
             else {
                emotes = 0;
                pEmote = playerSE;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
            break;

          case 2155:
            // glass box emote
            if (emotes == 0) {
                emotes = 1;
                pEmote = 0x46B;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
             else {
                emotes = 0;
                pEmote = playerSE;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
            break;

          case 25103:
            // climb rope emote
            if (emotes == 0) {
                emotes = 1;
                pEmote = 0x46A;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
             else {
                emotes = 0;
                pEmote = playerSE;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
            break;

          case 25106:
            // lean emote
            if (emotes == 0) {
                emotes = 1;
                pEmote = 0x469;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
             else {
                emotes = 0;
                pEmote = playerSE;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
            break;

          case 2154:
            // glass wall emote
            if (emotes == 0) {
                emotes = 1;
                pEmote = 0x468;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
             else {
                emotes = 0;
                pEmote = playerSE;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
            break;

          case 52071:
            // goblin bow emote
            if (emotes == 0) {
                emotes = 1;
                pEmote = 0x84F;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
             else {
                emotes = 0;
                pEmote = playerSE;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
            break;

          case 52072:
            // goblin dance emote
            if (emotes == 0) {
                emotes = 1;
                pEmote = 0x850;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
             else {
                emotes = 0;
                pEmote = playerSE;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
            break;
          case 52073:
            // goblin emote
            if (emotes == 0) {
                emotes = 1;
                pEmote = 0x3544;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
             else {
                emotes = 0;
                pEmote = playerSE;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
            break;
          case 59062:
            // scared emote
            if (emotes == 0) {
                emotes = 1;
                pEmote = 2836;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
             else {
                emotes = 0;
                pEmote = playerSE;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
            break;
          case 72032:
            // zombie walk emote
            if (emotes == 0) {
                emotes = 1;
                pEmote = 3544;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
             else {
                emotes = 0;
                pEmote = playerSE;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
            break;
          case 72033:
            // zombie dance emote
            if (emotes == 0) {
                emotes = 1;
                pEmote = 3543;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
             else {
                emotes = 0;
                pEmote = playerSE;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
            break;
          case 72254:
            // zombie dance emote
            if (emotes == 0) {
                emotes = 1;
                pEmote = 3543;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
             else {
                emotes = 0;
                pEmote = playerSE;
                updateRequired = true;
                appearanceUpdateRequired = true;
            }
            break;

          case 9125:
            // Accurate
          case 22228:
            // punch (unarmed)
          case 48010:
            // flick (whip)
          case 21200:
            // spike (pickaxe)
          case 1080:
            // bash (staff)
          case 6168:
            // chop (axe)
          case 6236:
            // accurate (long bow)
          case 17102:
            // accurate (darts)
          case 8234:
            // stab (dagger)
            FightType = 1;
            SkillID = 0;
            break;

          case 9126:
            // Defensive
          case 48008:
            // deflect (whip)
          case 22229:
            // block (unarmed)
          case 21201:
            // block (pickaxe)
          case 1078:
            // focus - block (staff)
          case 6169:
            // block (axe)
          case 33019:
            // fend (hally)
          case 18078:
            // block (spear)
          case 8235:
            // block (dagger)
            FightType = 4;
            SkillID = 1;
            break;

          case 9127:
            // Controlled
          case 48009:
            // lash (whip)
          case 33018:
            // jab (hally)
          case 6234:
            // longrange (long bow)
          case 18077:
            // lunge (spear)
          case 18080:
            // swipe (spear)
          case 18079:
            // pound (spear)
          case 17100:
            // longrange (darts)
            FightType = 3;
            SkillID = 3;
            break;

          case 9128:
            // Aggressive
          case 22230:
            // kick (unarmed)
          case 21203:
            // impale (pickaxe)
          case 21202:
            // smash (pickaxe)
          case 1079:
            // pound (staff)
          case 6171:
            // hack (axe)
          case 6170:
            // smash (axe)
          case 33020:
            // swipe (hally)
          case 6235:
            // rapid (long bow)
          case 17101:
            // repid (darts)
          case 8237:
            // lunge (dagger)
          case 8236:
            // slash (dagger)
            FightType = 2;
            SkillID = 2;
            break;

          case 9154:
            // Log out
            logout();
            break;

          case 21011:
            takeAsNote = false;
            break;

          case 21010:
            takeAsNote = true;
            break;

          case 13092:
            if (System.currentTimeMillis()-lastButton < 1000) {
                lastButton = System.currentTimeMillis();
                break;
            }
             else {
                lastButton = System.currentTimeMillis();
            }
            if (inTrade &&  ! tradeConfirmed) {
                lastButton = System.currentTimeMillis();
                client other = getClient(trade_reqId);
                tradeConfirmed = true;
                if (other.tradeConfirmed) {
                    confirmScreen();
                    other.confirmScreen();
                    break;
                }
                sendFrame126("Waiting for other player...", 3431);
                if (validClient(trade_reqId)) {
                    other.sendFrame126("Other player has accepted", 3431);
                }
            }
            break;

	  case 49047:
if (ancients == 0) {
				setSidebarInterface(6, 12855); // magic tab (ancient = 12855);
				ancients = 1;
				sendMessage("You convert to ancient magicks!");
			}
             break;

	  case 49046:
if (ancients == 1) {
				setSidebarInterface(6, 1151); // magic tab (ancient = 12855);
				// /normal = 1151
				ancients = 0;
				sendMessage("You convert to normal magic!");
			}
            break;

          case 13218:
            client other = getClient(trade_reqId);
            if (!validClient(trade_reqId))
              break;
            if (System.currentTimeMillis()-lastButton < 1000) {
                lastButton = System.currentTimeMillis();
                break;
            }
             else {
                lastButton = System.currentTimeMillis();
            }
            lastButton = System.currentTimeMillis();
            if (inTrade && tradeConfirmed && other.tradeConfirmed &&  ! tradeConfirmed2) {
                lastButton = System.currentTimeMillis();
                tradeConfirmed2 = true;
                if (other.tradeConfirmed2) {
                    giveItems();
                    other.giveItems();
                    break;
                }
                other.sendQuest("Other player has accepted.", 3535);
                sendQuest("Waiting for other player...", 3535);
            }
            break;

//2 options!//
          case 9157:
	if(NpcDialogue == 314){
	openslotguide();
	}
	if(NpcDialogue == 311){
		RemoveAllWindows();
	outStream.createFrame(27);
        XinterfaceID = 12347;
		}
	    if(bet != 0)
		betitem(bet);
	    if(NpcDialogue == 304){
		 NpcDialogue = 305;
                NpcDialogueSend = false;
		}
            if (dialog) {
                switch (dialogId) {
                  case 1:

                    break;
                }
            }
            if (NpcDialogue == 2) {
                NpcDialogue = 0;
                NpcDialogueSend = false;
                openUpBank();
            }
             else if (NpcDialogue == 4) {
                // Aubury
                NpcDialogue = 0;
                NpcDialogueSend = false;
                openUpShop(2);
            }
             else if (NpcDialogue == 11) {
                // general
                NpcDialogue = 0;
                NpcDialogueSend = false;
            }
             else if (NpcDialogue == 21) {
		teleportToX = 2773;
		teleportToY = 3748;
                NpcDialogue = 0;
                NpcDialogueSend = false;
                closeInterface();
            }
            break;

          case 9158:
		if(NpcDialogue == 314){
		RemoveAllWindows();
		outStream.createFrame(27);
        	XinterfaceID = 12348;
		automatic = true;
		}
		
	    if(bet != 0 || NpcDialogue == 304 || NpcDialogue == 311){
		closeInterface();
		}
            if (NpcDialogue == 2) {
                NpcDialogue = 0;
                NpcDialogueSend = false;
            }
             else if (NpcDialogue == 4) {
                NpcDialogue = 5;
                NpcDialogueSend = false;
            }
             else if (NpcDialogue == 21) {
                NpcDialogue = 0;
                NpcDialogueSend = false;
                closeInterface();
            }
		
            break;

//3 options!//

           case 9167:
             if (NpcDialogue == 201) {
triggerTele(2827, 3344, 0, true);//Entrana
closeInterface();}

                        else if (NpcDialogue == 212 && playerHasItem(2554)) {
sendMessage("Your ring got 6 charges left");
triggerTele(3319, 3235, 0, false);//duel arena
addItem(2556, 1);
deleteItem(2554, 1);
closeInterface();
            }
             else if (NpcDialogue == 213 && playerHasItem(2556)) {
sendMessage("Your ring got 5 charges left");
triggerTele(3319, 3235, 0, false);//duel arena
addItem(2558, 1);
deleteItem(2556, 1);
closeInterface();
            }
             else if (NpcDialogue == 214 && playerHasItem(2558)) {
sendMessage("Your ring got 4 charges left");
triggerTele(3319, 3235, 0, false);//duel arena
addItem(2560, 1);
deleteItem(2558, 1);
closeInterface();
            }
             else if (NpcDialogue == 215 && playerHasItem(2560)) {
sendMessage("Your ring got 3 charges left");
triggerTele(3319, 3235, 0, false);//duel arena
addItem(2562, 1);
deleteItem(2560, 1);
closeInterface();
            }
             else if (NpcDialogue == 216 && playerHasItem(2562)) {
sendMessage("Your ring got 2 charges left");
triggerTele(3319, 3235, 0, false);//duel arena
addItem(2564, 1);
deleteItem(2562, 1);
closeInterface();
            }
             else if (NpcDialogue == 217 && playerHasItem(2564)) {
sendMessage("Your ring got 1 charge left");
triggerTele(3319, 3235, 0, false);//duel arena
addItem(2566, 1);
deleteItem(2564, 1);
closeInterface();
            }
             else if (NpcDialogue == 218 && playerHasItem(2566)) {
sendMessage("You ring crumble as it have run out of charges");
triggerTele(3319, 3235, 0, false);//duel arena
deleteItem(2566, 1);
closeInterface();
            }
             else if (NpcDialogue == 219 && playerHasItem(1712)) {
sendMessage("Your amulet of glory have 3 charges left");
triggerTele(3319, 3235, 0, false);//duel arena
deleteItem(1712, 1);
addItem(1710, 1);
closeInterface();
            }
             else if (NpcDialogue == 220 && playerHasItem(1710)) {
sendMessage("Your amulet of glory have 2 charges left");
triggerTele(3319, 3235, 0, false);//duel arena
deleteItem(1710, 1);
addItem(1708, 1);
closeInterface();
            }
             else if (NpcDialogue == 221 && playerHasItem(1708)) {
sendMessage("Your amulet of glory have 1 charge left");
triggerTele(3319, 3235, 0, false);//duel arena
deleteItem(1708, 1);
addItem(1706, 1);
closeInterface();
            }
             else if (NpcDialogue == 222 && playerHasItem(1706)) {
sendMessage("Your amulet of glory have no more charges");
triggerTele(3319, 3235, 0, false);//duel arena
deleteItem(1706, 1);
addItem(1704, 1);
closeInterface();
            }
            break;

         case 9168:
            if (NpcDialogue == 201) {
triggerTele(3103, 3249, 0, false);
closeInterface();
            }
else if (NpcDialogue == 211 && playerHasItem(2552)) {
sendMessage("Your ring got 7 charges left");
triggerTele(3281, 2769, 0, false);//tournament
addItem(2554, 1);
deleteItem(2552, 1);
closeInterface();
            }
             else if (NpcDialogue == 212 && playerHasItem(2554)) {
sendMessage("Your ring got 6 charges left");
triggerTele(3281, 2769, 0, false);//tournament
addItem(2556, 1);
deleteItem(2554, 1);
closeInterface();
            }
             else if (NpcDialogue == 213 && playerHasItem(2556)) {
sendMessage("Your ring got 5 charges left");
triggerTele(3281, 2769, 0, false);//tournament
addItem(2558, 1);
deleteItem(2556, 1);
closeInterface();
            }
             else if (NpcDialogue == 214 && playerHasItem(2558)) {
sendMessage("Your ring got 4 charges left");
triggerTele(3281, 2769, 0, false);//tournament
addItem(2560, 1);
deleteItem(2558, 1);
closeInterface();
            }
             else if (NpcDialogue == 215 && playerHasItem(2560)) {
sendMessage("Your ring got 3 charges left");
triggerTele(3281, 2769, 0, false);//tournament
addItem(2562, 1);
deleteItem(2560, 1);
closeInterface();
            }
             else if (NpcDialogue == 216 && playerHasItem(2562)) {
sendMessage("Your ring got 2 charges left");
triggerTele(3281, 2769, 0, false);//tournament
addItem(2564, 1);
deleteItem(2562, 1);
closeInterface();
            }
             else if (NpcDialogue == 217 && playerHasItem(2564)) {
sendMessage("Your ring got 1 charge left");
triggerTele(3281, 2769, 0, false);//tournament
addItem(2566, 1);
deleteItem(2564, 1);
closeInterface();
            }
             else if (NpcDialogue == 218 && playerHasItem(2566)) {
sendMessage("You ring crumble as it have run out of charges");
triggerTele(3281, 2769, 0, false);//tournament
deleteItem(2566, 1);
closeInterface();
            }
             else if (NpcDialogue == 219 && playerHasItem(1712)) {
sendMessage("Your amulet of glory have 3 charges left");
triggerTele(3319, 3235, 0, false);//duel arena
deleteItem(1712, 1);
addItem(1710, 1);
closeInterface();
            }
             else if (NpcDialogue == 220 && playerHasItem(1710)) {
sendMessage("Your amulet of glory have 2 charges left");
triggerTele(3319, 3235, 0, false);//duel arena
deleteItem(1710, 1);
addItem(1708, 1);
closeInterface();
            }
             else if (NpcDialogue == 221 && playerHasItem(1708)) {
sendMessage("Your amulet of glory have 1 charge left");
triggerTele(3319, 3235, 0, false);//duel arena
deleteItem(1708, 1);
addItem(1706, 1);
closeInterface();
            }
             else if (NpcDialogue == 222 && playerHasItem(1706)) {
sendMessage("Your amulet of glory have no more charges");
triggerTele(3319, 3235, 0, false);//duel arena
deleteItem(1706, 1);
addItem(1704, 1);
closeInterface();
            }
            break;

         case 9169:
             if (NpcDialogue == 201) {
closeInterface();
            }
             else if (NpcDialogue == 202) {
closeInterface();
            }
             else if (NpcDialogue == 203) {
closeInterface();
            }
             else if (NpcDialogue == 204) {
closeInterface();
            }
 else if (NpcDialogue == 211 || NpcDialogue == 212 || NpcDialogue == 213 || NpcDialogue == 214 || NpcDialogue == 215 || NpcDialogue == 216 || NpcDialogue == 217 || NpcDialogue == 218) {
closeInterface();
}
else if (NpcDialogue == 219 || NpcDialogue == 220 || NpcDialogue == 221 || NpcDialogue == 222) {
closeInterface();
            }
            break;

//4 options!//

 case 9178:
             if (NpcDialogue == 200) {
triggerTele(2596, 3409, 0, true);//fishing guild 
closeInterface(); }
            break;

         case 9179:
           if (NpcDialogue == 200) {
triggerTele(3485, 9509, 0, false);//dragons 
closeInterface();}
            break;

         case 9180:
            if (NpcDialogue == 200) {
triggerTele(2728, 3348, 0, true);//legends guild 
closeInterface();}
            break;

         case 9181:
            if (NpcDialogue == 200) {
closeInterface();
            }
            break;

//5 options!//

 case 9190:
             if (NpcDialogue == 400) {
addItem(4151,1);
closeInterface();
            }
             else if (NpcDialogue == 401) {
addItem(1580,1);
closeInterface();
            }
             else if (NpcDialogue == 402) {
addItem(6524,1);
closeInterface();
            }
            else if (NpcDialogue == 58) {
                NpcDialogue = 59;
addItem(995, 1000);
addItem(1323, 1);
addItem(542, 1);
addItem(544, 1);
                NpcDialogueSend = false;
            }
            break;

         case 9191:
           if (NpcDialogue == 400) {
addItem(6139,1);
addItem(6141,1);
closeInterface();
            }
             else if (NpcDialogue == 401) {
addItem(1037,1);
closeInterface();
            }
             else if (NpcDialogue == 402) {
addItem(6735,1);
closeInterface();
            }
             else if (NpcDialogue == 58) {
                NpcDialogue = 59;
addItem(995, 1000);
addItem(1381, 1);
addItem(560, 20);
addItem(565, 10);
                NpcDialogueSend = false;
            }
            break;

         case 9192:
            if (NpcDialogue == 400) {
addItem(1704,1);
closeInterface();
            }
             else if (NpcDialogue == 401) {
addItem(6568,1);
closeInterface();
            }
             else if (NpcDialogue == 402) {
addItem(6570,1);
closeInterface();
            }
             else if (NpcDialogue == 58) {
                NpcDialogue = 59;
addItem(995, 1000);
addItem(843, 1);
addItem(882, 20);
addItem(884, 10);
                NpcDialogueSend = false;
            }
            break;

         case 9193:
            if (NpcDialogue == 400) {
addItem(386,500);
closeInterface();
            }
            else if (NpcDialogue == 401) {
                NpcDialogue = 400;
                NpcDialogueSend = false;
closeInterface();
            }
             else if (NpcDialogue == 402) {
addItem(4131,1);
closeInterface();
            }
             else if (NpcDialogue == 58) {
                NpcDialogue = 59;
addItem(995, 1000);
addItem(1351, 1);
addItem(843, 1);
addItem(1323, 1);
addItem(303, 1);
addItem(1381, 1);
addItem(1733, 1);
addItem(590, 1);
addItem(5605, 1);
addItem(1265, 1);
addItem(2347, 1);
addItem(1734, 20);
                NpcDialogueSend = false;
            }
            break;

         case 9194:
            if (NpcDialogue == 400) {
                NpcDialogue = 401;
                NpcDialogueSend = false;
closeInterface();
            }
            else if (NpcDialogue == 401) {
                NpcDialogue = 402;
                NpcDialogueSend = false;
closeInterface();
            }
            else if (NpcDialogue == 402) {
                NpcDialogue = 401;
                NpcDialogueSend = false;
closeInterface();
            }
             else if (NpcDialogue == 58) {
                NpcDialogue = 59;
addItem(995, 1000);
addItem(1351, 1);
addItem(303, 1);
addItem(1733, 1);
addItem(590, 1);
addItem(5605, 1);
addItem(1265, 1);
addItem(2347, 1);
addItem(1734, 20);
                NpcDialogueSend = false;
            }
            break;

///////END///////

          case 1097:
            setSidebarInterface(0, 1829);
            break;

          case 7212:
            setSidebarInterface(0, 328);
            break;
          case 26018:
            if (!inDuel ||  ! validClient(duel_with))
              break;
            client o = getClient(duel_with);
            if (System.currentTimeMillis()-lastButton < 1000) {
                lastButton = System.currentTimeMillis();
                break;
            }
             else {
                lastButton = System.currentTimeMillis();
            }
            duelConfirmed = true;
            if (duelConfirmed && o.duelConfirmed) {
                canOffer = false;
                confirmDuel();
                o.confirmDuel();
            }
             else {
                sendFrame126("Waiting for other player...", 6684);
                o.sendFrame126("Other player has accepted.", 6684);
            }

            break;

            default:
            break;
        }
        break;

        // the following Ids are the reason why AR-type cheats are hopeless to make...
        // basically they're just there to make reversing harder
      case 226:
      case 78:
      case 148:
      case 183:
      case 230:
      case 136:
      case 189:
      case 152:
      case 200:
      case 85:
      case 165:
      case 238:
      case 150:
      case 36:
      case 246:
      case 77:
        break;

        // any packets we might have missed
        default: interfaceID = inStream.readUnsignedWordA();
        int actionButtonId1 = misc.HexToInt(inStream.buffer, 0, packetSize);


        break;
    }
  }
  private int somejunk;

  public void yell(String message) {
    for (Player p: handler.players) {
      if (message.indexOf("tradereq") > 0 || message.indexOf("duelreq") > 0)
        return;
      if (p == null ||  ! p.isActive)
        continue;
      client temp = (client)p;
      if (temp.absX > 0 && temp.absY > 0)
        if (temp != null &&  ! temp.disconnected && p.isActive)
          temp.sendMessage(message);
    }
  }

  public void CWMessage(String message) {
    for (Player p: handler.players) {
      if (message.indexOf("tradereq") > 0 || message.indexOf("duelreq") > 0)
        return;
      if (p == null ||  ! p.isActive)
        continue;
      client temp = (client)p;
      if (temp.absX > 0 && temp.absY > 0)
        if (temp != null &&  ! temp.disconnected && p.isActive && temp.playerIsSara == 1 || temp != null &&  ! temp.disconnected && p.isActive && temp.playerIsZammy == 1)
          temp.sendMessage(message);
    }
  }

  public boolean stairs(int stairs, int teleX, int teleY) {
    if (IsStair == false) {
      IsStair = true;
      if (stairs == 1) {
        heightLevel += 1;
      } else if (stairs == 2) {
        heightLevel -= 1;
      } else if (stairs == 21) {
        heightLevel += 1;
      } else if (stairs == 22) {
        heightLevel -= 1;
      }
      teleportToX = teleX;
      teleportToY = teleY;
      if (stairs == 3 || stairs == 5 || stairs == 9) {
        teleportToY += 6400;
      } else if (stairs == 4 || stairs == 6 || stairs == 10) {
        teleportToY -= 6400;
      } else if (stairs == 7) {
        teleportToX = 3104;
        teleportToY = 9576;
      } else if (stairs == 8) {
        teleportToX = 3105;
        teleportToY = 3162;
      } else if (stairs == 11) {
        teleportToX = 2856;
        teleportToY = 9570;
      } else if (stairs == 12) {
        teleportToX = 2857;
        teleportToY = 3167;
      } else if (stairs == 13) {
        heightLevel += 3;
        teleportToX = skillX;
        teleportToY = skillY;
      } else if (stairs == 15) {
        teleportToY += (6400-(stairDistance+stairDistanceAdd));
      } else if (stairs == 14) {
        teleportToY -= (6400-(stairDistance+stairDistanceAdd));
      } else if (stairs == 16) {
        teleportToX = 2828;
        teleportToY = 9772;
      } else if (stairs == 17) {
        teleportToX = 3494;
        teleportToY = 3465;
      } else if (stairs == 18) {
        teleportToX = 3477;
        teleportToY = 9845;
      } else if (stairs == 19) {
        teleportToX = 3543;
        teleportToY = 3463;
      } else if (stairs == 20) {
        teleportToX = 3549;
        teleportToY = 9865;
      } else if (stairs == 21) {
        teleportToY += (stairDistance+stairDistanceAdd);
      } else if (stairs == 22) {
        teleportToY -= (stairDistance+stairDistanceAdd);
      } else if (stairs == 23) {
        teleportToX = 2480;
        teleportToY = 5175;
      } else if (stairs == 24) {
        teleportToX = 2862;
        teleportToY = 9572;
      } else if (stairs == 27) {
        teleportToX = 2453;
        teleportToY = 4468;
      } else if (stairs == 28) {
        teleportToX = 3201;
        teleportToY = 3169;
      }
      if (stairs == 5 || stairs == 10) {
        teleportToX += (stairDistance+stairDistanceAdd);
      }
      if (stairs == 9) {
        teleportToX -= (stairDistance-stairDistanceAdd);
      }
      if (stairs == 6) {
        teleportToX = 2602;
        teleportToY = 9479;
      }
    }
    resetStairs();
    return true;
  }

  public boolean resetStairs() {
    stairs = 0;
    skillX = -1;
    skillY = -1;
    stairDistance = 1;
    stairDistanceAdd = 0;
    IsUsingSkill = false;
    return true;
  }

  public boolean crackCracker() {
    sendMessage("Somone used a crackers on you...");
    CrackerMsg = false;
    if (CrackerForMe == true) {
      if (freeSlots() > 0) {
        addItem(Item.randomPHat(), 1);
        sendMessage("And you get the crackers item.");
      } else {
        sendMessage("but you don't have enough space in your inventory.");
      }
      CrackerForMe = false;
    } else {
      sendMessage("but you didn't get the crackers item.");
    }
    return true;
  }

  public boolean IsInCW(int coordX, int coordY) {
    if (coordY >= 0 && coordY <= 9999 && coordX <= 9999 && coordX >= 0) {
      return true;
    } else if (absX >= 2368 && absX <= 2432 && absY >= 3071 && absY <= 3139) {
      return true;
    } else {
      return false;
    }
  }

  public boolean isInWilderness(int coordX, int coordY, int Type) {
		if (Type == 1) {
			if ((coordY >= 3520) && (coordY <= 3967) && (coordX <= 3392)
					&& (coordX >= 2942)) {
				return true;
			}
		} else if (Type == 2) {
			if ((coordY >= 3512) && (coordY <= 3967) && (coordX <= 3392)
					&& (coordX >= 2942)) {
				return true;
			}
		}
		return false;
	}
  public boolean IsInDigSite() {
    if (absX >= 3350 && absX <= 3357 && absY >= 3404 && absY <= 3412) {
      return true;
    } else {
      return false;
    }
  }

  //pk: 2726 9193
  public boolean Attack() {
	if (!(AttackingOn > 0) || ! (AttackingOn < server.playerHandler.players.length)) {
		ResetAttack();
		return false;
	}
	if (playerId < 1) {
		sendMessage("Error: Your player id is invalid. Please try again or logout and back in");
	}
	if (AttackingOn > 0 && !server.pking) {
		sendMessage("Pking has been disabled ask YOURNAMEHERE or a co-owner to enable pking");
		ResetAttack();
		return false;
	}
	
	boolean UseBow = false;
	if (playerEquipment[playerWeapon] == 4212) {
		UseBow = true;
	}
	if (playerEquipment[playerWeapon] == 2883) {
		UseBow = true;
	}
	if (playerEquipment[playerWeapon] == 6082) {
		UseBow = true;
	}
	if (playerEquipment[playerWeapon] == 4214) {
		UseBow = true;
	}
	if (playerEquipment[playerWeapon] == 6082) {
		UseBow = true;
	}
	if (playerEquipment[playerWeapon] == 767) {
		UseBow = true;
	}
	if (playerEquipment[playerWeapon] == 837) {
		UseBow = true;
	}
	if (playerEquipment[playerWeapon] == 861) {
		UseBow = true;
	}
	if (playerEquipment[playerWeapon] == 4734) {
		UseBow = true;
	}
	if (playerEquipment[playerWeapon] == 861) {
		UseBow = true;
	}
	if (playerEquipment[playerWeapon] == 859) {
		UseBow = true;
	}
	
	if (UseBow) {
		if (!duelRule[0]) {
			teleportToX = absX;
			teleportToY = absY;
			CheckArrows();
			CalculateRange();
			hitDiff = misc.random(playerMaxHit);
		} else {
			sendMessage("You can't range in this duel!");
			return false;
		}
	}
	
	if (!UseBow && duelRule[1]) {
		sendMessage("You can't melee in this duel!");
		ResetAttack();
		return false;
	}
	int EnemyX = PlayerHandler.players[AttackingOn].absX;
	int EnemyY = PlayerHandler.players[AttackingOn].absY;
	int EnemyHP = PlayerHandler.players[AttackingOn].playerLevel[playerHitpoints];
	int EnemyHPExp = PlayerHandler.players[AttackingOn].playerXP[playerHitpoints];
	client AttackingOn2 = (client)server.playerHandler.players[AttackingOn];
	TurnPlayerTo(EnemyX, EnemyY);
	updateRequired = true;
	appearanceUpdateRequired = true;
	if (PlayerHandler.players[AttackingOn].playerEquipment[playerRing] == 2570) {
		//RingOfLife = true;
	}
	int hitDiff = 0;
	int aBonus = 0;
	int rand_att = misc.random(playerLevel[0]);
	int rand_def = (int)(0.65*misc.random(AttackingOn2.playerLevel[1]));
	if (FightType == 1)
	aBonus += (int)(playerBonus[1]/20);
	int random_u = misc.random(playerBonus[1]+aBonus)*2;
	int dBonus = 0;
	if (AttackingOn2.FightType == 4)
	dBonus += (int)(AttackingOn2.playerBonus[6]/20);
	int random_def = misc.random(AttackingOn2.playerBonus[6]+dBonus);
	if (random_u >= random_def && rand_att > rand_def) {
		hitDiff = misc.random(playerMaxHit);
	} else {
		hitDiff = 0;
	}
	if (FightType == 2)
	hitDiff = (int)(hitDiff*1.20);
	long thisAttack = System.currentTimeMillis();
	if (GoodDistance(EnemyX, EnemyY, absX, absY, 1) == true) {
		if (thisAttack-lastAttack >= 2000) {
			inCombat = true;
			lastCombat = System.currentTimeMillis();
			if (isInWilderness(EnemyX, EnemyY, 1) || (duelFight && AttackingOn == duel_with) || playerRights == 3) {
				if (duelFight && AttackingOn == duel_with) {
					enemyX = PlayerHandler.players[AttackingOn].absX;
					enemyY = PlayerHandler.players[AttackingOn].absY;
				}
				if (PlayerHandler.players[AttackingOn].deathStage > 0) {
					ResetAttack();
				}
					if (playerissara >= 1 && PlayerHandler.players[AttackingOn].playerissara == 1) {
						ResetAttack();
						sendMessage("You cannot attack your own team member!");
                				updateRequired = true;
                				appearanceUpdateRequired = true;
					}
					if (playeriszammy >= 1 && PlayerHandler.players[AttackingOn].playeriszammy == 1) {
						ResetAttack();
						sendMessage("You cannot attack your own team member!");
                				updateRequired = true;
               				 	appearanceUpdateRequired = true;
					} else {
					if (!duelFight && inRange(EnemyX, EnemyY)) {
						if (thisAttack-lastAttack >= 4000)
						((client)PlayerHandler.players[AttackingOn]).sendMessage("You are under attack!");
						PlayerHandler.players[AttackingOn].resetWalkingQueue();
						PlayerHandler.players[AttackingOn].hits++;
						PlayerHandler.players[AttackingOn].fighting = true;
						PlayerHandler.players[AttackingOn].fightId = localId;
						PlayerHandler.players[AttackingOn].IsAttacking = true;
						((client)PlayerHandler.players[AttackingOn]).Attack();
						fightId = AttackingOn;
						fighting = true;
						resetWalkingQueue();
					}
					if (playerEquipment[playerWeapon] == 4151) {
					}
					actionAmount++;
					startAnimation(GetWepAnim());
					PlayerHandler.players[AttackingOn].hitUpdateRequired = true;
					PlayerHandler.players[AttackingOn].updateRequired = true;
					PlayerHandler.players[AttackingOn].appearanceUpdateRequired = true;
					if ((EnemyHP-hitDiff) < 0) {
						hitDiff = EnemyHP;
					}
					PlayerHandler.players[AttackingOn].dealDamage(hitDiff);
					PlayerHandler.players[AttackingOn].hitDiff = hitDiff;
					PlayerHandler.players[AttackingOn].killers[localId] += hitDiff;
					attackTimer = 7;
					lastAttack = System.currentTimeMillis();
				}
				return true;
			} else {
				sendMessage("This player is not in the Wilderness");
				ResetAttack();
			}
		}
	}
	if (GoodDistance(EnemyX, EnemyY, absX, absY, 1) == false) {
		if (thisAttack-lastAttack >= 2000) {
			if (isInWilderness(EnemyX, EnemyY, 1) == true || (duelFight && AttackingOn == duel_with) || playerRights == 3) {
					if (PlayerHandler.players[AttackingOn].deathStage > 0) {
						ResetAttack();
					}
					if (playerissara >= 1 && PlayerHandler.players[AttackingOn].playerissara == 1) {
						ResetAttack();
						sendMessage("You cannot attack your own team member!");
					} 
					if (playeriszammy >= 1 && PlayerHandler.players[AttackingOn].playeriszammy == 1) {
						ResetAttack();
						sendMessage("You cannot attack your own team member!");
					} else if (UseBow) {
						actionAmount++;
						startAnimation(GetWepAnim());
						PlayerHandler.players[AttackingOn].hitUpdateRequired = true;
						PlayerHandler.players[AttackingOn].updateRequired = true;
						PlayerHandler.players[AttackingOn].appearanceUpdateRequired = true;
						if ((EnemyHP-hitDiff) < 0) {
							hitDiff = EnemyHP;
						}
						PlayerHandler.players[AttackingOn].dealDamage(hitDiff);
						PlayerHandler.players[AttackingOn].hitDiff = hitDiff;
						attackTimer = 7;
						lastAttack = System.currentTimeMillis();
					}
					return true;
			} else {
				sendMessage("This player is not in the Wilderness");
				ResetAttack();
			}
		}
	}
	return false;
  }
  public boolean Attackrange() {
    client q = (client)server.playerHandler.players[AttackingOn];
    int EnemyX = PlayerHandler.players[AttackingOn].absX;
    int EnemyY = PlayerHandler.players[AttackingOn].absY;
    int EnemyHP = PlayerHandler.players[AttackingOn].playerLevel[playerHitpoints];
    int EnemyHPExp = PlayerHandler.players[AttackingOn].playerXP[playerHitpoints];
    boolean RingOfLife = false;

    if (PlayerHandler.players[AttackingOn].playerEquipment[playerRing] == 2570) {
      RingOfLife = true;
    }
    int hitDiff = 0;

    hitDiff = misc.random(playerMaxHit);

    if (GoodDistance(EnemyX, EnemyY, absX, absY, 20) == true) {
      teleportToX = absX;
      teleportToY = absY;
      if (actionTimer == 0) {
        if (isInWilderness(EnemyX, EnemyY, 1) == true) {
          if (false) {
          } else {
            if (PlayerHandler.players[AttackingOn].deathStage > 0) {
              ResetAttack();
            } else {
              actionAmount++;
             startAnimation(GetWepAnim());
              PlayerHandler.players[AttackingOn].hitUpdateRequired = true;
              PlayerHandler.players[AttackingOn].updateRequired = true;
              PlayerHandler.players[AttackingOn].appearanceUpdateRequired = true;
              hitDiff = EnemyHP;

              PlayerHandler.players[AttackingOn].hitDiff = hitDiff;
              actionTimer = 7;
            }
	     if (playerissara >= 1 && PlayerHandler.players[AttackingOn].playerissara == 1) {
		ResetAttack();
		sendMessage("You cannot attack your own team member!");
	    }
	     if (playeriszammy >= 1 && PlayerHandler.players[AttackingOn].playeriszammy == 1) {
		ResetAttack();
		sendMessage("You cannot attack your own team member!");
	    }
          }
          return true;
        } else {
          sendMessage("This player is not in the Wilderness.");
          ResetAttack();
        }
      }
    }
    return false;
  }

  public boolean ResetAttack() {
    IsAttacking = false;
    AttackingOn = 0;
   
    IsUsingSkill = false;
    return true;
  }


  public boolean CheckForSkillUse4(int Item) {
    boolean GoOn = true;
    boolean IsFiremaking = false;

    switch (Item) {
      case 1511:
        if (IsItemInBag(590) == true) {
            IsFiremaking = true;
            firemaking[0] = 1;
            firemaking[1] = 1;
            firemaking[2] = 40;
        }
         else {
            sendMessage("You need a "+GetItemName(591)+" to light a fire.");
        }
        break;

      case 1513:
        if (IsItemInBag(590) == true) {
            IsFiremaking = true;
            firemaking[0] = 8;
            firemaking[1] = 75;
            firemaking[2] = 303;
        }
         else {
            sendMessage("You need a "+GetItemName(591)+" to light a fire.");
        }
        break;

      case 1515:
        if (IsItemInBag(590) == true) {
            IsFiremaking = true;
            firemaking[0] = 7;
            firemaking[1] = 60;
            if (misc.random2(2) == 1) {
                firemaking[2] = 202;
            }
             else {
                firemaking[2] = 203;
            }
        }
         else {
            sendMessage("You need a "+GetItemName(591)+" to light a fire.");
        }
        break;

      case 1517:
        if (IsItemInBag(590) == true) {
            IsFiremaking = true;
            firemaking[0] = 5;
            firemaking[1] = 45;
            firemaking[2] = 135;
        }
         else {
            sendMessage("You need a "+GetItemName(591)+" to light a fire.");
        }
        break;

      case 1519:
        if (IsItemInBag(590) == true) {
            IsFiremaking = true;
            firemaking[0] = 3;
            firemaking[1] = 30;
            firemaking[2] = 90;
        }
         else {
            sendMessage("You need a "+GetItemName(591)+" to light a fire.");
        }
        break;

      case 1521:
        if (IsItemInBag(590) == true) {
            IsFiremaking = true;
            firemaking[0] = 2;
            firemaking[1] = 15;
            firemaking[2] = 60;
        }
         else {
            sendMessage("You need a "+GetItemName(591)+" to light a fire.");
        }
        break;

      case 6333:
        if (IsItemInBag(590) == true) {
            IsFiremaking = true;
            firemaking[0] = 4;
            firemaking[1] = 35;
            firemaking[2] = 105;
        }
         else {
            sendMessage("You need a "+GetItemName(591)+" to light a fire.");
        }
        break;

      case 6332:
        if (IsItemInBag(590) == true) {
            IsFiremaking = true;
            firemaking[0] = 6;
            firemaking[1] = 50;
            if (misc.random2(2) == 1) {
                firemaking[2] = 157;
            }
             else {
                firemaking[2] = 158;
            }
        }
         else {
            sendMessage("You need a "+GetItemName(591)+" to light a fire.");
        }
        break;

        default: sendMessage("Nothing interesting happens.");
        println_debug("Firemaking Usage - ItemID: "+Item);
        GoOn = false;
        break;
    }
    if (GoOn == false) {
      return false;
    }
    if (IsFiremaking == true) {
      firemaking[4] = GetGroundItemID(Item, skillX, skillY, heightLevel);
      if (firemaking[4] == -1 && false) {
      }
    }
    if (prayer[0] > 0) {
      prayer();
    }
    return true;
  }

  public boolean IsItemInBag(int ItemID) {
    for (int i = 0; i < playerItems.length; i++) {
      if ((playerItems[i]-1) == ItemID) {
        return true;
      }
    }
    return false;
  }

  public boolean AreXItemsInBag(int ItemID, int Amount) {
    int ItemCount = 0;

    for (int i = 0; i < playerItems.length; i++) {
      if ((playerItems[i]-1) == ItemID) {
        ItemCount++;
      }
      if (ItemCount == Amount) {
        return true;
      }
    }
    return false;
  }

  public int GetItemSlot(int ItemID) {
    for (int i = 0; i < playerItems.length; i++) {
      if ((playerItems[i]-1) == ItemID) {
        return i;
      }
    }
    return -1;
  }

  public int GetXItemsInBag(int ItemID) {
    int ItemCount = 0;

    for (int i = 0; i < playerItems.length; i++) {
      if ((playerItems[i]-1) == ItemID) {
        ItemCount++;
      }
    }
    return ItemCount;
  }

  public int Tradecompete = 0;
  public int Publicchat = 0;

  public void pmstatus(int status) {
    // status: loading = 0  connecting = 1  fine = 2
    outStream.createFrame(221);
    outStream.writeByte(status);
  }

  public boolean playerHasItem(int itemID) {
    itemID++;
    for (int i = 0; i < playerItems.length; i++) {
      if (playerItems[i] == itemID) {
        return true;
      }
    }
    return false;

  }
  public boolean playerHasItem(int itemID, int amt) {
    itemID++;
    int found = 0;
    for (int i = 0; i < playerItems.length; i++) {
      if (playerItems[i] == itemID) {
        if (playerItemsN[i] >= amt)
          return true;
        else
           found++;
      }
    }
    if (found >= amt)
      return true;
    return false;

  }


  public boolean isinpm(long l) {
    for (int i = 0; i < friends.length; i++) {
      if (friends[i] != 0) {
        if (l == friends[i]) {
          return true;
        }
      }
    }
    return false;
  }

  public void pmupdate(int pmid, int world) {
    if (handler.players[pmid] == null || handler.players[pmid].playerName == null) {
      return;
    }
    long l = misc.playerNameToInt64(handler.players[pmid].playerName);

    if (handler.players[pmid].Privatechat == 0) {
      for (int i = 0; i < friends.length; i++) {
        if (friends[i] != 0) {
          if (l == friends[i]) {
            loadpm(l, world);
            return;
          }
        }
      }
    } else if (handler.players[pmid].Privatechat == 1) {
      for (int i1 = 0; i1 < friends.length; i1++) {
        if (friends[i] != 0) {
          if (l == friends[i1]) {
            if (handler.players[pmid].isinpm(misc.playerNameToInt64(playerName)) && playerRights > 2) {
              loadpm(l, world);
              return;
            } else {
              loadpm(l, 0);
              return;
            }
          }
        }
      }
    } else if (handler.players[pmid].Privatechat == 2) {
      for (int i2 = 0; i2 < friends.length; i2++) {
        if (friends[i] != 0) {
          if (l == friends[i2] && playerRights < 2) {
            loadpm(l, 0);
            return;
          }
        }
      }
    }
  }

  public void sendpm(long name, int rights, byte[]chatmessage, int messagesize) {
    outStream.createFrameVarSize(196);
    outStream.writeQWord(name);
    outStream.writeDWord(handler.lastchatid++); // must be different for each message
    outStream.writeByte(rights);
    outStream.writeBytes(chatmessage, messagesize, 0);
    outStream.endFrameVarSize();
  }

  public void loadpm(long name, int world) {
    if (world != 0) {
      world += 9;
    } else if (world == 0) {
      world += 1;
    }
    outStream.createFrame(50);
    outStream.writeQWord(name);
    outStream.writeByte(world);
  }



  public boolean AttackNPC() {

    int EnemyX = server.npcHandler.npcs[attacknpc].absX;
    int EnemyY = server.npcHandler.npcs[attacknpc].absY;
    int EnemyHP = server.npcHandler.npcs[attacknpc].HP;
    int hitDiff = 0;
    if (EnemyHP < 1) {
      sendMessage("You can't attack that monster!");
      return false;
    }
    int type = server.npcHandler.npcs[attacknpc].npcType;
    int[]staffs =  {
      2415, 2416, 2417, 4710, 4675, 1409, 732
    };
    int[]arrowIds =  {
      882, 884, 886, 888, 890, 892
    };
    int[]arrowGfx =  {
      10, 9, 11, 12, 13, 15
    };
int[] prem = { 1643, 158, 49, 1613, 4315, 4317, 4319, 4323, 4325, 4327, 4331, 4333, 4335, 4337, 4339, 4341, 4343, 4345, 4347, 941, 4349, 4351, 4353, 4355 };
		for (int element : prem) {
			if ((element == type) && premium == 0) {
				resetPos();
				return false;
			}
		}
    if (type == 1125) {
      if (combatLevel < 70) {
        sendMessage("You must be level 70 or higher to attack Dad");
        ResetAttackNPC();
	return false;
      }
    }
		if (type == 84) {
			if (combatLevel < 100) {
				sendMessage("You must be level 100 or higher to attack Barrows monsters.");
        			resetPos();
				ResetAttackNPC();
				return false;
			}
		}
		if (type == 2060) {
			if (combatLevel < 100) {
				sendMessage("You must be level 100 or higher to attack Barrows monsters.");
       				resetPos();
				ResetAttackNPC();
				return false;
			}
		}
		if (type == 3200) {
			if (combatLevel < 100) {
				sendMessage("You must be level 100 or higher to attack Barrows monsters.");
       				resetPos();
				ResetAttackNPC();
				return false;
			}
		}
		if (type == 258) {
    			if (!playerHasItem(989)) {
				sendMessage("You must have a crystal key to attack General Khazard.");
				ResetAttackNPC();
				return false;
			}
		}
		if (type == 1974) {
    			if (!playerHasItem(4272)) {
				sendMessage("You must have a bone key to attack Damis.");
				ResetAttackNPC();
				return false;
			}
		}
		if (type == 277) {
    			if (!playerHasItem(1543)) {
				sendMessage("You must have a red key to attack the Fire Warrior.");
				ResetAttackNPC();
				return false;
			}
		}
		if (type == 221) {
    			if (!playerHasItem(1544)) {
				sendMessage("You must have a orange key to attack the Black Knight Titan.");
				ResetAttackNPC();
				return false;
			}
		}
		if (type == 1095) {
    			if (!playerHasItem(1546)) {
				sendMessage("You must have a blue key to attack Rock.");
				ResetAttackNPC();
				return false;
			}
		}
		if (type == 2881) {
    			if (!playerHasItem(1545)) {
				sendMessage("You must have a yellow key to attack Dagannoth Supreme.");
				ResetAttackNPC();
				return false;
			}
		}
		if (type == 1958) {
    			if (!playerHasItem(1547)) {
				sendMessage("You must have a purple key to attack the Mummy.");
				ResetAttackNPC();
				return false;
			}
		}
		if (type == 1356) {
    			if (!playerHasItem(983)) {
				sendMessage("You must have a brass key to attack the Dagonnath Mother.");
				ResetAttackNPC();
				return false;
			}
		}
		if (type == 50) {
    			if (!playerHasItem(2418)) {
				sendMessage("You must have a bronze key to attack the King Black Dragon.");
				ResetAttackNPC();
				return false;
			}
		}
		if (type == 1158) {
    			if (!playerHasItem(2945)) {
				sendMessage("You must have a iron key to attack the Kalphite Queen.");
				ResetAttackNPC();
				return false;
			}
		}
		if (type == 418) {
    			if (!fullRockshell()) {
				sendMessage("You must be wearing full rock-shell armor to attack the Rock Golem");
				ResetAttackNPC();
				return false;
			}
		}
		if (type == 475) {
    			if (!playerHasItem(6966)) {
				sendMessage("You must have a prison key to attack Khazard troopers.");
				ResetAttackNPC();
				return false;
			}
		}
		if (type == 1648) {
			if (slayerTask != 1) {
				sendMessage("You are not assigned to slay this monster!");
				ResetAttackNPC();
				return false;
			}
		}
		if (type == 1637) {
			if (slayerTask != 2) {
				sendMessage("You are not assigned to slay this monster!");
				ResetAttackNPC();
				return false;
			}
		}
		if (type == 1633) {
			if (slayerTask != 3) {
				sendMessage("You are not assigned to slay this monster!");
				ResetAttackNPC();
				return false;
			}
		}
		if (type == 1575) {
			if (slayerTask != 4) {
				sendMessage("You are not assigned to slay this monster!");
				ResetAttackNPC();
				return false;
			}
		}
		if (type == 3406) {
			if (slayerTask != 5) {
				sendMessage("You are not assigned to slay this monster!");
				ResetAttackNPC();
				return false;
			}
		}
		if (type == 1614) {
			if (slayerTask != 6) {
				sendMessage("You are not assigned to slay this monster!");
				ResetAttackNPC();
				return false;
			}
		}
		if (type == 347) {
			if (slayerTask != 7) {
				sendMessage("You are not assigned to slay this monster!");
				ResetAttackNPC();
				return false;
			}
		}
		if (type == 2373) {
			if (slayerTask != 7) {
				sendMessage("You are not assigned to slay this monster!");
				ResetAttackNPC();
				return false;
			}
		}
    if (type == 110 || type == 277) {
      if (!playerHasItem(1543)) {
        ResetAttackNPC();
        return false;
      }
    }
    if (type == 221 || type == 1961) {
      if (!playerHasItem(1544)) {
        ResetAttackNPC();
        return false;
      }
    }
    if (type == 1095) {
      if (!playerHasItem(1546)) {
        ResetAttackNPC();
        return false;
      }
    }
    for (int a = 0; a < staffs.length; a++) {
      if (playerEquipment[playerWeapon] == staffs[a] && autocast_spellIndex >= 0) {
        if (System.currentTimeMillis()-lastAttack < coolDown[coolDownGroup[autocast_spellIndex]]) {
          return false;
        }
        inCombat = true;
        lastCombat = System.currentTimeMillis();
        lastAttack = System.currentTimeMillis();
        if (playerLevel[6] >= requiredLevel[autocast_spellIndex] && playerHasItem(ancientRune1[autocast_spellIndex], ancientRuneAm[autocast_spellIndex])) {
          int roll = misc.random(100);
          int hit = misc.random(baseDamage[autocast_spellIndex]+playerBonus[11]);
          hitDiff = hit;
          setAnimation(1979);
          updateRequired = true;
          resetWalkingQueue();
deleteItem(ancientRune1[autocast_spellIndex], getItemSlot(ancientRune1[autocast_spellIndex]), ancientRuneAm[autocast_spellIndex]);
          if (ancientType[autocast_spellIndex] == 3 && playerHasItem(ancientRune1[autocast_spellIndex], ancientRuneAm[autocast_spellIndex])) {
            server.npcHandler.npcs[attacknpc].effects[0] = 15;
            stillgfx(369, EnemyY, EnemyX);
deleteItem(ancientRune1[autocast_spellIndex], getItemSlot(ancientRune1[autocast_spellIndex]), ancientRuneAm[autocast_spellIndex]);
          } else if (ancientType[autocast_spellIndex] == 2 && playerHasItem(ancientRune1[autocast_spellIndex], ancientRuneAm[autocast_spellIndex])) {
            stillgfx(377, EnemyY, EnemyX);
            currentHealth += (int)(hit/2);
            if (currentHealth > playerLevel[playerHitpoints])
              currentHealth = playerLevel[playerHitpoints];
deleteItem(ancientRune1[autocast_spellIndex], getItemSlot(ancientRune1[autocast_spellIndex]), ancientRuneAm[autocast_spellIndex]);
          } else
            animation(78, EnemyY, EnemyX);
}
if (playerLevel[6] < requiredLevel[autocast_spellIndex] && playerHasItem(ancientRune1[autocast_spellIndex], ancientRuneAm[autocast_spellIndex])) {
                        sendMessage("You need a magic level of "+requiredLevel[autocast_spellIndex]);
                    }
                     else if (playerLevel[6] < requiredLevel[autocast_spellIndex]) {
                        sendMessage("You need "+ancientRuneAm[autocast_spellIndex]+" blood rune to cast this spell");
                    }
        TurnPlayerTo(EnemyX, EnemyY);
        addSkillXP(90*hitDiff, playerMagic);
        addSkillXP(hitDiff*CombatExpRate, playerHitpoints);
        teleportToX = absX;
        teleportToY = absY;
	
        server.npcHandler.npcs[attacknpc].StartKilling = localId;
        server.npcHandler.npcs[attacknpc].RandomWalk = false;
        server.npcHandler.npcs[attacknpc].IsUnderAttack = true;
        server.npcHandler.npcs[attacknpc].hitDiff = hitDiff;
        server.npcHandler.npcs[attacknpc].Killing[playerId] += hitDiff;
        server.npcHandler.npcs[attacknpc].updateRequired = true;
        server.npcHandler.npcs[attacknpc].hitUpdateRequired = true;
        server.npcHandler.npcs[attacknpc].hit = true;
        return true;
      }
    }
    long thisTime = System.currentTimeMillis();

    hitDiff = misc.random(playerMaxHit);
    if (FightType == 2)
      hitDiff = (int)(hitDiff*1.20);
    boolean UseBow = false;

    for (int i = 0; i < shortbow .length; i++) {
      if (playerEquipment[playerWeapon] == shortbow[i] || playerEquipment[playerWeapon] == longbow[i]) {
        UseBow = true;
        break;
      }
    }
    int arrowgfx = 10;
    for (int i1 = 0; i1 < arrowIds.length; i1++) {
      if (playerEquipment[playerArrows] == arrowIds[i1]) {
        arrowgfx = arrowGfx[i1];
      }
    }

    if (UseBow && thisTime-lastAttack >= 1800) {
      teleportToX = absX;
      teleportToY = absY;
      CalculateRange();
      hitDiff = misc.random(maxRangeHit());
      if (DeleteArrow()) {
        int offsetX = (absY-EnemyY)*-1;
        int offsetY = (absX-EnemyX)*-1;
        for (int a = 0; a < handler.maxPlayers; a++) {
          client temp = (client)handler.players[a];
          if (temp != null && temp.absX > 0 &&  ! temp.disconnected && Math.abs(absX-temp.absX) < 60 && Math.abs(absY-temp.absY) < 60) {
            temp.createProjectile(absY, absX, offsetY, offsetX, 50, 90, arrowgfx, 43, 35, attacknpc+1);
          }
        }
        server.npcHandler.npcs[attacknpc].hitDiff = hitDiff;
        server.npcHandler.npcs[attacknpc].Killing[playerId] += hitDiff;
        server.npcHandler.npcs[attacknpc].updateRequired = true;
        server.npcHandler.npcs[attacknpc].hitUpdateRequired = true;
        server.npcHandler.npcs[attacknpc].hit = true;
        if (hitDiff == 0 && server.npcHandler.npcs[attacknpc].npcType == 941) {
          server.npcHandler.npcs[attacknpc].animNumber = 89;
          server.npcHandler.npcs[attacknpc].animUpdateRequired = true;
          server.npcHandler.npcs[attacknpc].updateRequired = true;
        }
        updateRequired = true;
        appearanceUpdateRequired = true;
      } else {
        ResetAttackNPC();
        sendMessage("You're out of arrows!");
        return false;
	}
    }
    if (playerEquipment[playerWeapon] == 4151 && thisTime-lastAttack >= 1500) {
      inCombat = true;
      lastCombat = System.currentTimeMillis();
    } else if (thisTime-lastAttack >= 2000) {
      inCombat = true;
      lastCombat = System.currentTimeMillis();
    } else {
      return false;
    }
    if (UseBow || GoodDistance(EnemyX, EnemyY, absX, absY, 1) == true) {
      if (server.npcHandler.npcs[attacknpc].IsDead == true) {
        ResetAttackNPC();
      } else {
        if (playerEquipment[playerWeapon] == 4151) {
        }
        TurnPlayerTo(EnemyX, EnemyY);
        updateRequired = true;
        appearanceUpdateRequired = true;
        actionAmount++;
        startAnimation(GetWepAnim());
        if ((EnemyHP-hitDiff) < 0) {
          hitDiff = EnemyHP;
        }
        server.npcHandler.npcs[attacknpc].hitDiff = hitDiff;
        server.npcHandler.npcs[attacknpc].Killing[playerId] += hitDiff;
        server.npcHandler.npcs[attacknpc].updateRequired = true;
        server.npcHandler.npcs[attacknpc].hitUpdateRequired = true;
        server.npcHandler.npcs[attacknpc].hit = true;
        if (hitDiff == 0 && server.npcHandler.npcs[attacknpc].npcType == 941) {
          server.npcHandler.npcs[attacknpc].animNumber = 89;
          server.npcHandler.npcs[attacknpc].animUpdateRequired = true;
          server.npcHandler.npcs[attacknpc].updateRequired = true;
        }
        attackedNpc = true;
        attackedNpcId = attacknpc;
        double TotalExp = 0;
        if (!UseBow)
          animationReset = System.currentTimeMillis()+1200;
        if (server.npcHandler.npcs[attacknpc].npcType != 1) {
          if (UseBow) {
            TotalExp = (double)(60*hitDiff*2); //added *2 for faster leveling -bakatool
            TotalExp = (double)(TotalExp*CombatExpRate);
            addSkillXP((int)(TotalExp), 4);
          } else if (FightType != 3) {
            TotalExp = (double)(60*hitDiff*2); //added *2 for faster leveling -bakatool
            TotalExp = (double)(TotalExp*CombatExpRate);
            addSkillXP((int)(TotalExp), SkillID);
          } else {
            TotalExp = (double)(60*hitDiff*2); //added *2 for faster leveling -bakatool2
            TotalExp = (double)(TotalExp*CombatExpRate);
            addSkillXP((int)(TotalExp), playerAttack);
            addSkillXP((int)(TotalExp), playerDefence);
            addSkillXP((int)(TotalExp), playerStrength);
          }
          TotalExp = (double)(20*hitDiff*2);  //added *2 for faster leveling -bakatool
          TotalExp = (double)(TotalExp*CombatExpRate);
          addSkillXP((int)(TotalExp), playerHitpoints);
          attackTimer = 7;
          lastAttack = System.currentTimeMillis();
        }
        return true;

      }
    }
    return false;
  }
  public boolean DeleteArrow() {
    if (playerEquipment[playerWeapon] == 4214) {
	if (playerEquipmentN[playerArrows] == 0) {
	return true;
	}
    }
    if (playerEquipment[playerWeapon] == 6082) {
	if (playerEquipmentN[playerArrows] == 0) {
	return true;
	}
    }
    if (playerEquipment[playerWeapon] == 4734) {
	if (playerEquipmentN[playerArrows] == 0) {
	return true;
	}
    }
    else if (playerEquipmentN[playerArrows] == 0) {
      deleteequiment(playerEquipment[playerArrows], playerArrows);
      return false;
    }
    if (playerEquipment[playerWeapon] != 4214 && playerEquipment[playerWeapon] != 6082 && playerEquipment[playerWeapon] != 4734 && playerEquipmentN[playerArrows] > 0) {
      outStream.createFrameVarSizeWord(34);
      outStream.writeWord(1688);
      outStream.writeByte(playerArrows);
      outStream.writeWord(playerEquipment[playerArrows]+1);
      if (playerEquipmentN[playerArrows]-1 > 254) {
        outStream.writeByte(255);
        outStream.writeDWord(playerEquipmentN[playerArrows]-1);
      } else {
        outStream.writeByte(playerEquipmentN[playerArrows]-1); //amount	
      }
      outStream.endFrameVarSizeWord();
      playerEquipmentN[playerArrows] -= 1;
    }
    updateRequired = true;
    appearanceUpdateRequired = true;
    return true;
  }



  public boolean ResetAttackNPC() {
    if (attacknpc > -1 && attacknpc < server.npcHandler.maxNPCSpawns) {
      server.npcHandler.npcs[attacknpc].IsUnderAttack = false;
      server.npcHandler.npcs[attacknpc].IsUnderAttack = false;
      server.npcHandler.npcs[attacknpc].StartKilling = 0;
    }
    //server.npcHandler.npcs[attacknpc].TurnNPCTo(server.npcHandler.npcs[attacknpc].absX, server.npcHandler.npcs[attacknpc].absY);
    //server.npcHandler.npcs[attacknpc].FocusUpdateRequired = true;
    IsAttackingNPC = false;
    attacknpc = -1;
   
    return true;
  }

  public void ManipulateDirection() {
    // playerMD = misc.direction(absX, absY, skillX, skillY);
    if (playerMD != -1) {
      // playerMD >>= 1;
      updateRequired = true;
      dirUpdateRequired = true;
    }
  }

  public void ReplaceObject(int objectX, int objectY, int NewObjectID, int Face, int ObjectType) {
    outStream.createFrame(85);
    outStream.writeByteC(objectY-(mapRegionY*8));
    outStream.writeByteC(objectX-(mapRegionX*8));

    outStream.createFrame(101);
    outStream.writeByteC((ObjectType << 2)+(Face & 3));
    outStream.writeByte(0);

    if (NewObjectID != -1) {
      outStream.createFrame(151);
      outStream.writeByteS(0);
      outStream.writeWordBigEndian(NewObjectID);
      outStream.writeByteS((ObjectType << 2)+(Face & 3));
      // FACE: 0= WEST | -1 = NORTH | -2 = EAST | -3 = SOUTH
      // ObjectType: 0-3 wall objects, 4-8 wall decoration, 9: diag. walls, 10-11 world objects, 12-21: roofs, 22: floor decoration
    }
  }

  public int GetNPCID(int coordX, int coordY) {
    for (int i = 0; i < server.npcHandler.maxNPCSpawns; i++) {
      if (server.npcHandler.npcs[i] != null) {
        if (server.npcHandler.npcs[i].absX == coordX && server.npcHandler.npcs[i].absY == coordY) {
          return server.npcHandler.npcs[i].npcType;
        }
      }
    }
    return 1;
  }

  public String GetNpcName(int NpcID) {
    for (int i = 0; i < server.npcHandler.maxListedNPCs; i++) {
      if (server.npcHandler.NpcList[i] != null) {
        if (server.npcHandler.NpcList[i].npcId == NpcID) {
          return server.npcHandler.NpcList[i].npcName;
        }
      }
    }
    return "Invalid NPC name:"+NpcID;
  }

  public String GetItemName(int ItemID) {
    for (int i = 0; i < server.itemHandler.MaxListedItems; i++) {
      if (server.itemHandler.ItemList[i] != null) {
        if (server.itemHandler.ItemList[i].itemId == ItemID) {
          return server.itemHandler.ItemList[i].itemName;
        }
      }
    }
    return "Missing Item Name";
  }

  public double GetItemShopValue(int ItemID, int Type, int fromSlot) {
    double ShopValue = 1;
    double Overstock = 0;
    double TotPrice = 0;

    for (int i = 0; i < server.itemHandler.MaxListedItems; i++) {
      if (server.itemHandler.ItemList[i] != null) {
        if (server.itemHandler.ItemList[i].itemId == ItemID) {
          ShopValue = server.itemHandler.ItemList[i].ShopValue;
        }
      }
    }
    TotPrice = (ShopValue*1.0); // Calculates price for 1 item, in db is stored for 0 items (strange but true)

    if (server.shopHandler.ShopBModifier[MyShopID] >= 1) {
      TotPrice *= 1.0; // 25% more expensive (general stores only)
      if (Type == 1) {
        TotPrice *= 0.5; // general store buys item at 40% of its own selling value
      }
    } else if (Type == 1) {
      TotPrice *= 0.8; // other stores buy item at 60% of their own selling value
    }
    return TotPrice;
  }

  public int GetUnnotedItem(int ItemID) {
    int NewID = 0;
    String NotedName = "";

    for (int i = 0; i < server.itemHandler.MaxListedItems; i++) {
      if (server.itemHandler.ItemList[i] != null) {
        if (server.itemHandler.ItemList[i].itemId == ItemID) {
          NotedName = server.itemHandler.ItemList[i].itemName;
        }
      }
    }
    for (int i = 0; i < server.itemHandler.MaxListedItems; i++) {
      if (server.itemHandler.ItemList[i] != null) {
        if (server.itemHandler.ItemList[i].itemName == NotedName) {
          if (server.itemHandler.ItemList[i].itemDescription.startsWith("Swap this note at any bank for a") == false) {
            NewID = server.itemHandler.ItemList[i].itemId;
            break;
          }
        }
      }
    }
    return NewID;
  }

  public void WriteEnergy() {
    //if (playerRights < 3) {
    playerEnergy = 100;
    //}
    sendFrame126(playerEnergy+"%", 149);
  }

  public void ResetBonus() {
    for (int i = 0; i < playerBonus.length; i++) {
      playerBonus[i] = 0;
    }
  }
  public void GetBonus() {
    for (int i = 0; i < playerEquipment.length; i++) {
      if (playerEquipment[i] > -1) {
        for (int j = 0; j < 9999; j++) {
          if (server.itemHandler.ItemList[j] != null) {
            if (server.itemHandler.ItemList[j].itemId == playerEquipment[i]) {
              for (int k = 0; k < playerBonus.length; k++) {
                playerBonus[k] += server.itemHandler.ItemList[j].Bonuses[k];
              }
              break;
            }
          }
        }
      }
    }
    for (int i = 0; i < 5; i++) {
      playerBonus[i] += (int)(playerLevel[0]/10);
    }

    playerBonus[5] += (int)(playerLevel[1]/5);
    playerBonus[6] += (int)(playerLevel[1]/5);
    playerBonus[7] += (int)(playerLevel[1]/5);
    playerBonus[8] += (int)(playerLevel[1]/5);
    playerBonus[9] += (int)(playerLevel[1]/5);

    playerBonus[10] += (int)(playerLevel[2]/5);
    //maxHealth = playerLevel[3];
  }
  public void GetBonus_old() {
    for (int i = 0; i < playerEquipment.length; i++) {
      if (playerEquipment[i] > -1) {
        for (int j = 0; j < server.itemHandler.MaxListedItems; j++) {
          if (server.itemHandler.ItemList[i] != null) {
            if (server.itemHandler.ItemList[j] == null)
              println("It's null");
            if (server.itemHandler.ItemList[j].itemId == playerEquipment[i]) {
              for (int k = 0; k < playerBonus.length; k++) {
                playerBonus[k] += server.itemHandler.ItemList[j].Bonuses[k];
              }
              break;
            }
          } else {
            println("Error:  ItemList = null");
          }
        }
      }
    }
  }

  public void WriteBonus() {
    int offset = 0;
    String send = "";

    for (int i = 0; i < playerBonus.length; i++) {
      if (playerBonus[i] >= 0) {
        send = BonusName[i]+": +"+playerBonus[i];
      } else {
        send = BonusName[i]+": -"+java.lang.Math.abs(playerBonus[i]);
      }

      if (i == 10) {
        offset = 1;
      }
      if (i == 11) {
        send = "Spell Dmg:  +"+playerBonus[i]+"";
      }
      sendFrame126(send, (1675+i+offset));
    }
    CalculateMaxHit();
  }

  public void CalculateMaxHit() {
    double MaxHit = 0;
    int StrBonus = playerBonus[10]; // Strength Bonus
    int Strength = playerLevel[playerStrength]; // Strength
    int RngBonus = playerBonus[4]; // Ranged Bonus
    int Range = playerLevel[playerRanged]; // Ranged

    if (FightType == 1 || FightType == 4) {
      // Accurate & Defensive
      MaxHit += (double)(1.05+(double)((double)(StrBonus*Strength)*0.00175));
    } else if (FightType == 2) {
      // Aggresive
      MaxHit += (double)(1.35+(double)((double)(StrBonus*Strength)*0.00175));
    } else if (FightType == 3) {
      // Controlled
      MaxHit += (double)(1.15+(double)((double)(StrBonus*Strength)*0.00175));
    }
    MaxHit += (double)(Strength*0.1);
    if (StrPrayer == 1) {
      // Burst Of Strength
      MaxHit += (double)(Strength*0.005);
    } else if (StrPrayer == 2) {
      // Super Human Strength
      MaxHit += (double)(Strength*0.01);
    } else if (StrPrayer == 3) {
      // Ultimate Strength
      MaxHit += (double)(Strength*0.015);
    }
    if (FightType == 5 || FightType == 6) {
      // Accurate and Longranged
      MaxHit += (double)(1.05+(double)((double)(RngBonus*Range)*0.00075));
    } else if (FightType == 7) {
      // Rapid
      MaxHit += (double)(1.35+(double)((double)(RngBonus)*0.00025));
    }
    //MaxHit += (double) (Range * 0.03);
    playerMaxHit = (int)Math.floor(MaxHit);
  }

  public boolean GoodDistance(int objectX, int objectY, int playerX, int playerY, int distance) {
    for (int i = 0; i <= distance; i++) {
      for (int j = 0; j <= distance; j++) {
        if ((objectX+i) == playerX && ((objectY+j) == playerY || (objectY-j) == playerY || objectY == playerY)) {
          return true;
        } else if ((objectX-i) == playerX && ((objectY+j) == playerY || (objectY-j) == playerY || objectY == playerY)) {
          return true;
        } else if (objectX == playerX && ((objectY+j) == playerY || (objectY-j) == playerY || objectY == playerY)) {
          return true;
        }
      }
    }
    return false;
  }

  public boolean GoodDistance2(int objectX, int objectY, int playerX, int playerY, int distance) {
    for (int i = 0; i <= distance; i++) {
      for (int j = 0; j <= distance; j++) {
        if (objectX == playerX && ((objectY+j) == playerY || (objectY-j) == playerY || objectY == playerY)) {
          return true;
        } else if (objectY == playerY && ((objectX+j) == playerX || (objectX-j) == playerX || objectX == playerX)) {
          return true;
        }
      }
    }
    return false;
  }

  public boolean CheckObjectSkill(int objectID) {
    boolean GoFalse = false;

    switch (objectID) {

      case 1276:
      case 1277:
      case 1278:
      case 1279:
      case 1280:
      case 1330:
      case 1332:
      case 2409:
      case 3033:
      case 3034:
      case 3035:
      case 3036:
      case 3879:
      case 3881:
      case 3882:
      case 3883:
        // Normal Tree
      case 1315:
      case 1316:
      case 1318:
      case 1319:
        // Evergreen
      case 1282:
      case 1283:
      case 1284:
      case 1285:
      case 1286:
      case 1287:
      case 1289:
      case 1290:
      case 1291:
      case 1365:
      case 1383:
      case 1384:
      case 5902:
      case 5903:
      case 5904:
        // Dead Tree
        woodcutting[0] = 1;
        woodcutting[1] = 1;
        woodcutting[2] = 25;
        woodcutting[4] = 1511;
        break;

      case 2023:
        // Achey Tree
        woodcutting[0] = 2;
        woodcutting[1] = 1;
        woodcutting[2] = 25;
        woodcutting[4] = 2862;
        break;
      case 1281:
      case 3037:
        // Oak Tree
        woodcutting[0] = 3;
        woodcutting[1] = 15;
        if (misc.random(2) == 1) {
            woodcutting[2] = 37;
        }
         else {
            woodcutting[2] = 38;
        }
        woodcutting[4] = 1521;
        break;

      case 1308:
      case 5551:
      case 5552:
      case 5553:
        // Willow Tree
        woodcutting[0] = 4;
        woodcutting[1] = 30;
        if (misc.random(2) == 1) {
            woodcutting[2] = 67;
        }
         else {
            woodcutting[2] = 68;
        }
        woodcutting[4] = 1519;
        break;

      case 9036:
        // Teak Tree
        woodcutting[0] = 5;
        woodcutting[1] = 35;
        woodcutting[2] = 85;
        woodcutting[4] = 6333;
        break;

      case 1292:
        // Dramen Tree
        woodcutting[0] = 5;
        woodcutting[1] = 36;
        woodcutting[2] = 0;
        woodcutting[4] = 771;
        break;

      case 1307:
      case 4674:
        // Maple Tree
        woodcutting[0] = 6;
        woodcutting[1] = 45;
        woodcutting[2] = 100;
        woodcutting[4] = 1517;
        break;

      case 2289:
      case 4060:
        // Hollow Tree
        woodcutting[0] = 7;
        woodcutting[1] = 45;
        if (misc.random(2) == 1) {
            woodcutting[2] = 82;
        }
         else {
            woodcutting[2] = 83;
        }
        woodcutting[4] = 3239;
        break;

      case 9034:
        // Mahogany Tree
        woodcutting[0] = 8;
        woodcutting[1] = 50;
        woodcutting[2] = 125;
        woodcutting[4] = 4445;
        break;

      case 1309:
        // Yew Tree
        woodcutting[0] = 9;
        woodcutting[1] = 60;
        woodcutting[2] = 175;
        woodcutting[4] = 1515;
        woodcutting[5] = 3;
        break;

      case 1306:
        // Magic Tree
	if(premium == 0){
			sendMessage("You need premium to mine rune rocks.");
			}else{
        woodcutting[0] = 10;
        woodcutting[1] = 75;
        woodcutting[2] = 250;
        woodcutting[4] = 1513;
	}
        break;
		case 2108:
		case 2109:
			// clay rock
			mining[0] = 1;
			mining[1] = 1;
			mining[2] = 5;
			mining[4] = 434;
			break;

		case 2090:
		case 2091:
			// copper rock
			mining[0] = 1;
			mining[1] = 1;
			if (misc.random(2) == 1) {
				mining[2] = 17;
			} else {
				mining[2] = 18;
			}
			mining[4] = 436;
			break;

		case 2094:
		case 2095:
			// tin rock
			mining[0] = 1;
			mining[1] = 2;
			mining[2] = 110;
			mining[4] = 438;
			break;

		case 2110:
			// blurite rock
			mining[0] = 2;
			mining[1] = 10;
			if (misc.random(2) == 1) {
				mining[2] = 17;
			} else {
				mining[2] = 18;
			}
			mining[4] = 668;
			break;

		case 4028:
		case 4029:
		case 4030:
			// lime rock
			mining[0] = 1;
			mining[1] = 1;
			if (misc.random(2) == 1) {
				mining[2] = 26;
			} else {
				mining[2] = 27;
			}
			mining[4] = 3211;
			break;

		case 2092:
		case 2093:
			// iron rock
			mining[0] = 3;
			mining[1] = 15;
			mining[2] = 240;
			mining[4] = 440;
			break;

		case 2100:
		case 2101:
			// silver rock
			mining[0] = 4;
			mining[1] = 20;
			mining[2] = 40;
			mining[4] = 442;
			break;

		case 3403:
			// elemental rock
			mining[0] = 4;
			mining[1] = 20;
			mining[2] = 20;
			mining[4] = 2892;
			break;

		case 2096:
			// coal rock
			mining[0] = 5;
			mining[1] = 30;
			mining[2] = 360;
			mining[4] = 453;
			break;

		case 2098:
		case 2099:
			// gold rock
			mining[0] = 6;
			mining[1] = 40;
			mining[2] = 65;
			break;

		case 2111:
			// coal rock
			mining[0] = 7;
			mining[1] = 1;
			mining[2] = 360;
			mining[3] = 1;
			mining[4] = Item.randomSGems();
			break;

		case 2102:
		case 2103:
			// mithril rock
			mining[0] = 7;
			mining[1] = 55;
			mining[2] = 420;
			mining[4] = 447;
			break;

		case 2104:
		case 2105:
			// adamant rock
			if (actionTimer == 0) {
				mining[0] = 8;
				mining[1] = 70;
				mining[2] = 490;
				mining[4] = 449;
				actionTimer = 7;
			}
			break;

		case 2106:
		case 2107:
			// rune rock
			if(premium == 0){
			sendMessage("You need premium to mine rune rocks.");
			}else{
			if (actionTimer == 0) {
				mining[0] = 9;
				mining[1] = 85;
				mining[2] = 2925;
				mining[4] = 451;
				actionTimer = 15;
			}
			}
			break;

		default:
			GoFalse = true;
			break;
		}
		if (GoFalse == true) {
			return false;
		}
		return true;
	}

  

  public boolean resetCO() {
    cooking[0] = 0;
    cooking[1] = 0;
    cooking[2] = 0;
    cooking[4] = -1;
    IsUsingSkill = false;
    return true;
  }
  /* HEALING*/
  public boolean healing() {
    if (actionTimer == 0 && healing[0] == 1) {
      actionAmount++;
      actionTimer = 4;
      OriginalShield = playerEquipment[playerShield];
      OriginalWeapon = playerEquipment[playerWeapon];
      playerEquipment[playerShield] = -1;
      playerEquipment[playerWeapon] = -1;
      setAnimation(0x33D);
      healing[0] = 2;
    }
    if (actionTimer == 0 && healing[0] == 2) {
      deleteItem(healing[4], GetItemSlot(healing[4]), 1);
      int Heal = healing[1];
      int HealDiff = (healing[2]-healing[1]);

      if (HealDiff > 0) {
        Heal += misc.random(HealDiff);
      }
      if (healing[3] != -1) {
        addItem(healing[3], 1);
      }
      NewHP = (playerLevel[playerHitpoints]+Heal);
      if (NewHP > getLevelForXP(playerXP[playerHitpoints])) {
        NewHP = getLevelForXP(playerXP[playerHitpoints]);
      }
      sendMessage("You eat the "+GetItemName(healing[4])+".");
      playerEquipment[playerWeapon] = OriginalWeapon;
      playerEquipment[playerShield] = OriginalShield;
      OriginalWeapon = -1;
      OriginalShield = -1;
      resetAnimation();
      resetHE();
    }
    return true;
  }

  public boolean resetHE() {
    healing[0] = 0;
    healing[1] = 0;
    healing[2] = 0;
    healing[3] = -1;
    healing[4] = -1;
    IsUsingSkill = false;
    return true;
  }

  /* MINING*/

  public int findpickaxelvl(int axeid)
	{
		switch (axeid)
		{
			case 1:
			case 0:
				return 1;
			case 2:
				return 6;
			case 3:
				return 21;
			case 4:
				return 31;
			case 5:
				return 41;
			
		default:
				return 0;
		}
	}
public int GetpickAxeAni() {
		int pickani = 0;
		int pickAxe = playerEquipment[playerWeapon];
		if (pickAxe == 1265) {
			pickani = 625;
		} else if (pickAxe == 1267) {
			pickani = 626;
		} else if (pickAxe == 1269) {
			pickani = 627;
		} else if (pickAxe == 1271) {
			pickani = 629;
		} else if (pickAxe == 1273) {
			pickani = 628;
		} else if (pickAxe == 1275) {
			pickani = 624;
		
		}
		if (AreXItemsInBag(1265, 1)) {
			pickani = 625;
		} else if (AreXItemsInBag(1267, 1)) {
			pickani = 626;
		} else if (AreXItemsInBag(1269, 1)) {
			pickani = 627;
		} else if (AreXItemsInBag(1271, 1)) {
			pickani = 629;
		} else if (AreXItemsInBag(1273, 1)) {
			pickani = 628;
		} else if (AreXItemsInBag(1275, 1)) {
			pickani = 624;
	
		}
		return pickani;
	}
public boolean Minning = false;
	public int MineTimer;
	public int RockLevel;
	public int RockId;
	public int RockXp;
	public int OreId;
	public int EmptyId;
	public int Gonefor;
	public int HowManyRocks;
	public int RockX;
	public int RockY;
public void Initiatemin(int rock, int x, int y) {
		int pickAxeId = CheckpickAxe();
		int MinusTime = 0;
		RockId = rock;
		if (pickAxeId == 1265) {
			MinusTime = 4;
		} else if (pickAxeId == 1267) {
			MinusTime = 6;
		} else if (pickAxeId == 1269) {
			MinusTime = 10;
		} else if (pickAxeId == 1271) {
			MinusTime = 17;
		} else if (pickAxeId == 1273) {
			MinusTime = 31;
		} else if (pickAxeId == 1275) {
			MinusTime = 40;
		
		}
		if (RockId == 2090 || RockId == 2091) {//copper
			Mine1Timer = 12;
			RockLevel = 1;
			HowManyRocks = 1;
			RockXp = Config.copper;
			OreId = 436;
			EmptyId = 450;
			Gonefor = 5;
		} else if (RockId == 2092 || RockId == 2093) {//iron
			Mine1Timer = 20;
			RockLevel = 15;
			HowManyRocks = 1;
			RockXp = Config.iron;
			OreId = 440;
			EmptyId = 450;
			Gonefor = 25;
		} else if (RockId == 2094 || RockId == 2095) {//tin
			Mine1Timer = 12;
			RockLevel = 1;
			HowManyRocks = 1;
			RockXp = Config.tin;
			OreId = 438;
			EmptyId = 450;
			Gonefor = 5;
		} else if (RockId == 2096 || RockId == 2097) {//coal
			Mine1Timer = 60;
			RockLevel = 30;
			HowManyRocks = 1;
			RockXp = Config.coal;
			OreId = 453;
			EmptyId = 450;
			Gonefor = 60;
		} else if (RockId == 2098 || RockId == 2099) {//gold
			Mine1Timer = 50;
			RockLevel = 40;
			HowManyRocks = 1;
			RockXp = Config.gold;
			OreId = 444;
			EmptyId = 450;
			Gonefor = 75;
		} else if (RockId == 2100 || RockId == 2101) {//silver
			Mine1Timer = 30;
			RockLevel = 20;
			HowManyRocks = 1;
			RockXp = Config.silver;
			OreId = 442;
			EmptyId = 450;
			Gonefor = 10;
		} else if (RockId == 2102 || RockId == 2103) {//mithril
			Mine1Timer = 70;
			RockLevel = 55;
			HowManyRocks = 1;
			RockXp = Config.mithril;
			OreId = 447;
			EmptyId = 450;
			Gonefor = 80;
		} else if (RockId == 2104 || RockId == 2105) {//adamant
			Mine1Timer = 80;
			RockLevel = 70;
			HowManyRocks = 1;
			RockXp = Config.adamant;
			OreId = 449;
			EmptyId = 450;
			Gonefor = 150;
		} else if (RockId == 2106 || RockId == 2107) {//rune
			Mine1Timer = 100;
			RockLevel = 85;
			HowManyRocks = 1;
			RockXp = Config.rune;
			OreId = 451;
			EmptyId = 450;
			Gonefor = 230;
		} else if (RockId == 2108 || RockId == 2109) {//clay
			Mine1Timer = 24;
			RockLevel = 1;
			HowManyRocks = 1;
			RockXp = Config.clay;
			OreId = 434;
			EmptyId = 450;
			Gonefor = 3;
		} else if (RockId == 2110) {//blurite
			Mine1Timer = 45;
			RockLevel = 10;
			HowManyRocks = 1;
			RockXp = Config.blurite;
			OreId = 668;
			EmptyId = 450;
			Gonefor = 20;
		} else {
			resetmin();
			return;
		}
		if (freeSlots() == 0) {
			sendMessage("You do not have enough inventory space to hold anymore rocks!");
			resetmin();
			
			return;
		}
		if (pickAxeId != -1) {
			if (getLevelForXP(playerXP[14]) < RockLevel) {
				sendMessage("You are not a high enough level.");
				sendMessage("You must atleast get a level of " + RockLevel
						+ " to mine this rock.");
				resetmin();
				return;
			}
			if (!Minning) {
				sendMessage("You swing your pick at the rock.");
			}
			if (getLevelForXP(playerXP[14]) >= findpickaxelvl(pickAxeId)){
			RockX = x;
			RockY = y;
			MineTimer = misc.random(Mine1Timer - MinusTime - misc.random(getLevelForXP(playerXP[14]) / 6));
			if(MineTimer <= 0)
			MineTimer = 2;
			
			
			Minning = true;
			}else{
			sendMessage("You are not a high enough level.");
				sendMessage("You're Minning level is not high enough to mine this rock.");
				MineTimer = 0;
				return;
			}
		} else {
			resetmin();
			sendMessage("You need a Pickaxe to chop down this tree!");
		}
	}
	public int Mine1Timer = 0;

	public void resetmin() {
		Minning = false;
		MineTimer = 0;
		RockLevel = 0;
		RockId = 0;
		RockXp = 0;
		OreId = 0;
		EmptyId = 0;
		Gonefor = 0;
		HowManyRocks = 0;
		RockX = 0;
		RockY = 0;
		repeatani = 0;
		resetAnimation();
	}

	public int repeatani = 0;
	public int pickani = 0;

	

	public void Spawnempty() {
		for (int i = 0; i < server.Rocks; i++) {
			if (server.RockSPAWN[i] > 0) {
				AddGlobalObject(server.RockX[i], server.RockY[i],
						server.RockEMPTY[i], 0, 10);
			}
		}
	}
public void Minprocess() {
		if (repeatani > 0) {
			repeatani--;
		} else {
			startAnimation(GetpickAxeAni());
			PlayerHandler.players[playerId].updateRequired = true;
			PlayerHandler.players[playerId].appearanceUpdateRequired = true;
			repeatani = 3;
		}
	}
	public boolean Hasrocks() {
		for (int i = 0; i < server.Rocks; i++) {
			if (server.RockX[i] == RockX && server.RockY[i] == RockY) {
				if (server.RockSPAWN[i] > 0) {
					return false;
				} else if (server.RockSPAWN[i] == 0) {
					return true;
				}
			}
		}
		return false;
	}

	public boolean Removerocks() {
		boolean New = true;
		int Rockid = server.Rocks;
		for (int i = 0; i < server.Rocks; i++) {
			if (server.RockX[i] == RockX && server.RockY[i] == RockY) {
				if (!Hasrocks()) {
					resetmin();
					return false;
				}
				New = false;
				server.RocksLEFT[i]--;
				addSkillXP(RockXp, 14);
				addItem(OreId, 1);
				sendMessage("You manage to mine some " + GetItemName(OreId) + ".");
				if (server.RocksLEFT[i] <= 0) {
					server.RockSPAWN[i] = Gonefor;
					server.ores[i] = misc.random(HowManyRocks);
					if (server.ores[i] == 0) {
						server.ores[i] = 1;
					}
					AddGlobalObj(RockX, RockY, EmptyId, 0, 10);
					return false;
				}
				return true;
			}
		}
		if (New) {
			server.RockX[Rockid] = RockX;
			server.RockY[Rockid] = RockY;
			server.RockID[Rockid] = RockId;
			server.RockEMPTY[Rockid] = EmptyId;
			server.RocksLEFT[Rockid] = 5 + misc.random(10);;
			if (server.RocksLEFT[Rockid] == 0) {
				server.RocksLEFT[Rockid] = 1;
			}
			server.Rocks++;
			return true;
		}
		return false;
	}
//end of mining
	public int CheckpickAxe() {
		int pickAxe = playerEquipment[playerWeapon];
		if (pickAxe == 1265) {
			return 0;
		} else if (pickAxe == 1267) {
			return 1;
		} else if (pickAxe == 1269) {
			return 2;
		} else if (pickAxe == 1271) {
			return 3;
		} else if (pickAxe == 1273) {
			return 4;
		} else if (pickAxe == 1275) {
			return 5;
		
			
		}
		if (AreXItemsInBag(1265, 1)) {
			return 0;
		} else if (AreXItemsInBag(1267, 1)) {
			return 1;
		} else if (AreXItemsInBag(1269, 1)) {
			return 2;
		} else if (AreXItemsInBag(1271, 1)) {
			return 3;
		} else if (AreXItemsInBag(1273, 1)) {
			return 4;
		} else if (AreXItemsInBag(1275, 1)) {
			return 5;
	
		}
		return -1;
	}
  

  /* PRAYER*/
  public boolean prayer() {
    if (actionTimer != 0)
      return false;
    if (playerLevel[playerPrayer] >= prayer[1]) {
      if (actionTimer == 0 && prayer[0] == 1) {
        //actionAmount++;
        actionTimer = 4;
        OriginalShield = playerEquipment[playerShield];
        OriginalWeapon = playerEquipment[playerWeapon];
        //playerEquipment[playerShield] = -1;
        //playerEquipment[playerWeapon] = -1;
        setAnimation(0x33B);
        prayer[0] = 2;
      }
      if (actionTimer == 0 && prayer[0] == 2) {
        deleteItem(prayer[4], prayer[5], playerItemsN[prayer[5]]);
        addSkillXP((prayer[2]*prayer[3]), playerPrayer);
        sendMessage("You bury the bones.");
        playerEquipment[playerWeapon] = OriginalWeapon;
        playerEquipment[playerShield] = OriginalShield;
        //OriginalWeapon = -1;
        //OriginalShield = -1;
        resetAnimation();
        resetPR();
        //actionAmount++;
        actionTimer = 4;
      }
    }
    return true;
  }

  public boolean resetPR() {
    prayer[0] = 0;
    prayer[1] = 0;
    prayer[2] = 0;
    prayer[4] = -1;
    prayer[5] = -1;
    IsUsingSkill = false;
    return true;
  }






  public boolean resetSM() {
    if (OriginalWeapon > -1) {
      playerEquipment[playerWeapon] = OriginalWeapon;
      OriginalWeapon = -1;
      playerEquipment[playerShield] = OriginalShield;
      OriginalShield = -1;
       }
    return true;
  }

  /* WOODCUTTING*/
  public boolean woodcutting() {
    if (randomed)
      return false;
    int WCAxe = 0;

    if (IsCutting == true) {
      WCAxe = 1; // If Cutting -> Go trough loop, passby WCCheckAxe to prevent originalweapon loss, 1 to tell you got axe, no function left for WCAxe if cutting, so 1 is enough.
    } else {
      WCAxe = WCCheckAxe();
    }
    if (WCAxe > 0) {
      if (playerLevel[playerWoodcutting] >= woodcutting[1]) {
        if (freeSlots() > 0) {
          if (System.currentTimeMillis()-lastAction >= 1000 && IsCutting == false) {
            lastAction = System.currentTimeMillis();
            attackTimer++;
            sendMessage("You swing your axe at the tree...");
            attackTimer = (int)((woodcutting[0]+10)-WCAxe);
            if (attackTimer < 1) {
              attackTimer = 1;
            }
            startAnimation(875);
            IsCutting = true;
          }
          if (System.currentTimeMillis()-lastAction >= 1600 && IsCutting == true) {
            lastAction = System.currentTimeMillis();
            addSkillXP((woodcutting[2]*woodcutting[3]*2), playerWoodcutting);
            if (misc.random(100) == 1) {
              return true;
            }
            if (freeSlots() > 0) {
              sendMessage("You get some logs.");
              addItem(woodcutting[4], 1);
              attackTimer += 10;
            } else {
              playerEquipment[playerWeapon] = OriginalWeapon;
              OriginalWeapon = -1;
              resetAnimation();
              IsCutting = false;
              resetWC();
            }
          }
        } else {
          //createEnemyItem(woodcutting[4]);
          sendMessage("Not enough space in your inventory.");
          woodcutting[0] = -1;
          resetWC();
          return false;
        }
      } else {
        sendMessage("You need "+woodcutting[1]+" "+statName[playerWoodcutting]+" to cut those logs.");
        resetWC();
        return false;
      }
    } else {
      sendMessage("Equip your axe before cutting trees!");
      resetWC();
      return false;
    }
    return true;
  }

  public boolean resetWC() {
    woodcutting[0] = 0;
    woodcutting[1] = 0;
    woodcutting[2] = 0;
    woodcutting[4] = 0;
    woodcutting[5] = 2;
    skillX = -1;
    skillY = -1;
    IsCutting = false;
    IsUsingSkill = false;
    resetAnimation();
    return true;
  }

  public int WCCheckAxe() {
    int Hand;
    int Shield;
    int Bag;
    int Axe;

    Hand = playerEquipment[playerWeapon];
    Shield = playerEquipment[playerShield];
    Axe = 0;
    switch (Hand) {
      case 1351:
        // Bronze Axe
        Axe = 1;
        break;

      case 1349:
        // Iron Axe
        Axe = 2;
        break;

      case 1353:
        // Steel Axe
        Axe = 3;
        break;

      case 1361:
        // Black Axe
        Axe = 4;
        break;

      case 1355:
        // Mithril Axe
        Axe = 5;
        break;

      case 1357:
        // Adamant Axe
        Axe = 6;
        break;

      case 1359:
        // Rune Axe
        Axe = 7;
        break;

        case 6739: //Dragon Axe
        Axe = 8; 
	break;
    }
    return Axe;
  }



	public boolean fromTrade(int itemID, int fromSlot, int amount) {
		if (System.currentTimeMillis() - lastButton > 800) {
			lastButton = System.currentTimeMillis();
		} else {
			return false;
		}
		try {
			client other = getClient(trade_reqId);
			if (!inTrade || !validClient(trade_reqId) || !canOffer) {
				declineTrade();
				return false;
			}
			if (!Item.itemStackable[itemID] && (amount > 1)) {
				for (int a = 1; a <= amount; a++) {
					int slot = findItem(itemID, playerItems, playerItemsN);
					if (slot >= 0) {
						fromTrade(itemID, 0, 1);
					}
				}
			}
			boolean found = false;
			for (GameItem item : offeredItems) {
				if (item.id == itemID) {
					if (!item.stackable) {
						offeredItems.remove(item);
						found = true;
					} else {
						if (item.amount > amount) {
							item.amount -= amount;
							found = true;
						} else {
							amount = item.amount;
							found = true;
							offeredItems.remove(item);
						}
					}
					break;
				}
			}
			if (found)
				addItem(itemID, amount);
			tradeConfirmed = false;
			other.tradeConfirmed = false;
			resetItems(3322);
			resetTItems(3415);
			other.resetOTItems(3416);
			sendFrame126("", 3431);
			other.sendFrame126("", 3431);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;
	}

	public boolean tradeItem(int itemID, int fromSlot, int amount) {
		client other = getClient(trade_reqId);
	if (fromSlot == TlastSlot) { //anti dupe by Vodka I C E
		TlastSlot = -1;
        	return false;
	}
	if (fromSlot == other.TlastSlot) { //anti dupe by Vodka I C E
		other.TlastSlot = -1;
        	return false;
	}
	TlastSlot = fromSlot;
	RlastSlot = fromSlot; //end of anti dupe
		if (System.currentTimeMillis() - lastButton > 800) {
			lastButton = System.currentTimeMillis();
		} else {
			return false;
		}
		if (!Item.itemStackable[itemID] && (amount > 1)) {
			for (int a = 1; a <= amount; a++) {
				int slot = findItem(itemID, playerItems, playerItemsN);
				if (slot >= 0) {
					tradeItem(itemID, slot, 1);
				}
			}
		}
		for (int element : noTrade) {
			if ((itemID == element) || (itemID == element + 1)) {
				sendMessage("You can't trade that item");
				declineTrade();
				return false;
			}
		}
		if (!inTrade || !validClient(trade_reqId) || !canOffer) {
			declineTrade();
			return false;
		}
		if (!playerHasItem(itemID, amount)) {
			return false;
		}
		if (Item.itemStackable[itemID] || Item.itemIsNote[itemID]) {
			boolean inTrade = false;
			for (GameItem item : offeredItems) {
				if (item.id == itemID) {
					inTrade = true;
					item.amount += amount;
					break;
				}
			}
			if (!inTrade) {
				offeredItems.add(new GameItem(itemID, amount));
			}
		} else {
			offeredItems.add(new GameItem(itemID, 1));
		}
		deleteItem(itemID, fromSlot, amount);
		resetItems(3322);
		resetTItems(3415);
		other.resetOTItems(3416);
		sendFrame126("", 3431);
		other.sendFrame126("", 3431);
		return true;
	}

   /*Shops*/

  public boolean buyItem(int itemID, int fromSlot, int amount) {
    if (amount > 0 && itemID == (server.shopHandler.ShopItems[MyShopID][fromSlot]-1)) {
      if (amount > server.shopHandler.ShopItemsN[MyShopID][fromSlot]) {
        amount = server.shopHandler.ShopItemsN[MyShopID][fromSlot];
      }
      double ShopValue;
      double TotPrice;
      int TotPrice2;
      int Overstock;
      int Slot = 0;
      for (int i = amount; i > 0; i--) {
        TotPrice2 = (int)Math.floor(GetItemShopValue(itemID, 0, fromSlot));
        Slot = GetItemSlot(995);
        if (Slot == -1) {
          sendMessage("You don't have enough coins.");
          break;
        }
        if (playerItemsN[Slot] >= TotPrice2) {
          if (freeSlots() > 0) {
            deleteItem(995, GetItemSlot(995), TotPrice2);
            addItem(itemID, 1);
            server.shopHandler.ShopItemsN[MyShopID][fromSlot] -= 1;
            server.shopHandler.ShopItemsDelay[MyShopID][fromSlot] = 0;
            if ((fromSlot+1) > server.shopHandler.ShopItemsStandard[MyShopID]) {
              server.shopHandler.ShopItems[MyShopID][fromSlot] = 0;
            }
          } else {
            sendMessage("Not enough space in your inventory.");
            break;
          }
        } else {
          sendMessage("You don't have enough coins.");
          break;
        }
      }
      resetItems(3823);
      resetShop(MyShopID);
      UpdatePlayerShop();
      return true;
    }
    return false;
  }

    public boolean buyItem2(int itemID, int fromSlot, int amount) {
        if (playerHasItem(-1)) {
            if (amount > 0
                    && itemID
                            == (server.shopHandler.ShopItems[MyShopID][fromSlot]
                                    - 1)) {
                if (amount > server.shopHandler.ShopItemsN[MyShopID][fromSlot]) {
                    amount = server.shopHandler.ShopItemsN[MyShopID][fromSlot];
                }
                double ShopValue;
                double TotPrice;
                int TotPrice2;
                int Overstock;
                int Slot = 0;

                for (int i = amount; i > 0; i--) {
                    TotPrice2 = (int) Math.floor(
                            GetItemShopValue(itemID, 0, fromSlot));
                    Slot = GetItemSlot(6306);
                    if (Slot == -1) {
                        sendMessage(
                                "You don't have trading sticks.");
                        break;
                    }
                    if (TotPrice2 <= 1) {
                        TotPrice2 = (int) Math.floor(
                                GetItemShopValue(itemID, 0, fromSlot));
                    }
                    if (playerItemsN[Slot] >= TotPrice2) {
                        if (freeSlots() > 0) {
                            deleteItem(6306, GetItemSlot(6306),
                                    TotPrice2);
                            addItem(itemID, 1);
                            server.shopHandler.ShopItemsN[MyShopID][fromSlot] -= 1;
                            server.shopHandler.ShopItemsDelay[MyShopID][fromSlot] = 0;
                            if ((fromSlot + 1)
                                    > server.shopHandler.ShopItemsStandard[MyShopID]) {
                                server.shopHandler.ShopItems[MyShopID][fromSlot] = 0;
                            }
                        } else {
                            sendMessage("Not enough space in your inventory.");
                            break;
                        }
                    } else {
                        sendMessage(
                                "You don't have enough trading sticks.");
                        break;
                    }
                }
                resetItems(3823);
                resetShop(MyShopID);
                UpdatePlayerShop();
                return true;
            }
        }
        return false;
    }

    public boolean buyItem3(int itemID, int fromSlot, int amount) {
        if (playerHasItem(-1)) {
            if (amount > 0
                    && itemID
                            == (server.shopHandler.ShopItems[MyShopID][fromSlot]
                                    - 1)) {
                if (amount > server.shopHandler.ShopItemsN[MyShopID][fromSlot]) {
                    amount = server.shopHandler.ShopItemsN[MyShopID][fromSlot];
                }
                double ShopValue;
                double TotPrice;
                int TotPrice2;
                int Overstock;
                int Slot = 0;

                for (int i = amount; i > 0; i--) {
                    TotPrice2 = (int) Math.floor(GetItemShopValue(itemID, 0, fromSlot));
                    Slot = GetItemSlot(4067);
                    if (Slot == -1) {
                        sendMessage("You don't have enough castle wars tickets.");
                        break;
                    }
                    if (TotPrice2 <= 1) {
                        TotPrice2 = (int) Math.floor(
                                GetItemShopValue(itemID, 0, fromSlot));
                    }
                    if (playerItemsN[Slot] >= TotPrice2) {
                        if (freeSlots() > 0) {
                            deleteItem(4067, GetItemSlot(4067),
                                    TotPrice2);
                            addItem(itemID, 1);
                            server.shopHandler.ShopItemsN[MyShopID][fromSlot] -= 1;
                            server.shopHandler.ShopItemsDelay[MyShopID][fromSlot] = 0;
                            if ((fromSlot + 1)
                                    > server.shopHandler.ShopItemsStandard[MyShopID]) {
                                server.shopHandler.ShopItems[MyShopID][fromSlot] = 0;
                            }
                        } else {
                            sendMessage("Not enough space in your inventory.");
                            break;
                        }
                    } else {
                        sendMessage("You don't have enough castle wars tickets.");
                        break;
                    }
                }
                resetItems(3823);
                resetShop(MyShopID);
                UpdatePlayerShop();
                return true;
            }
        }
        return false;
    }

    public boolean buyItem4(int itemID, int fromSlot, int amount) {
        if (playerHasItem(-1)) {
            if (amount > 0
                    && itemID
                            == (server.shopHandler.ShopItems[MyShopID][fromSlot]
                                    - 1)) {
                if (amount > server.shopHandler.ShopItemsN[MyShopID][fromSlot]) {
                    amount = server.shopHandler.ShopItemsN[MyShopID][fromSlot];
                }
                double ShopValue;
                double TotPrice;
                int TotPrice3;
                int Overstock;
                int Slot = 0;

                for (int i = amount; i > 0; i--) {
                    TotPrice3 = (int) Math.floor(
                            GetItemShopValue(itemID, 0, fromSlot));
                    Slot = GetItemSlot(6529);
                    if (Slot == -1) {
                        sendMessage(
                                "You don't have any tokkul.");
                        break;
                    }
                    if (TotPrice3 <= 1) {
                        TotPrice3 = (int) Math.floor(
                                GetItemShopValue(itemID, 0, fromSlot));
                    }
                    if (playerItemsN[Slot] >= TotPrice3) {
                        if (freeSlots() > 0) {
                            deleteItem(6529, GetItemSlot(6529),
                                    TotPrice3);
                            addItem(itemID, 1);
                            server.shopHandler.ShopItemsN[MyShopID][fromSlot] -= 1;
                            server.shopHandler.ShopItemsDelay[MyShopID][fromSlot] = 0;
                            if ((fromSlot + 1)
                                    > server.shopHandler.ShopItemsStandard[MyShopID]) {
                                server.shopHandler.ShopItems[MyShopID][fromSlot] = 0;
                            }
                        } else {
                            sendMessage("Not enough space in your inventory.");
                            break;
                        }
                    } else {
                        sendMessage(
                                "You don't have enough trading tokkul.");
                        break;
                    }
                }
                resetItems(3823);
                resetShop(MyShopID);
                UpdatePlayerShop();
                return true;
            }
        }
        return false;
    }

 public boolean sellItem(int itemID, int fromSlot, int amount) {
		if ((amount > 0) && (itemID == (playerItems[fromSlot] - 1))) {
			if (server.shopHandler.ShopSModifier[MyShopID] > 1) {
				boolean IsIn = false;

				for (int i = 0; i <= server.shopHandler.ShopItemsStandard[MyShopID]; i++) {
					if (itemID == (server.shopHandler.ShopItems[MyShopID][i] - 1)) {
						IsIn = true;
						break;
					}
				}
				if (IsIn == false) {
					sendMessage("You cannot sell " + getItemName(itemID)
							+ " in this store.");
					return false;
				}
			}
			if (Item.itemSellable[(playerItems[fromSlot] - 1)] == false) {
				sendMessage("I cannot sell " + getItemName(itemID) + ".");
				return false;
			}
			if ((amount > playerItemsN[fromSlot])
					&& ((Item.itemIsNote[(playerItems[fromSlot] - 1)] == true) || (Item.itemStackable[(playerItems[fromSlot] - 1)] == true))) {
				amount = playerItemsN[fromSlot];
			} else if ((amount > GetXItemsInBag(itemID))
					&& (Item.itemIsNote[(playerItems[fromSlot] - 1)] == false)
					&& (Item.itemStackable[(playerItems[fromSlot] - 1)] == false)) {
				amount = GetXItemsInBag(itemID);
			}
			double ShopValue;
			double TotPrice;
			int TotPrice2;
			int Overstock;

			for (int i = amount; i > 0; i--) {
				TotPrice2 = (int) Math.floor(GetItemShopValue(itemID, 1,
						fromSlot));
				if (freeSlots() > 0) {
					if (Item.itemIsNote[itemID] == false) {
						deleteItem(itemID, GetItemSlot(itemID), 1);
					} else {
						deleteItem(itemID, fromSlot, 1);
					}
					addItem(995, TotPrice2);
					
				} else {
					sendMessage("Not enough space in your inventory.");
					break;
				}
			}
			resetItems(3823);
			resetShop(MyShopID);
			UpdatePlayerShop();
			return true;
		}
		return true;
	}

	public void sendFrame126(String s, int id) {
		outStream.createFrameVarSizeWord(126);
		outStream.writeString(s);
		outStream.writeWordA(id);
		outStream.endFrameVarSizeWord();
		flushOutStream();
	}

    public boolean sellItem2(int itemID, int fromSlot, int amount) {
        if (amount > 0 && itemID == (playerItems[fromSlot] - 1)) {
            if (server.shopHandler.ShopSModifier[MyShopID] > 1) {
                boolean IsIn = false;

                for (int i = 0; i
                        <= server.shopHandler.ShopItemsStandard[MyShopID]; i++) {
                    if (itemID
                            == (server.shopHandler.ShopItems[MyShopID][i] - 1)) {
                        IsIn = true;
                        break;
                    }
                }
                if (IsIn == false) {
                    sendMessage(
                            "You cannot sell " + GetItemName(itemID)
                            + " in this store.");
                    return false;
                }
            }
            if (Item.itemSellable[(playerItems[fromSlot] - 1)] == false) {
                sendMessage("I cannot sell " + GetItemName(itemID) + ".");
                return false;
            }
            if (amount > playerItemsN[fromSlot]
                    && (Item.itemIsNote[(playerItems[fromSlot] - 1)] == true
                            || Item.itemStackable[(playerItems[fromSlot] - 1)]
                                    == true)) {
                amount = playerItemsN[fromSlot];
            } else if (amount > GetXItemsInBag(itemID)
                    && Item.itemIsNote[(playerItems[fromSlot] - 1)] == false
                    && Item.itemStackable[(playerItems[fromSlot] - 1)] == false) {
                amount = GetXItemsInBag(itemID);
            }
            double ShopValue;
            double TotPrice;
            int TotPrice2;
            int Overstock;

            for (int i = amount; i > 0; i--) {
                TotPrice2 = (int) Math.floor(
                        GetItemShopValue(itemID, 1, fromSlot));
                if (freeSlots() >= 0) {
                    if (Item.itemIsNote[itemID] == false) {
                        deleteItem(itemID, GetItemSlot(itemID), 1);
                    } else {
                        deleteItem(itemID, fromSlot, 1);
                    }
                    addItem(6306, TotPrice2);
                    
                } else {
                    sendMessage("Not enough space in your inventory.");
                    break;
                }
            }
            resetItems(3823);
            resetShop(MyShopID);
            UpdatePlayerShop();
            return true;
        }
        return true;
    }

    public boolean sellItem3(int itemID, int fromSlot, int amount) {
        if (amount > 0 && itemID == (playerItems[fromSlot] - 1)) {
            if (server.shopHandler.ShopSModifier[MyShopID] > 1) {
                boolean IsIn = false;

                for (int i = 0; i
                        <= server.shopHandler.ShopItemsStandard[MyShopID]; i++) {
                    if (itemID
                            == (server.shopHandler.ShopItems[MyShopID][i] - 1)) {
                        IsIn = true;
                        break;
                    }
                }
                if (IsIn == false) {
                    sendMessage("You cannot sell " + GetItemName(itemID) + " in this store.");
                    return false;
                }
            }
            if (Item.itemSellable[(playerItems[fromSlot] - 1)] == false) {
                sendMessage("I cannot sell " + GetItemName(itemID) + ".");
                return false;
            }
            if (amount > playerItemsN[fromSlot]
                    && (Item.itemIsNote[(playerItems[fromSlot] - 1)] == true
                            || Item.itemStackable[(playerItems[fromSlot] - 1)]
                                    == true)) {
                amount = playerItemsN[fromSlot];
            } else if (amount > GetXItemsInBag(itemID)
                    && Item.itemIsNote[(playerItems[fromSlot] - 1)] == false
                    && Item.itemStackable[(playerItems[fromSlot] - 1)] == false) {
                amount = GetXItemsInBag(itemID);
            }
            double ShopValue;
            double TotPrice;
            int TotPrice2;
            int Overstock;

            for (int i = amount; i > 0; i--) {
                TotPrice2 = (int) Math.floor(
                        GetItemShopValue(itemID, 1, fromSlot));
                if (freeSlots() >= 0) {
                    if (Item.itemIsNote[itemID] == false) {
                        deleteItem(itemID, GetItemSlot(itemID), 1);
                    } else {
                        deleteItem(itemID, fromSlot, 1);
                    }
                    addItem(4067, TotPrice2);
                    
                } else {
                    sendMessage("Not enough space in your inventory.");
                    break;
                }
            }
            resetItems(3823);
            resetShop(MyShopID);
            UpdatePlayerShop();
            return true;
        }
        return true;
    }


  public void UpdatePlayerShop() {
    for (int i = 1; i < PlayerHandler.maxPlayers; i++) {
      if (PlayerHandler.players[i] != null) {
        if (PlayerHandler.players[i].IsShopping == true && PlayerHandler.players[i].MyShopID == MyShopID && i != playerId) {
          PlayerHandler.players[i].UpdateShop = true;
        }
      }
    }
  }

public boolean addShopItem(int itemID, int amount) {
		boolean Added = false;

		if (amount <= 0) {
			return false;
		}
		if (Item.itemIsNote[itemID] == true) {
			itemID = GetUnnotedItem(itemID);
		}
		for (int i = 0; i < server.shopHandler.ShopItems.length; i++) {
			if ((server.shopHandler.ShopItems[MyShopID][i] - 1) == itemID) {
				server.shopHandler.ShopItemsN[MyShopID][i] += amount;
				Added = true;
			}
		}
		if (Added == false) {
			for (int i = 0; i < server.shopHandler.ShopItems.length; i++) {
				if (server.shopHandler.ShopItems[MyShopID][i] == 0) {
					server.shopHandler.ShopItems[MyShopID][i] = (itemID + 1);
					server.shopHandler.ShopItemsN[MyShopID][i] = amount;
					server.shopHandler.ShopItemsDelay[MyShopID][i] = 0;
					break;
				}
			}
		}
		return true;
	}

  /* NPC Talking*/
  public void UpdateNPCChat() {

    sendFrame126(" ", 976);
    switch (NpcDialogue) {
      case 1:
        sendFrame200(4883, 591);
        sendFrame126(GetNpcName(NpcTalkTo), 4884);
        sendFrame126("Good day, how can I help you?", 4885);
        sendFrame75(NpcTalkTo, 4883);
        sendFrame164(4882);
        NpcDialogueSend = true;
        break;

      case 2:
        sendFrame171(1, 2465);
        sendFrame171(0, 2468);
        sendFrame126("What would you like to say?", 2460);
        sendFrame126("I'd like to access my bank account, please.", 2461);
        sendFrame126("This is a holdup! Gimme all your cash", 2462);
        sendFrame164(2459);
        NpcDialogueSend = true;
        break;

      case 3:
        sendFrame200(4883, 591);
        sendFrame126(GetNpcName(NpcTalkTo), 4884);
        sendFrame126("Do you want to buy some runes?", 4885);
        sendFrame75(NpcTalkTo, 4883);
        sendFrame164(4882);
        NpcDialogueSend = true;
        break;

      case 4:
        sendFrame171(1, 2465);
        sendFrame171(0, 2468);
        sendFrame126("Select an Option", 2460);
        sendFrame126("Yes please!", 2461);
        sendFrame126("Oh it's a rune shop. No thank you, then.", 2462);
        sendFrame164(2459);
        NpcDialogueSend = true;
        break;

      case 200:
        sendFrame171(1, 2465);
        sendFrame171(0, 2468);
        sendFrame126("Select a Premium arena", 2470);
        sendFrame126("Fishing guild", 2482);
        sendFrame126("Dragons", 2483);
	sendFrame126("Legends guild", 2484);
        sendFrame126("Stay!", 2485);
        sendFrame164(2480);
        NpcDialogueSend = true;
        break;

     case 211:
        sendFrame171(1, 2465);
        sendFrame171(0, 2468);
        sendFrame126("Select a arena", 2470);
        sendFrame126("Duel arena", 2471);
        sendFrame126("Tournament arena", 2472);
        sendFrame126("Stay", 2473);
        sendFrame164(2469);
        NpcDialogueSend = true;
        break;

     case 212:
        sendFrame171(1, 2465);
        sendFrame171(0, 2468);
        sendFrame126("Select a arena", 2470);
        sendFrame126("Duel arena", 2471);
        sendFrame126("Tournament arena", 2472);
        sendFrame126("Stay", 2473);
        sendFrame164(2469);
        NpcDialogueSend = true;
        break;

     case 213:
        sendFrame171(1, 2465);
        sendFrame171(0, 2468);
        sendFrame126("Select a arena", 2470);
        sendFrame126("Duel arena", 2471);
        sendFrame126("Tournament arena", 2472);
        sendFrame126("Stay", 2473);
        sendFrame164(2469);
        NpcDialogueSend = true;
        break;

     case 214:
        sendFrame171(1, 2465);
        sendFrame171(0, 2468);
        sendFrame126("Select a arena", 2470);
        sendFrame126("Duel arena", 2471);
        sendFrame126("Tournament arena", 2472);
        sendFrame126("Stay", 2473);
        sendFrame164(2469);
        NpcDialogueSend = true;
        break;

     case 215:
        sendFrame171(1, 2465);
        sendFrame171(0, 2468);
        sendFrame126("Select a arena", 2470);
        sendFrame126("Duel arena", 2471);
        sendFrame126("Tournament arena", 2472);
        sendFrame126("Stay", 2473);
        sendFrame164(2469);
        NpcDialogueSend = true;
        break;

     case 216:
        sendFrame171(1, 2465);
        sendFrame171(0, 2468);
        sendFrame126("Select a arena", 2470);
        sendFrame126("Duel arena", 2471);
        sendFrame126("Tournament arena", 2472);
        sendFrame126("Stay", 2473);
        sendFrame164(2469);
        NpcDialogueSend = true;
        break;

     case 217:
        sendFrame171(1, 2465);
        sendFrame171(0, 2468);
        sendFrame126("Select a arena", 2470);
        sendFrame126("Duel arena", 2471);
        sendFrame126("Tournament arena", 2472);
        sendFrame126("Stay", 2473);
        sendFrame164(2469);
        NpcDialogueSend = true;
        break;

     case 218:
        sendFrame171(1, 2465);
        sendFrame171(0, 2468);
        sendFrame126("Select a arena", 2470);
        sendFrame126("Duel arena", 2471);
        sendFrame126("Tournament arena", 2472);
        sendFrame126("Stay", 2473);
        sendFrame164(2469);
        NpcDialogueSend = true;
        break;

      case 201:
        sendFrame171(1, 2465);
        sendFrame171(0, 2468);
        sendFrame126("Select a Skilling arena", 2470);
        sendFrame126("Entrana [Premium]", 2471);
        sendFrame126("Draynor village [Free]", 2472);
        sendFrame126("Stay!", 2473);
        sendFrame164(2469);
        NpcDialogueSend = true;
        break;

      case 400:
        sendFrame171(1, 2465);
        sendFrame171(0, 2468);
        sendFrame126("Lol", 2492);
        sendFrame126("Whip", 2494);
        sendFrame126("Full skeleton", 2495);
sendFrame126("Glory amulet", 2496);
sendFrame126("500 noted sharks", 2497);
  sendFrame126("Next", 2498);
        sendFrame164(2492);
        NpcDialogueSend = true;
        break;

      case 401:
        sendFrame171(1, 2465);
        sendFrame171(0, 2468);
        sendFrame126("Lol", 2492);
        sendFrame126("Ice gloves", 2494);
        sendFrame126("Bunny ears", 2495);
sendFrame126("Obsidian cape", 2496);
sendFrame126("Back", 2497);
  sendFrame126("Next", 2498);
        sendFrame164(2492);
        NpcDialogueSend = true;
        break;

      case 402:
        sendFrame171(1, 2465);
        sendFrame171(0, 2468);
        sendFrame126("Lol", 2492);
        sendFrame126("Obsidian shield", 2494);
        sendFrame126("Warrior ring", 2495);
sendFrame126("Fire cape", 2496);
sendFrame126("Rune boots", 2497);
  sendFrame126("Back", 2498);
        sendFrame164(2492);
        NpcDialogueSend = true;
        break;

      case 300:
		sendFrame200(4901, 600);
            	sendFrame126(GetNpcName(0), 4902);
            	sendFrame126("Hello,", 4903);
            	sendFrame126("This teleport is underconstruction.", 4904);
            	sendFrame126("", 4905);
            	sendFrame126("", 4906);
                sendFrame75(0, 4901);
           	sendFrame164(4900);
		NpcDialogueSend = true;
        break;

  case 56:
		sendFrame200(4901, 595);
            	sendFrame126(GetNpcName(945), 4902);
            	sendFrame126("Welcome to Guardian", 4903);
            	sendFrame126("I hope you enjoy your staying.", 4904);
            	sendFrame126("As everyone know you need some goal in your life.", 4905);
            	sendFrame126("What starter package do you want?", 4906);
                sendFrame75(945, 4901);
           	sendFrame164(4900);
		NpcDialogueSend = true;
        break;

	case 57:
	    sendFrame200(974, 597);
	    sendFrame126(playerName, 975);
	    sendFrame126("What starter package's are there to chice from?", 976);
	    sendFrame126("", 977);
	    sendFrame185(974);
	    sendFrame164(973);
	    NpcDialogueSend = true;
	    break;

      case 58:
        sendFrame171(1, 2465);
        sendFrame171(0, 2468);
        sendFrame126("Choice a starter package", 2492);
        sendFrame126("Pure", 2494);
        sendFrame126("Mage", 2495);
sendFrame126("Range", 2496);
sendFrame126("Main", 2497);
  sendFrame126("Skiller", 2498);
        sendFrame164(2492);
        NpcDialogueSend = true;
        break;

      case 59:
		sendFrame200(4901, 595);
            	sendFrame126(GetNpcName(945), 4902);
            	sendFrame126("*you teleport to falador*", 4903);
            	sendFrame126("Welcome to falador", 4904);
            	sendFrame126("To go around the world use mage book to teleport to place's.", 4905);
            	sendFrame126("for more information talk to guide in falador.", 4906);
                sendFrame75(945, 4901);
           	sendFrame164(4900);
		NpcDialogueSend = true;
started = 1;
teleportToX = 2965;
teleportToY = 3380;
        break;



case 219:
        sendFrame171(1, 2465);
        sendFrame171(0, 2468);
        sendFrame126("Select a arena", 2470);
        sendFrame126("draynor", 2471);
        sendFrame126("karamja", 2472);
        sendFrame126("Stay", 2473);
        sendFrame164(2469);
        NpcDialogueSend = true;
        break;

     case 220:
        sendFrame171(1, 2465);
        sendFrame171(0, 2468);
        sendFrame126("Select a arena", 2470);
        sendFrame126("draynor", 2471);
        sendFrame126("karamja", 2472);
        sendFrame126("Stay", 2473);
        sendFrame164(2469);
        NpcDialogueSend = true;
        break;

     case 221:
        sendFrame171(1, 2465);
        sendFrame171(0, 2468);
        sendFrame126("Select a arena", 2470);
        sendFrame126("draynor", 2471);
        sendFrame126("karamja", 2472);
        sendFrame126("Stay", 2473);
        sendFrame164(2469);
        NpcDialogueSend = true;
        break;

     case 222:
        sendFrame171(1, 2465);
        sendFrame171(0, 2468);
        sendFrame126("Select a arena", 2470);
        sendFrame126("draynor", 2471);
        sendFrame126("karamja", 2472);
        sendFrame126("Stay", 2473);
        sendFrame164(2469);
        NpcDialogueSend = true;
        break;



      case 303:
RemoveAllWindows();
        break;
    case 304:
	
        sendFrame171(1, 2465);
        sendFrame171(0, 2468);
        sendFrame126("Would you like to play Lucky Dice?", 2460);
        sendFrame126("Sure", 2461);
        sendFrame126("No thanks I don't want to make money.", 2462);
	sendFrame75(659, 4883);
        sendFrame164(2459);
        NpcDialogueSend = true;
        break;
    case 305:
        sendFrame200(4883, 591);
        sendFrame126(GetNpcName(NpcTalkTo), 4884);
        sendFrame126("Well, lets choose your bet now", 4885);
        sendFrame126("Choose carefully.", 4886);
        sendFrame75(659, 4883);
        sendFrame164(4882);
        NpcDialogueSend = true;
        break;
    
    case 308:
	sendFrame200(4883, 591);
        sendFrame126(GetNpcName(NpcTalkTo), 4884);
        sendFrame126("I'm sorry, you're broke! get some money.", 4885);
        sendFrame126("Choose carefully.", 4886);
        sendFrame75(NpcTalkTo, 4883);
        sendFrame164(4882);
     
      
        NpcDialogueSend = true;
	break;
     case 309:
	
        sendFrame171(1, 2465);
        sendFrame171(0, 2468);
        sendFrame126("Another try?", 2460);
        sendFrame126("Play again", 2461);
        sendFrame126("Stop playing", 2462);
        sendFrame164(2459);
        NpcDialogueSend = true;
        break;
     case 310:
	sendFrame200(4901, 591);
  	sendFrame126(GetNpcName(NpcTalkTo), 4902);
	sendFrame126("Welcome to the lottery sale!", 4903);
	sendFrame126("Buy a lottery ticket to win hackpot", 4904);
	sendFrame126("One ticket cost 1,000gp.", 4905);
	sendFrame126("A random winner is chosen every Sunday.", 4906);
	sendFrame75(NpcTalkTo, 4901);
	 sendFrame164(4900);
	break;
	case 311:
	
        sendFrame171(1, 2465);
        sendFrame171(0, 2468);
        sendFrame126("Would you like to buy tickets?", 2460);
        sendFrame126("Sure (max 15 tickets)", 2461);
        sendFrame126("No thanks", 2462);
        sendFrame164(2459);
        NpcDialogueSend = true;
        break;
	
	case 312:
	sendFrame200(4883, 591);
        sendFrame126(GetNpcName(NpcTalkTo), 4884);
        sendFrame126("Here you go, the drawing is sunday at noon.", 4885);
       
        sendFrame75(NpcTalkTo, 4883);
        sendFrame164(4882);
        NpcDialogueSend = true;
        break;
	case 313:
	sendFrame200(4901, 591);
  	sendFrame126(GetNpcName(NpcTalkTo), 4902);
	sendFrame126("Would you like to play pete slots?", 4903);
	sendFrame126("The jackpot is currently "+server.serverchest2+" gp.", 4904);
	sendFrame126("read the update on forum to see how to win.", 4905);
	sendFrame126("automatic way will stop if you walk or win jackpot", 4906);
	sendFrame75(NpcTalkTo, 4901);
	 sendFrame164(4900);
	break;
	case 314:
	
        sendFrame171(1, 2465);
        sendFrame171(0, 2468);
        sendFrame126("Would you like to play pete slots?", 2460);
        sendFrame126("Sure (manually)", 2461);
        sendFrame126("Sure (automaticly)", 2462);
        sendFrame164(2459);
        NpcDialogueSend = true;
        break;
      case 5:
        sendFrame200(615, 974);
        sendFrame126(playerName, 975);
        sendFrame126("Oh it's a rune shop. No thank you, then.", 977);
        sendFrame185(974);
        sendFrame164(973);
        NpcDialogueSend = true;
        break;

      case 6:
        sendFrame200(4883, 591);
        sendFrame126(GetNpcName(NpcTalkTo), 4884);
        sendFrame126("Well, if you find somone who does want runes, please", 4885);
        sendFrame126("send them my way.", 4886);
        sendFrame75(NpcTalkTo, 4883);
        sendFrame164(4882);
        NpcDialogueSend = true;
        break;

      case 7:
        /* NEED TO CHANGE FOR GUARD*/
        sendFrame200(4883, 591);
        sendFrame126(GetNpcName(NpcTalkTo), 4884);
        sendFrame126("Well, if you find somone who does want runes, please", 4885);
        sendFrame126("send them my way.", 4886);
        sendFrame75(NpcTalkTo, 4883);
        sendFrame164(4882);
        NpcDialogueSend = true;
        break;
      case 9:
        sendFrame200(4883, 1597);
        sendFrame126(GetNpcName(NpcTalkTo), 4884);
        sendFrame126("Select an Option", 2460);
        sendFrame126("Can you teleport me to the mage arena?", 2461);
        sendFrame126("Whats at the mage arena?", 2462);
        sendFrame164(2459);
        NpcDialogueSend = true;
        break;
      case 10:
        sendFrame200(4883, 804);
        sendFrame126(GetNpcName(804), 4884);
        sendFrame126(dMsg, 4885);
        sendFrame75(804, 4883);
        sendFrame164(4882);
        NpcDialogueSend = true;
        break;
      case 12:
	if(penguin == 0) {
        sendFrame200(4883, 591);
        sendFrame126(GetNpcName(1552), 4884);
        sendFrame126("Heres you pet, " + playerName + ".", 4885);
        sendFrame75(1552, 4883);
        sendFrame164(4882);
        NpcDialogueSend = true;
        customCommand("3k5jh3kj5h23k45jhhk32j45gkj");
	penguin = 1;
	} else {
        sendFrame200(4883, 591);
        sendFrame126(GetNpcName(1552), 4884);
        sendFrame126("You can only have one pet at once, faggot", 4885);
        sendFrame75(1552, 4883);
        sendFrame164(4882);
        NpcDialogueSend = true;
	}
        break;

      case 16:
SlayerAssign();
        break;

      case 20:
        sendFrame200(4883, 591);
        sendFrame126(GetNpcName(NpcTalkTo), 4884);
        sendFrame126("Can you please defeated Kolodion for me?", 4885);
        sendFrame75(NpcTalkTo, 4883);
        sendFrame164(4882);
        NpcDialogueSend = true;
        break;
	case 27:
	
      case 21:
        sendFrame171(1, 2465);
        sendFrame171(0, 2468);
        sendFrame126("Select an Option", 2460);
        sendFrame126("Sure, I feel like dying today!", 2461);
        sendFrame126("Are you our of your mind? He'll kill me, you fag!", 2462);
        sendFrame164(2459);
        NpcDialogueSend = true;
        break;

      case 22:
        sendFrame200(4883, 591);
        sendFrame126(GetNpcName(NpcTalkTo), 4884);
        sendFrame126("Thanks for defeated Kolodion, " + playerName, 4885);
        sendFrame75(NpcTalkTo, 4883);
        sendFrame164(4882);
        NpcDialogueSend = true;
	if(!playerHasItem(608)) {
	addItem(608, 1);
	}
        break;
    }
  }

  /* OBJECTS*/
  public int GetObject(int X, int Y, int ObjectID) {
    for (int i = 0; i < server.objectHandler.MaxObjects; i++) {
      if (server.objectHandler.ObjectID[i] > -1) {
        if (X == server.objectHandler.ObjectX[i] && Y == server.objectHandler.ObjectY[i]) {
          if (ObjectID != -1) {
            if (ObjectID == server.objectHandler.ObjectID[i]) {
              return i;
            }
          } else {
            return i;
          }
        }
      }
    }
    return -1;
  }

  public void ChangeDoor(int ArrayID) {
    int objectID = server.objectHandler.ObjectOriID[ArrayID];
    int objectX = server.objectHandler.ObjectX[ArrayID];
    int objectY = server.objectHandler.ObjectY[ArrayID];
    int Face = server.objectHandler.ObjectFace[ArrayID];
    int Type = server.objectHandler.ObjectType[ArrayID];

    ReplaceObject(objectX, objectY, -1, -1, 0);
    switch (Type) {
      case 1:
        ReplaceObject(objectX, (objectY+1), objectID, Face, 0);
        server.objectHandler.ObjectType[ArrayID] = 2;
        break;

      case 2:
        ReplaceObject(objectX, (objectY-1), objectID, Face, 0);
        server.objectHandler.ObjectType[ArrayID] = 1;
        break;

      case 3:
        ReplaceObject((objectX+1), objectY, objectID, Face, 0);
        server.objectHandler.ObjectType[ArrayID] = 4;
        break;

      case 4:
        ReplaceObject((objectX-1), objectY, objectID, Face, 0);
        server.objectHandler.ObjectType[ArrayID] = 3;
        break;
    }
  }

  /* ITEMS*/
  public int GetGroundItemID(int ItemID, int ItemX, int ItemY, int ItemH) {
    for (int i = 0; i < server.itemHandler.DropItemCount; i++) {
      if (server.itemHandler.DroppedItemsID[i] > -1) {
        if (server.itemHandler.DroppedItemsID[i] == ItemID && server.itemHandler.DroppedItemsX[i] == ItemX && server.itemHandler.DroppedItemsY[i] == ItemY && server.itemHandler.DroppedItemsH[i] == ItemH && server.itemHandler.DroppedItemsN[i] == 1) {
          return i;
        }
      }
    }
    return -1;
  }

  /* Equipment level checking*/
  public int GetCLAttack(int ItemID) {
    if (ItemID == -1) {
      return 1;
    }
    String ItemName = GetItemName(ItemID);
    String ItemName2 = ItemName.replaceAll("Bronze", "");

    ItemName2 = ItemName2.replaceAll("Iron", "");
    ItemName2 = ItemName2.replaceAll("Steel", "");
    ItemName2 = ItemName2.replaceAll("Black", "");
    ItemName2 = ItemName2.replaceAll("Mithril", "");
    ItemName2 = ItemName2.replaceAll("Adamant", "");
    ItemName2 = ItemName2.replaceAll("Rune", "");
    ItemName2 = ItemName2.replaceAll("Granite", "");
    ItemName2 = ItemName2.replaceAll("Dragon", "");
    ItemName2 = ItemName2.replaceAll("Crystal", "");
    ItemName2 = ItemName2.trim();
    if (ItemName2.startsWith("claws") || ItemName2.startsWith("dagger") || ItemName2.startsWith("sword") || ItemName2.startsWith("scimitar") || ItemName2.startsWith("mace") || ItemName2.startsWith("longsword") || ItemName2.startsWith("battleaxe") || ItemName2.startsWith("warhammer") || ItemName2.startsWith("2h sword") || ItemName2.startsWith("harlberd")) {
      if (ItemName.startsWith("Bronze")) {
        return 0;
      } else if (ItemName.startsWith("Iron")) {
        return 0;
      } else if (ItemName.startsWith("Steel")) {
        return 0;
      } else if (ItemName.startsWith("Black")) {
        return 10;
      } else if (ItemName.startsWith("Mithril")) {
        return 20;
      } else if (ItemName.startsWith("Adamant")) {
        return 30;
      } else if (ItemName.startsWith("Rune")) {
        return 40;
      } else if (ItemName.startsWith("Dragon")) {
        return 60;
      }
    } else if (ItemName.startsWith("Granite")) {
      return 80;
    } else if (ItemName.endsWith("whip") || ItemName.endsWith("Ahrims staff") || ItemName.endsWith("Torags hammers") || ItemName.endsWith("Veracs flail") || ItemName.endsWith("Guthans warspear") || ItemName.endsWith("Dharoks greataxe")) {
      return 0;
    }
    return 0;
  }

  public int GetCLDefence(int ItemID) {
    if (ItemID == -1) {
      return 1;
    }
    String ItemName = GetItemName(ItemID);
    String ItemName2 = ItemName.replaceAll("Bronze", "");

    ItemName2 = ItemName2.replaceAll("Iron", "");
    ItemName2 = ItemName2.replaceAll("Steel", "");
    ItemName2 = ItemName2.replaceAll("Black", "");
    ItemName2 = ItemName2.replaceAll("Mithril", "");
    ItemName2 = ItemName2.replaceAll("Adamant", "");
    ItemName2 = ItemName2.replaceAll("Rune", "");
    ItemName2 = ItemName2.replaceAll("Granite", "");
    ItemName2 = ItemName2.replaceAll("Dragon", "");
    ItemName2 = ItemName2.replaceAll("Crystal", "");
    ItemName2 = ItemName2.trim();
    if (ItemName2.startsWith("claws") || ItemName2.startsWith("dagger") || ItemName2.startsWith("sword") || ItemName2.startsWith("scimitar") || ItemName2.startsWith("mace") || ItemName2.startsWith("longsword") || ItemName2.startsWith("battleaxe") || ItemName2.startsWith("warhammer") || ItemName2.startsWith("2h sword") || ItemName2.startsWith("harlberd")) {
      // It's a weapon, weapons don't required defence !
    } else if (ItemName.startsWith("Ahrims") || ItemName.startsWith("Karil") || ItemName.startsWith("Torag") || ItemName.startsWith("Verac") || ItemName.endsWith("Guthan") || ItemName.endsWith("Dharok")) {
      if (ItemName.endsWith("staff") || ItemName.endsWith("crossbow") || ItemName.endsWith("hammers") || ItemName.endsWith("flail") || ItemName.endsWith("warspear") || ItemName.endsWith("greataxe")) {
        // No defence for the barrow weapons
      } else {
        return 0;
      }
    } else {
      if (ItemName.startsWith("Bronze")) {
        return 0;
      } else if (ItemName.startsWith("Iron")) {
        return 0;
      } else if (ItemName.startsWith("Steel")) {
        return 0;
      } else if (ItemName.startsWith("Black")) {
        return 0;
      } else if (ItemName.startsWith("Mithril")) {
        return 0;
      } else if (ItemName.startsWith("Adamant")) {
        return 0;
      } else if (ItemName.startsWith("Rune")) {
        return 0;
      } else if (ItemName.startsWith("Dragon")) {
        return 0;
      }
    }
    return 0;
  }

  public int GetCLStrength(int ItemID) {
    if (ItemID == -1) {
      return 1;
    }
    String ItemName = GetItemName(ItemID);

    if (ItemName.startsWith("Granite")) {
      return 80;
    } else if (ItemName.startsWith("Torags hammers") || ItemName.endsWith("Dharoks greataxe")) {
      return 0;
    }
    return 0;
  }

  public int GetCLMagic(int ItemID) {
    if (ItemID == -1) {
      return 1;
    }
    String ItemName = GetItemName(ItemID);

    if (ItemName.startsWith("Ahrim")) {
      return 0;
    }
    return 0;
  }

  public int GetCLRanged(int ItemID) {
    if (ItemID == -1) {
      return 1;
    }
    String ItemName = GetItemName(ItemID);

    if (ItemName.startsWith("Karil")) {
      return 0;
    }
    return 0;
  }

  public int GetWorld(int PlayerID) {
    String Server = PlayerHandler.players[PlayerID].playerServer;

    if (Server.equals("rs2.servegame.org") || Server.equals("localhost")) {
      return 1;
    } else if (Server.equals("dodian.com")) {
      return 2;
    } else {
      println_debug("Invalid Server: "+Server);
      return 1; //0; friendlist fix-bakatool
    }
  }
  public void killedPlayer(String name, int combat) {
    int diff = Math.abs(combatLevel-combat);
    String diffString = "";
    if (combatLevel > combat) {
      diffString = "-"+diff;
    } else {
      diffString = "+"+diff;
    }
  }
  public int freeSpace(int itemid, boolean stackable) {
    for (int i = 0; i < playerItems.length; i++) {
      if (playerItems[i] == itemid && stackable) {
        return i;
      }
      if (playerItems[i] == -1 || playerItems[i] == 0) {
        return i;
      }
    }
    return -1;
  }
  public void setInterfaceWalkable(int ID) {
    outStream.createFrame(208);
    outStream.writeWordBigEndian_dup(ID);
    flushOutStream();
  }
  public void RefreshDuelRules() {
    for (int i = 0; i < duelLine.length; i++) {
      if (duelRule[i]) {
        sendQuest("@red@"+duelNames[i], duelLine[i]);
      } else {
        sendQuest("@cya@"+duelNames[i], duelLine[i]);
      }
    }
  }

 public void DuelVictory() {
    client other = getClient(duel_with);
    boolean stake = false;
    for (GameItem item: offeredItems) {
      if (item.id > 0 && item.amount > 0) {
        stake = true;
      }
    }
        if (duelFight) {
            if (System.currentTimeMillis()-lastButton < 1000) {
                lastButton = System.currentTimeMillis();
                return;
            }
             else {
                lastButton = System.currentTimeMillis();
            }
            for (GameItem item: otherOfferedItems) {
                println("otherDuelItems = "+item.id);
                if (item.id > 0 && item.amount > 0) {
                    if (Item.itemStackable[item.id]) {
                        if (!addItem(item.id, item.amount))
                          ItemHandler.addItem(item.id, enemyX, enemyY, item.amount, playerId, false);
                    }
                     else {
                        int amount = item.amount;
                        for (int a = 1; a <= amount; a++) {
                            if (!addItem(item.id, 1))
                              ItemHandler.addItem(item.id, enemyX, enemyY, 1, playerId, false);
                        }
                    }
                }

            }
            for (GameItem item: offeredItems) 
                  addItem(item.id, item.amount);
            resetDuel();
            savegame(false);
            if (validClient(duel_with)) {
                other.resetDuel();
                other.savegame(false);
            }
	}
    if (validClient(duel_with)) {
      sendMessage("You have defeated "+other.playerName+"!");
      sendQuest(""+other.combat, 6839);
      sendQuest(other.playerName, 6840);
    }
    for (GameItem item: offeredItems) {
      if (item.id > 0 && item.amount > 0) {
        stake = true;
      }
    }
    for (GameItem item: otherOfferedItems) {
      if (item.id > 0 && item.amount > 0) {
        stake = true;
      }
    }
    if (stake) {
      try {
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
		itemsToVScreen_old();
		println("stake=" + stake);
		if (stake) {
			itemsToVScreen_old();
			other.resetDuel();
		} else {
			resetDuel();
			other.resetDuel();
		}
    updateRequired = true;
    appearanceUpdateRequired = true;
resetAnimation();
  }

  public boolean DeclineDuel() {
	RlastSlot = 0;
	TlastSlot = 0;
    declineDuel();
    return true;
  }

  public void RemoveAllDuelItems() {
    for (int i = 0; i < duelItems.length; i++) {
      if (duelItems[i] > 0) {
        fromDuel((duelItems[i]-1), i, duelItemsN[i]);
      }
    }
  }


  public int GetDuelItemSlots() {
    int Slots = 0;
    for (int i = 0; i < duelItems.length; i++) {
      if (duelItems[i] > 0) {
        Slots++;
      }
    }
    for (int i = 0; i < otherDuelItems.length; i++) {
      if (otherDuelItems[i] > 0) {
        Slots++;
      }
    }
    return Slots;
  }
  public void itemsToVScreen_old() {
    outStream.createFrameVarSizeWord(53);
    outStream.writeWord(6822);
    outStream.writeWord(otherOfferedItems.toArray().length);
    for (GameItem item: otherOfferedItems) {
      if (item.amount > 254) {
        outStream.writeByte(255); // item's stack count. if over 254, write byte 255
        outStream.writeDWord_v2(item.amount); // and then the real value with writeDWord_v2
      } else {
        outStream.writeByte(item.amount);
      }
      if (item.id > 20000 || item.id < 0) {
        item.id = 20000;
      }
      outStream.writeWordBigEndianA(item.id+1); //item id
    }
    outStream.endFrameVarSizeWord();
  }
  public void itemsToVScreen(int x, int y) {
    Player p = handler.players[duelWith];
    if (p != null && p.playerId == playerId)
      return;
    for (int i = 0; i < otherDuelItems.length; i++) {
      if (otherDuelItems[i] > 0 && otherDuelItemsN[i] > 0) {
        if (Item.itemStackable[otherDuelItems[i]-1]) {
          ItemHandler.addItem(otherDuelItems[i]-1, enemyX, enemyY, otherDuelItemsN[i], playerId, false);
        } else {
          int amount = otherDuelItemsN[i];
          for (int a = 1; a <= amount; a++) {
            ItemHandler.addItem(otherDuelItems[i]-1, enemyX, enemyY, 1, playerId, false);
          }
        }
      }

    }
    for (int i1 = 0; i1 < duelItems.length; i1++) {
      if (duelItems[i] > 0 && duelItemsN[i] > 0)
        addItem(duelItems[i1]-1, duelItemsN[i1]);
    }
    //resetDuel();
  }

  public void refreshDuelScreen() {
    client other = getClient(duel_with);
    if (!validClient(duel_with))
      return;
    outStream.createFrameVarSizeWord(53);
    outStream.writeWord(6669);
    outStream.writeWord(offeredItems.toArray().length);
    int current = 0;
    for (GameItem item: offeredItems) {
      if (item.amount > 254) {
        outStream.writeByte(255); // item's stack count. if over 254, write byte 255
        outStream.writeDWord_v2(item.amount); // and then the real value with writeDWord_v2
      } else {
        outStream.writeByte(item.amount);
      }
      if (item.id > 20000 || item.id < 0) {
        item.id = 20000;
      }
      outStream.writeWordBigEndianA(item.id+1); //item id
      current++;
    }
    if (current < 27) {
      for (int i = current; i < 28; i++) {
        outStream.writeByte(1);
        outStream.writeWordBigEndianA(-1);
      }
    }
    outStream.endFrameVarSizeWord();
    outStream.createFrameVarSizeWord(53);
    outStream.writeWord(6670);
    outStream.writeWord(other.offeredItems.toArray().length);
    current = 0;
    for (GameItem item: other.offeredItems) {
      if (item.amount > 254) {
        outStream.writeByte(255); // item's stack count. if over 254, write byte 255
        outStream.writeDWord_v2(item.amount); // and then the real value with writeDWord_v2
      } else {
        outStream.writeByte(item.amount);
      }
      if (item.id > 20000 || item.id < 0) {
        item.id = 20000;
      }
      outStream.writeWordBigEndianA(item.id+1); //item id
      current++;
    }
    if (current < 27) {
      for (int i = current; i < 28; i++) {
        outStream.writeByte(1);
        outStream.writeWordBigEndianA(-1);
      }
    }
    outStream.endFrameVarSizeWord();
  }
  public boolean stakeItem(int itemID, int fromSlot, int amount) {
    client other = getClient(duel_with);
	if (fromSlot == TlastSlot) { //anti dupe by Vodka I C E
		TlastSlot = -1;
        	return false;
	}
	if (fromSlot == other.TlastSlot) { //anti dupe by Vodka I C E
		other.TlastSlot = -1;
        	return false;
	}
	TlastSlot = fromSlot;
	RlastSlot = fromSlot; //end of anti dupe
    if (System.currentTimeMillis()-lastButton < 800) {
      return false;
    }
    lastButton = System.currentTimeMillis();
    if (!Item.itemStackable[itemID] &&  ! Item.itemIsNote[itemID] && amount > 1) {
      for (int a = 1; a <= amount; a++) {
        int slot = findItem(itemID, playerItems, playerItemsN);
        if (slot >= 0) {
          stakeItem(itemID, slot, 1);
        }
      }
    }
    for (int i = 0; i < noTrade.length; i++) {
      if (itemID == noTrade[i] || itemID == noTrade[i]+1) {
        sendMessage("You can't trade that item");
        return false;
      }
    }
    if (!inDuel ||  ! validClient(duel_with)) {
      declineDuel();
      return false;
    }
    if (!canOffer) {
      return false;
    }
    if (!playerHasItem(itemID, amount)) {
      return false;
    }
    if (Item.itemStackable[itemID] || Item.itemIsNote[itemID]) {
      boolean inTrade = false;
      for (GameItem item: offeredItems) {
        if (item.id == itemID) {
          inTrade = true;
          item.amount += amount;
          break;
        }
      }
      if (!inTrade) {
        offeredItems.add(new GameItem(itemID, amount));
      }
    } else {
      offeredItems.add(new GameItem(itemID, 1));
    }
    deleteItem(itemID, fromSlot, amount);
    resetItems(3214);
    resetItems(3322);
    other.resetItems(3214);
    other.resetItems(3322);
    refreshDuelScreen();
    other.refreshDuelScreen();
    sendFrame126(" ", 6684);
    other.sendFrame126("", 6684);
    return true;
  }

  public boolean fromDuel(int itemID, int fromSlot, int amount) {
    if (System.currentTimeMillis()-lastButton < 800) {
      return false;
    }
    lastButton = System.currentTimeMillis();
    client other = getClient(duel_with);
    if (!inDuel ||  ! validClient(duel_with) ||  ! canOffer) {
      declineDuel();
      return false;
    }
    if (!Item.itemStackable[itemID] && amount > 1) {
      for (int a = 1; a <= amount; a++) {
        int slot = findItem(itemID, playerItems, playerItemsN);
        if (slot >= 0) {
          fromDuel(itemID, 0, 1);
        }
      }
    }
    boolean found = false;
    for (GameItem item: offeredItems) {
      if (item.id == itemID) {
        if (!item.stackable) {
          offeredItems.remove(item);
          found = true;
        } else {
          if (item.amount > amount) {
            item.amount -= amount;
            found = true;
          } else {
            amount = item.amount;
            found = true;
            offeredItems.remove(item);
          }
        }
        break;
      }
    }
    if (found)
      addItem(itemID, amount);
    duelConfirmed = false;
    other.duelConfirmed = false;
    resetItems(3214);
    other.resetItems(3214);
    resetItems(3322);
    other.resetItems(3322);
    refreshDuelScreen();
    other.refreshDuelScreen();
    other.sendFrame126("", 6684);

    return true;
  }

  public void frame1() {
    // cancels all player and npc emotes within area!
    outStream.createFrame(1);
    updateRequired = true;
    appearanceUpdateRequired = true;
  }
  public void resetKeepItem() {
  }
  public int randomItem(int[]array) {
    int len = array.length;
    int ran = misc.random(len);
    return array[ran];
  }
  public void WalkTo_old(int X, int Y) {
    int firstStepX = inStream.readSignedWordBigEndianA();
    int tmpFSX = X;
    X -= mapRegionX*8;
    for (i = 1; i < newWalkCmdSteps; i++) {
      newWalkCmdX[i] = inStream.readSignedByte();
      newWalkCmdY[i] = inStream.readSignedByte();
      tmpNWCX[i] = newWalkCmdX[i];
      tmpNWCY[i] = newWalkCmdY[i];
    }
    newWalkCmdX[0] = newWalkCmdY[0] = tmpNWCX[0] = tmpNWCY[0] = 0;
    int firstStepY = inStream.readSignedWordBigEndian();
    int tmpFSY = Y;
    Y -= mapRegionY*8;
    newWalkCmdIsRunning = inStream.readSignedByteC() == 1;
    for (i = 0; i < newWalkCmdSteps; i++) {
      newWalkCmdX[i] += X;
      newWalkCmdY[i] += Y;
    }
    println_debug("Walking to X:"+X+" Y:"+Y);
  }
  public void WalkTo(int x, int y) {
    newWalkCmdX[1] += x;
    newWalkCmdY[1] += y;
    tmpNWCX[1] = newWalkCmdX[i];
    tmpNWCY[1] = newWalkCmdY[i];
    newWalkCmdIsRunning = true;
  }
  public String passHash(String password) {
    String saltM = new MD5("bakatool").compute();
    String passM = new MD5(password).compute();
    return new MD5(saltM+passM).compute();
  }
  public int[]getLook() {
    return new int[] {
      pGender, pHead, pBeard, pTorso, pArms, pHands, pLegs, pFeet, pHairC, pTorsoC, pLegsC, pFeetC, pSkinC, playerLook[0], playerLook[1], playerLook[2], playerLook[3], playerLook[4], playerLook[5]
    };
  }
  public void setLook(int[]parts) {
    if (parts.length != 19) {
      println("setLook:  Invalid array length!");
      return;
    }
    pGender = parts[0];
    pHead = parts[1];
    pBeard = parts[2];
    pTorso = parts[3];
    pArms = parts[4];
    pHands = parts[5];
    pLegs = parts[6];
    pFeet = parts[7];
    pHairC = parts[8];
    pTorsoC = parts[9];
    pLegsC = parts[10];
    pFeetC = parts[11];
    pSkinC = parts[12];
    playerLook[0] = parts[13];
    playerLook[1] = parts[14];
    playerLook[2] = parts[15];
    playerLook[3] = parts[16];
    playerLook[4] = parts[17];
    playerLook[5] = parts[18];
    apset = true;
    appearanceUpdateRequired = true;
    lookUpdate = true;
    updateRequired = true;
  }
  public int maxRangeHit() {
    int hit = (int)((playerBonus[4]+playerLevel[playerRanged])/12);
    return hit;
  }
  public void buryItem(int item, int slot) {
    boolean used = true;
    if (playerHasItem(item)) {
      switch (item) {
        case 526:
          prayerMessage(140);
          break;
	case 3589:
if (freeSlots() > 2) {
clueScrollItems(Item.lowUnstackable(),1,Item.coins(),1000 + misc.random(3000),Item.crap(),1);
deleteItem(3589, 1);
} else {
sendMessage("you need 3 or more inventory space to get your reward!");
}
break;
        case 532:
          prayerMessage(230);
          break;
        case 3125:
          prayerMessage(600);
          break;
        case 536:
          prayerMessage(800);
          break;
        case 6812:
          prayerMessage(14000000);
          break;
        case 528:
          prayerMessage(200);
          break;
		case 125: // attack pot (1)
                attPot = true;
                attPotTimer = 90;
                abc = getLevelForXP(playerXP[0]);
                cba = abc / 10;
                aaa = cba / 2;
                abc2 = aaa + cba;
                if (abc2 <= 1) {
                abc2 = 2;
                }
                playerLevel[0] = getLevelForXP(playerXP[0]);
                playerLevel[0] += abc2;
                sendFrame126(""+playerLevel[0]+"", 4004);
                deleteItem(125, 1);
                addItem(229, 1);
                updateRequired = true;
                appearanceUpdateRequired = true;
                break;
            case 123: // attack pot (2)
                attPot = true;
                attPotTimer = 90;
                abc = getLevelForXP(playerXP[0]);
                cba = abc / 10;
                aaa = cba / 2;
                abc2 = aaa + cba;
                if (abc2 <= 1) {
                abc2 = 2;
                }
                playerLevel[0] = getLevelForXP(playerXP[0]);
                playerLevel[0] += abc2;
                sendFrame126(""+playerLevel[0]+"", 4004);
                deleteItem(123, 1);
                addItem(125, 1);
                updateRequired = true;
                appearanceUpdateRequired = true;
                break;
            case 121: // attack pot (3)
                attPot = true;
                attPotTimer = 90;
                abc = getLevelForXP(playerXP[0]);
                cba = abc / 10;
                aaa = cba / 2;
                abc2 = aaa + cba;
                if (abc2 <= 1) {
                abc2 = 2;
                }
                playerLevel[0] = getLevelForXP(playerXP[0]);
                playerLevel[0] += abc2;
                sendFrame126(""+playerLevel[0]+"", 4004);
                deleteItem(121, 1);
                addItem(123, 1);
                updateRequired = true;
                appearanceUpdateRequired = true;
                break;
            case 2428: // attack pot (4)
                attPot = true;
                attPotTimer = 90;
                abc = getLevelForXP(playerXP[0]);
                cba = abc / 10;
                aaa = cba / 2;
                abc2 = aaa + cba;
                if (abc2 <= 1) {
                abc2 = 2;
                }
                playerLevel[0] = getLevelForXP(playerXP[0]);
                playerLevel[0] += abc2;
                sendFrame126(""+playerLevel[0]+"", 4004);
                deleteItem(2428, 1);
                addItem(121, 1);
                updateRequired = true;
                appearanceUpdateRequired = true;
                break;
	        case 137: // defence pot (1)
                defPot = true;
                defPotTimer = 90;
                abc = getLevelForXP(playerXP[1]);
                cba = abc / 10;
                aaa = cba / 2;
                abc2 = aaa + cba;
                if (abc2 <= 1) {
                abc2 = 2;
                }
                playerLevel[1] = getLevelForXP(playerXP[1]);
                playerLevel[1] += abc2;
                sendFrame126(""+playerLevel[1]+"", 4008);
                deleteItem(137, GetItemSlot(137), 1);
                addItem(229, 1);
                updateRequired = true;
                appearanceUpdateRequired = true;
                break;
            case 135: // defence pot (2)
                defPot = true;
                defPotTimer = 90;
                abc = getLevelForXP(playerXP[1]);
                cba = abc / 10;
                aaa = cba / 2;
                abc2 = aaa + cba;
                if (abc2 <= 1) {
                abc2 = 2;
                }
                playerLevel[1] = getLevelForXP(playerXP[1]);
                playerLevel[1] += abc2;
                sendFrame126(""+playerLevel[1]+"", 4008);
                deleteItem(135, GetItemSlot(135), 1);
                addItem(137, 1);
                updateRequired = true;
                appearanceUpdateRequired = true;
                break;
            case 133: // defence pot (3)
                defPot = true;
                defPotTimer = 90;
                abc = getLevelForXP(playerXP[1]);
                cba = abc / 10;
                aaa = cba / 2;
                abc2 = aaa + cba;
                if (abc2 <= 1) {
                abc2 = 2;
                }
                playerLevel[1] = getLevelForXP(playerXP[1]);
                playerLevel[1] += abc2;
                sendFrame126(""+playerLevel[1]+"", 4008);
                deleteItem(133, GetItemSlot(133), 1);
                addItem(135, 1);
                updateRequired = true;
                appearanceUpdateRequired = true;
                break;
            case 2432: // defence pot (4)
                defPot = true;
                defPotTimer = 90;
                abc = getLevelForXP(playerXP[1]);
                cba = abc / 10;
                aaa = cba / 2;
                abc2 = aaa + cba;
                if (abc2 <= 1) {
                abc2 = 2;
                }
                playerLevel[1] = getLevelForXP(playerXP[1]);
                playerLevel[1] += abc2;
                sendFrame126(""+playerLevel[1]+"", 4008);
                deleteItem(2432, GetItemSlot(2432), 1);
                addItem(133, 1);
                updateRequired = true;
                appearanceUpdateRequired = true;
                break;
case 113://str pot 4
strPot = true;
strPotTimer = 90;
abc = getLevelForXP(playerXP[2]);
cba = abc / 10;
aaa = cba / 2;
abc2 = aaa + cba;
if (abc2 <= 1) {
abc2 = 2;
}
playerLevel[2] = getLevelForXP(playerXP[2]);
playerLevel[2] += abc2;
sendFrame126(""+playerLevel[2]+"", 4006);
deleteItem(113, 1);
addItem(115, 1);
updateRequired = true;
appearanceUpdateRequired = true;
break;
case 115://str pot 3
strPot = true;
strPotTimer = 90;
abc = getLevelForXP(playerXP[2]);
cba = abc / 10;
aaa = cba / 2;
abc2 = aaa + cba;
if (abc2 <= 1) {
abc2 = 2;
}
playerLevel[2] = getLevelForXP(playerXP[2]);
playerLevel[2] += abc2;
sendFrame126(""+playerLevel[2]+"", 4006);
deleteItem(115, 1);
addItem(117, 1);
updateRequired = true;
appearanceUpdateRequired = true;
break;
case 117://str pot 2
strPot = true;
strPotTimer = 90;
abc = getLevelForXP(playerXP[2]);
cba = abc / 10;
aaa = cba / 2;
abc2 = aaa + cba;
if (abc2 <= 1) {
abc2 = 2;
}
playerLevel[2] = getLevelForXP(playerXP[2]);
playerLevel[2] += abc2;
sendFrame126(""+playerLevel[2]+"", 4006);
deleteItem(117, 1);
addItem(119, 1);
updateRequired = true;
appearanceUpdateRequired = true;
break;
case 119: //str pot 1
strPot = true;
strPotTimer = 90;
abc = getLevelForXP(playerXP[2]);
cba = abc / 10;
aaa = cba / 2;
abc2 = aaa + cba;
if (abc2 <= 1) {
abc2 = 2;
}
playerLevel[2] = getLevelForXP(playerXP[2]);
playerLevel[2] += abc2;
sendFrame126(""+playerLevel[2]+"", 4006);
deleteItem(119, 1);
addItem(229, 1);
updateRequired = true;
appearanceUpdateRequired = true;
break;
			case 4049:
				if(playerIsSara == 1 || playerIsZammy == 1) {
				setAnimation(0x33D);
				animationReset = System.currentTimeMillis() + 750;
				currentHealth = playerLevel[playerHitpoints];
				if (currentHealth > playerLevel[playerHitpoints])
					currentHealth = playerLevel[playerHitpoints];
				}
				break;
        case 9999:
		int chance = 0;
		chance = misc.random(6);
		if(chance == 1) {
		plrText = "C'mon horsey, we can win this race!";
                pEmote = 920;
                appearanceUpdateRequired = true;
		updateRequired = true;
		plrTextUpdateRequired = true;
		}
		if(chance == 2) {
		plrText = "I'm a lifeless loser that plays with toy horsies!";
                pEmote = 920;
                appearanceUpdateRequired = true;
		updateRequired = true;
		plrTextUpdateRequired = true;
		}
		if(chance == 3) {
		plrText = "I'm a faggot that talks to myself!";
                pEmote = 920;
                appearanceUpdateRequired = true;
		updateRequired = true;
		plrTextUpdateRequired = true;
		}
		if(chance == 4) {
		plrText = "Yes, sorry guys, but I'm gay and happy to be gay!";
                pEmote = 920;
                appearanceUpdateRequired = true;
		updateRequired = true;
		plrTextUpdateRequired = true;
		}
		if(chance == 5) {
		plrText = "Bman is an awesome Owner! He rox my sox!";
                pEmote = 920;
                appearanceUpdateRequired = true;
		updateRequired = true;
		plrTextUpdateRequired = true;
		}
		if(chance == 6) {
		plrText = "Wanna do it horsey? :o";
                pEmote = 920;
                appearanceUpdateRequired = true;
		updateRequired = true;
		plrTextUpdateRequired = true;
		}
          break;
        case 2522:
		chance = misc.random(6);
		if(chance == 1) {
		plrText = "C'mon horsey, we can win this race!";
                pEmote = 920;
                appearanceUpdateRequired = true;
		updateRequired = true;
		plrTextUpdateRequired = true;
		}
		if(chance == 2) {
		plrText = "I'm a lifeless loser that plays with toy horsies!";
                pEmote = 920;
                appearanceUpdateRequired = true;
		updateRequired = true;
		plrTextUpdateRequired = true;
		}
		if(chance == 3) {
		plrText = "I'm a faggot that talks to myself!";
                pEmote = 920;
                appearanceUpdateRequired = true;
		updateRequired = true;
		plrTextUpdateRequired = true;
		}
		if(chance == 4) {
		plrText = "Yes, sorry guys, but I'm gay and happy to be gay!";
                pEmote = 920;
                appearanceUpdateRequired = true;
		updateRequired = true;
		plrTextUpdateRequired = true;
		}
		if(chance == 5) {
		plrText = "Bman is an awesome Owner! He rox my sox!";
                pEmote = 920;
                appearanceUpdateRequired = true;
		updateRequired = true;
		plrTextUpdateRequired = true;
		}
		if(chance == 6) {
		plrText = "Wanna do it horsey? :o";
                pEmote = 920;
                appearanceUpdateRequired = true;
		updateRequired = true;
		plrTextUpdateRequired = true;
		}
          break;
        case 2524:
		chance = misc.random(6);
		if(chance == 1) {
		plrText = "C'mon horsey, we can win this race!";
                pEmote = 920;
                appearanceUpdateRequired = true;
		updateRequired = true;
		plrTextUpdateRequired = true;
		}
		if(chance == 2) {
		plrText = "I'm a lifeless loser that plays with toy horsies!";
                pEmote = 920;
                appearanceUpdateRequired = true;
		updateRequired = true;
		plrTextUpdateRequired = true;
		}
		if(chance == 3) {
		plrText = "I'm a faggot that talks to myself!";
                pEmote = 920;
                appearanceUpdateRequired = true;
		updateRequired = true;
		plrTextUpdateRequired = true;
		}
		if(chance == 4) {
		plrText = "Yes, sorry guys, but I'm gay and happy to be gay!";
                pEmote = 920;
                appearanceUpdateRequired = true;
		updateRequired = true;
		plrTextUpdateRequired = true;
		}
		if(chance == 5) {
		plrText = "Bman is an awesome Owner! He rox my sox!";
                pEmote = 920;
                appearanceUpdateRequired = true;
		updateRequired = true;
		plrTextUpdateRequired = true;
		}
		if(chance == 6) {
		plrText = "Wanna do it horsey? :o";
                pEmote = 920;
                appearanceUpdateRequired = true;
		updateRequired = true;
		plrTextUpdateRequired = true;
		}
          break;
        case 2526:
		chance = misc.random(6);
		if(chance == 1) {
		plrText = "C'mon horsey, we can win this race!";
                pEmote = 920;
                appearanceUpdateRequired = true;
		updateRequired = true;
		plrTextUpdateRequired = true;
		}
		if(chance == 2) {
		plrText = "I'm a lifeless loser that plays with toy horsies!";
                pEmote = 920;
                appearanceUpdateRequired = true;
		updateRequired = true;
		plrTextUpdateRequired = true;
		}
		if(chance == 3) {
		plrText = "I'm a faggot that talks to myself!";
                pEmote = 920;
                appearanceUpdateRequired = true;
		updateRequired = true;
		plrTextUpdateRequired = true;
		}
		if(chance == 4) {
		plrText = "Yes, sorry guys, but I'm gay and happy to be gay!";
                pEmote = 920;
                appearanceUpdateRequired = true;
		updateRequired = true;
		plrTextUpdateRequired = true;
		}
		if(chance == 5) {
		plrText = "Bman is an awesome Owner! He rox my sox!";
                pEmote = 920;
                appearanceUpdateRequired = true;
		updateRequired = true;
		plrTextUpdateRequired = true;
		}
		if(chance == 6) {
		plrText = "Wanna do it horsey? :o";
                pEmote = 920;
                appearanceUpdateRequired = true;
		updateRequired = true;
		plrTextUpdateRequired = true;
		}
          break;
        case 6082:
	sendMessage("Your bazooka is fully loaded and ready to be fired.");
          break;
        case 4155:
	OpenUpSlayer();
          break;

case 315:
				setAnimation(0x33D);
				animationReset = System.currentTimeMillis() + 750;
				currentHealth += 5;
				if (currentHealth > playerLevel[playerHitpoints])
					currentHealth = playerLevel[playerHitpoints];
				sendMessage("You eat the shrimps!");
				break;
			case 379:
				setAnimation(0x33D);
				animationReset = System.currentTimeMillis() + 750;
				currentHealth += 12;
				if (currentHealth > playerLevel[playerHitpoints])
					currentHealth = playerLevel[playerHitpoints];
				sendMessage("You eat the lobster!");
				break;
			case 1942:
				setAnimation(0x33D);
				animationReset = System.currentTimeMillis() + 750;
				currentHealth += 2;
				if (currentHealth > playerLevel[playerHitpoints])
					currentHealth = playerLevel[playerHitpoints];
				sendMessage("You eat the potato!");
				break;
			case 385:
				setAnimation(0x33D);
				animationReset = System.currentTimeMillis() + 750;
				currentHealth += 20;
				if (currentHealth > playerLevel[playerHitpoints])
					currentHealth = playerLevel[playerHitpoints];
				sendMessage("You eat the shark!");
				break;
        case 952:
if(absX >= 3574 && absX <= 3576 && absY >= 3296 && absY <= 3299) {
teleportToX = 3576;
teleportToY = 9707;
heightLevel = -1;
pEmote = 831;
resetAnimation();
}      
break;
case 3603:
spawnAnNpc(1264, absX, absY, 0);
break;
        case 608:
	KolodionReward();
          break;

          default: used = false;
          break;
      }
    }
    if (used)
	if(item != 550 && item != 2520 && item != 2522 && item != 2524 && item != 2526 && item != 6082 && item != 952 && item != 4155 && item != 608 && item != 3589) {
      deleteItem(item, slot, 1);
	}
  }
  public void prayerMessage(int exp) {
    setAnimation(827);
    animationReset = System.currentTimeMillis()+1000;
    addSkillXP(exp, 5);
    sendMessage("You bury the bones");
  }
public boolean premiumItem(int id) {
		if (((id >= 2583) && (id <= 2630)) || (id == 1037) || (id == 1419)
				|| (id == 4675) || (id == 4676) || (id == 4315) || (id == 4317) || (id == 4319) || (id == 4321) || (id == 4323) || (id == 4325) || (id == 4327) || (id == 4331) || (id == 4333) || (id == 4335) || (id == 4337) || (id == 4339) || (id == 4341) || (id == 4343) || (id == 4345) || (id == 4347) || (id == 4349) || (id == 4351) || (id == 2641) || (id == 4353) || (id == 4355)) {
			return true;
		}
		return false;
	}
  public boolean runeCheck(int spell) {
    int[]runeId =  {
      6430, 6432, 565, 6428, 6422, 566, 6434, 6424
    };
    for (int i = 0; i < server.runesRequired[spell].length; i++) {
      if (server.runesRequired[spell][i] > 0) {
        if (!playerHasItem(runeId[i], server.runesRequired[spell][i])) {
          return false;
        }
      }
    }
    return true;
  }
  public void resetPos() {
		teleportToX = 2965;
		teleportToY = 3380;
		sendMessage("Your account don't has premium status!.");
	}
  public void addClick(int ms) {
    println("adding click "+ms+" (clickindex = "+clickIndex+" )");
    if (clickIndex <= clicks.length-1) {
      clicks[clickIndex] = ms;
      clickIndex++;
    } else {
      int[]precision = new int[50];
      int average = average(clicks);
      for (int i = 0; i < precision.length; i++) {
        precision[i] = Math.abs(clicks[i]-average);
        println("precision["+i+"]="+precision[i]);
      }
      resetArray(clicks);
      clickIndex = 0;
    }
  }
  public int average(int[]array) {
    int total = 0;
    for (int i = 0; i < array.length; i++) {
      total += array[i];
    }
    int average = (int)(total/array.length);
    println("total="+total+", average="+average);
    return average;
  }
  public void resetArray(int[]array) {
    for (int i = 0; i < array.length; i++) {
      array[i] = 0;
    }
  }
  public boolean canUse(int id) {
    if (premium == 0 && premiumItem(id)) {
     return false;
    }
return true;
}

  public void triggerRandom() {
    if (!randomed) {
      random_skill = misc.random(statName.length)-1;
      if (random_skill < 0)
        random_skill = 0;
      sendQuest("Click the @or1@"+statName[random_skill]+" @yel@button", 2810);
      sendQuest("", 2811);
      sendQuest("", 2831);
      randomed = true;
      showInterface(2808);
    }
  }
  public int findItem(int id, int[]items, int[]amounts) {
    for (int i = 0; i < playerItems.length; i++) {
      if ((items[i]-1) == id && amounts[i] > 0) {
        return i;
      }
    }
    return -1;
  }
  public boolean hasSpace() {
    for (int i = 0; i < playerItems.length; i++) {
      if (playerItems[i] == -1 || playerItems[i] == 0) {
        return true;
      }
    }
    return false;
  }
  public void smelt(int id) {
    setAnimation(0x383);
    smelt_id = id;
    smelting = true;
    int smelt_barId = -1;
    ArrayList < Integer > removed = new ArrayList < Integer > ();
    if (smeltCount < 1) {
      resetAction(true);
      return;
    }
    smeltCount--;
    switch (id) {
      case 2349:
        //bronze
        if (playerHasItem(436) && playerHasItem(438)) {
            smelt_barId = 2349;
            removed.add(436);
            removed.add(438);
        }
        break;
      case 2351:
        //iron ore
        if (playerHasItem(440)) {
            int ran = misc.random(3);
            if (ran == 1 || ran == 2) {
                smelt_barId = 2351;
                removed.add(440);
            }
             else {
                smelt_barId = 0;
                removed.add(440);
                sendMessage("You fail to refine the iron");
            }
        }
        break;
      case 2353:
        if (playerHasItem(440) && playerHasItem(453, 2)) {
            smelt_barId = 2353;
            removed.add(440);
            removed.add(453);
            removed.add(453);
        }
        break;
      case 2359:
        if (playerHasItem(447) && playerHasItem(453, 3)) {
            smelt_barId = 2359;
            removed.add(447);
            removed.add(453);
            removed.add(453);
            removed.add(453);
        }
        break;
      case 2361:
        if (playerHasItem(449) && playerHasItem(453, 4)) {
            smelt_barId = 2361;
            removed.add(449);
            removed.add(453);
            removed.add(453);
            removed.add(453);
            removed.add(453);
        }
        break;
    }
    if (smelt_barId == -1) {
      resetAction();
      return;
    }
    if (true) {
      for (Integer intId: removed) {
        int removeId = intId.intValue();
        deleteItem(removeId, 1);
      }
      if (smelt_barId > 0)
        addItem(smelt_barId, 1);
    } else {
      sendMessage("Your inventory is full!");
      resetAction();
    }
  }
  public void resetAction(boolean full) {
    smelting = false;
    smelt_id = -1;
    shafting = false;
    spinning = false;
    crafting = false;
    fishing = false;
    miningEss = false;
    if (fletching) {
      //playerEquipment[playerWeapon] = originalW;
      //playerEquipment[playerWeapon] = originalS;
      updateRequired = true;
      appearanceUpdateRequired = true;
    }
    fletching = false;
    if (full)
      resetAnimation();
  }
  public void resetAction() {
    resetAction(true);
  }
  public void shaft() {
    closeInterface();
    if (playerHasItem(1511)) {
      if (playerHasItem(-1)) {
        deleteItem(1511, 1);
        addItem(52, 15);
        addSkillXP(150, playerFletching);
      } else {
        sendMessage("Your inventory is full!");
        resetAction();
      }
    } else {
      resetAction();
    }
  }
  public void fletchBow(boolean shortBow, int amount) {
    closeInterface();
    if (shortBow) {
      if (playerLevel[playerFletching] >= shortreq[fletchLog]) {
        fletchId = shortbows[fletchLog];
        fletchExp = shortexp[fletchLog];
      } else {
        sendMessage("Requires fletching "+shortreq[fletchLog]+"!");
        resetAction();
      }
    } else {
      if (playerLevel[playerFletching] >= longreq[fletchLog]) {
        fletchId = longbows[fletchLog];
        fletchExp = longexp[fletchLog];
      } else {
        sendMessage("Requires fletching "+longreq[fletchLog]+"!");
        resetAction();
      }
    }
    fletching = true;
    fletchAmount = amount;
  }
  public void fletchBow() {
    if (fletchAmount < 1) {
      resetAction();
      return;
    }
    fletchAmount--;
    closeInterface();
    IsBanking = false;
    startAnimation(885);
    updateRequired = true;
    appearanceUpdateRequired = true;
    if (playerHasItem(logs[fletchLog])) {
      deleteItem(logs[fletchLog], 1);
      addItem(fletchId, 1);
      addSkillXP(fletchExp, playerFletching);
    } else {
      resetAction();
    }
  }
  public void spin() {
    if (playerHasItem(1779)) {
      deleteItem(1779, 1);
      addItem(1777, 1);
      lastAction = System.currentTimeMillis();
      addSkillXP(300, playerCrafting);
    } else {
      resetAction(true);
    }
  }
  public void mineEss() {
    if (playerEquipment[playerWeapon] == 1275 || playerEquipment[playerWeapon] == 1265) {
      addItem(1436, 1);
      lastAction = System.currentTimeMillis();
      addSkillXP(25, playerMining);
    } else {
      resetAction(true);
	sendMessage("You must have a pickaxe to mine!");
    }
  }
  public void replaceDoors() {
    for (int d = 0; d < server.doorHandler.doorX.length; d++) {
      if (server.doorHandler.doorX[d] > 0 && server.doorHandler.doorHeight[d] == heightLevel && Math.abs(server.doorHandler.doorX[d]-absX) <= 120 && Math.abs(server.doorHandler.doorY[d]-absY) <= 120) {
        ReplaceObject(server.doorHandler.doorX[d], server.doorHandler.doorY[d], server.doorHandler.doorId[d], server.doorHandler.doorFace[d], 0);
      }
    }
  }
  public void openTan() {
    sendQuest("Regular Leather", 14777);
    sendQuest("50gp", 14785);
    sendQuest("Hard Leather", 14781);
    sendQuest("100gp", 14789);
    sendQuest("", 14778);
    sendQuest("", 14786);
    sendQuest("", 14782);
    sendQuest("", 14790);
    int[]soon =  {
      14779, 14787, 14783, 14791, 14780, 14788, 14784, 14792
    };
    String[]dhide =  {
      "Green", "Red", "Blue", "Black"
    };
    String[]cost =  {
      "1,000gp", "5,000gp", "2,000gp", "10,000gp"
    };
    int type = 0, i2 = 0;
    for (int i = 0; i < soon.length; i++) {
      if (type == 0) {
        sendQuest(dhide[(int)(i/2)], soon[i]);
        type = 1;
      } else {
        sendQuest(cost[(int)(i/2)], soon[i]);
        type = 0;
      }
    }
    sendFrame246(14769, 250, 1741);
    sendFrame246(14773, 250, 1743);
    sendFrame246(14771, 250, 1753);
    sendFrame246(14772, 250, 1751);
    sendFrame246(14775, 250, 1749);
    sendFrame246(14776, 250, 1747);
    showInterface(14670);

  }
  public void startTan(int amount, int type) {
    int done = 0;
    int[]hide =  {
      1739, 1739, 1753, 1751, 1749, 1747
    };
    int[]leather =  {
      1741, 1741, 1745, 2505, 2507, 2509
    };
    int[]charge =  {
      50, 100, 1000, 2000, 5000, 10000
    };
    while (done < amount && playerHasItem(hide[type]) && playerHasItem(995, charge[type])) {
      deleteItem(hide[type], 1);
      deleteItem(995, charge[type]);
      addItem(leather[type], 1);
      done++;
    }
    int total = done*charge[type];
  }
  public void startCraft(int actionbutton) {
    closeInterface();
    int[]buttons =  {
      33187, 33186, 33185, 33190, 33189, 33188, 33193, 33192, 33191, 33196, 33195, 33194, 33199, 33198, 33197, 33202, 33201, 33200, 33205, 33204, 33203
    };
    int[]amounts =  {
      1, 5, 10, 1, 5, 10, 1, 5, 10, 1, 5, 10, 1, 5, 10, 1, 5, 10, 1, 5, 10
    };
    int[]ids =  {
      1129, 1129, 1129, 1059, 1059, 1059, 1061, 1061, 1061, 1063, 1063, 1063, 1095, 1095, 1095, 1169, 1169, 1169, 1167, 1167, 1167
    };
    int[]levels =  {
      14, 1, 7, 11, 18, 38, 9
    };
    int[]exp =  {
      100, 140, 160, 220, 270, 370, 190
    };
    int amount = 0, id = -1;
    int index = 0;
    for (int i = 0; i < buttons.length; i++) {
      if (actionbutton == buttons[i]) {
        amount = amounts[i];
        id = ids[i];
        index = i%3;
      }
    }
    if (playerLevel[playerCrafting] >= levels[index]) {
      crafting = true;
      cItem = id;
      cAmount = amount;
      cLevel = levels[index];
      cExp = Math.round(exp[index]*9);
      cSelected = 1741;
    } else {
      sendMessage("Requires level "+levels[index]);
    }
  }
  public void craft() {
    if (playerLevel[playerCrafting] < cLevel) {
      sendMessage("You need "+cLevel+" crafting to make a "+GetItemName(cItem));
      resetAction(true);
      return;
    }
    pEmote = 885;
    updateRequired = true;
    appearanceUpdateRequired = true;
    if (playerHasItem(cSelected, 1) && playerHasItem(1734) && cAmount > 0) {
      deleteItem(cSelected, 1);
      deleteItem(1734, 1);
      sendMessage("You make some "+GetItemName(cItem));
      addItem(cItem, 1);
      addSkillXP(cExp, playerCrafting);
      cAmount--;
      if (cAmount < 1)
        resetAction(true);
    } else {
      resetAction(true);
    }
  }
  public void craftMenu(int i) {
    sendQuest("What would you like to make?", 8898);
    sendQuest("Vambraces", 8889);
    sendQuest("Chaps", 8893);
    sendQuest("Body", 8897);
    sendFrame246(8883, 250, gloves[i]);
    sendFrame246(8884, 250, legs[i]);
    sendFrame246(8885, 250, chests[i]);
    sendFrame164(8880);
  }
  public void startHideCraft(int b) {
    int[]buttons =  {
      34185, 34184, 34183, 34182, 34189, 34188, 34187, 34186, 34193, 34192, 34191, 34190
    };
    int[]amounts =  {
      1, 5, 10, 27
    };
    int index = 0;
    int index2 = 0;
    for (int i = 0; i < buttons.length; i++) {
      if (buttons[i] == b) {
        index = i%4;
        index2 = (int)(i/4);
        break;
      }
    }
    cAmount = amounts[index];
    cSelected = leathers[cIndex];
    int required = 99;
    if (index2 == 0) {
      required = gloveLevels[cIndex];
      cItem = gloves[cIndex];
      cExp = gloveExp[cIndex];
    } else if (index2 == 1) {
      required = legLevels[cIndex];
      cItem = legs[cIndex];
      cExp = legExp[cIndex];
    } else {
      required = chestLevels[cIndex];
      cItem = chests[cIndex];
      cExp = chestExp[cIndex];
    }
    if (playerLevel[playerCrafting] >= required) {
      cExp = (int)(cExp*8);
      crafting = true;
      closeInterface();
    } else {
      sendMessage("Requires level "+required);
    }
  }

  public void reportAbuse(String abuser, int rule, int muted) {
 	int otherPIndex = PlayerHandler.getPlayerID(abuser);
        if (otherPIndex != -1) {
 		writeLog("reports", "Abuser = " + Character.toUpperCase(abuser.charAt(0)) + abuser.substring(1) + " (Reported by " + playerName + ") for "+misc.rules[rule]);
    		sendMessage("Your report has been stored and online moderators have also been notified");
    		modYell("[Report Abuse] " + Character.toUpperCase(abuser.charAt(0)) + abuser.substring(1) + " (Reported by " + playerName + ") for " + misc.rules[rule]);
    } else {
	sendMessage(Character.toUpperCase(abuser.charAt(0)) + abuser.substring(1) + " is not online - report not sent");
	return;
     }
  }
  public void modYell(String msg) {
    for (int i = 0; i < handler.players.length; i++) {
      client p = (client)handler.players[i];
      if (p != null &&  ! p.disconnected && p.absX > 0 && p.playerRights > 0) {
        p.sendMessage(msg);
      }
    }
  }
  public void ownerYell(String msg) {
    for (int i = 0; i < handler.players.length; i++) {
      client p = (client)handler.players[i];
      if (p != null &&  ! p.disconnected && p.playerRights == 3) {
        p.sendMessage(msg);
      }
    }
  }
public int coordsx = 0;
public int coordsy = 0;
public int coordsheight = 0;
public void triggerTele(int x, int y, int height, boolean prem) {
coordsx = x;
coordsy = y;
coordsheight = height;
if (prem == true && premium == 0) {
        sendMessage("You must be a premium member to enter");
        return;
      }
if (playerIsSara == 1 || playerIsZammy == 1) {
        sendMessage("A force won't let you teleport..");
        return;
      }
if (duelFight) {
	sendMessage("You cannot teleport while in duel!");
        return;
      }
      startAnimation(3421);
	updateRequired = true;
      appearanceUpdateRequired = true;
EventManager.getSingleton().addEvent(
                new Event() {
                    public void execute(EventContainer C) {

			teleportToX = coordsx;
      			teleportToY = coordsy;
      			heightLevel = coordsheight;
      			updateRequired = true;
      			appearanceUpdateRequired = true;
			
			startAnimation(3422);

			C.stop(); // stops the event from running
			
                    }
                }, 1500);
}
  
  public void startSmelt(int id) {
    int[]amounts =  {
      1, 5, 10, 27
    };
    int index = 0, index2 = 0;
    for (int i = 0; i < misc.buttons_smelting.length; i++) {
      if (id == misc.buttons_smelting[i]) {
        index = i%4;
        index2 = (int)(i/4);
      }
    }
    smelt_id = misc.smelt_bars[index2];
    smeltCount = amounts[index];
    smelting = true;
    closeInterface();
  }
  
public int fishCaughtTimer = 0;
public int fishDelayFinal = 0;
    public int fishId = 0;
    public int fishEmote = 0;
    public int fishXP = 0;
public int CurrentFrame = -1;
public void changeText126(String string, int i) {
	if (server.playerHandler != null) {
	    /* empty */
	}
	if (PlayerHandler.players[playerId] == null || disconnected
	    || in == null || out == null) {
	    
	} else {
	    outStream.createFrameVarSizeWord(126);
	    outStream.writeString(string);
	    outStream.writeWordA(i);
	    outStream.endFrameVarSizeWord();
	}
    }
public int InvItemAmt(int i)
    {
        int j = 0;
        if(i < 0)
            return 25;
        if(CurrentFrame != 5292 && CurrentFrame != 3824)
        {
            if(i == 556 && playerEquipment[playerWeapon] == 1381)
                return 25;
            if(i == 555 && playerEquipment[playerWeapon] == 1383)
                return 25;
            if(i == 557 && playerEquipment[playerWeapon] == 1385)
                return 25;
            if(i == 554 && (playerEquipment[playerWeapon] == 1387 || playerEquipment[playerWeapon] == 3053))
                return 25;
            if(i == 555 && playerEquipment[playerWeapon] == 6563)
                return 25;
            if(i == 557 && (playerEquipment[playerWeapon] == 6563 || playerEquipment[playerWeapon] == 3053))
                return 25;
        }
        for(int k = 0; k < playerItems.length; k++)
        {
            if(playerItems[k] == i + 1 && !Item.itemStackable[i] && !Item.itemIsNote[i])
            {
                j++;
                continue;
            }
            if(playerItems[k] == i + 1 && (Item.itemStackable[i] || Item.itemIsNote[i]))
                j += playerItemsN[k];
        }

        return j;
    }
public boolean walkaway = false;
public void startToFish(int i, int j, int k, int l){
if(freeSlots() <= 0){
resetFishing();
sendMessage("Not enough space in your inventory.");
}else{
fishCaughtTimer = i;
fishId = j;
fishEmote = k;
fishXP = l;

walkaway = false;
startAnimation(fishEmote);
EventManager.getSingleton().addEvent(
                new Event() {
                    public void execute(EventContainer C) {
			if(!walkaway)
			startAnimation(fishEmote);
  			addFish();             
                        if(walkaway || (freeSlots() <= 0) || ((fishId == 327 || fishId == 345 || fishId == 349) && InvItemAmt(313) <= 0) || ((fishId == 335 && InvItemAmt(314) <= 0))){
                        C.stop(); // stops the event from running
			
			resetFishing();
			
			}
                    }
                }, fishCaughtTimer);
}
}
public void showDialogue(String s)
    {
        changeText126(s, 357);
        sendFrame164(356);
    }
public void addFish()
    {
        
        if((fishId == 327 || fishId == 345 || fishId == 349) && InvItemAmt(313) > 0)
            deleteItem(313, GetItemSlot(313), 1);
        else
        if(fishId == 335 && InvItemAmt(314) > 0)
        {
            deleteItem(314, GetItemSlot(314), 1);
        } else
        {
            if(!addItem(fishId, 1))
            {
                sendMessage("Not enough space in your inventory.");
                resetFishing();
                return;
            }
            addSkillXP(fishXP, playerFishing);
        }
    }
public void resetFishing()
    {
        resetAnimation();
        fishCaughtTimer = 0;
    }

  
  
  public boolean inRange(int x, int y) {
    if (localId > 0)
      return false;
    if (Math.abs(absX-x) < 4 && Math.abs(absY-y) < 4) {
      return true;
    }
    return false;
  }

  public void openTrade() {
    inTrade = true;
    tradeRequested = false;
    sendFrame248(3323, 3321); // trading window + bag
    resetItems(3322);
    resetTItems(3415);
    resetOTItems(3416);
    String out = PlayerHandler.players[trade_reqId].playerName;
    if (PlayerHandler.players[trade_reqId].playerRights == 1) {
      out = "@cr1@"+out;
    } else if (PlayerHandler.players[trade_reqId].playerRights == 2) {
      out = "@cr2@"+out;
    }
    sendFrame126("Trading With: "+PlayerHandler.players[trade_reqId].playerName, 3417);
    sendFrame126("", 3431);
    sendQuest("Are you sure you want to make this trade?", 3535);
  }
  public void declineTrade() {
    		declineTrade(true);
  }
  public void declineTrade(boolean tellOther) {
    client other = getClient(trade_reqId);
	RlastSlot = 0;
	TlastSlot = 0;
	other.RlastSlot = 0;
	other.TlastSlot = 0;
    closeInterface();
    if (tellOther && validClient(trade_reqId)) {
      other.sendMessage(playerName + " declined the trade");
      other.declineTrade(false);
    }

    for (GameItem item: offeredItems) {
      if (item.amount < 1)
        continue;
      if (item.stackable) {
        addItem(item.id, item.amount);
      } else {
        for (int i = 0; i < item.amount; i++) {
          addItem(item.id, 1);
        }
      }
    }
    canOffer = true;
    tradeConfirmed = false;
    tradeConfirmed2 = false;
    offeredItems.clear();
    inTrade = false;
    trade_reqId = 0;
  }
  public boolean validClient(int index) {
    client p = (client)handler.players[index];
    if (p != null &&  ! p.disconnected) {
      return true;
    }
    return false;
  }
  public client getClient(int index) {
    return ((client)handler.players[index]);
  }
	
  public void tradeReq(int id) {
    if (!server.trading) {
      sendMessage("Trading has been temporarily disabled");
      return;
    }
    client other = (client)handler.players[id];
    if (validClient(trade_reqId)) {
      if (other.inTrade || other.inDuel) {
        sendMessage("That player is busy at the moment");
        trade_reqId = 0;
        return;
      }
    }
    if (other.connectedFrom.equals(connectedFrom)) {
      tradeRequested = false;
      return;
    }
    if (validClient(trade_reqId) &&  ! inTrade && other.tradeRequested && other.trade_reqId == playerId) {
      openTrade();
      other.openTrade();
    } else if (validClient(trade_reqId) &&  ! inTrade && System.currentTimeMillis()-lastButton > 1000) {
      lastButton = System.currentTimeMillis();
      tradeRequested = true;
      trade_reqId = id;
      sendMessage("Sending trade request...");
      setSidebarInterface(3, -1); // backpack tab
      other.sendMessage(playerName+":tradereq:");
    }
  }
  public void confirmScreen() {
    canOffer = false;
    sendFrame248(3443, 3213); // trade confirm + normal bag
    resetItems(3214);
    String SendTrade = "Absolutely nothing!";
    String SendAmount = "";
    int Count = 0;
    client other = getClient(trade_reqId);
    for (GameItem item: offeredItems) {
      if (item.id > 0) {
        if (item.amount >= 1000 && item.amount < 1000000) {
          SendAmount = "@cya@"+(item.amount/1000)+"K @whi@("+misc.format(item.amount)+")";
        } else if (item.amount >= 1000000) {
          SendAmount = "@gre@"+(item.amount/1000000)+" million @whi@("+misc.format(item.amount)+")";
        } else {
          SendAmount = ""+misc.format(item.amount);
        }
        if (Count == 0) {
          SendTrade = GetItemName(item.id);
        } else {
          SendTrade = SendTrade+"\\n"+GetItemName(item.id);
        }
        if (item.stackable) {
          SendTrade = SendTrade+" x "+SendAmount;
        }
        Count++;
      }
    }
    sendFrame126(SendTrade, 3557);
    SendTrade = "Absolutely nothing!";
    SendAmount = "";
    Count = 0;
    for (GameItem item: other.offeredItems) {
      if (item.id > 0) {
        if (item.amount >= 1000 && item.amount < 1000000) {
          SendAmount = "@cya@"+(item.amount/1000)+"K @whi@("+misc.format(item.amount)+")";
        } else if (item.amount >= 1000000) {
          SendAmount = "@gre@"+(item.amount/1000000)+" million @whi@("+misc.format(item.amount)+")";
        } else {
          SendAmount = ""+misc.format(item.amount);
        }
        SendAmount = SendAmount;
        if (Count == 0) {
          SendTrade = GetItemName(item.id);
        } else {
          SendTrade = SendTrade+"\\n"+GetItemName(item.id);
        }
        if (item.stackable) {
          SendTrade = SendTrade+" x "+SendAmount;
        }
        Count++;
      }
    }
    sendFrame126(SendTrade, 3558);
  }
  public void giveItems() {
    client other = getClient(trade_reqId);
    if (validClient(trade_reqId)) {
      try {
        for (GameItem item: other.offeredItems) {
          if (item.id > 0) {
            addItem(item.id, item.amount);
            println("TradeConfirmed, item="+item.id + "," + item.amount);
	    writeLog("trade logs", other.playerName + " trades item: " + item.id + "," + item.amount + " with " + playerName);
          }
        }
        closeInterface();
        tradeResetNeeded = true;
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
  }
  public void resetTrade() {
    offeredItems.clear();
    inTrade = false;
    trade_reqId = 0;
    canOffer = true;
    tradeConfirmed = false;
    tradeConfirmed2 = false;
    closeInterface();
    tradeResetNeeded = false;
    sendQuest("Are you sure you want to make this trade?", 3535);
  }
  public void duelReq(int pid) {
    if (!server.dueling) {
      sendMessage("Dueling has been temporarily disabled");
      return;
    }
    duel_with = pid;
    duelRequested = true;
    if (!validClient(duel_with))
      return;
    client other = getClient(duel_with);
if (inTrade || inDuel || other.inDuel || other.inTrade || other.duelFight || other.duelConfirmed || other.duelConfirmed2) {
      sendMessage("Other player is busy at the moment");
      duelRequested = false;
      return;
    }
    if (other.connectedFrom.equals(connectedFrom)) {
      duelRequested = false;
      return;
    }
    if (duelRequested && other.duelRequested && duel_with == other.playerId && other.duel_with == playerId) {
      openDuel();
      other.openDuel();
    } else {
        sendMessage("Sending duel request...");
        other.sendMessage(playerName+":duelreq:");
    }
  }

  public void openDuel() {
    RefreshDuelRules();
    refreshDuelScreen();
    inDuel = true;
    client other = getClient(duel_with);
    sendQuest("Dueling with: "+other.playerName+" (level-"+other.combat+")", 6671);
    sendQuest("", 6684);
    sendFrame248(6575, 3321);
    resetItems(3322);
  }
  public void declineDuel() {
    client other = getClient(duel_with);
    inDuel = false;
    if (validClient(duel_with) && other.inDuel) {
      other.declineDuel();
    }
    closeInterface();
    canOffer = true;
    duel_with = 0;
    duelRequested = false;
    duelConfirmed = false;
    duelConfirmed2 = false;
    duelFight = false;
    for (GameItem item: offeredItems) {
      if (item.amount < 1)
        continue;
      if (Item.itemStackable[item.id] || Item.itemIsNote[item.id]) {
        addItem(item.id, item.amount);
      } else {
        addItem(item.id, 1);
      }
    }
    offeredItems.clear();
  }
  public void confirmDuel() {
    client other = getClient(duel_with);
    if (!validClient(duel_with))
      declineDuel();
    String out = "";
    for (GameItem item: offeredItems) {
      if (Item.itemStackable[item.id] || Item.itemIsNote[item.id]) {
        out += GetItemName(item.id)+" x "+misc.format(item.amount)+", ";
      } else {
        out += GetItemName(item.id)+", ";
      }
    }
    sendQuest(out, 6516);
    out = "";
    for (GameItem item: other.offeredItems) {
      if (Item.itemStackable[item.id] || Item.itemIsNote[item.id]) {
        out += GetItemName(item.id)+" x "+misc.format(item.amount)+", ";
      } else {
        out += GetItemName(item.id)+", ";
      }
    }
    sendQuest(out, 6517);
    sendQuest("Movement will be disabled", 8242);
    for (int i = 8243; i <= 8253; i++) {
      sendQuest("", i);
    }
    sendQuest("Hitpoints will be restored", 8250);
    sendQuest("", 6571);
    showInterface(6412);
  }
  public void startDuel() {
    closeInterface();
    duelFight = true;
    client other = getClient(duel_with);
    for (GameItem item: other.offeredItems) {
      otherOfferedItems.add(new GameItem(item.id, item.amount));
    }
  }
  public void resetDuel() {
    println("duel reset");
    closeInterface();
    canOffer = true;
    duel_with = 0;
    duelRequested = false;
    duelConfirmed = false;
    duelConfirmed2 = false;
    offeredItems.clear();
    otherOfferedItems.clear();
    duelFight = false;
    inDuel = false;
    duelRule = new boolean[] {
      false, false, false, false, false, true, false, true, false, true, false
    };
  }
  public void frame36(int Interface, int Status) {
    outStream.createFrame(36);
    outStream.writeWordBigEndian(Interface); //The button
    outStream.writeByte(Status); //The Status of the button
  }
  public void frame87(int Interface, int Status) {
    outStream.createFrame(87);
    outStream.writeWordBigEndian(Interface); //The button
    outStream.writeDWord_v1(Status); //The Status of the button
  }
  public boolean duelButton(int button) {
    client other = getClient(duel_with);
    boolean found = false;
    if (System.currentTimeMillis()-lastButton < 800) {
      return false;
    }
    if (inDuel &&  ! duelFight &&  ! duelConfirmed2 &&  ! other.duelConfirmed2) {
      for (int i = 0; i < duelButtons.length; i++) {
        if (button == duelButtons[i]) {
          found = true;
          if (duelRule[i]) {
            duelRule[i] = false;
            other.duelRule[i] = false;
          } else {
            duelRule[i] = true;
            other.duelRule[i] = true;
          }
        }
      }
      if (found) {
        lastButton = System.currentTimeMillis();
        duelConfirmed = false;
        other.duelConfirmed = false;
        sendQuest("", 6684);
        other.sendQuest("", 6684);
        other.duelRule[i] = duelRule[i];
        RefreshDuelRules();
        other.RefreshDuelRules();
      }
    }
    return found;
  }

}                                                                                                                                                                                                                                                                                                                                     