public class Config {


//woodcutting
public static final int normal = 50;
public static final int oak = 55;
public static final int willow = 60;
public static final int maple = 70;
public static final int yew = 80;
public static final int magic = 90;

//firemaking

public static final int log = 50;
public static final int oaklog = 60;
public static final int willowlog = 70;
public static final int maplelog = 80;
public static final int yewlog = 90;
public static final int magiclog = 100;

//minning
public static final int clay = 50;
public static final int copper = 60;
public static final int tin = 55;
public static final int blurite = 80;
public static final int iron = 55;
public static final int silver = 60;
public static final int coal = 70;
public static final int gold = 80;
public static final int mithril = 90;
public static final int adamant = 100;
public static final int rune = 130;

//smithing
public static final int bronzebar = 40;
public static final int ironbar = 50;
public static final int silverbar = 55;
public static final int steelbar = 60;
public static final int goldbar = 75;
public static final int mithrilbar = 80;
public static final int adamantbar = 100;
public static final int runebar = 110;


//pvp
public static final int combatXP = 40;
}