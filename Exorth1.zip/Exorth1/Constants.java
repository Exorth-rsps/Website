public interface Constants{
	public final int[] logs = {1511,  1521, 1519, 1517, 1515, 1513};
	public final int[] shortbows = {50, 54, 60, 64, 68, 72, 4214, 4734, 6082};
	public final int[] shortreq = {5, 20, 35, 50, 65, 80};
	public final int[] shortexp = {50, 100, 200, 300, 400, 450};
	public final int[] shortbow = {841, 843, 849, 853, 857, 861, 4214, 4734, 6082};
	public final int[] longbows = {48, 56, 58, 62, 66, 70, 4214, 4734, 6082};
	public final int[] longreq = {10, 25, 40, 55, 70, 85};
	public final int[] longexp = {60, 110, 220, 330, 440, 490};
	public final int[] longbow = {839, 845, 847, 851, 855, 859, 4214, 4734, 6082};
	public final int[] hides = {1753, 1751, 1749, 1747};
	public final int[] leathers = {1745, 2505, 2507, 2509};
	public final int[] gloves = {1065, 2487, 2489, 2491}; 
	public final int[] gloveLevels = {57, 66, 73, 79};
	public final int[] gloveExp = {62, 70, 78, 86};
	public final int[] chests = {1135, 2499, 2501, 2503};
	public final int[] chestLevels = {63, 71, 77, 82};
	public final int[] chestExp = {186, 210, 234, 258};
	public final int[] legs = {1099, 2493, 2495, 2497};
	public final int[] legLevels = {60, 68, 75, 82};
	public final int[] legExp = {124, 140, 156, 172};
	public final int[] NONbowStuff = {15156,863,864,865,866,867,868,869,806,807,808,809,810,811,825,826,827,828,829,830,800,801,802,803,804,805,6522};
	
}