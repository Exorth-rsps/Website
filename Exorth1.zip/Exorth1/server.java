import java.io.*;
import java.util.*;
import java.net.*;
public class server implements Runnable {
public static int uptime;


  public server() {
    // the current way of controlling the server at runtime and a great debugging/testing tool
    //jserv js = new jserv(this);
    //js.start();

  }
public static int Rocks = 0;
    public static int[] RockX = new int[100000];
    public static int[] RockY = new int[100000];
    public static int[] RockSPAWN = new int[100000];
    public static int[] RocksLEFT = new int[100000];
    public static int[] ores = new int[100000];
    public static int[] RockID = new int[100000];
    public static int[] RockEMPTY = new int[100000];
public static int Stalls = 0;
    public static int[] StallX = new int[100000];
    public static int[] StallY = new int[100000];
    public static int[] StallSPAWN = new int[100000];
   public static int serverchest1 = 0;
	public static int serverchest2 = 0;
    public static int[] StallID = new int[100000];
    public static int[] StallEmpty = new int[100000];
  // TODO: yet to figure out proper value for timing, but 500 seems good
  public static boolean trading = true, dueling = true, pking = true, yell = true, tradingchannel = true, staffTrade = false;
  public static int delay = 500;
  public static long delayUpdate = 0, lastRunite = 0;
  public static ArrayList < Integer > bannedUid = new ArrayList < Integer > ();
  public static int world = 1;
  public static boolean enforceClient = false;
  public static boolean loginServerConnected = true;
  public static final int cycleTime = 500;
  public static int[] ranks = new int[11];
  public static String[] rankPpl = new String[11];
public static NpcAnimHandler NpcAnimHandler = new NpcAnimHandler();
  public static boolean updateServer = false;
  public static int updateSeconds = 180; //180 because it doesnt make the time jump at the start :P
  public static long startTime;
  public static GraphicsHandler GraphicsHandler = null;
  public int[]ips = new int[1000];
  public long[]lastConnect = new long[1000];
  public static int[][]runesRequired = new int[24][9];
  public static DoorHandler doorHandler;
  public static ArrayList < String > connections = new ArrayList < String > ();
  public static ArrayList < String > banned = new ArrayList < String > ();
  public static ArrayList < Object > objects = new ArrayList < Object > ();

  public static void main(java.lang.String args[])throws NullPointerException {
    GraphicsHandler = new GraphicsHandler();
    misc.println("Xeonscape.com Coded and owned by Squad.");
    misc.println("-------------------------------------------------------------");
    try {
      File f = new File("server.ini");
      if ( ! f.exists()) {
        misc.println("server.ini doesn't exist!");
      }
	EventManager.initialise();
      Properties p = new Properties();
      p.load(new FileInputStream("./server.ini"));
      int client = Integer.parseInt(p.getProperty("ClientRequired").trim());
      world = Integer.parseInt(p.getProperty("WorldId"));
      serverlistenerPort = Integer.parseInt(p.getProperty("ServerPort").trim());
      if (client > 0) {
        enforceClient = true;
      }
    } catch (Exception e) {
      misc.println("Error loading settings");
      e.printStackTrace();
    }
    clientHandler = new server();
    (new Thread(clientHandler)).start(); // launch server listener
    playerHandler = new PlayerHandler();
    npcHandler = new NPCHandler();

	
    itemHandler = new ItemHandler();
    doorHandler = new DoorHandler();
    if (itemHandler == null) {
      misc.println("ERROR NULL");
    }
    shopHandler = new ShopHandler();
    objectHandler = new ObjectHandler();
    GraphicsHandler = new GraphicsHandler();
    process proc = new process();
uptime++;
    new Thread(proc).start();
  }

  public static server clientHandler = null; // handles all the clients
  public static java.net.ServerSocket clientListener = null;
  public static boolean shutdownServer = false; // set this to true in order to shut down and kill the server
  public static boolean shutdownClientHandler; // signals ClientHandler to shut down
  public static int serverlistenerPort = 5555; //5555=default
  public static PlayerHandler playerHandler = null;
  public static NPCHandler npcHandler = null;
  public static ItemHandler itemHandler = null;
  public static ShopHandler shopHandler = null;
  public static ObjectHandler objectHandler = null;

  public static void calcTime() {
    long curTime = System.currentTimeMillis();
    updateSeconds = 180-((int)(curTime-startTime)/1000);
    if (updateSeconds == 0) {
      shutdownServer = true;
    }
  }

  public void run() {
    // setup the listener
    try {
      shutdownClientHandler = false;
      clientListener = new java.net.ServerSocket(serverlistenerPort, 1, null);
      while (true) {
        try {
          java.net.Socket s = clientListener.accept();
          s.setTcpNoDelay(true);
          String connectingHost = s.getInetAddress().getHostName();
          if ( /*connectingHost.startsWith("localhost") || connectingHost.equals("127.0.0.1")*/true) {
            if (connectingHost.startsWith("izar.lunarpages.com") || connectingHost.startsWith("server2") || connectingHost.startsWith("dodian.com") || connectingHost.startsWith("newgamersworld.com") || connectingHost.startsWith("sputnik") || connectingHost.startsWith("sugardaddy")) {
              misc.println("Checking Server Status...");
              s.close();
            } else {
              connections.add(connectingHost);
              if (checkHost(connectingHost)) {
                misc.println("Connection from "+connectingHost);
                playerHandler.newPlayerClient(s, connectingHost);
              } else {
               // misc.println("ClientHandler: Rejected "+connectingHost+":"+s.getPort());
                s.close();
              }
            }
          } else {
            //misc.println("ClientHandler: Rejected "+connectingHost+":"+s.getPort());
            s.close();
          }
          if (delayUpdate > 0 && System.currentTimeMillis() > delayUpdate) {
            delay = 500;
            delayUpdate = 0;
          }
          Thread.sleep(delay);
        } catch (Exception e) {
          logError(e.getMessage());
        }
      }
    } catch (java.io.IOException ioe) {
      if ( ! shutdownClientHandler) {
        misc.println("Server is already in use.");
      } else {
        misc.println("ClientHandler was shut down.");
      }
    }
  }

  public void killServer() {
    try {
      shutdownClientHandler = true;
      if (clientListener != null)
        clientListener.close();
      clientListener = null;
    } catch (java.lang.Exception __ex) {
      __ex.printStackTrace();
    }
  }
  public static void logError(String message) {
    misc.println(message);
  }
  public int getConnections(String host) {
    int count = 0;
    for (int i = 0; i < playerHandler.players.length; i++) {
      Player p = playerHandler.players[i];
      if (p != null &&  ! p.disconnected && p.connectedFrom.equalsIgnoreCase(host)) {
        count++;
      }
    }
    return count;
  }
  public boolean checkHost(String host) {
    for (String h: banned) {
      if (h.equals(host))
        return false;
    }
    int num = 0;
    for (String h: connections) {
      if (host.equals(h)) {
        num++;
      }
    }/*
    if (num > 3) {
      banHost(host, num);
      return false;
    }*/

    if (checkLog("ipbans", host)) {
      System.out.println(host + " refused - they are ip banned.");
      return false; //ip ban added by bakatool
    }
    return true;
  }/*
  public void banHost(String host, int num) {
    if (false) {
      banned.add(host);
    } else {
      try {
        misc.println("BANNING HOST "+host+" (flooding)");
        banned.add(host);
        delay = 2000;
        delayUpdate = System.currentTimeMillis()+60000;
      } catch (Exception e) {
        e.printStackTrace();
      }
    }

  }*/

  public boolean checkLog(String file, String playerName) {
    //check ipbans -bakatool
    try {
      BufferedReader in = new BufferedReader(new FileReader("config" + File.separator + file + ".txt"));
      String data = null;
      while ((data = in.readLine()) != null) {
        if (playerName.equalsIgnoreCase(data)) {
          return true;
        }
      }
    } catch (IOException e) {
      System.out.println("Critical error while checking for data!");
      System.out.println(file+":"+playerName);
      e.printStackTrace();
    }
    return false;
  }

  public static void openPage(String pageName) {
    try {
      URL page = new URL(pageName);
      URLConnection conn = page.openConnection();
      DataInputStream in = new DataInputStream(conn.getInputStream());
      String source, pageSource = "";
      while ((source = in.readLine()) != null) {
        pageSource += source;
      }
    } catch (Exception e) {
      e.printStackTrace();
      return;
    }
  }

  public static int EnergyRegian = 60;

  public static int MaxConnections = 100000;
  public static String[]Connections = new String[MaxConnections];
  public static int[]ConnectionCount = new int[MaxConnections];
  public static boolean ShutDown = false;
  public static int ShutDownCounter = 0;
}


