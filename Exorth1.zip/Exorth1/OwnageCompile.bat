@echo off
color 9B
set jv=None
if exist "%ProgramFiles%\Java\jdk1.5.0" (set jpath=%ProgramFiles%\Java\jdk1.5.0)
  if exist "%ProgramFiles%\Java\jdk1.5.0" (set jv=1.5.0)

if exist "%ProgramFiles%\Java\jdk1.5.0_01" (set jpath=%ProgramFiles%\Java\jdk1.5.0_01)
  if exist "%ProgramFiles%\Java\jdk1.5.0_01" (set jv=1.5.0_01)

if exist "%ProgramFiles%\Java\jdk1.5.0_02" (set jpath=%ProgramFiles%\Java\jdk1.5.0_02)
  if exist "%ProgramFiles%\Java\jdk1.5.0_02" (set jv=1.5.0_02)

if exist "%ProgramFiles%\Java\jdk1.5.0_03" (set jpath=%ProgramFiles%\Java\jdk1.5.0_03)
  if exist "%ProgramFiles%\Java\jdk1.5.0_03" (set jv=1.5.0_03)

if exist "%ProgramFiles%\Java\jdk1.5.0_04" (set jpath=%ProgramFiles%\Java\jdk1.5.0_04)
  if exist "%ProgramFiles%\Java\jdk1.5.0_04" (set jv=1.5.0_04)

if exist "%ProgramFiles%\Java\jdk1.5.0_05" (set jpath=%ProgramFiles%\Java\jdk1.5.0_05)
  if exist "%ProgramFiles%\Java\jdk1.5.0_05" (set jv=1.5.0_05)

if exist "%ProgramFiles%\Java\jdk1.5.0_06" (set jpath=%ProgramFiles%\Java\jdk1.5.0_06)
  if exist "%ProgramFiles%\Java\jdk1.5.0_06" (set jv=1.5.0_06)

if exist "%ProgramFiles%\Java\jdk1.5.0_07" (set jpath=%ProgramFiles%\Java\jdk1.5.0_07)
  if exist "%ProgramFiles%\Java\jdk1.5.0_07" (set jv=1.5.0_07)

if exist "%ProgramFiles%\Java\jdk1.5.0_08" (set jpath=%ProgramFiles%\Java\jdk1.5.0_08)
  if exist "%ProgramFiles%\Java\jdk1.5.0_08" (set jv=1.5.0_08)

if exist "%ProgramFiles%\Java\jdk1.5.0_09" (set jpath=%ProgramFiles%\Java\jdk1.5.0_09)
  if exist "%ProgramFiles%\Java\jdk1.5.0_09" (set jv=1.5.0_09)

if exist "%ProgramFiles%\Java\jdk1.5.0_10" (set jpath=%ProgramFiles%\Java\jdk1.5.0_10)
  if exist "%ProgramFiles%\Java\jdk1.5.0_10" (set jv=1.5.0_10)

if exist "%ProgramFiles%\Java\jdk1.6.0" (set jpath=%ProgramFiles%\Java\jdk1.6.0)
  if exist "%ProgramFiles%\Java\jdk1.6.0" (set jv=1.6.0)

if exist "%ProgramFiles%\Java\jdk1.6.0_01" (set jpath=%ProgramFiles%\Java\jdk1.6.0_01)
  if exist "%ProgramFiles%\Java\jdk1.6.0_01" (set jv=1.6.0_01)

if exist "%ProgramFiles%\Java\jdk1.6.0_02" (set jpath=%ProgramFiles%\Java\jdk1.6.0_02)
  if exist "%ProgramFiles%\Java\jdk1.6.0_02" (set jv=1.6.0_02)

if exist "%ProgramFiles%\Java\jdk1.6.0_03" (set jpath=%ProgramFiles%\Java\jdk1.6.0_03)
  if exist "%ProgramFiles%\Java\jdk1.6.0_03" (set jv=1.6.0_03)

if exist "%ProgramFiles%\Java\jdk1.6.0_04" (set jpath=%ProgramFiles%\Java\jdk1.6.0_04)
  if exist "%ProgramFiles%\Java\jdk1.6.0_04" (set jv=1.6.0_04)

if exist "%ProgramFiles%\Java\jdk1.6.0_05" (set jpath=%ProgramFiles%\Java\jdk1.6.0_05)
  if exist "%ProgramFiles%\Java\jdk1.6.0_05" (set jv=1.6.0_05)

if exist "%ProgramFiles%\Java\jdk1.6.0_06" (set jpath=%ProgramFiles%\Java\jdk1.6.0_06)
  if exist "%ProgramFiles%\Java\jdk1.6.0_06" (set jv=1.6.0_06)

if exist "%ProgramFiles%\Java\jdk1.6.0_07" (set jpath=%ProgramFiles%\Java\jdk1.6.0_07)
  if exist "%ProgramFiles%\Java\jdk1.6.0_07" (set jv=1.6.0_07)

if exist "%ProgramFiles%\Java\jdk1.6.0_08" (set jpath=%ProgramFiles%\Java\jdk1.6.0_08)
  if exist "%ProgramFiles%\Java\jdk1.6.0_08" (set jv=1.6.0_08)

if exist "%ProgramFiles%\Java\jdk1.6.0_09" (set jpath=%ProgramFiles%\Java\jdk1.6.0_09)
  if exist "%ProgramFiles%\Java\jdk1.6.0_09" (set jv=1.6.0_09)

if exist "%ProgramFiles%\Java\jdk1.6.0_10" (set jpath=%ProgramFiles%\Java\jdk1.6.0_10)
  if exist "%ProgramFiles%\Java\jdk1.6.0_10" (set jv=1.6.0_10)

if exist "%ProgramFiles%\Java\jdk1.7.0" (set jpath=%ProgramFiles%\Java\jdk1.7.0)
  if exist "%ProgramFiles%\Java\jdk1.7.0" (set jv=1.7.0)

if exist "%ProgramFiles%\Java\jdk1.7.0_1" (set jpath=%ProgramFiles%\Java\jdk1.7.0_1)
  if exist "%ProgramFiles%\Java\jdk1.7.0_1" (set jv=1.7.0_1)

if %jv%==None goto notfound
  goto menu

:notfound
  title JDK not found
    color 0A
    cls
    echo JDK version not supported.
    pause
    exit

:menu
  title OwnageCompiler
    cls
    echo.
    echo   ________________________________________________________
    echo [[________________________________________________________]]
    echo [[_______________________OwnageCompiler___________________]]
    echo [[____________________Created by Dragonkiller_____________]]
    echo [[_____________________All Java supported_________________]]
    echo [[________________________________________________________]]
    echo [[______________________Your JDK - %jv%_______________]]
    echo [[________________________________________________________]]
    echo c        -   Compile
    echo d        -   Takes down
    echo r        -   Run
    echo cr       -   Compiles, takes it down, and runs
    echo cr2      -   Compiles and runs
    echo reb      -   Reboot
    echo e        -   Exit
    echo.
    echo.
    set /p c=Access: 
      if %c%==c goto compile
      if %c%==r goto run
      if %c%==d goto odiondown
      if %c%==e goto exit
      if %c%==cr goto restart
      if %c%==cr2 goto restart2
      if %c%==reb goto reboot
      goto menu

:compile
  title Compile
    cls
    "%jpath%\bin\javac.exe" -cp . *.java
    pause
    goto menu

:restart
  title Compile - Down - Run
    cls
    echo Compiling...
    "%jpath%\bin\javac.exe" -cp . *.java
    pause

  title Down
    cls
    echo Taking down...
    tskill java /a

  title Your Game
    cls
    set java="%jpath%\bin\java.exe"
    java -Xmx1024m -cp .;./jython.jar;./MySql/mysql-connector-java-3.0.17-ga-bin.jar server
    exit

:restart2
  title Compile - Run
    cls
    echo Compiling...
    "%jpath%\bin\javac.exe" -cp . *.java
    pause

  title Your Game
    cls
    set java="%jpath%\bin\java.exe"
    java -Xmx1024m -cp .;./jython.jar;./MySql/mysql-connector-java-3.0.17-ga-bin.jar server
    exit

:odiondown
  title Down
    cls
    tskill java /a
    pause
    goto menu

:run
  title Your Game
    cls
    set java="%jpath%\bin\java.exe"
    java -Xmx1024m -cp .;./jython.jar;./MySql/mysql-connector-java-3.0.17-ga-bin.jar server
    exit

:reboot
  title Down - Run
    cls
    echo Taking down...
    tskill java /a

  title Your Game
    cls
    set java="%jpath%\bin\java.exe"
    java -Xmx1024m -cp .;./jython.jar;./MySql/mysql-connector-java-3.0.17-ga-bin.jar server
    exit